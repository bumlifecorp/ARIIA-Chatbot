![Uploading 2776.png…]()
<img width="1024" height="1024" alt="2731" src="https://github.com/user-attachments/assets/7270bf4b-c59b-417e-9b53-1de66960c176" />
<img width="720" height="720" alt="781" src="https://github.com/user-attachments/assets/bf09eeea-cd56-41c8-ba9d-2c2a48952b45" />
<img width="1254" height="1254" alt="3921" src="https://github.com/user-attachments/assets/2f0207a9-8a7e-4182-a86a-397de3a1fd0f" />
<img width="577" height="1209" alt="1439" src="https://github.com/user-attachments/assets/1e2aca67-f681-471d-8a5d-1882cb5cf4c7" />
<img width="2048" height="2048" alt="1397" src="https://github.com/user-attachments/assets/be3b8a1c-9d1f-4eb2-959f-a620086c508a" />
<img width="720" height="1640" alt="1374" src="https://github.com/user-attachments/assets/ea4dbecb-a877-4d0a-a2ce-3cd62fe100c9" />
<img width="1440" height="1441" alt="344" src="https://github.com/user-attachments/assets/58993b89-f93b-4eaa-a1a1-a12b6d434ce7" />
<img width="1024" height="1024" alt="387" src="https://github.com/user-attachments/assets/7b619665-1074-47d4-81d6-55bc53882485" />
<img width="887" height="870" alt="333" src="https://github.com/user-attachments/assets/35ad622c-3900-4d8e-a74c-1556d8201f71" />
<img width="590" height="596" alt="168" src="https://github.com/user-attachments/assets/304890fe-786a-45f9-b79c-f1d11abb8fb4" />
<img width="1442" height="1423" alt="165" src="https://github.com/user-attachments/assets/86fbfd8b-474c-4942-9553-79214fb3252f" />
