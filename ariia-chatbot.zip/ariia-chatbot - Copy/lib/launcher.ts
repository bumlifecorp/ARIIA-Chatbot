export type LauncherApp = { id: string; name: string; category: string };

export function filterLauncherApps(apps: LauncherApp[], query: string) {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return apps;
  return apps.filter((app) => `${app.name} ${app.category}`.toLowerCase().includes(normalized));
}

export function routeOrbitIntent(query: string): "focus" | "notes" | "calendar" | "drawer" {
  const normalized = query.toLowerCase();
  if (normalized.includes("focus") || normalized.includes("concentrate")) return "focus";
  if (normalized.includes("write") || normalized.includes("note")) return "notes";
  if (normalized.includes("plan") || normalized.includes("schedule")) return "calendar";
  return "drawer";
}
