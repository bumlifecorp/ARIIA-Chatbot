# AI Orbit Launcher — Android APK Build Notes

## What is prepared

The project is configured as an Expo Android application named **AI Orbit Launcher** with package identifier `com.app.aiorbitlauncher`. The Android configuration includes the generated original launcher branding, portrait orientation, edge-to-edge rendering, notification permission, and `MAIN` plus `HOME` intent metadata so native builds can appear as a candidate Home application.

The app includes an original launcher surface inspired by the public MuksOS feature direction: first-run onboarding, pinned and hidden app management, app search, Orbit natural-language assistance, focus mode, web-search routing, and local reminders.

## Build profiles

`eas.json` defines two Android APK profiles:

| Profile | Distribution | Artifact |
|---|---|---|
| `preview` | Internal | Installable `.apk` for device testing |
| `production` | Store-ready build profile | `.apk` artifact; signing and store policy work still apply |

From a machine with Expo Application Services access, run:

```bash
npx eas-cli build --platform android --profile preview
```

The first EAS build may request an Expo account, Android application signing credentials, and project association. Those credentials must be supplied through the normal EAS flow; they are not stored in this repository.

## Native Android scope

The Expo project is APK-ready as an application build, but a production-grade replacement for the system launcher still needs device-level validation for the Android Home role, installed-package discovery, package intent launching, default-launcher prompts, notification permissions, and manufacturer-specific behavior. The current preview uses a local catalog of representative app tiles so it remains deterministic in Expo Go and web preview.

The Orbit assistant uses the project’s server-side built-in LLM route. If the device is offline, the UI retains its local quick-action fallbacks. Real voice capture/transcription and privileged Android package operations are deliberately separate follow-up features.
