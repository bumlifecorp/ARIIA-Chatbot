#!/usr/bin/env python3
"""MQTT client skeleton for Smart Connect (replaces legacy socket client)."""

from __future__ import annotations

import json
import os
import time

try:
    import paho.mqtt.client as mqtt
except ImportError:
    mqtt = None  # type: ignore


class SmartConnectMQTT:
    def __init__(self, broker: str | None = None, topic_prefix: str = "eagle/voice"):
        self.broker = (broker or os.getenv("MQTT_BROKER", "localhost:1883")).replace("mqtt://", "")
        self.topic_prefix = topic_prefix
        self.client = None
        if mqtt:
            host, _, port = self.broker.partition(":")
            self.client = mqtt.Client()
            self.client.connect(host, int(port or 1883), 60)
            self.client.loop_start()

    def publish_command(self, action: str, args: dict | None = None) -> None:
        payload = json.dumps({"action": action, "args": args or {}, "ts": int(time.time() * 1000)})
        topic = f"{self.topic_prefix}/commands"
        if self.client:
            self.client.publish(topic, payload)
        else:
            print(f"[mqtt-stub] {topic} {payload}")

    def close(self) -> None:
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
