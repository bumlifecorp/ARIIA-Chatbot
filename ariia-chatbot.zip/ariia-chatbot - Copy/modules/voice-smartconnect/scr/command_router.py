#!/usr/bin/env python3
"""Simple offline command router for Eagle Eye voice interface."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

VOCAB_PATH = Path(__file__).resolve().parent.parent / "commands" / "vocabulary.json"


def load_vocab() -> dict:
    with open(VOCAB_PATH) as f:
        return json.load(f)


def match_command(text: str, vocab: Optional[dict] = None) -> Optional[Tuple[str, Dict[str, Any]]]:
    """Return (action, args) or None. Very lightweight phrase match."""
    vocab = vocab or load_vocab()
    normalized = text.strip().lower()
    for cmd in vocab.get("commands", []):
        phrase = cmd["phrase"].lower()
        if phrase in normalized:
            args = dict(cmd.get("args") or {})
            # crude time extraction
            if args.get("parse_time"):
                m = re.search(r"(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?", normalized)
                if m:
                    args["raw_time"] = m.group(0)
            return cmd["action"], args
    return None


def main() -> None:
    import sys
    vocab = load_vocab()
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        result = match_command(line, vocab)
        if result:
            action, args = result
            print(json.dumps({"action": action, "args": args, "utterance": line}))
        else:
            print(json.dumps({"action": null, "utterance": line}))


if __name__ == "__main__":
    main()
