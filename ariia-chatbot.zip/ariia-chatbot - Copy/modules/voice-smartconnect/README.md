# Voice & Smart Connect Module

Offline-capable voice interface + MQTT smart-connect layer for ARIIA / Eagle Eye.

## Features
- Speech-to-Text command router
- Teachable commands + offline mode
- Speech alarms & purpose-driven reminders
- MQTT client (replaces legacy socket client)
- App / settings control vocabulary

## Layout
```
voice-smartconnect/
  src/command_router.py
  src/mqtt_client.py
  commands/vocabulary.json
```

## Example
```bash
echo "open camera" | python src/command_router.py
# → {"action": "hud.enable_local_camera", ...}
```
