#!/usr/bin/env python3
"""Lightweight event store (ZoneMinder-style alert / clip metadata).

Persists alert events and optional frame references. Does not implement
full NVR recording; use a proper recorder in production.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List

STORE_PATH = Path(os.getenv("EVENT_STORE_PATH", "events.jsonl"))


def append_event(event: Dict[str, Any]) -> None:
    event = dict(event)
    event.setdefault("ts", int(time.time() * 1000))
    STORE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(STORE_PATH, "a") as f:
        f.write(json.dumps(event) + "\n")


def from_node_message(msg: dict) -> None:
    """If the node message contains alerts, persist a compact event."""
    meta = msg.get("meta") or {}
    alerts = meta.get("alerts") or []
    if not alerts:
        return
    append_event(
        {
            "source_id": msg.get("source_id"),
            "ts": msg.get("ts"),
            "alerts": alerts,
            "object_count": len(meta.get("objects") or []),
            "possibility": meta.get("possibility"),
            "frame_ref": None,  # set to object-store URI in production
        }
    )


def tail(n: int = 20) -> List[dict]:
    if not STORE_PATH.exists():
        return []
    lines = STORE_PATH.read_text().strip().splitlines()
    return [json.loads(x) for x in lines[-n:]]


if __name__ == "__main__":
    import sys

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            from_node_message(json.loads(line))
        except json.JSONDecodeError:
            pass
    print(json.dumps(tail(), indent=2))
