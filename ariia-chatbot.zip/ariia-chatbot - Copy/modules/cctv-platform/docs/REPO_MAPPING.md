# Repository mapping (legitimate sources only)

## Explicitly excluded (unauthorized access tools)
- webhack
- CCTV_Hack / HackCCTV / cctv-Hack.py
These will never be integrated.

## Legitimate patterns incorporated

| Source theme                         | Eagle Eye location                          | What was added |
|--------------------------------------|---------------------------------------------|----------------|
| CCTV_YOLO / dnn-object-detection     | `processing/yolo/`                          | Real-time YOLO + conf/iou controls, GPU/CPU |
| Fall-Detection (aspect / pose style) | `processing/fall_detection/`                | Improved heuristic + temporal window      |
| Live-Streaming OpenCV-Flask          | `adapters/websocket/` + `ingest/multi_stream.py` | Multi-camera threaded ingest + MJPEG     |
| Multi-camera RTSP patterns           | `ingest/multi_stream.py`                    | Independent thread per source             |
| ZoneMinder-style alerts / recording  | `storage/event_store.py`                    | Event + clip metadata skeleton            |
| advanced-camera-card / viewer ideas  | `ui/`                                       | Multi-feed grid already present           |
| cctv-camera-database / registry      | `api/camera_registry.py`                    | Authorized-only camera metadata store     |
| Satellite-Segmentation / datasets    | `processing/satellite/`                     | Segmentation stub + dataset notes         |
| gpredict / SatelliteToolbox concepts | `processing/satellite/orbital_notes.md`     | Orbital context notes only                |
| SmartCCTV / Automated surveillance   | pipeline + predictions                      | Alert enrichment via possibility engine   |
| CCTV-Smartphone-AI-Monitoring        | HUD local-camera + vision-analyzer          | Already supported as single local node    |
| OpenCCTV / cctvAgent concepts        | `ingest/` + Live-API                        | Agent-style node publisher                |

All integrations assume you supply credentials and URLs for cameras you own or are explicitly authorized to monitor.
