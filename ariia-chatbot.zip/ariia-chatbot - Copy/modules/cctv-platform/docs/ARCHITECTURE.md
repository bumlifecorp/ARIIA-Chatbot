# Live-Feed Platform Architecture

```
┌────────────────────────────────────────────────────────────────────┐
│                         Orchestration                               │
│              Docker Compose / Kubernetes + autoscaling              │
└────────────────────────────┬───────────────────────────────────────┘
                             │
┌────────────────────────────▼───────────────────────────────────────┐
│  Presentation / Consumers                                           │
│  • Eagle Eye HUD (Dome Matrix)  • React multi-feed grid             │
│  • Node-RED  • ROS  • custom WebSocket / gRPC clients               │
└────────────────────────────┬───────────────────────────────────────┘
                             │  Node Bus (JSON / protobuf)
┌────────────────────────────▼───────────────────────────────────────┐
│  Adapters                                                           │
│  WebSocket/HTTP  │  MQTT  │  Kafka  │  gRPC  │  Node-RED nodes      │
└────────────────────────────┬───────────────────────────────────────┘
                             │
┌────────────────────────────▼───────────────────────────────────────┐
│  Processing Pipeline (GPU preferred, CPU fallback)                  │
│  YOLO / DNN  →  SORT/DeepSORT  →  Fall Detection  →  Satellite seg  │
│  + Predictions Engine (possibility Π/N)                             │
└────────────────────────────┬───────────────────────────────────────┘
                             │
┌────────────────────────────▼───────────────────────────────────────┐
│  Ingest Layer                                                       │
│  RTSP  │  WebRTC  │  MJPEG  │  Local camera (single HUD node)       │
│  Satellite feeds  │  Phone / edge agents                            │
└────────────────────────────┬───────────────────────────────────────┘
                             │
┌────────────────────────────▼───────────────────────────────────────┐
│  Storage                                                            │
│  InfluxDB (metrics & events)  │  Object store (frames / clips)      │
│  Camera registry (metadata only)                                    │
└────────────────────────────────────────────────────────────────────┘
```

## Component responsibilities

| Component              | Responsibility                                      | Latency target |
|------------------------|-----------------------------------------------------|----------------|
| Ingest                 | Decode streams, produce raw frames                  | < 30 ms        |
| YOLO / DNN             | Object detection (GPU/CPU)                          | < 80 ms        |
| Tracking               | SORT / DeepSORT identity continuity                 | < 20 ms        |
| Fall detection         | Pose / motion heuristic + ML                        | < 40 ms        |
| Satellite pipeline     | Segmentation / change detection                     | batch or < 2 s |
| Node API / Adapters    | Publish standardized messages                       | < 10 ms        |
| Storage                | Time-series + optional frame retention              | async          |
| HUD / UI               | Render authenticated nodes only                     | UI frame rate  |

## Hardware sizing guidance

| Profile        | CPU          | GPU              | RAM    | Concurrent 1080p streams |
|----------------|--------------|------------------|--------|--------------------------|
| Edge (Pi/phone)| 4-core       | none / NPU       | 4–8 GB | 1–2                      |
| Small server   | 8-core       | T4 / RTX 3060    | 16 GB  | 8–12                     |
| Production     | 16+ core     | A10 / L4 / A100  | 64 GB+ | 40–100+ (autoscaled)     |

Autoscaling rule (K8s): scale YOLO workers when average detection queue > 50 ms for 2 min.
