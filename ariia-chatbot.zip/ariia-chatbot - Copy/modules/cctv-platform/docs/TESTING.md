# Testing Plan

## Unit tests
- `processing/yolo/test_detect.py` – stub + real model (if GPU available)
- `processing/tracking/test_sort.py` – IoU assignment, age-out
- `processing/fall_detection/test_heuristic.py`
- Schema validation against NODE_SCHEMA

## Integration tests
- Ingest → YOLO → Tracker → Fall → MQTT round-trip
- WebSocket client receives authenticated messages only
- Local camera path (device 0) produces `stream.protocol == "local"`

## Sample datasets
- COCO subset or public fall-detection clips (authorized use only)
- Synthetic RTSP via ffmpeg: `ffmpeg -re -f lavfi -i testsrc -f rtsp rtsp://localhost:8554/cam`

## Load targets
| Metric                    | Target                          |
|---------------------------|---------------------------------|
| Detection latency (GPU)   | < 80 ms median                  |
| End-to-end node publish   | < 200 ms                        |
| Concurrent 1080p streams  | ≥ 8 on small-server profile     |
| WebSocket clients         | ≥ 50 concurrent                 |

## CI
- CPU-only path must pass without GPU
- Lint + type-check on all Python packages
- Container image builds on every main commit
