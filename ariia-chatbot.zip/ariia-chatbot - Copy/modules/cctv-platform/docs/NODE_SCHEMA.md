# Standard Node Input Schema

Language-agnostic JSON message used by all adapters and consumers.

## Core message

```json
{
  "source_id": "cam01",
  "node_type": "camera|satellite|phone|bci|telemetry",
  "ts": 1727366400123,
  "authenticated": true,
  "stream": {
    "protocol": "rtsp|webrtc|mjpeg|local",
    "url": "rtsp://user:pass@host/stream" 
  },
  "frame": {
    "encoding": "jpeg|h264|webp|raw",
    "data": "<base64 or binary reference / URI>",
    "width": 1920,
    "height": 1080,
    "fps": 30
  },
  "meta": {
    "objects": [
      {
        "id": 1,
        "class": "person",
        "bbox": [120, 80, 64, 180],
        "conf": 0.92,
        "track_id": 42
      }
    ],
    "alerts": ["fall", "loitering"],
    "tracks": [
      {"track_id": 42, "history": [[120,80],[125,82]], "age": 17}
    ],
    "satellite_segmentation": {
      "mask_uri": "s3://.../mask.png",
      "classes": ["building", "road", "vegetation"]
    },
    "location": {"lat": 59.3293, "lon": 18.0686, "alt": 12.5},
    "possibility": {"threat_pi": 0.65, "threat_n": 0.21}
  }
}
```

## Minimal frame-only example (high fps path)

```json
{
  "source_id": "cam01",
  "ts": 1727366400123,
  "frame": {
    "encoding": "jpeg",
    "data": "/9j/4AAQSkZJRgABAQ...",
    "width": 640,
    "height": 480
  }
}
```

## Rules

1. `authenticated` must be `true` before the HUD Dome Matrix accepts the node.
2. Timestamps are Unix milliseconds (UTC).
3. `frame.data` may be base64 or a short-lived URI (recommended for high resolution).
4. Possibility fields are optional and attached by the Predictions Engine.
5. Local camera nodes use `"stream.protocol": "local"` and are limited to one HUD node by design.
