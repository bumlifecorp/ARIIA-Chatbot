# Security & Privacy Checklist

## Authentication & Authorization
- [ ] All external nodes require a valid token or mTLS certificate before `authenticated: true`
- [ ] Local camera node is explicitly opted-in and limited to a single HUD slot
- [ ] API keys / Influx tokens stored only in environment variables or secrets manager (never in source)
- [ ] Role-based access: viewer / operator / admin

## Transport
- [ ] TLS 1.2+ everywhere (HTTPS, WSS, MQTTS, gRPC with TLS)
- [ ] Certificate pinning optional for high-security deployments
- [ ] Kafka / MQTT topics protected by ACLs

## Data protection
- [ ] PII redaction pipeline (faces, license plates) before long-term storage
- [ ] Configurable retention policies (default: metrics 30 d, raw frames 7 d or disabled)
- [ ] Frame data preferably passed by short-lived URI rather than base64 in bus messages
- [ ] Encryption at rest for object store and Influx

## Logging & Audit
- [ ] Structured logging of node connect/disconnect, auth failures, alert firings
- [ ] No raw credentials or full frame payloads in logs
- [ ] Audit trail of configuration changes

## Operational
- [ ] Rate limiting on public HTTP/WebSocket endpoints
- [ ] Container images run as non-root
- [ ] Regular dependency scanning (Trivy / Dependabot)
- [ ] Network policies limiting egress from processing pods

## Explicit non-goals
- No tools for unauthorized camera discovery
- No credential stuffing or “hack” modules
- No storage of third-party credentials without user consent
