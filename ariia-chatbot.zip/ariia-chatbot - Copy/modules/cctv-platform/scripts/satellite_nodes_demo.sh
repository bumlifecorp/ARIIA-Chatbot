#!/usr/bin/env bash
# Publish all registered satellite datasets as nodes → segment → core enrichment
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EAGLE="$(cd "$ROOT/../.." && pwd)"
export PYTHONPATH="$EAGLE/modules:$ROOT:${PYTHONPATH:-}"

echo "[sat] publishing dataset nodes (once) → segment → enriched output"
python3 "$ROOT/processing/satellite/datasets/publish_nodes.py" --once | \
  python3 -m processing.satellite.segment 2>/dev/null | \
  head -n 3

echo "[sat] done – each line is a full External Node with GPS + MiniFinder tracking"
