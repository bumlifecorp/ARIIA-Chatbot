#!/usr/bin/env bash
# Full path: synthetic → YOLO → track → fall → possibility → core enrichment (GPS/MiniFinder)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EAGLE="$(cd "$ROOT/../.." && pwd)"
PRED="$EAGLE/modules/predictions"
export PYTHONPATH="$EAGLE/modules:$ROOT:$PRED/src:${PYTHONPATH:-}"

echo "[pipeline] frame → yolo → sort → fall → possibility → core GPS/MiniFinder"
python3 - <<'PY' | \
  python3 -m processing.yolo.detect --device cpu --conf 0.3 2>/dev/null | \
  python3 -m processing.tracking.sort_tracker 2>/dev/null | \
  python3 -m processing.fall_detection.detect_fall 2>/dev/null | \
  python3 "$PRED/src/cli.py" 2>/dev/null | \
  python3 -m core.enrichment
import base64, json, time, numpy as np, cv2
img = np.zeros((480, 640, 3), dtype=np.uint8)
cv2.rectangle(img, (200, 120), (320, 400), (200, 200, 200), -1)
cv2.putText(img, "EAGLE", (210, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,255), 2)
ok, buf = cv2.imencode(".jpg", img)
msg = {
  "source_id": "demo-cam",
  "ts": int(time.time()*1000),
  "authenticated": True,
  "frame": {"encoding": "jpeg", "data": base64.b64encode(buf).decode(), "width": 640, "height": 480},
  "meta": {"objects": [], "alerts": [], "location": {"lat": 59.3293, "lon": 18.0686, "alt": 12.0, "accuracy_m": 15}}
}
print(json.dumps(msg))
PY
echo "[pipeline] done"
