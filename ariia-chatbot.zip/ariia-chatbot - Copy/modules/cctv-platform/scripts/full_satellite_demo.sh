#!/usr/bin/env bash
# 1) Train stub model
# 2) Publish dataset nodes OR STAC synthetic node
# 3) Run through segment (loads model) + core enrichment
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EAGLE="$(cd "$ROOT/../.." && pwd)"
export PYTHONPATH="$EAGLE/modules:$ROOT:${PYTHONPATH:-}"

echo "=== [1/3] Train segmentation stub ==="
python3 "$ROOT/processing/satellite/models/train_stub.py" --epochs 2

echo "=== [2/3] STAC node (synthetic fallback if offline) ==="
python3 "$ROOT/processing/satellite/stac/fetch_asset.py" --synthetic-only --source-id sat-stac-live 2>/dev/null | \
  python3 -m processing.satellite.segment 2>/dev/null | head -c 600
echo ""
echo "..."

echo "=== [3/3] Dataset registry nodes → segment ==="
python3 "$ROOT/processing/satellite/datasets/publish_nodes.py" --once 2>/dev/null | \
  python3 -m processing.satellite.segment 2>/dev/null | head -n 2 | head -c 500
echo ""
echo "=== full satellite demo done ==="
