# Eagle Eye Defense – Live-Feed Platform (CCTV Module)

Modular, containerized live-feed platform that unifies functionality from authorized CCTV, YOLO, ZoneMinder-style, Fall-Detection, satellite, and streaming repositories into a single node-based system.

Every camera / satellite / phone feed is exposed as a **standardized External Node** consumable by Node-RED, ROS, WebSocket/HTTP, MQTT/Kafka, gRPC, and the Eagle Eye HUD (Dome Matrix).

## Quick start

```bash
cp .env.example .env          # edit Influx URL + tokens
docker compose -f deploy/docker/docker-compose.yml up -d
# optional GPU profile
docker compose -f deploy/docker/docker-compose.gpu.yml up -d
```

## Repository → Module mapping

| Source theme                        | Implemented as                       |
|-------------------------------------|--------------------------------------|
| RTSP / OpenCV / Flask streaming     | `ingest/` + `adapters/websocket`     |
| YOLO / DNN object detection         | `processing/yolo/`                   |
| Fall detection                      | `processing/fall_detection/`         |
| SORT / DeepSORT tracking            | `processing/tracking/`               |
| Satellite + SatelliteToolbox.jl     | `processing/satellite/`              |
| ZoneMinder-style recording/alerts   | `storage/` + `api/`                  |
| Camera database / discovery         | `api/camera_registry.py`             |
| Multi-grid UI / advanced card       | `ui/` (React skeleton)               |
| gpredict / orbital                  | `processing/satellite/`              |
| Android / smartphone monitoring     | Edge profile + HUD local-camera node |

## Deliverables checklist

1. Architecture diagram + responsibilities → `docs/ARCHITECTURE.md`
2. Node schema + examples → `docs/NODE_SCHEMA.md` (also root)
3. Adapter skeletons (Node-RED, WS/HTTP, MQTT, Kafka, gRPC) → `adapters/`
4. Processing modules (YOLO, fall, satellite, tracking) + CLI → `processing/`
5. Docker + K8s manifests + sizing → `deploy/`
6. Security & privacy checklist → `docs/SECURITY.md`
7. Testing plan → `docs/TESTING.md`
8. Integration examples (Node-RED flow, ROS msg, React UI) → `ui/`, `adapters/nodered/`, `docs/`

## Security note

This platform is designed **only for feeds you are authorized to access**.  
No components for unauthorized camera discovery, credential stuffing, or “hacking” tools are included.

## Repository policy
See `docs/REPO_MAPPING.md`. Hacking-oriented repositories (webhack, CCTV_Hack, HackCCTV, cctv-Hack.py) are **excluded**.
Only authorized feeds and legitimate CV/streaming patterns are supported.
