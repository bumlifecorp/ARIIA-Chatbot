#!/usr/bin/env python3
"""Authorized camera registry (metadata only).

Stores only cameras the operator has explicitly added with credentials
they are allowed to use. No discovery / scanning of third-party cameras.
"""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path
from typing import Dict, List, Optional

DEFAULT_DB = Path(os.getenv("CAMERA_REGISTRY_PATH", "camera_registry.json"))


def load(path: Path = DEFAULT_DB) -> List[dict]:
    if not path.exists():
        return []
    with open(path) as f:
        return json.load(f)


def save(entries: List[dict], path: Path = DEFAULT_DB) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(entries, f, indent=2)


def add(
    source_id: str,
    url: str,
    label: str = "",
    protocol: str = "rtsp",
    notes: str = "",
    path: Path = DEFAULT_DB,
) -> dict:
    entries = load(path)
    entry = {
        "source_id": source_id,
        "url": url,
        "label": label or source_id,
        "protocol": protocol,
        "notes": notes,
        "added_ts": int(time.time()),
        "authorized": True,
    }
    entries = [e for e in entries if e["source_id"] != source_id]
    entries.append(entry)
    save(entries, path)
    return entry


def list_nodes(path: Path = DEFAULT_DB) -> List[dict]:
    """Emit registry entries as External Node descriptors (no frames)."""
    out = []
    for e in load(path):
        if not e.get("authorized"):
            continue
        out.append(
            {
                "source_id": e["source_id"],
                "node_type": "camera",
                "ts": int(time.time() * 1000),
                "authenticated": True,
                "stream": {"protocol": e.get("protocol", "rtsp"), "url": e["url"]},
                "meta": {"label": e.get("label"), "objects": [], "alerts": []},
            }
        )
    return out


def main() -> None:
    p = argparse.ArgumentParser(description="Authorized camera registry")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add")
    a.add_argument("--id", required=True)
    a.add_argument("--url", required=True)
    a.add_argument("--label", default="")
    a.add_argument("--protocol", default="rtsp")

    sub.add_parser("list")
    sub.add_parser("nodes")

    args = p.parse_args()
    if args.cmd == "add":
        entry = add(args.id, args.url, args.label, args.protocol)
        print(json.dumps(entry, indent=2))
    elif args.cmd == "list":
        print(json.dumps(load(), indent=2))
    elif args.cmd == "nodes":
        for n in list_nodes():
            print(json.dumps(n))


if __name__ == "__main__":
    main()
