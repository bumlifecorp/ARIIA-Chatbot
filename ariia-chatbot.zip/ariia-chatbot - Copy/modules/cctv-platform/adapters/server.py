#!/usr/bin/env python3
"""WebSocket + multipart MJPEG / JSON stream endpoint."""

from __future__ import annotations

import asyncio
import json
import os
from typing import Set

from aiohttp import web, WSMsgType

CLIENTS: Set[web.WebSocketResponse] = set()


async def websocket_handler(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    CLIENTS.add(ws)
    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                # optional client commands
                pass
            elif msg.type == WSMsgType.ERROR:
                break
    finally:
        CLIENTS.discard(ws)
    return ws


async def mjpeg_handler(request: web.Request) -> web.StreamResponse:
    """Classic multipart MJPEG for simple browser <img> tags."""
    resp = web.StreamResponse(
        status=200,
        reason="OK",
        headers={"Content-Type": "multipart/x-mixed-replace; boundary=frame"},
    )
    await resp.prepare(request)
    # In production this would subscribe to the node bus
    # and write --frame\r\nContent-Type: image/jpeg\r\n\r\n + jpeg + \r\n
    await resp.write(b"--frame\r\nContent-Type: text/plain\r\n\r\nMJPEG skeleton\r\n")
    return resp


async def publish(msg: dict) -> None:
    data = json.dumps(msg)
    dead = []
    for ws in CLIENTS:
        try:
            await ws.send_str(data)
        except Exception:
            dead.append(ws)
    for ws in dead:
        CLIENTS.discard(ws)


def create_app() -> web.Application:
    app = web.Application()
    app.router.add_get("/ws", websocket_handler)
    app.router.add_get("/mjpeg", mjpeg_handler)
    app.router.add_get("/health", lambda r: web.json_response({"ok": True}))
    return app


if __name__ == "__main__":
    port = int(os.getenv("WS_PORT", "8080"))
    web.run_app(create_app(), host="0.0.0.0", port=port)
