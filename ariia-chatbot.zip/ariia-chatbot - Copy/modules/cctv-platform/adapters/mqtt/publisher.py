#!/usr/bin/env python3
"""MQTT producer for standardized node messages."""

from __future__ import annotations

import json
import os
import sys

import paho.mqtt.client as mqtt


def main() -> None:
    broker = os.getenv("MQTT_BROKER", "mqtt://localhost:1883").replace("mqtt://", "")
    host, _, port = broker.partition(":")
    port = int(port or 1883)
    topic = os.getenv("MQTT_TOPIC", "eagle/nodes")
    token = os.getenv("NODE_AUTH_TOKEN", "")

    client = mqtt.Client()
    user = os.getenv("MQTT_USERNAME")
    if user:
        client.username_pw_set(user, os.getenv("MQTT_PASSWORD"))
    client.connect(host, port, 60)
    client.loop_start()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        msg = json.loads(line)
        if token and not msg.get("authenticated"):
            continue
        client.publish(topic, line, qos=0)

    client.loop_stop()
    client.disconnect()


if __name__ == "__main__":
    main()
