#!/usr/bin/env python3
"""RTSP / MJPEG / local-camera ingest → standardized node messages."""

from __future__ import annotations

import argparse
import base64
import json
import os
import time
from typing import Generator, Optional

import cv2


def frames_from_source(
    source: str,
    source_id: str,
    max_fps: float = 15.0,
    jpeg_quality: int = 80,
) -> Generator[dict, None, None]:
    """Yield node messages. source can be RTSP URL, device index (int), or file."""
    cap = cv2.VideoCapture(source if not source.isdigit() else int(source))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open source: {source}")

    interval = 1.0 / max_fps
    last = 0.0

    try:
        while True:
            now = time.time()
            if now - last < interval:
                time.sleep(0.001)
                continue
            ok, frame = cap.read()
            if not ok:
                break
            last = now

            h, w = frame.shape[:2]
            ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), jpeg_quality])
            if not ok:
                continue

            msg = {
                "source_id": source_id,
                "node_type": "camera",
                "ts": int(now * 1000),
                "authenticated": True,
                "stream": {
                    "protocol": "local" if str(source).isdigit() else "rtsp",
                    "url": str(source),
                },
                "frame": {
                    "encoding": "jpeg",
                    "data": base64.b64encode(buf).decode("ascii"),
                    "width": w,
                    "height": h,
                    "fps": max_fps,
                },
                "meta": {"objects": [], "alerts": []},
            }
            yield msg
    finally:
        cap.release()


def main() -> None:
    p = argparse.ArgumentParser(description="RTSP / local ingest → JSON lines")
    p.add_argument("--source", required=True, help="RTSP URL or camera index (0)")
    p.add_argument("--source-id", default="cam01")
    p.add_argument("--fps", type=float, default=10.0)
    p.add_argument("--out", default="-", help="output file or - for stdout")
    args = p.parse_args()

    out = open(args.out, "w") if args.out != "-" else None
    try:
        for msg in frames_from_source(args.source, args.source_id, args.fps):
            line = json.dumps(msg) + "\n"
            if out:
                out.write(line)
            else:
                print(line, end="")
    finally:
        if out:
            out.close()


if __name__ == "__main__":
    main()
