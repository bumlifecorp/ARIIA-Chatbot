#!/usr/bin/env python3
"""Multi-camera RTSP / local ingest with one thread per source.

Inspired by legitimate multi-camera OpenCV + Flask patterns.
Each source yields standardized Eagle Eye node messages.
"""

from __future__ import annotations

import argparse
import base64
import json
import threading
import time
from queue import Queue, Empty
from typing import Dict, List, Optional

import cv2


class StreamWorker(threading.Thread):
    def __init__(
        self,
        source_id: str,
        source: str,
        out_q: Queue,
        max_fps: float = 10.0,
        jpeg_quality: int = 75,
        stop_event: Optional[threading.Event] = None,
    ):
        super().__init__(daemon=True)
        self.source_id = source_id
        self.source = source
        self.out_q = out_q
        self.max_fps = max_fps
        self.jpeg_quality = jpeg_quality
        self.stop_event = stop_event or threading.Event()

    def run(self) -> None:
        src = int(self.source) if self.source.isdigit() else self.source
        cap = cv2.VideoCapture(src)
        if not cap.isOpened():
            print(f"[multi] cannot open {self.source_id}: {self.source}", flush=True)
            return
        interval = 1.0 / self.max_fps
        last = 0.0
        try:
            while not self.stop_event.is_set():
                now = time.time()
                if now - last < interval:
                    time.sleep(0.002)
                    continue
                ok, frame = cap.read()
                if not ok:
                    time.sleep(0.5)
                    continue
                last = now
                h, w = frame.shape[:2]
                ok, buf = cv2.imencode(
                    ".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), self.jpeg_quality]
                )
                if not ok:
                    continue
                msg = {
                    "source_id": self.source_id,
                    "node_type": "camera",
                    "ts": int(now * 1000),
                    "authenticated": True,
                    "stream": {
                        "protocol": "local" if str(self.source).isdigit() else "rtsp",
                        "url": str(self.source),
                    },
                    "frame": {
                        "encoding": "jpeg",
                        "data": base64.b64encode(buf).decode("ascii"),
                        "width": w,
                        "height": h,
                        "fps": self.max_fps,
                    },
                    "meta": {"objects": [], "alerts": []},
                }
                try:
                    self.out_q.put(msg, timeout=0.5)
                except Exception:
                    pass
        finally:
            cap.release()


def run_multi(sources: Dict[str, str], max_fps: float = 8.0) -> None:
    q: Queue = Queue(maxsize=32)
    stop = threading.Event()
    workers = [
        StreamWorker(sid, url, q, max_fps=max_fps, stop_event=stop)
        for sid, url in sources.items()
    ]
    for w in workers:
        w.start()
    try:
        while True:
            try:
                msg = q.get(timeout=1.0)
                print(json.dumps(msg), flush=True)
            except Empty:
                if not any(w.is_alive() for w in workers):
                    break
    except KeyboardInterrupt:
        stop.set()


def main() -> None:
    p = argparse.ArgumentParser(description="Multi-source ingest → JSON lines")
    p.add_argument(
        "--source",
        action="append",
        metavar="ID=URL",
        help="e.g. cam01=rtsp://... or local=0 (repeatable)",
    )
    p.add_argument("--fps", type=float, default=8.0)
    args = p.parse_args()
    if not args.source:
        p.error("provide at least one --source ID=URL")
    sources = {}
    for item in args.source:
        if "=" not in item:
            p.error(f"bad --source {item}")
        sid, url = item.split("=", 1)
        sources[sid] = url
    run_multi(sources, max_fps=args.fps)


if __name__ == "__main__":
    main()
