# Satellite / orbital notes

Legitimate references only (no reverse-engineering of proprietary systems).

- **gpredict-style** orbital prediction can be used to schedule when a satellite
  pass is relevant for a given ground footprint.
- **SatelliteToolbox.jl** (Julia) provides orbital mechanics primitives; a thin
  Python bridge can call it for ephemeris if needed.
- **awesome-satellite-imagery-datasets** lists public, licensed datasets suitable
  for training segmentation models (Sentinel, Landsat, etc.).
- Segmentation pipeline remains in `segment.py` (stub). Replace with a U-Net /
  SegFormer trained on authorized public datasets.

Do not incorporate any earth-reverse-engineering or unauthorized imagery scraping.

See also **DATASETS.md** in this folder for a curated list of public annotated and archive datasets.

