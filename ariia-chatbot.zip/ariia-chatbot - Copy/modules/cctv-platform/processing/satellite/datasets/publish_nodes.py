#!/usr/bin/env python3
"""
Publish each registered satellite dataset / imagery source as a single
External Node stream input.

Every node is passed through the core enrichment (GPS + MiniFinder tracking)
before being emitted.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

# core enrichment lives at modules/core
ROOT = Path(__file__).resolve().parents[4]  # eagle-eye-defense
sys.path.insert(0, str(ROOT / "modules"))

from core.enrichment import enrich  # noqa: E402

REG_PATH = Path(__file__).resolve().parent / "registry.json"


def load_registry() -> list:
    with open(REG_PATH) as f:
        return json.load(f)


def dataset_to_node(entry: dict, ts: int | None = None) -> dict:
    ts = ts or int(time.time() * 1000)
    msg = {
        "source_id": entry["source_id"],
        "node_type": entry.get("node_type", "satellite"),
        "ts": ts,
        "authenticated": bool(entry.get("authorized", True)),
        "stream": {
            "protocol": entry.get("protocol", "stac"),
            "url": entry.get("url", ""),
            "dataset": entry.get("dataset"),
            "bands": entry.get("bands", []),
            "resolution_m": entry.get("resolution_m"),
        },
        "meta": {
            "label": entry.get("label", entry["source_id"]),
            "license": entry.get("license"),
            "objects": [],
            "alerts": [],
            "satellite_segmentation": {
                "status": "ready",
                "classes": ["building", "road", "vegetation", "water", "bare"],
            },
        },
    }
    loc = entry.get("location")
    return enrich(msg, force_location=loc)


def main() -> None:
    p = argparse.ArgumentParser(description="Publish satellite dataset nodes")
    p.add_argument("--once", action="store_true", help="emit once and exit")
    p.add_argument("--interval", type=float, default=5.0, help="seconds between cycles")
    p.add_argument("--source-id", help="emit only this source_id")
    args = p.parse_args()

    entries = load_registry()
    if args.source_id:
        entries = [e for e in entries if e["source_id"] == args.source_id]
        if not entries:
            print(f"unknown source_id: {args.source_id}", file=sys.stderr)
            sys.exit(1)

    while True:
        for e in entries:
            if not e.get("authorized", True):
                continue
            node = dataset_to_node(e)
            print(json.dumps(node), flush=True)
        if args.once:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
