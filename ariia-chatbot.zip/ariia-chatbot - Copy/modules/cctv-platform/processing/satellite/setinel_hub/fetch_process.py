#!/usr/bin/env python3
"""
Sentinel Hub Process API → Eagle Eye satellite node.

Requires OAuth client credentials:
  SH_CLIENT_ID, SH_CLIENT_SECRET
Optional:
  SH_BASE_URL (default https://services.sentinel-hub.com)
  SH_TOKEN_URL

Without credentials: synthetic fallback (same node contract).
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / "modules"))

from core.enrichment import enrich  # noqa: E402

try:
    import requests
    HAS_REQ = True
except ImportError:
    HAS_REQ = False

DEFAULT_BASE = "https://services.sentinel-hub.com"
DEFAULT_TOKEN = "https://services.sentinel-hub.com/auth/realms/main/protocol/openid-connect/token"

TRUE_COLOR_EVALSCRIPT = """//VERSION=3
function setup() {
  return { input: ["B04", "B03", "B02"], output: { bands: 3 } };
}
function evaluatePixel(s) {
  return [2.5 * s.B04, 2.5 * s.B03, 2.5 * s.B02];
}
"""

NDVI_EVALSCRIPT = """//VERSION=3
function setup() {
  return { input: ["B04", "B08"], output: { bands: 3 } };
}
function evaluatePixel(s) {
  let ndvi = (s.B08 - s.B04) / (s.B08 + s.B04 + 1e-6);
  return [ndvi, ndvi, ndvi];
}
"""


def synthetic_jpeg() -> bytes:
    return bytes([
        0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
        0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43,
        0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08, 0x07, 0x07, 0x07, 0x09,
        0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
        0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20,
        0x24, 0x2E, 0x27, 0x20, 0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29,
        0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27, 0x39, 0x3D, 0x38, 0x32,
        0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
        0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00,
        0x01, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0xFF, 0xC4, 0x00, 0xB5, 0x10, 0x00, 0x02, 0x01, 0x03,
        0x03, 0x02, 0x04, 0x03, 0x05, 0x05, 0x04, 0x04, 0x00, 0x00, 0x01, 0x7D,
        0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06,
        0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xA1, 0x08,
        0x23, 0x42, 0xB1, 0xC1, 0x15, 0x52, 0xD1, 0xF0, 0x24, 0x33, 0x62, 0x72,
        0x82, 0x09, 0x0A, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x25, 0x26, 0x27, 0x28,
        0x29, 0x2A, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x43, 0x44, 0x45,
        0x46, 0x47, 0x48, 0x49, 0x4A, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59,
        0x5A, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x73, 0x74, 0x75,
        0x76, 0x77, 0x78, 0x79, 0x7A, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
        0x8A, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0xA2, 0xA3,
        0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6,
        0xB7, 0xB8, 0xB9, 0xBA, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9,
        0xCA, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xE1, 0xE2,
        0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xF1, 0xF2, 0xF3, 0xF4,
        0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01,
        0x00, 0x00, 0x3F, 0x00, 0x7F, 0x46, 0xFF, 0xD9,
    ])


def get_token(client_id: str, client_secret: str, token_url: str) -> Optional[str]:
    if not HAS_REQ:
        return None
    try:
        r = requests.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            },
            headers={"content-type": "application/x-www-form-urlencoded"},
            timeout=30,
        )
        r.raise_for_status()
        return r.json().get("access_token")
    except Exception as e:
        print(f"[sh] token failed: {e}", file=sys.stderr)
        return None


def process_image(
    token: str,
    bbox: List[float],
    time_from: str,
    time_to: str,
    width: int = 512,
    height: int = 512,
    max_cloud: int = 20,
    evalscript: str = TRUE_COLOR_EVALSCRIPT,
    base_url: str = DEFAULT_BASE,
) -> Optional[bytes]:
    if not HAS_REQ:
        return None
    url = f"{base_url.rstrip('/')}/process/v1"
    body = {
        "input": {
            "bounds": {
                "bbox": bbox,
                "properties": {"crs": "http://www.opengis.net/def/crs/EPSG/0/4326"},
            },
            "data": [{
                "type": "sentinel-2-l2a",
                "dataFilter": {
                    "timeRange": {"from": time_from, "to": time_to},
                    "maxCloudCoverage": max_cloud,
                },
            }],
        },
        "output": {"width": width, "height": height},
        "evalscript": evalscript,
    }
    try:
        r = requests.post(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "Accept": "image/jpeg",
            },
            json=body,
            timeout=120,
        )
        r.raise_for_status()
        return r.content
    except Exception as e:
        print(f"[sh] process failed: {e}", file=sys.stderr)
        return None


def build_node(
    source_id: str,
    jpeg: bytes,
    lat: float,
    lon: float,
    product: str,
) -> dict:
    ts = int(time.time() * 1000)
    msg = {
        "source_id": source_id,
        "node_type": "satellite",
        "ts": ts,
        "authenticated": True,
        "stream": {
            "protocol": "sentinel-hub",
            "url": "process/v1",
            "dataset": "sentinel-2-l2a",
            "product": product,
        },
        "frame": {
            "encoding": "jpeg",
            "data": base64.b64encode(jpeg).decode("ascii") if jpeg else "",
            "width": 512,
            "height": 512,
        },
        "meta": {
            "label": f"Sentinel Hub {product}",
            "objects": [],
            "alerts": [],
        },
    }
    return enrich(
        msg,
        force_location={"lat": lat, "lon": lon, "alt": 0.0, "accuracy_m": 200.0},
    )


def fetch_node(
    bbox: List[float],
    time_from: str = "2024-06-01T00:00:00Z",
    time_to: str = "2024-06-30T23:59:59Z",
    source_id: str = "sat-sh-s2",
    product: str = "truecolor",
    synthetic_only: bool = False,
) -> dict:
    lat = (bbox[1] + bbox[3]) / 2
    lon = (bbox[0] + bbox[2]) / 2
    jpeg: Optional[bytes] = None

    client_id = os.environ.get("SH_CLIENT_ID")
    client_secret = os.environ.get("SH_CLIENT_SECRET")
    base = os.environ.get("SH_BASE_URL", DEFAULT_BASE)
    token_url = os.environ.get("SH_TOKEN_URL", DEFAULT_TOKEN)
    evalscript = NDVI_EVALSCRIPT if product == "ndvi" else TRUE_COLOR_EVALSCRIPT

    if not synthetic_only and client_id and client_secret:
        token = get_token(client_id, client_secret, token_url)
        if token:
            jpeg = process_image(
                token, bbox, time_from, time_to,
                evalscript=evalscript, base_url=base,
            )
            if jpeg:
                print(f"[sh] process ok product={product} bytes={len(jpeg)}", file=sys.stderr)

    if not jpeg:
        print("[sh] synthetic fallback", file=sys.stderr)
        jpeg = synthetic_jpeg()

    return build_node(source_id, jpeg, lat, lon, product)


def main() -> None:
    p = argparse.ArgumentParser(description="Sentinel Hub Process → Eagle Eye node")
    p.add_argument("--bbox", default="2.2,48.8,2.5,48.95")
    p.add_argument("--from", dest="time_from", default="2024-06-01T00:00:00Z")
    p.add_argument("--to", dest="time_to", default="2024-06-30T23:59:59Z")
    p.add_argument("--source-id", default="sat-sh-s2")
    p.add_argument("--product", choices=["truecolor", "ndvi"], default="truecolor")
    p.add_argument("--synthetic-only", action="store_true")
    args = p.parse_args()
    bbox = [float(x) for x in args.bbox.split(",")]
    node = fetch_node(
        bbox=bbox,
        time_from=args.time_from,
        time_to=args.time_to,
        source_id=args.source_id,
        product=args.product,
        synthetic_only=args.synthetic_only,
    )
    print(json.dumps(node), flush=True)


if __name__ == "__main__":
    main()
