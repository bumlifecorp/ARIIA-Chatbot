#!/usr/bin/env python3
"""
Google Earth Engine → Eagle Eye satellite node.

When earthengine-api is installed and credentials are configured, fetches a
thumbnail JPEG for a bbox/time range and emits a full node with GPS + MiniFinder
enrichment.

Without credentials / ee package: synthetic fallback node (same contract).
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / "modules"))

from core.enrichment import enrich  # noqa: E402

try:
    import requests
    HAS_REQ = True
except ImportError:
    HAS_REQ = False

try:
    import ee
    HAS_EE = True
except ImportError:
    HAS_EE = False


def synthetic_jpeg() -> bytes:
    """Minimal valid 1x1 JPEG."""
    return bytes([
        0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
        0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43,
        0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08, 0x07, 0x07, 0x07, 0x09,
        0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
        0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20,
        0x24, 0x2E, 0x27, 0x20, 0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29,
        0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27, 0x39, 0x3D, 0x38, 0x32,
        0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
        0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00,
        0x01, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0xFF, 0xC4, 0x00, 0xB5, 0x10, 0x00, 0x02, 0x01, 0x03,
        0x03, 0x02, 0x04, 0x03, 0x05, 0x05, 0x04, 0x04, 0x00, 0x00, 0x01, 0x7D,
        0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06,
        0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xA1, 0x08,
        0x23, 0x42, 0xB1, 0xC1, 0x15, 0x52, 0xD1, 0xF0, 0x24, 0x33, 0x62, 0x72,
        0x82, 0x09, 0x0A, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x25, 0x26, 0x27, 0x28,
        0x29, 0x2A, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x43, 0x44, 0x45,
        0x46, 0x47, 0x48, 0x49, 0x4A, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59,
        0x5A, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x73, 0x74, 0x75,
        0x76, 0x77, 0x78, 0x79, 0x7A, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
        0x8A, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0xA2, 0xA3,
        0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6,
        0xB7, 0xB8, 0xB9, 0xBA, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9,
        0xCA, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xE1, 0xE2,
        0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xF1, 0xF2, 0xF3, 0xF4,
        0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01,
        0x00, 0x00, 0x3F, 0x00, 0x7F, 0x46, 0xFF, 0xD9,
    ])


def init_ee() -> bool:
    if not HAS_EE:
        print("[gee] earthengine-api not installed", file=sys.stderr)
        return False
    project = os.environ.get("GEE_PROJECT")
    email = os.environ.get("GEE_SERVICE_ACCOUNT_EMAIL")
    key_file = os.environ.get("GEE_KEY_FILE") or os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    try:
        if email and key_file and Path(key_file).is_file():
            creds = ee.ServiceAccountCredentials(email, key_file=key_file)
            ee.Initialize(creds, project=project) if project else ee.Initialize(creds)
            print("[gee] initialized with service account", file=sys.stderr)
            return True
        if project:
            ee.Initialize(project=project)
            print("[gee] initialized with default credentials + project", file=sys.stderr)
            return True
        ee.Initialize()
        print("[gee] initialized with default credentials", file=sys.stderr)
        return True
    except Exception as e:
        print(f"[gee] init failed: {e}", file=sys.stderr)
        return False


def fetch_s2_thumb(
    bbox: List[float],
    start: str,
    end: str,
    dimensions: int = 512,
    cloud_lt: float = 20.0,
) -> Tuple[Optional[bytes], Dict[str, Any]]:
    """Return (jpeg_bytes, meta) for best Sentinel-2 SR scene in range."""
    west, south, east, north = bbox
    region = ee.Geometry.BBox(west, south, east, north)
    col = (
        ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterBounds(region)
        .filterDate(start, end)
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", cloud_lt))
        .sort("CLOUDY_PIXEL_PERCENTAGE")
    )
    image = col.first()
    info = image.getInfo()
    if not info:
        return None, {}

    props = info.get("properties") or {}
    meta = {
        "gee_id": info.get("id"),
        "cloud_cover": props.get("CLOUDY_PIXEL_PERCENTAGE"),
        "datetime": props.get("system:time_start"),
        "collection": "COPERNICUS/S2_SR_HARMONIZED",
    }
    vis = image.select(["B4", "B3", "B2"]).visualize(min=0, max=3000)
    url = vis.getThumbURL({
        "region": region,
        "dimensions": dimensions,
        "format": "jpg",
    })
    if not HAS_REQ:
        return None, meta
    r = requests.get(url, timeout=120)
    r.raise_for_status()
    return r.content, meta


def build_node(
    source_id: str,
    jpeg: bytes,
    lat: float,
    lon: float,
    meta_extra: Dict[str, Any],
    collection: str,
) -> dict:
    ts = int(time.time() * 1000)
    msg = {
        "source_id": source_id,
        "node_type": "satellite",
        "ts": ts,
        "authenticated": True,
        "stream": {
            "protocol": "gee",
            "url": meta_extra.get("gee_id") or "synthetic",
            "dataset": collection,
            "cloud_cover": meta_extra.get("cloud_cover"),
            "datetime": meta_extra.get("datetime"),
        },
        "frame": {
            "encoding": "jpeg",
            "data": base64.b64encode(jpeg).decode("ascii") if jpeg else "",
            "width": 512,
            "height": 512,
        },
        "meta": {
            "label": f"GEE {str(meta_extra.get('gee_id') or 'synthetic')[:48]}",
            "objects": [],
            "alerts": [],
            "gee_id": meta_extra.get("gee_id"),
        },
    }
    return enrich(
        msg,
        force_location={"lat": lat, "lon": lon, "alt": 0.0, "accuracy_m": 200.0},
    )


def fetch_node(
    bbox: List[float],
    start: str = "2024-06-01",
    end: str = "2024-06-30",
    source_id: str = "sat-gee-s2",
    synthetic_only: bool = False,
    dimensions: int = 512,
    cloud_lt: float = 20.0,
) -> dict:
    lat = (bbox[1] + bbox[3]) / 2
    lon = (bbox[0] + bbox[2]) / 2
    jpeg: Optional[bytes] = None
    meta: Dict[str, Any] = {}
    collection = "COPERNICUS/S2_SR_HARMONIZED"

    if not synthetic_only and init_ee():
        try:
            jpeg, meta = fetch_s2_thumb(bbox, start, end, dimensions, cloud_lt)
            print(f"[gee] thumb ok id={meta.get('gee_id')} cloud={meta.get('cloud_cover')}", file=sys.stderr)
        except Exception as e:
            print(f"[gee] thumb failed: {e}", file=sys.stderr)

    if not jpeg:
        print("[gee] synthetic fallback", file=sys.stderr)
        jpeg = synthetic_jpeg()
        meta = meta or {}

    return build_node(source_id, jpeg, lat, lon, meta, collection)


def main() -> None:
    p = argparse.ArgumentParser(description="GEE thumbnail → Eagle Eye node")
    p.add_argument("--bbox", default="2.2,48.8,2.5,48.95", help="west,south,east,north")
    p.add_argument("--start", default="2024-06-01")
    p.add_argument("--end", default="2024-06-30")
    p.add_argument("--source-id", default="sat-gee-s2")
    p.add_argument("--dimensions", type=int, default=512)
    p.add_argument("--cloud-lt", type=float, default=20.0)
    p.add_argument("--synthetic-only", action="store_true")
    args = p.parse_args()

    bbox = [float(x) for x in args.bbox.split(",")]
    print(f"[gee] ee_pkg={'yes' if HAS_EE else 'no'}", file=sys.stderr)
    node = fetch_node(
        bbox=bbox,
        start=args.start,
        end=args.end,
        source_id=args.source_id,
        synthetic_only=args.synthetic_only,
        dimensions=args.dimensions,
        cloud_lt=args.cloud_lt,
    )
    print(json.dumps(node), flush=True)


if __name__ == "__main__":
    main()
