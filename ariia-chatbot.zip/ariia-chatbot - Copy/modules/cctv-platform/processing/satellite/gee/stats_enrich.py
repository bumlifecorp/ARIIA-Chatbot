#!/usr/bin/env python3
"""
GEE reduceRegion stats enrichment for Eagle Eye nodes.

Reads JSON node lines from stdin, optionally runs Earth Engine reduceRegion
(NDVI mean, cloud-ish proxies) over the node's location/bbox, and writes
enriched nodes to stdout.

Without ee / credentials: attaches a deterministic placeholder stats block
so the pipeline contract stays stable.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / "modules"))

from core.enrichment import enrich  # noqa: E402

try:
    import ee
    HAS_EE = True
except ImportError:
    HAS_EE = False


def init_ee() -> bool:
    if not HAS_EE:
        return False
    project = os.environ.get("GEE_PROJECT")
    email = os.environ.get("GEE_SERVICE_ACCOUNT_EMAIL")
    key_file = os.environ.get("GEE_KEY_FILE") or os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    try:
        if email and key_file and Path(key_file).is_file():
            creds = ee.ServiceAccountCredentials(email, key_file=key_file)
            if project:
                ee.Initialize(creds, project=project)
            else:
                ee.Initialize(creds)
            return True
        if project:
            ee.Initialize(project=project)
            return True
        ee.Initialize()
        return True
    except Exception as e:
        print(f"[gee-stats] init failed: {e}", file=sys.stderr)
        return False


def placeholder_stats(source_id: str) -> Dict[str, Any]:
    h = abs(hash(source_id)) % 1000
    ndvi = round(0.2 + (h % 50) / 100.0, 3)  # 0.20–0.69
    return {
        "ndvi_mean": ndvi,
        "ndvi_std": 0.08,
        "scale_m": 10,
        "source": "placeholder",
        "computed_ts": int(time.time() * 1000),
    }


def reduce_ndvi(
    lat: float,
    lon: float,
    buffer_m: float = 500.0,
    start: str = "2024-06-01",
    end: str = "2024-06-30",
    cloud_lt: float = 20.0,
) -> Optional[Dict[str, Any]]:
    point = ee.Geometry.Point([lon, lat]).buffer(buffer_m)
    col = (
        ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterBounds(point)
        .filterDate(start, end)
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", cloud_lt))
        .sort("CLOUDY_PIXEL_PERCENTAGE")
    )
    image = col.first()
    ndvi = image.normalizedDifference(["B8", "B4"]).rename("ndvi")
    stats = ndvi.reduceRegion(
        reducer=ee.Reducer.mean().combine(ee.Reducer.stdDev(), sharedInputs=True),
        geometry=point,
        scale=10,
        maxPixels=1e7,
    )
    result = stats.getInfo() or {}
    if not result:
        return None
    return {
        "ndvi_mean": result.get("ndvi_mean"),
        "ndvi_std": result.get("ndvi_stdDev"),
        "scale_m": 10,
        "source": "gee-reduceRegion",
        "gee_id": image.get("system:id").getInfo() if hasattr(image, "get") else None,
        "computed_ts": int(time.time() * 1000),
    }


def enrich_stats(msg: dict, start: str, end: str, buffer_m: float, live: bool) -> dict:
    meta = msg.setdefault("meta", {})
    loc = meta.get("location") or {}
    lat = loc.get("lat")
    lon = loc.get("lon")
    source_id = str(msg.get("source_id") or "unknown")

    stats: Optional[Dict[str, Any]] = None
    if live and lat is not None and lon is not None and init_ee():
        try:
            stats = reduce_ndvi(float(lat), float(lon), buffer_m, start, end)
        except Exception as e:
            print(f"[gee-stats] reduce failed: {e}", file=sys.stderr)

    if stats is None:
        stats = placeholder_stats(source_id)

    meta["gee_stats"] = stats
    # light alert heuristic for predictions / MiniFinder consumers
    ndvi = stats.get("ndvi_mean")
    if isinstance(ndvi, (int, float)):
        if ndvi > 0.55:
            alerts = meta.setdefault("alerts", [])
            if "high_vegetation_ndvi" not in alerts:
                alerts.append("high_vegetation_ndvi")
        elif ndvi < 0.25:
            alerts = meta.setdefault("alerts", [])
            if "low_vegetation_ndvi" not in alerts:
                alerts.append("low_vegetation_ndvi")

    return enrich(msg)  # re-apply core GPS/MiniFinder if needed


def main() -> None:
    p = argparse.ArgumentParser(description="GEE reduceRegion stats on node stream")
    p.add_argument("--start", default="2024-06-01")
    p.add_argument("--end", default="2024-06-30")
    p.add_argument("--buffer-m", type=float, default=500.0)
    p.add_argument("--live", action="store_true", help="call GEE if credentials present")
    args = p.parse_args()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        out = enrich_stats(msg, args.start, args.end, args.buffer_m, args.live)
        print(json.dumps(out), flush=True)


if __name__ == "__main__":
    main()
