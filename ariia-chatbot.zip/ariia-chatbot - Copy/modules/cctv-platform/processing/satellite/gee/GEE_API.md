# Google Earth Engine – Eagle Eye integration notes

GEE is a planetary-scale **compute** platform over Landsat, Sentinel, MODIS, and many derived products.  
Access requires a **Google Cloud project** with Earth Engine enabled and either:

- interactive `ee.Authenticate()` (dev), or  
- **service account** JSON key (server / pipeline).

There is **no anonymous public STAC** equivalent; metadata and pixels both need auth.

---

## Auth

| Mode | How |
|------|-----|
| User (dev) | `ee.Authenticate()` then `ee.Initialize(project='your-project-id')` |
| Service account | `ee.ServiceAccountCredentials(email, key_file=...)` → `ee.Initialize(credentials, project=...)` |
| Env vars (Eagle Eye) | `GEE_PROJECT`, `GEE_SERVICE_ACCOUNT_EMAIL`, `GEE_KEY_FILE` (or `GOOGLE_APPLICATION_CREDENTIALS`) |

Never commit key JSON. Store path only in `.env`.

```python
import ee
credentials = ee.ServiceAccountCredentials(
    email=os.environ["GEE_SERVICE_ACCOUNT_EMAIL"],
    key_file=os.environ["GEE_KEY_FILE"],
)
ee.Initialize(credentials, project=os.environ["GEE_PROJECT"])
```

---

## Useful collections for Eagle Eye

| Collection ID | Content |
|---------------|---------|
| `COPERNICUS/S2_SR_HARMONIZED` | Sentinel-2 surface reflectance |
| `LANDSAT/LC08/C02/T1_L2` | Landsat 8 Collection 2 L2 |
| `LANDSAT/LC09/C02/T1_L2` | Landsat 9 |
| `NASA/HLS/HLSL30` / `HLSS30` | Harmonized Landsat–Sentinel |
| `MODIS/...` | Coarser global products |
| Dynamic World / ESA WorldCover | Land-cover layers |

---

## Thumbnail → node frame (recommended path)

For HUD nodes, prefer a **thumbnail URL** (fast, small JPEG/PNG) over full Export:

```python
image = (
    ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
    .filterBounds(ee.Geometry.BBox(west, south, east, north))
    .filterDate(start, end)
    .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 20))
    .sort("CLOUDY_PIXEL_PERCENTAGE")
    .first()
    .select(["B4", "B3", "B2"])
)
url = image.getThumbURL({
    "region": region,
    "dimensions": 512,
    "format": "jpg",
    "min": 0,
    "max": 3000,
})
# GET url → JPEG bytes → base64 into Eagle Eye frame
```

`ee.data.getThumbId` / `makeThumbUrl` are the lower-level equivalents.

---

## Export (heavy / offline)

```python
task = ee.batch.Export.image.toDrive(
    image=image,
    description="eagle-eye-s2",
    region=region,
    scale=10,
    fileFormat="GeoTIFF",
)
task.start()
```

Better for training chips than live nodes.

---

## Compute without downloading

```python
ndvi = image.normalizedDifference(["B8", "B4"])
stats = ndvi.reduceRegion(
    reducer=ee.Reducer.mean(),
    geometry=region,
    scale=10,
    maxPixels=1e8,
)
# stats.getInfo() → enrich meta for MiniFinder / predictions
```

---

## vs Planetary Computer vs Sentinel Hub

| | GEE | Planetary Computer | Sentinel Hub |
|--|-----|--------------------|--------------|
| Auth | Google Cloud / EE account | Public STAC; SAS for blobs | OAuth client |
| Strength | Server-side reduce, long time series, huge catalog | Open COG download, no account for metadata | Evalscript on-the-fly render |
| Live HUD frame | `getThumbURL` | `rendered_preview` | Process API |
| Cost | Free non-commercial quotas; paid commercial | Free public data | PU metering |

**Eagle Eye strategy:**  
- Default open path: **Planetary Computer** (`stac/fetch_asset.py`)  
- Optional auth path: **GEE** thumbnails + reduceRegion stats  
- Optional auth path: **Sentinel Hub** Process/Statistical when evalscripts matter  

---

## Env checklist

```bash
export GEE_PROJECT=your-gcp-project
export GEE_SERVICE_ACCOUNT_EMAIL=ee-runner@your-project.iam.gserviceaccount.com
export GEE_KEY_FILE=/secure/path/ee-key.json
# optional:
# pip install earthengine-api
```

---

*Investigated for Eagle Eye Defense – credentials never stored in repo.*

## Stats enrichment

`gee/stats_enrich.py` — stdin nodes → `meta.gee_stats` (NDVI mean/std via reduceRegion or placeholder).

