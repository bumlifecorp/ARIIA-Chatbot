# Satellite Imagery Datasets – Eagle Eye Guide

Curated public / openly licensed datasets suitable for training and evaluating the satellite segmentation and change-detection pipelines.  
**Only authorized, openly available sources.** No proprietary scrape or reverse-engineering.

---

## 1. Primary free imagery archives (raw / analysis-ready)

| Source | Sensors | Resolution | Access | Best for |
|--------|---------|------------|--------|----------|
| [Copernicus Data Space](https://dataspace.copernicus.eu/) (ESA) | Sentinel-1 (SAR), Sentinel-2 (optical), Sentinel-3 | 10–20 m (S2) | Free download / API | Operational monitoring, vegetation, urban |
| [USGS EarthExplorer](https://earthexplorer.usgs.gov/) | Landsat 1–9, ASTER, NAIP, Sentinel | 10–30 m | Free | Long-term change (1972–present) |
| [NASA Earthdata](https://earthdata.nasa.gov/) / [Worldview](https://worldview.earthdata.nasa.gov/) | MODIS, VIIRS, ASTER, HLS | 250 m–1 km (browse); HLS 30 m | Free | Global climate, near-real-time browse |
| [Microsoft Planetary Computer](https://planetarycomputer.microsoft.com/) | Sentinel-2 L2A, Landsat, many others | varies | Free STAC API | Cloud-native ML pipelines |
| [Google Earth Engine](https://earthengine.google.com/) | Landsat, Sentinel, MODIS, … | varies | Free (cloud processing) | Time-series, large-scale analysis |
| [OpenAerialMap](https://openaerialmap.org/) | UAV + satellite (open license) | cm–m | Free | High-res open orthophotos |
| [Maxar Open Data](https://www.maxar.com/open-data) | WorldView (disaster events) | ~0.3–0.5 m | Free (selected events) | Disaster response only |

**Harmonized product worth using**  
- **HLS v2.0** (Harmonized Landsat + Sentinel-2) – 30 m, near-global, improved atmospheric/cloud correction. Available on AWS + Earth Engine.

---

## 2. Annotated datasets for deep learning

### Semantic segmentation / land cover
| Dataset | Imagery | Labels | Notes |
|---------|---------|--------|-------|
| **LoveDA** | 0.3 m aerial/satellite | Building, Road, Water, Barren, Forest, Agricultural | Urban + rural, domain shift |
| **landcover.ai** | 0.25–0.5 m aerial (Poland) | Building, Wood, Water, Road | High-res European |
| **BigEarthNet** | Sentinel-2 | Multi-label CORINE land cover | 590k chips, Europe |
| **SEN12MS** | Sentinel-1 + Sentinel-2 + MODIS LC | Land-cover maps | Multi-modal triplets |
| **DynamicEarthNet** | PlanetScope | Change + semantic | High temporal frequency |
| **Esri / Impact Observatory 10 m Land Cover** | Sentinel-2 derived | 9 classes (annual) | Explorer + downloadable |

### Buildings / infrastructure
| Dataset | Notes |
|---------|-------|
| **SpaceNet** (multiple challenges) | WorldView, building footprints, roads – AWS open data |
| **xView / xView2** | 0.3 m, buildings + damage assessment |
| **Microsoft Building Footprints** | Large GeoJSON footprints (US, Canada, parts of Africa) derived from Bing imagery |
| **WHU Building** | Aerial + satellite building extraction |
| **Inria Aerial Image Labeling** | Building footprints, multiple cities |
| **Open Cities AI** | African cities, OSM footprints + aerial |

### Roads
| Dataset | Notes |
|---------|-------|
| **SpaceNet Roads** | Multiple cities, high-res |
| **Global-Scale Road (CVPR 2025)** | ~13 800 km², diverse terrain |
| **DeepGlobe Road Extraction** | Popular benchmark |

### Change detection / disaster
| Dataset | Notes |
|---------|-------|
| **xView2** | Pre/post disaster building damage |
| **SpaceNet Change Detection / Off-Nadir** | Multi-temporal |
| **STTORM-CD-Floods** | Sentinel-2 flood time series |
| **LEVIR-CD / CDD** | Classic change-detection pairs |

### Other useful
| Dataset | Task |
|---------|------|
| **CloudSEN12 / CloudSEN12+** | Cloud detection on Sentinel-2 |
| **SSL4EO-L** | Large Landsat self-supervised pre-training (5 M patches) |
| **PASTIS** | Panoptic agricultural time series (Sentinel-2) |
| **OpenSatMap** | High-res map construction / line detection (Google Maps level 19–20, research use – check license) |

---

## 3. Curated “awesome” lists (keep these bookmarked)

- [chrieke/awesome-satellite-imagery-datasets](https://github.com/chrieke/awesome-satellite-imagery-datasets) (archived but still excellent)
- [satellite-image-deep-learning/datasets](https://github.com/satellite-image-deep-learning/datasets)
- [RS-GISer/Awesome-Satellite-Imagery-Datasets](https://github.com/RS-GISer/Awesome-Satellite-Imagery-Datasets)
- [opengeos/geospatial-data-catalogs](https://github.com/opengeos/geospatial-data-catalogs) – AWS / GEE / Planetary Computer / STAC indexes
- [torchgeo](https://github.com/microsoft/torchgeo) – PyTorch datasets + models for geospatial

---

## 4. Recommended starting points for Eagle Eye

| Goal | Suggested data |
|------|----------------|
| Land-cover / scene segmentation | LoveDA + BigEarthNet + Sentinel-2 L2A via Planetary Computer |
| Building extraction | SpaceNet + WHU + Microsoft footprints |
| Change / anomaly detection | xView2 + LEVIR-CD + HLS time series |
| Cloud masking (preprocess) | CloudSEN12+ |
| Self-supervised backbone | SSL4EO-L (Landsat) or Sen2 equivalents |
| Quick visual exploration | Copernicus Browser, NASA Worldview, EarthExplorer |

---

## 5. Access patterns (code-friendly)

```text
# STAC example (Planetary Computer / Element84)
pystac-client + planetary-computer / stackstac / rioxarray

# Earth Engine
ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
ee.ImageCollection("LANDSAT/LC08/C02/T1_L2")

# Direct download
Copernicus Data Space API, USGS M2M API, NASA CMR
```

---

## 6. License & ethics reminder

- Prefer datasets with clear open licenses (CC-BY, ODbL, public domain, ESA/USGS open data policies).
- Commercial high-res (Maxar, Planet, Airbus) is free only under specific open-data or disaster programs — do not assume blanket redistribution rights.
- Never incorporate unauthorized camera feeds or reverse-engineered proprietary imagery into the platform.

---

*Last curated for Eagle Eye Defense satellite module – public sources only.*
