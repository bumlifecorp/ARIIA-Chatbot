# Sentinel Hub API – investigation notes

Sentinel Hub (Sinergise → **Planet Insights Platform**) is a **processing + catalog** service over Sentinel, Landsat, MODIS, HLS, and commercial data.  
Unlike Planetary Computer (public STAC + SAS-signed blobs), Sentinel Hub is **OAuth-first**: almost every useful call needs a Bearer token.

Docs are migrating toward **docs.planet.com**; legacy docs remain at docs.sentinel-hub.com for now.

---

## Auth (required)

| Step | Detail |
|------|--------|
| Account | Planet / Sentinel Hub dashboard → create **OAuth client** |
| Credentials | `client_id` + `client_secret` (secret shown only once) |
| Token URL | `https://services.sentinel-hub.com/auth/realms/main/protocol/openid-connect/token` |
| Grant | `client_credentials` |
| Header | `Authorization: Bearer <access_token>` |

```bash
curl -X POST \
  'https://services.sentinel-hub.com/auth/realms/main/protocol/openid-connect/token' \
  -H 'content-type: application/x-www-form-urlencoded' \
  -d 'grant_type=client_credentials&client_id=YOUR_ID' \
  --data-urlencode 'client_secret=YOUR_SECRET'
```

Python (`requests-oauthlib`):

```python
from oauthlib.oauth2 import BackendApplicationClient
from requests_oauthlib import OAuth2Session

client = BackendApplicationClient(client_id=CLIENT_ID)
oauth = OAuth2Session(client=client)
token = oauth.fetch_token(
    token_url="https://services.sentinel-hub.com/auth/realms/main/protocol/openid-connect/token",
    client_secret=CLIENT_SECRET,
    include_client_id=True,
)
# oauth session auto-attaches Bearer token
```

**CDSE deployment** (Copernicus Data Space Ecosystem) uses different hosts:

| Setting | CDSE value |
|---------|------------|
| Token URL | `https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token` |
| Base API | `https://sh.dataspace.copernicus.eu` |

---

## Main APIs

| API | Purpose | Typical endpoint |
|-----|---------|------------------|
| **Process** | Render imagery (true color, NDVI, custom evalscript) → PNG/JPEG/TIFF | `POST /process/v1` or legacy `/api/v1/process` |
| **Catalog** | STAC-style search for available scenes | `POST /catalog/v1/search` or `/api/v1/catalog/1.0.0/search` |
| **Statistical** | Stats (mean, histogram, cloud %) without downloading images | `POST /statistics/v1` or `/api/v1/statistics` |
| **Batch / Async** | Large jobs | `/batch/v2`, `/async/v1` |
| **BYOC** | Bring Your Own COG | `/byoc/v1` |
| **OGC** | WMS / WMTS / WCS for GIS tools | classic OGC endpoints |

Path format note (2026): both legacy `/api/v1/...` and new `/process/v1`, `/catalog/v1` work; response links prefer the new form.

Deployments:
- EU: `https://services.sentinel-hub.com`
- US West: `https://services-uswest2.sentinel-hub.com`
- CDSE: `https://sh.dataspace.copernicus.eu`

---

## Catalog search (STAC-like)

```http
POST /catalog/v1/search
Authorization: Bearer <token>
Content-Type: application/json

{
  "collections": ["sentinel-2-l2a"],
  "bbox": [2.2, 48.8, 2.5, 48.95],
  "datetime": "2024-06-01T00:00:00Z/2024-06-30T23:59:59Z",
  "limit": 5
}
```

Returns GeoJSON FeatureCollection of items (similar spirit to Planetary Computer STAC search, but **auth required**).

---

## Process API (render for HUD frames)

Best fit for Eagle Eye node `frame.data`: request a **JPEG/PNG** of a bbox + time range with an evalscript.

```json
{
  "input": {
    "bounds": {
      "bbox": [2.2, 48.8, 2.5, 48.95],
      "properties": { "crs": "http://www.opengis.net/def/crs/EPSG/0/4326" }
    },
    "data": [{
      "type": "sentinel-2-l2a",
      "dataFilter": {
        "timeRange": {
          "from": "2024-06-01T00:00:00Z",
          "to": "2024-06-30T23:59:59Z"
        },
        "maxCloudCoverage": 20
      }
    }]
  },
  "output": { "width": 512, "height": 512 },
  "evalscript": "//VERSION=3\nfunction setup(){return{input:[\"B04\",\"B03\",\"B02\"],output:{bands:3}}}\nfunction evaluatePixel(s){return[2.5*s.B04,2.5*s.B03,2.5*s.B02]}"
}
```

`Accept: image/jpeg` or set output format in the body.  
Response body = image bytes → base64 into Eagle Eye node frame.

Evalscripts are JavaScript that define bands + pixel math (true color, NDVI, false color, custom indices).

---

## Statistical API

Same input shape as Process, but returns **JSON statistics** (mean, std, histograms, cloud fraction) instead of pixels. Useful for MiniFinder / predictions enrichment without shipping full frames.

---

## Billing model (important)

| Concept | Detail |
|---------|--------|
| Unit | **Processing Unit (PU)** – depends on pixels × bands × observations × complexity |
| Free / trial | Short free trial; EO Browser-style free viewing moved toward Copernicus Browser |
| Exploration plan | ~$28/mo, ~30k PU (non-commercial) |
| Higher tiers | Basic / Enterprise with more PUs and rate limits |
| ESA-sponsored | Research accounts may get free quota |

Unused PUs typically **do not** roll over.

---

## Sentinel Hub vs Planetary Computer (for Eagle Eye)

| | **Planetary Computer** | **Sentinel Hub** |
|--|------------------------|------------------|
| Metadata search | Public STAC, no auth | Catalog STAC, **OAuth required** |
| Asset access | SAS-signed Azure blobs | Process API renders on the fly |
| Best for | Download COGs, train models, offline pipelines | On-demand RGB/NDVI JPEGs for HUD |
| Cost | Free public data + optional Azure compute | PU metering after free/trial |
| Custom indices | Post-process yourself | Evalscript in the request |
| Eagle Eye use | `stac/fetch_asset.py` (already) | Optional second source for live HUD tiles |

**Recommendation:** keep Planetary Computer as the default open pipeline. Add Sentinel Hub only when you need:
- custom evalscript products (NDVI, false color) as node frames, or  
- Statistical API summaries without downloading imagery.

---

## Mapping to Eagle Eye

| Eagle Eye piece | Sentinel Hub fit |
|-----------------|------------------|
| Node `frame` | Process API → JPEG/PNG |
| Catalog discovery | Catalog API search → `source_id` / datetime |
| `meta.location` | Request bbox center (core enrichment) |
| Predictions / MiniFinder | Statistical API cloud % / band means |
| Secrets | `SH_CLIENT_ID` / `SH_CLIENT_SECRET` in `.env` only |

Never commit OAuth secrets. Tokens are short-lived; refresh via client credentials.

---

## Minimal Python sketch (after you have credentials)

```python
# token as above with OAuth2Session...
url = "https://services.sentinel-hub.com/process/v1"
headers = {"Authorization": f"Bearer {token['access_token']}", "Content-Type": "application/json"}
body = { ... process request with evalscript ... }
r = oauth.post(url, json=body, headers={"Accept": "image/jpeg"})
jpeg_bytes = r.content  # → base64 into Eagle Eye node
```

---

*Investigated for Eagle Eye Defense satellite module. No credentials stored; OAuth required for all processing calls.*

## Eagle Eye fetcher

`sentinel_hub/fetch_process.py` — Process API truecolor/NDVI → node. Env: `SH_CLIENT_ID`, `SH_CLIENT_SECRET`.

