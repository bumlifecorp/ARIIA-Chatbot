# Microsoft Planetary Computer API – investigation notes

**Open (public) Planetary Computer** – no Azure account required for metadata search.  
Asset bytes live on private Azure Blob containers and need a short-lived **SAS token**.

There is also **Planetary Computer Pro** (Azure GeoCatalog) for private catalogs; that needs Entra ID. Eagle Eye uses the **open** endpoints below.

---

## Base URLs

| Service | URL |
|---------|-----|
| STAC API (metadata) | `https://planetarycomputer.microsoft.com/api/stac/v1` |
| OpenAPI / Swagger | `https://planetarycomputer.microsoft.com/api/stac/v1/docs` |
| SAS sign (single href) | `https://planetarycomputer.microsoft.com/api/sas/v1/sign?href={url}` |
| SAS token (collection) | `https://planetarycomputer.microsoft.com/api/sas/v1/token/{collection_id}` |
| Data / tiler (previews, mosaics) | `https://planetarycomputer.microsoft.com/api/data/v1/...` |

Verified live (2026-09-26): STAC root, `/search`, and `/sas/v1/token/sentinel-2-l2a` all respond.

---

## Auth model

| Resource | Auth |
|----------|------|
| STAC catalog, collections, search, items (JSON metadata) | **None** (public) |
| Blob asset HREFs (COGs, GeoTIFFs, …) | **SAS token** required |
| Higher rate limits / longer SAS | Optional `PC_SDK_SUBSCRIPTION_KEY` / `planetarycomputer configure` |

**SAS options**
1. `GET /api/sas/v1/sign?href=<unsigned_blob_url>` → `{ "href": "<signed>", "msft:expiry": "..." }`
2. `GET /api/sas/v1/token/{collection_id}` → `{ "token": "...", "msft:expiry": "..." }` then append `?{token}` to asset hrefs
3. Python: `pip install planetary-computer pystac-client` then `planetary_computer.sign(item)` or `Client.open(..., modifier=planetary_computer.sign_inplace)`

Tokens are short-lived (hours). Do not store them long-term.

---

## Core STAC operations

### Landing / collections
```http
GET /api/stac/v1/
GET /api/stac/v1/collections
GET /api/stac/v1/collections/{collection_id}
```

Important collections for Eagle Eye:
- `sentinel-2-l2a`
- `landsat-c2-l2`
- `hls2-s30` / HLS products
- `io-lulc-annual-v02` (land cover)

### Search (preferred: POST)
```http
POST /api/stac/v1/search
Content-Type: application/json

{
  "collections": ["sentinel-2-l2a"],
  "bbox": [west, south, east, north],
  "datetime": "2024-06-01/2024-08-31",
  "limit": 10,
  "query": { "eo:cloud_cover": { "lt": 20 } }
}
```

Also supports GET with query params, CQL2 filters, intersects (GeoJSON), sort, pagination token.

Response: GeoJSON `FeatureCollection` of STAC Items. Each feature has `id`, `bbox`, `geometry`, `properties`, `assets`.

### Get one item
```http
GET /api/stac/v1/collections/{collection_id}/items/{item_id}
```

---

## Assets on an item

Typical Sentinel-2 L2A assets include:
- Spectral bands: `B02`, `B03`, `B04`, `B08`, …
- `visual` / `rendered_preview` / `thumbnail` (handy for HUD JPEG frames)
- `SCL` (scene classification), `AOT`, etc.

`rendered_preview` is often served via the **data API** (already renderable PNG/JPEG-style), ideal for node `frame.data`.

---

## Recommended Python stack

```bash
pip install pystac-client planetary-computer
# optional for arrays: stackstac rioxarray rasterio
```

```python
import planetary_computer
from pystac_client import Client

catalog = Client.open(
    "https://planetarycomputer.microsoft.com/api/stac/v1",
    modifier=planetary_computer.sign_inplace,  # auto-sign assets
)

search = catalog.search(
    collections=["sentinel-2-l2a"],
    bbox=[2.2, 48.8, 2.5, 48.95],
    datetime="2024-06-01/2024-06-30",
    query={"eo:cloud_cover": {"lt": 20}},
    max_items=1,
)
item = next(search.items())
# item.assets["B04"].href is already signed
preview = item.assets.get("rendered_preview") or item.assets.get("visual")
```

---

## Relation to Eagle Eye

| Eagle Eye piece | Planetary Computer use |
|-----------------|------------------------|
| `stac/fetch_asset.py` | POST search + SAS sign + preview → node frame |
| `datasets/registry.json` | Collection IDs / STAC URLs |
| `segment.py` | Downstream of signed COG / preview |
| Core enrichment | Attaches GPS from item bbox / centroid |

**Do not** hardcode SAS tokens. Always sign at request time.

---

## Planetary Computer Pro (optional, private)

- Azure resource: GeoCatalog  
- Auth: Microsoft Entra ID (`DefaultAzureCredential`)  
- SDK: `azure-planetarycomputer`  
- Same STAC shapes + extra ingest / mosaic / managed SAS  
- Only needed if you host **private** catalogs; not required for open Sentinel/Landsat.

---

## Quick test commands

```bash
# Root
curl -s https://planetarycomputer.microsoft.com/api/stac/v1/ | head

# Search Paris area, low cloud
curl -s -X POST https://planetarycomputer.microsoft.com/api/stac/v1/search \
  -H 'Content-Type: application/json' \
  -d '{"collections":["sentinel-2-l2a"],"bbox":[2.2,48.8,2.5,48.95],"datetime":"2024-06-01/2024-06-30","limit":1,"query":{"eo:cloud_cover":{"lt":20}}}'

# Collection SAS token
curl -s https://planetarycomputer.microsoft.com/api/sas/v1/token/sentinel-2-l2a
```

---

*Investigated for Eagle Eye Defense satellite module – open PC endpoints only.*
