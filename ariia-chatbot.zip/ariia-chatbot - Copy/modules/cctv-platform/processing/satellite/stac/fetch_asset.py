#!/usr/bin/env python3
"""
Fetch a public Sentinel-2 (or Landsat) asset via Planetary Computer STAC
and emit it as an Eagle Eye node with a JPEG preview frame + full enrichment.

Preferred path (when installed):
  pip install pystac-client planetary-computer
  -> Client.open(..., modifier=planetary_computer.sign_inplace)
  -> prefer asset "rendered_preview" (then visual, thumbnail)

Fallback path:
  raw requests to /api/stac/v1/search + /api/sas/v1/sign
  -> same asset preference order
  -> synthetic JPEG if offline / no preview
"""

from __future__ import annotations

import argparse
import base64
import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / "modules"))

from core.enrichment import enrich  # noqa: E402

try:
    import cv2
    import numpy as np
    HAS_CV = True
except ImportError:
    HAS_CV = False

try:
    import requests
    HAS_REQ = True
except ImportError:
    HAS_REQ = False

try:
    import planetary_computer
    from pystac_client import Client as StacClient
    HAS_PC_SDK = True
except ImportError:
    HAS_PC_SDK = False

PC_STAC = "https://planetarycomputer.microsoft.com/api/stac/v1"
PC_SIGN = "https://planetarycomputer.microsoft.com/api/sas/v1/sign"
PREVIEW_KEYS = ("rendered_preview", "visual", "thumbnail", "preview")


def synthetic_frame(label: str = "S2") -> bytes:
    """Minimal valid JPEG without requiring OpenCV."""
    if HAS_CV:
        img = np.zeros((480, 640, 3), dtype=np.uint8)
        img[:, :] = (28, 55, 38)
        cv2.putText(
            img, f"STAC {label}", (36, 250),
            cv2.FONT_HERSHEY_SIMPLEX, 1.1, (200, 220, 200), 2,
        )
        ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
        if ok:
            return buf.tobytes()
    # 1x1 pixel JPEG fallback (always valid)
    return bytes([
        0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
        0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43,
        0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08, 0x07, 0x07, 0x07, 0x09,
        0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
        0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20,
        0x24, 0x2E, 0x27, 0x20, 0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29,
        0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27, 0x39, 0x3D, 0x38, 0x32,
        0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
        0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00,
        0x01, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0xFF, 0xC4, 0x00, 0xB5, 0x10, 0x00, 0x02, 0x01, 0x03,
        0x03, 0x02, 0x04, 0x03, 0x05, 0x05, 0x04, 0x04, 0x00, 0x00, 0x01, 0x7D,
        0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06,
        0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xA1, 0x08,
        0x23, 0x42, 0xB1, 0xC1, 0x15, 0x52, 0xD1, 0xF0, 0x24, 0x33, 0x62, 0x72,
        0x82, 0x09, 0x0A, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x25, 0x26, 0x27, 0x28,
        0x29, 0x2A, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x43, 0x44, 0x45,
        0x46, 0x47, 0x48, 0x49, 0x4A, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59,
        0x5A, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x73, 0x74, 0x75,
        0x76, 0x77, 0x78, 0x79, 0x7A, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
        0x8A, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0xA2, 0xA3,
        0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6,
        0xB7, 0xB8, 0xB9, 0xBA, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9,
        0xCA, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xE1, 0xE2,
        0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xF1, 0xF2, 0xF3, 0xF4,
        0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01,
        0x00, 0x00, 0x3F, 0x00, 0x7F, 0x46, 0xFF, 0xD9,
    ])


def jpeg_from_bytes(data: bytes, max_side: int = 640) -> bytes:
    if not HAS_CV:
        return data
    arr = np.frombuffer(data, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return data
    h, w = img.shape[:2]
    scale = min(1.0, max_side / max(h, w))
    if scale < 1.0:
        img = cv2.resize(img, (int(w * scale), int(h * scale)))
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
    return buf.tobytes() if ok else data


def search_with_sdk(bbox, datetime, collection="sentinel-2-l2a", cloud_lt=20):
    if not HAS_PC_SDK:
        return None
    try:
        catalog = StacClient.open(PC_STAC, modifier=planetary_computer.sign_inplace)
        search = catalog.search(
            collections=[collection], bbox=bbox, datetime=datetime,
            query={"eo:cloud_cover": {"lt": cloud_lt}}, max_items=1,
        )
        return next(search.items(), None)
    except Exception as e:
        print(f"[stac-sdk] search failed: {e}", file=sys.stderr)
        return None


def preview_from_sdk_item(item):
    meta = {"stac_id": getattr(item, "id", None), "datetime": None, "cloud_cover": None}
    props = getattr(item, "properties", None) or {}
    if isinstance(props, dict):
        meta["datetime"] = props.get("datetime")
        meta["cloud_cover"] = props.get("eo:cloud_cover")
    assets = getattr(item, "assets", {}) or {}
    for key in PREVIEW_KEYS:
        asset = assets.get(key)
        if asset is None:
            continue
        href = getattr(asset, "href", None)
        if not href or not HAS_REQ:
            continue
        try:
            r = requests.get(href, timeout=90)
            r.raise_for_status()
            print(f"[stac-sdk] preview from '{key}' ({len(r.content)} B)", file=sys.stderr)
            return jpeg_from_bytes(r.content), meta
        except Exception as e:
            print(f"[stac-sdk] '{key}' failed: {e}", file=sys.stderr)
    return None, meta


def bbox_center_from_item(item, fallback_bbox):
    try:
        bb = list(item.bbox) if getattr(item, "bbox", None) else fallback_bbox
        if len(bb) >= 4:
            return (bb[1] + bb[3]) / 2, (bb[0] + bb[2]) / 2
    except Exception:
        pass
    return (fallback_bbox[1] + fallback_bbox[3]) / 2, (fallback_bbox[0] + fallback_bbox[2]) / 2


def search_with_requests(bbox, datetime, collection="sentinel-2-l2a", cloud_lt=20):
    if not HAS_REQ:
        return None
    body = {
        "collections": [collection], "bbox": bbox, "datetime": datetime,
        "limit": 1, "query": {"eo:cloud_cover": {"lt": cloud_lt}},
    }
    try:
        r = requests.post(f"{PC_STAC}/search", json=body, timeout=45)
        r.raise_for_status()
        feats = r.json().get("features") or []
        return feats[0] if feats else None
    except Exception as e:
        print(f"[stac-http] search failed: {e}", file=sys.stderr)
        return None


def sign_href(href):
    if not HAS_REQ:
        return None
    try:
        r = requests.get(PC_SIGN, params={"href": href}, timeout=20)
        r.raise_for_status()
        return r.json().get("href")
    except Exception as e:
        print(f"[stac-http] sign failed: {e}", file=sys.stderr)
        return None


def preview_from_http_item(item):
    props = item.get("properties") or {}
    meta = {
        "stac_id": item.get("id"),
        "datetime": props.get("datetime"),
        "cloud_cover": props.get("eo:cloud_cover"),
    }
    assets = item.get("assets") or {}
    for key in PREVIEW_KEYS:
        asset = assets.get(key) or {}
        href = asset.get("href")
        if not href:
            continue
        signed = sign_href(href) or href
        try:
            r = requests.get(signed, timeout=90)
            r.raise_for_status()
            print(f"[stac-http] preview from '{key}' ({len(r.content)} B)", file=sys.stderr)
            return jpeg_from_bytes(r.content), meta
        except Exception as e:
            print(f"[stac-http] '{key}' failed: {e}", file=sys.stderr)
    return None, meta


def build_node(source_id, jpeg, lat, lon, stac_meta, collection):
    ts = int(time.time() * 1000)
    msg = {
        "source_id": source_id,
        "node_type": "satellite",
        "ts": ts,
        "authenticated": True,
        "stream": {
            "protocol": "stac",
            "url": stac_meta.get("stac_id") or "synthetic",
            "dataset": collection,
            "cloud_cover": stac_meta.get("cloud_cover"),
            "datetime": stac_meta.get("datetime"),
        },
        "frame": {
            "encoding": (
                "png" if jpeg[:8] == b"\x89PNG\r\n\x1a\n" else "jpeg"
            ),
            "data": base64.b64encode(jpeg).decode("ascii") if jpeg else "",
            "width": 640,
            "height": 480,
        },
        "meta": {
            "label": f"STAC {str(stac_meta.get('stac_id') or 'synthetic')[:48]}",
            "objects": [],
            "alerts": [],
            "stac_id": stac_meta.get("stac_id"),
        },
    }
    return enrich(msg, force_location={"lat": lat, "lon": lon, "alt": 0.0, "accuracy_m": 200.0})


def fetch_node(bbox, datetime="2024-06-01/2024-08-31", source_id="sat-stac-live",
               collection="sentinel-2-l2a", cloud_lt=20, synthetic_only=False):
    jpeg = None
    stac_meta = {}
    lat = (bbox[1] + bbox[3]) / 2
    lon = (bbox[0] + bbox[2]) / 2

    if not synthetic_only:
        if HAS_PC_SDK:
            item = search_with_sdk(bbox, datetime, collection, cloud_lt)
            if item is not None:
                jpeg, stac_meta = preview_from_sdk_item(item)
                lat, lon = bbox_center_from_item(item, bbox)
                print(f"[stac] SDK item {stac_meta.get('stac_id')}", file=sys.stderr)

        if jpeg is None and HAS_REQ:
            item = search_with_requests(bbox, datetime, collection, cloud_lt)
            if item is not None:
                jpeg, stac_meta = preview_from_http_item(item)
                bb = item.get("bbox") or bbox
                if len(bb) >= 4:
                    lat, lon = (bb[1] + bb[3]) / 2, (bb[0] + bb[2]) / 2
                print(f"[stac] HTTP item {stac_meta.get('stac_id')}", file=sys.stderr)

    if not jpeg:
        print("[stac] using synthetic preview frame", file=sys.stderr)
        jpeg = synthetic_frame(collection.split("-")[0].upper())
        stac_meta = stac_meta or {"stac_id": None}

    return build_node(source_id, jpeg, lat, lon, stac_meta, collection)


def main():
    p = argparse.ArgumentParser(description="Planetary Computer STAC -> Eagle Eye node")
    p.add_argument("--bbox", default="2.2,48.8,2.5,48.95")
    p.add_argument("--datetime", default="2024-06-01/2024-08-31")
    p.add_argument("--source-id", default="sat-stac-live")
    p.add_argument("--collection", default="sentinel-2-l2a")
    p.add_argument("--cloud-lt", type=int, default=20)
    p.add_argument("--synthetic-only", action="store_true")
    args = p.parse_args()
    bbox = [float(x) for x in args.bbox.split(",")]
    print(f"[stac] SDK={'yes' if HAS_PC_SDK else 'no'}  requests={'yes' if HAS_REQ else 'no'}", file=sys.stderr)
    node = fetch_node(
        bbox=bbox, datetime=args.datetime, source_id=args.source_id,
        collection=args.collection, cloud_lt=args.cloud_lt, synthetic_only=args.synthetic_only,
    )
    print(json.dumps(node), flush=True)


if __name__ == "__main__":
    main()
