#!/usr/bin/env python3
"""
Satellite segmentation pipeline.

- Accepts node messages (including STAC / dataset nodes)
- Loads optional stub model from models/seg_stub.json
- Always applies core enrichment (GPS + MiniFinder)
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "modules"))

from core.enrichment import enrich  # noqa: E402

MODEL_PATH = Path(__file__).resolve().parent / "models" / "seg_stub.json"
_MODEL = None


def load_model():
    global _MODEL
    if _MODEL is not None:
        return _MODEL
    if MODEL_PATH.exists():
        with open(MODEL_PATH) as f:
            _MODEL = json.load(f)
    else:
        _MODEL = {
            "model": "builtin-prior",
            "classes": ["building", "road", "vegetation", "water", "bare"],
            "weights": {"building": 0.15, "road": 0.1, "vegetation": 0.45, "water": 0.1, "bare": 0.2},
        }
    return _MODEL


def predict_scores(model: dict) -> dict:
    import random
    w = model.get("weights") or {}
    classes = model.get("classes") or list(w.keys())
    raw = {c: max(0.01, w.get(c, 0.1) + random.uniform(-0.04, 0.04)) for c in classes}
    s = sum(raw.values()) or 1.0
    return {c: round(raw[c] / s, 3) for c in classes}


def segment(msg: dict) -> dict:
    model = load_model()
    scores = predict_scores(model)
    meta = msg.setdefault("meta", {})
    meta["satellite_segmentation"] = {
        "mask_uri": None,
        "classes": list(scores.keys()),
        "scores": scores,
        "model": model.get("model", "unknown"),
        "processed_ms": 6.0,
        "dataset_hint": (msg.get("stream") or {}).get("dataset"),
    }
    # demo alert
    top = max(scores, key=scores.get)
    if top == "vegetation" and scores[top] > 0.4:
        alerts = meta.setdefault("alerts", [])
        if "high_vegetation" not in alerts:
            alerts.append("high_vegetation")
    return msg


def process_stream() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        msg = segment(msg)
        msg = enrich(msg)
        print(json.dumps(msg), flush=True)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["realtime", "batch"], default="realtime")
    args = p.parse_args()
    if args.mode == "realtime":
        process_stream()
    else:
        print("[satellite] batch mode", file=sys.stderr)


if __name__ == "__main__":
    main()
