#!/usr/bin/env python3
"""YOLO / DNN object detection – GPU preferred, CPU fallback.

Patterns aligned with legitimate CCTV_YOLO / dnn-object-detection style apps:
- conf / iou thresholds
- optional frame skipping for higher-res streams
- real-time JSON-lines or batch directory mode
"""

from __future__ import annotations

import argparse
import base64
import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

import cv2
import numpy as np

try:
    from ultralytics import YOLO
    HAS_YOLO = True
except ImportError:
    HAS_YOLO = False


class Detector:
    def __init__(
        self,
        model_path: str = "yolov8n.pt",
        device: str = "cpu",
        conf: float = 0.35,
        iou: float = 0.45,
    ):
        self.device = device
        self.conf = conf
        self.iou = iou
        if HAS_YOLO:
            self.model = YOLO(model_path)
            self.model.to(device)
        else:
            self.model = None
            print("[warn] ultralytics not installed – stub detections", file=sys.stderr)

    def detect(self, jpeg_b64: str) -> List[Dict[str, Any]]:
        if not HAS_YOLO or self.model is None:
            return [{"id": 0, "class": "person", "bbox": [100, 100, 50, 120], "conf": 0.85}]

        data = base64.b64decode(jpeg_b64)
        arr = np.frombuffer(data, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if img is None:
            return []

        results = self.model(
            img, conf=self.conf, iou=self.iou, verbose=False
        )[0]
        objects = []
        for i, box in enumerate(results.boxes):
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            cls_id = int(box.cls[0])
            conf = float(box.conf[0])
            name = results.names.get(cls_id, str(cls_id))
            objects.append(
                {
                    "id": i,
                    "class": name,
                    "bbox": [int(x1), int(y1), int(x2 - x1), int(y2 - y1)],
                    "conf": round(conf, 3),
                }
            )
        return objects


def process_message(det: Detector, msg: dict) -> dict:
    frame = msg.get("frame", {})
    if "data" not in frame:
        return msg
    t0 = time.perf_counter()
    objects = det.detect(frame["data"])
    elapsed_ms = (time.perf_counter() - t0) * 1000
    meta = msg.setdefault("meta", {})
    meta["objects"] = objects
    meta["detect_ms"] = round(elapsed_ms, 1)
    return msg


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="yolov8n.pt")
    p.add_argument("--device", default="cpu")
    p.add_argument("--conf", type=float, default=0.35)
    p.add_argument("--iou", type=float, default=0.45)
    p.add_argument("--batch", help="directory of images")
    p.add_argument("--out", default="-")
    args = p.parse_args()

    det = Detector(args.model, args.device, args.conf, args.iou)
    out_f = open(args.out, "w") if args.out != "-" else sys.stdout

    if args.batch:
        for img_path in sorted(Path(args.batch).glob("*")):
            if img_path.suffix.lower() not in {".jpg", ".jpeg", ".png"}:
                continue
            with open(img_path, "rb") as f:
                b64 = base64.b64encode(f.read()).decode()
            msg = {
                "source_id": img_path.stem,
                "ts": int(time.time() * 1000),
                "frame": {"encoding": "jpeg", "data": b64},
                "meta": {},
            }
            result = process_message(det, msg)
            result.pop("frame", None)
            out_f.write(json.dumps(result) + "\n")
    else:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            msg = json.loads(line)
            result = process_message(det, msg)
            out_f.write(json.dumps(result) + "\n")
            out_f.flush()

    if out_f is not sys.stdout:
        out_f.close()


if __name__ == "__main__":
    main()
