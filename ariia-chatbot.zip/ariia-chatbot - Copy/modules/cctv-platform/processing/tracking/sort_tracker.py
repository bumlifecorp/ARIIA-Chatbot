#!/usr/bin/env python3
"""SORT / DeepSORT style tracker skeleton.

Maintains track_id across frames for objects produced by YOLO.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Dict, List, Tuple

# Minimal IoU + Kalman would go here; this is a pure-id assignment skeleton.


class SimpleTracker:
    def __init__(self, iou_threshold: float = 0.3, max_age: int = 30):
        self.next_id = 1
        self.tracks: Dict[int, dict] = {}
        self.iou_threshold = iou_threshold
        self.max_age = max_age

    @staticmethod
    def iou(a: List[int], b: List[int]) -> float:
        ax, ay, aw, ah = a
        bx, by, bw, bh = b
        x1 = max(ax, bx)
        y1 = max(ay, by)
        x2 = min(ax + aw, bx + bw)
        y2 = min(ay + ah, by + bh)
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        union = aw * ah + bw * bh - inter
        return inter / union if union > 0 else 0.0

    def update(self, objects: List[dict]) -> List[dict]:
        # age existing
        for tid in list(self.tracks):
            self.tracks[tid]["age"] += 1
            if self.tracks[tid]["age"] > self.max_age:
                del self.tracks[tid]

        assigned = set()
        for obj in objects:
            best_iou, best_tid = 0.0, None
            for tid, tr in self.tracks.items():
                if tid in assigned:
                    continue
                i = self.iou(obj["bbox"], tr["bbox"])
                if i > best_iou:
                    best_iou, best_tid = i, tid
            if best_tid is not None and best_iou >= self.iou_threshold:
                obj["track_id"] = best_tid
                self.tracks[best_tid] = {"bbox": obj["bbox"], "age": 0}
                assigned.add(best_tid)
            else:
                tid = self.next_id
                self.next_id += 1
                obj["track_id"] = tid
                self.tracks[tid] = {"bbox": obj["bbox"], "age": 0}
        return objects


def main() -> None:
    tracker = SimpleTracker()
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        msg = json.loads(line)
        meta = msg.setdefault("meta", {})
        objects = meta.get("objects", [])
        meta["objects"] = tracker.update(objects)
        meta["tracks"] = [
            {"track_id": tid, "age": tr["age"]} for tid, tr in tracker.tracks.items()
        ]
        print(json.dumps(msg), flush=True)


if __name__ == "__main__":
    main()
