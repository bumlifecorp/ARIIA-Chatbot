#!/usr/bin/env python3
"""Fall detection – improved aspect-ratio + temporal heuristic.

Legitimate pattern used by many open fall-detection demos:
when a person bbox becomes significantly wider than tall for several
consecutive frames, emit a 'fall' alert.

Replace the heuristic with a pose model (MediaPipe / MoveNet) for production.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict, deque
from typing import Deque, Dict, List


class FallTracker:
    def __init__(self, window: int = 8, aspect_thresh: float = 1.55, min_hits: int = 4):
        self.window = window
        self.aspect_thresh = aspect_thresh
        self.min_hits = min_hits
        self.history: Dict[int, Deque[bool]] = defaultdict(lambda: deque(maxlen=window))

    def update(self, objects: List[dict]) -> bool:
        fell = False
        seen = set()
        for obj in objects:
            if str(obj.get("class", "")).lower() != "person":
                continue
            bbox = obj.get("bbox") or [0, 0, 0, 0]
            if len(bbox) < 4:
                continue
            w, h = float(bbox[2]), float(bbox[3])
            if h <= 1:
                continue
            aspect = w / h
            tid = int(obj.get("track_id") or obj.get("id") or 0)
            lying = aspect >= self.aspect_thresh and h < 160
            self.history[tid].append(lying)
            seen.add(tid)
            if sum(self.history[tid]) >= self.min_hits:
                fell = True
        for tid in list(self.history.keys()):
            if tid not in seen:
                self.history[tid].append(False)
                if not any(self.history[tid]):
                    del self.history[tid]
        return fell


def process_stream() -> None:
    tracker = FallTracker()
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        meta = msg.setdefault("meta", {})
        objects = meta.get("objects") or []
        if tracker.update(objects):
            alerts = meta.setdefault("alerts", [])
            if "fall" not in alerts:
                alerts.append("fall")
            meta["fall_score"] = 0.75
        print(json.dumps(msg), flush=True)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["realtime", "batch"], default="realtime")
    args = p.parse_args()
    if args.mode == "realtime":
        process_stream()
    else:
        print("[fall] batch mode: pipe frames or use a video loader of your choice", file=sys.stderr)


if __name__ == "__main__":
    main()
