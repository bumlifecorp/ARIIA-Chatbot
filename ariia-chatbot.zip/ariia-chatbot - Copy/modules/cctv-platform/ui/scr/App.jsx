import React, { useEffect, useState } from "react";

/**
 * Minimal multi-feed grid that consumes the WebSocket node stream.
 * Shows source_id, object count, and alerts.
 */
export default function App() {
  const [nodes, setNodes] = useState({});

  useEffect(() => {
    const ws = new WebSocket(
      (location.protocol === "https:" ? "wss://" : "ws://") +
        location.host.replace(/:\d+$/, ":8080") +
        "/ws"
    );
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        setNodes((prev) => ({
          ...prev,
          [msg.source_id]: {
            ts: msg.ts,
            objects: msg.meta?.objects?.length || 0,
            alerts: msg.meta?.alerts || [],
            w: msg.frame?.width,
            h: msg.frame?.height,
          },
        }));
      } catch (_) {}
    };
    return () => ws.close();
  }, []);

  const list = Object.entries(nodes);
  return (
    <div style={{ fontFamily: "system-ui", background: "#0b0f14", color: "#e6edf3", minHeight: "100vh", padding: 16 }}>
      <h1>Eagle Eye – Live Feed Grid</h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 12 }}>
        {list.map(([id, n]) => (
          <div key={id} style={{ border: "1px solid #30363d", borderRadius: 8, padding: 12 }}>
            <strong>{id}</strong>
            <div style={{ fontSize: 13, opacity: 0.8 }}>
              {n.w}×{n.h} · objects: {n.objects}
            </div>
            {n.alerts.length > 0 && (
              <div style={{ color: "#f85149", marginTop: 6 }}>
                {n.alerts.join(", ")}
              </div>
            )}
          </div>
        ))}
        {list.length === 0 && <p>Waiting for authenticated nodes…</p>}
      </div>
    </div>
  );
}
