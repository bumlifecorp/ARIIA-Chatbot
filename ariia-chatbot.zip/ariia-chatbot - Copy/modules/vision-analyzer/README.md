# Vision Analyzer Module

On-device + cloud object intelligence for Eagle Eye Defense.

## Features
- CameraX 1.3.1 style ImageAnalysis (Android)
- ML Kit Detection & Tracking (real-time background)
- Offline object recognition + action binding
- Optional Azure Vision / liveness hooks
- Publishes results as External Nodes to the live-feed bus

## Layout
```
vision-analyzer/
  lib/vision_bridge.dart      # Dart helpers → node meta.objects
  android/ImageAnalyzer.kt    # CameraX Analyzer skeleton
  README.md
```

## Status
Skeletons implemented. Ready to wire to HUD local-camera node and cctv-platform node schema.
