/// Flutter-side bridge that turns vision results into ExternalNode meta.
library vision_bridge;

class VisionDetection {
  final int id;
  final String label;
  final double confidence;
  final List<double> bbox; // [x, y, w, h]

  const VisionDetection({
    required this.id,
    required this.label,
    required this.confidence,
    required this.bbox,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'class': label,
        'conf': confidence,
        'bbox': bbox,
      };
}

/// Convert a list of detections into the standard node meta.objects list.
List<Map<String, dynamic>> toNodeObjects(List<VisionDetection> dets) =>
    dets.map((d) => d.toJson()).toList();
