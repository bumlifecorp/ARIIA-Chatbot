package com.eagleeye.vision

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import java.nio.ByteBuffer
import java.util.concurrent.Executor

/**
 * Skeleton ImageAnalysis.Analyzer for real-time object detection.
 * Integrate ML Kit Object Detection / Face Detection here.
 * Results should be published as Eagle Eye node messages.
 */
class EagleImageAnalyzer(
    private val executor: Executor,
    private val onResult: (List<DetectedObject>) -> Unit,
) : ImageAnalysis.Analyzer {

    data class DetectedObject(
        val id: Int,
        val label: String,
        val confidence: Float,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
    )

    @androidx.camera.core.ExperimentalGetImage
    override fun analyze(imageProxy: ImageProxy) {
        // TODO: convert ImageProxy → InputImage and run ML Kit
        // For skeleton we emit an empty list so the pipeline stays live.
        try {
            onResult(emptyList())
        } finally {
            imageProxy.close()
        }
    }
}
