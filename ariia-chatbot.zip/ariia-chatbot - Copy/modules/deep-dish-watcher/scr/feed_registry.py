#!/usr/bin/env python3
"""Registry of authorized global / public-safety feeds → External Nodes."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Dict, List

FEEDS_PATH = Path(__file__).resolve().parent.parent / "feeds" / "example_feeds.json"


def load_feeds() -> List[dict]:
    if not FEEDS_PATH.exists():
        return []
    with open(FEEDS_PATH) as f:
        return json.load(f)


def to_node(feed: dict) -> dict:
    return {
        "source_id": feed["id"],
        "node_type": feed.get("type", "camera"),
        "ts": int(time.time() * 1000),
        "authenticated": True,
        "stream": {
            "protocol": feed.get("protocol", "rtsp"),
            "url": feed.get("url", ""),
        },
        "meta": {
            "label": feed.get("label", feed["id"]),
            "region": feed.get("region"),
            "objects": [],
            "alerts": [],
        },
    }


def main() -> None:
    for feed in load_feeds():
        print(json.dumps(to_node(feed)))


if __name__ == "__main__":
    main()
