# Deep-Dish / The Watchrr Module

Global watch layer: maps, authorized camera networks, public-safety anomaly feeds.

## Features
- Live Earth / 3D map launcher hooks
- Authorized public / private camera feed aggregation
- Mobotix / RTSP feed registration
- Public-safety anomaly signals → node alerts
- All feeds published as External Nodes

## Layout
```
deep-dish-watchrr/
  src/feed_registry.py
  feeds/example_feeds.json
```

## Note
Only feeds you are authorized to access should be registered.
