"""Possibility theory runtime for Eagle Eye Defense.

Implements π, Π, N and a simple threat scorer that attaches
meta.possibility to node messages.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Set


@dataclass
class PossibilityDistribution:
    """π : Ω → [0, 1]. Keys are atomic outcomes; missing keys are treated as 0."""

    values: Dict[str, float] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for k, v in list(self.values.items()):
            self.values[k] = max(0.0, min(1.0, float(v)))

    def pi(self, x: str) -> float:
        return self.values.get(x, 0.0)

    def possibility(self, event: Iterable[str]) -> float:
        """Π(A) = sup_{x in A} π(x)"""
        return max((self.pi(x) for x in event), default=0.0)

    def necessity(self, event: Iterable[str]) -> float:
        """N(A) = 1 - Π(Aᶜ)"""
        universe = set(self.values.keys())
        complement = universe - set(event)
        return 1.0 - self.possibility(complement)

    def normalize(self) -> "PossibilityDistribution":
        """Ensure at least one element has π = 1 (normal distribution)."""
        if not self.values:
            return self
        m = max(self.values.values())
        if m <= 0:
            return self
        if m < 1.0:
            scale = 1.0 / m
            self.values = {k: min(1.0, v * scale) for k, v in self.values.items()}
        return self


def threat_from_detections(
    objects: Sequence[Mapping],
    alerts: Sequence[str],
    class_weights: Optional[Mapping[str, float]] = None,
) -> Dict[str, float]:
    """Heuristic possibility distribution over threat levels.

    Returns dict with keys threat_pi / threat_n suitable for meta.possibility.
    """
    weights = class_weights or {
        "person": 0.3,
        "car": 0.2,
        "truck": 0.25,
        "knife": 0.9,
        "gun": 0.95,
        "firearm": 0.95,
    }
    alert_boost = {
        "fall": 0.55,
        "loitering": 0.4,
        "intrusion": 0.7,
        "gunshot": 0.95,
        "anomaly": 0.6,
    }

    # Build a simple distribution over {none, low, medium, high}
    dist = PossibilityDistribution(
        {
            "none": 1.0,
            "low": 0.4,
            "medium": 0.2,
            "high": 0.05,
        }
    )

    max_obj = 0.0
    for obj in objects:
        cls = str(obj.get("class", "")).lower()
        conf = float(obj.get("conf", 0.5))
        w = weights.get(cls, 0.15)
        max_obj = max(max_obj, w * conf)

    max_alert = 0.0
    for a in alerts:
        max_alert = max(max_alert, alert_boost.get(str(a).lower(), 0.3))

    score = max(max_obj, max_alert)
    if score >= 0.85:
        dist.values = {"none": 0.1, "low": 0.3, "medium": 0.7, "high": 1.0}
    elif score >= 0.55:
        dist.values = {"none": 0.2, "low": 0.5, "medium": 1.0, "high": 0.6}
    elif score >= 0.3:
        dist.values = {"none": 0.4, "low": 1.0, "medium": 0.5, "high": 0.15}
    else:
        dist.values = {"none": 1.0, "low": 0.35, "medium": 0.1, "high": 0.02}

    dist.normalize()
    # Threat event = {medium, high}
    threat_event = {"medium", "high"}
    return {
        "threat_pi": round(dist.possibility(threat_event), 3),
        "threat_n": round(dist.necessity(threat_event), 3),
        "levels": {k: round(v, 3) for k, v in dist.values.items()},
    }


def enrich_message(msg: dict) -> dict:
    """Attach meta.possibility to a node message."""
    meta = msg.setdefault("meta", {})
    objects = meta.get("objects") or []
    alerts = meta.get("alerts") or []
    meta["possibility"] = threat_from_detections(objects, alerts)
    return msg
