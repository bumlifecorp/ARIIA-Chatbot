#!/usr/bin/env python3
"""CLI: read node JSON lines from stdin, attach possibility scores, write to stdout."""

from __future__ import annotations

import json
import sys

from possibility import enrich_message


def main() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        print(json.dumps(enrich_message(msg)), flush=True)


if __name__ == "__main__":
    main()
