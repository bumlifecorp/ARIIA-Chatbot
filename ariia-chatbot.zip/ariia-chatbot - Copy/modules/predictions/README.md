# Predictions Engine

Possibility-theory runtime (Zadeh / Dubois-Prade) for Eagle Eye Defense.

## Core API

```python
from possibility import PossibilityDistribution, enrich_message, threat_from_detections

dist = PossibilityDistribution({"none": 1.0, "high": 0.2})
print(dist.possibility({"high"}))   # Π
print(dist.necessity({"high"}))     # N

# Enrich a live-feed node message
msg = enrich_message(node_msg)      # adds meta.possibility
```

## CLI (pipeline stage)

```bash
# after YOLO + tracker + fall
python -m src.cli < enriched.jsonl > with_possibility.jsonl
```

## Integration

Consumes `meta.objects` + `meta.alerts` from the live-feed platform and writes:

```json
"possibility": {
  "threat_pi": 0.65,
  "threat_n": 0.21,
  "levels": {"none": 0.2, "low": 0.5, "medium": 1.0, "high": 0.6}
}
```

## Status
Runtime library + CLI implemented. Ready to insert into the node bus pipeline.
