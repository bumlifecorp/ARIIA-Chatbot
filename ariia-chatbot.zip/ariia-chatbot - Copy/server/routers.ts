import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { z } from "zod";
import { storagePut, storageGetSignedUrl } from "./storage";
import { transcribeAudio } from "./_core/voiceTranscription";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  voice: router({
    transcribe: publicProcedure
      .input(z.object({
        audioBase64: z.string().min(1).max(24000000),
        mimeType: z.string().default("audio/mp4"),
        language: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const audio = Buffer.from(input.audioBase64, "base64");
        if (audio.byteLength > 16 * 1024 * 1024) throw new Error("Voice clip is larger than 16MB");
        const upload = await storagePut(`orbit/voice/${Date.now()}.m4a`, audio, input.mimeType);
        const signedUrl = await storageGetSignedUrl(upload.key);
        const result = await transcribeAudio({ audioUrl: signedUrl, language: input.language, prompt: "Transcribe this short Android launcher command exactly." });
        if ("error" in result) throw new Error(result.error);
        return { text: result.text, language: result.language, duration: result.duration };
      }),
  }),

  orbit: router({
    assist: publicProcedure
      .input(z.object({
        query: z.string().min(1).max(280),
        availableApps: z.array(z.object({ id: z.string(), name: z.string(), category: z.string() })).max(20),
      }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          model: "gpt-5-mini",
          messages: [
            {
              role: "system",
              content: "You are Orbit, a concise Android launcher assistant. Return a single safe launcher action. Never claim to launch apps, send messages, or change device settings. Choose focus for focus/concentration requests, app for requests matching an available app, web for web-search requests, reminder for reminder requests, or clarify if the intent is unclear. Keep title and body short and useful.",
            },
            {
              role: "user",
              content: `Available apps: ${JSON.stringify(input.availableApps)}\\nRequest: ${input.query}`,
            },
          ],
          reasoning: { effort: "minimal" },
          maxTokens: 220,
          responseFormat: {
            type: "json_schema",
            json_schema: {
              name: "orbit_action",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  kind: { type: "string", enum: ["focus", "app", "web", "reminder", "clarify"] },
                  appId: { type: ["string", "null"] },
                  title: { type: "string" },
                  body: { type: "string" },
                  actionLabel: { type: "string" },
                  query: { type: ["string", "null"] },
                },
                required: ["kind", "appId", "title", "body", "actionLabel", "query"],
                additionalProperties: false,
              },
            },
          },
        });
        const content = response.choices[0]?.message?.content;
        if (typeof content !== "string") throw new Error("Orbit returned no usable response");
        return JSON.parse(content) as { kind: "focus" | "app" | "web" | "reminder" | "clarify"; appId: string | null; title: string; body: string; actionLabel: string; query: string | null };
      }),
  }),
});

export type AppRouter = typeof appRouter;
