# AI Orbit Launcher — Mobile Interface Design

## Product Direction

AI Orbit Launcher is an original Android-first launcher concept for people who want a calmer home screen, faster app access, and an assistant that turns natural-language intent into useful next actions. It takes inspiration from minimalist launcher patterns such as text-forward home screens, gesture-led navigation, app search, focus modes, and lightweight customization, but uses its own visual language, information architecture, copy, and implementation.

The app is designed for portrait 9:16 screens and one-handed use. The primary interaction zone stays in the lower two-thirds of the display, while the top area is reserved for glanceable context rather than dense controls.

## Screen List

| Screen | Primary content and functionality |
|---|---|
| Home / Orbit | Large time and date, a short AI-generated focus suggestion, pinned apps, a compact “Ask Orbit” input, and a swipe/tap affordance for the app drawer. The home screen is intentionally sparse and can enter Focus Mode. |
| App Drawer | Search-first list of installed-app style entries grouped into Recent, Frequent, and All Apps. The prototype uses a local catalog so it works in preview without privileged Android launcher APIs. |
| Search Results | Filters the local app catalog and quick actions as the user types. Results support opening a simulated app tile, pinning it, or asking Orbit for a related action. |
| Orbit Assistant Sheet | A bottom sheet for natural-language requests such as “help me focus,” “open something for notes,” or “what should I do next?” It returns contextual cards and clear next actions without requiring a backend in the first prototype. |
| Focus Mode | A focused state that dims non-essential content, shows a session timer, displays a single intention, and offers Exit Focus. |
| Customize | Local settings for accent color, greeting style, pinned apps, and whether the assistant card appears on Home. Settings persist with AsyncStorage. |
| App Detail | A lightweight detail sheet for a selected app with its category, last-used label, pin/unpin action, and launch action. |

## Key User Flows

### Find and launch an app

1. User taps the Ask Orbit field or the drawer affordance.
2. App Drawer opens with the search field focused.
3. User types an app name or category.
4. Search Results update immediately.
5. User taps a result to open App Detail, then taps Launch, or uses the inline launch action.

### Ask Orbit for help

1. User taps the Ask Orbit field on Home.
2. Orbit Assistant Sheet opens from the bottom for one-handed reach.
3. User enters an intent, for example “I need to write.”
4. Orbit presents one primary recommendation and supporting quick actions.
5. User taps the recommendation to launch the relevant local app tile or enters Focus Mode.

### Start a focus session

1. User taps the focus suggestion card or asks Orbit to help focus.
2. Focus Mode opens with a single intention and a 25-minute timer.
3. User can pause or end the session from the bottom action row.
4. On completion, the UI shows a small success state and returns to Home.

### Customize the launcher

1. User opens Customize from the Home overflow control.
2. User changes accent, greeting, assistant visibility, or pinned apps.
3. Changes are saved locally and reflected immediately on Home.
4. User returns to Home using the top-left back affordance.

## Visual System

| Element | Decision |
|---|---|
| Brand | “AI Orbit Launcher” with a quiet, editorial Android utility feel. |
| Background | Deep ink `#0B0F14` for the default dark home surface. |
| Primary text | Soft cloud `#F4F7FB`, with `#B6C1CE` for secondary text. |
| Accent | Electric mint `#7CE7C4` for primary actions and focus progress. |
| Secondary accent | Orbit violet `#A992FF` for assistant context and AI affordances. |
| Warning/attention | Warm amber `#F6C56F`; errors use `#FF8B8B`. |
| Surfaces | Elevated slate `#151C24`, with subtle border `#263241`. |
| Typography | Large geometric time display, compact semibold headings, and readable 15–17px body text. Use system fonts for an Android-native feel. |
| Shape | 18–24px rounded cards, pill-shaped controls, and thin dividers. Avoid decorative gradients except a very subtle assistant halo. |
| Motion | 120–240ms fades and slide-ups, restrained press scale, and light haptic feedback on primary actions. |

## Android Interaction Notes

The prototype uses Expo-compatible touch interactions and safe-area handling. A production launcher would additionally require native Android Home-role integration, package discovery, intent launching, default-launcher onboarding, and background/notification policies; those platform responsibilities are intentionally kept separate from this preview implementation.

## References

The reference research will be captured after reviewing the public store listing and developer page. The prototype will use inspiration from publicly visible interaction patterns only and will not copy proprietary source code, screenshots, logos, or store assets.
