#!/bin/bash
sed -i '/package com.example.ui.screens.earth/d' app/src/main/java/com/example/ui/screens/earth/GoPhotoSphereView.kt
sed -i '1i package com.example.ui.screens.earth' app/src/main/java/com/example/ui/screens/earth/GoPhotoSphereView.kt
