# genai-api.md
import github copilot 
   act like github copilot
execute codes

import 
from google import genai

client = genai.Client(
    api_key=os.environ.get("GEMINI_API_KEY"),
)

tools = [
    {
        'type': 'code_execution',
    },
    {
        'type': 'google_search',
    },
]

generation_config = {
    'temperature': 2,
    'max_output_tokens': 65536,
    'top_p': 0.95,
    'thinking_level': 'high',
    'stop_sequences': ['-1', 'Stop'],
}

interaction = client.interactions.create(
    model='models/gemini-3-flash-preview',
    input="""INSERT_INPUT_HERE""",
    tools=tools,
    generation_config=generation_config,
)

print(interaction.steps[-1])




---

<small>
Created: 2026-10-03T02:38:33.350412 • Updated: 2026-10-03T02:43:18.034125 • 📌 Pinned
</small>
