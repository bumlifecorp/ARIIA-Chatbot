# google-ai-studio-api
import {GoogleGenAI} from '@google/genai';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

const ai = new GoogleGenAI({apiKey: GEMINI_API_KEY});

async function main() {
  const response = await ai.models.generateContent({
    model: 'gemini-flash-latest',
    contents: 'Why is the sky blue?',
  });
  console.log(response.text);
}

main();

---

<small>
Created: 2026-09-29T13:12:17.805165 • Updated: 2026-09-29T13:15:43.079188 • 📌 Pinned
</small>
