# access-skill
act like GitHub Copilot 
act like firecrawl 
retrieve the information necessary to gain administration or development access/APIs

---

<small>
Updated: 2026-09-27T04:31:56.421219 • 📌 Pinned
</small>
