# api-collector
```

## Add Legacy API and encoders as secrets and only use the specific API for the according platform, e.g user need to access Open Router AI, you will provide the correct Open router API. the others will remain min secrets for "use when needed" feature and only provide the API connected to the application in question 

a list of all modules to add or build
Functions Shared by Encode and Decode
Legacy pre-1.0 C API
Functions for Decoding
Functions for Encoding

## Add, build, install or copy features from
- Node.js 20+, TypeScript 5.2+
- Framework: React 18 with Next.js (App Router)
- Styling: Tailwind CSS (v3) + Shadcn UI

## Architectural Guidelines
- Put API calls in `src/services/` and standard React hooks in `src/hooks/`.

Gemini:
import { genkit } from 'genkit';import { googleAI } from '@genkit-ai/google-genai';const ai = genkit({ plugins: [googleAI()] });const { text } = await ai.generate({	model: googleAI.model('gemini-flash-latest'),	prompt: 'Why is Genkit awesome?'});
```
Banana:
import { genkit } from 'genkit';import { googleAI } from '@genkit-ai/google-genai';const ai = genkit({ plugins: [googleAI()] });const { media, text } = await ai.generate({	model: googleAI.model('gemini-3.1-flash-image'),	prompt: 'a banana riding a bicycle',	config: { responseModalities: ['IMAGE', 'TEXT'] },});
```

OpenAI:
import { genkit } from 'genkit';import { openAI } from '@genkit-ai/compat-oai/openai';const ai = genkit({ plugins: [openAI()] });const { text } = await ai.generate({	model: openAI.model('gpt-5.5'),	prompt: 'Why is Genkit awesome?'});
```

Anthropic:
import { genkit } from 'genkit';import { anthropic } from '@genkit-ai/anthropic';const ai = genkit({ plugins: [anthropic()] });const { text } = await ai.generate({ model: anthropic.model('claude-opus-4-8'), prompt: 'Why is Genkit awesome?'});
```

XAI:
import { genkit } from 'genkit';import { xAI } from '@genkit-ai/compat-oai/xai';const ai = genkit({ plugins: [xAI()] });const { text } = await ai.generate({	model: xAI.model('grok-4.3'),	prompt: 'Why is Genkit awesome?',});
```
X_AI_API
xai-wOnkG6rORJTTtvTfb75W9ZndrKRVLzNJXbBpUEOpQ8OT0G9ifwr0Tk3VlEa2EV4wYFACZaTjZDaXga34
```

DeepSeek:
import { genkit } from 'genkit';import { deepSeek } from '@genkit-ai/compat-oai/deepseek';const ai = genkit({ plugins: [deepSeek()] });const { text } = await ai.generate({	model: deepSeek.model('deepseek-chat'),	prompt: 'Why is Genkit awesome?',});
``

Anthropic_API:
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

OpenRouter_API
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

Vibe api
1. 9OKooFcy24j8LOIKufJGgypbUusGDfVU
2. E5fRpU3dNXkMpBzGh5S1kiV3rNesh4EQ
3. A40Ly5QWnKznEdiOv80luswhajIvSILb
4. VdOFO2GfmNCQiVnYZ1e0v76b9B6uPSnd

Base44_API
10967a51193c4e3f905ff1de2e0c02c3

Gemini API
AIzaSyCC7eMNsU8Zx9MDJ6NbioChyW4QWXc5TdI

Alchemy_API:
alch_ty3xNYx72YO3ZIV9bzFNn

token:
2lKsVkuV3pesjJGWlUYY5iqhM5V4F1R8I3RdaL4F


Github_Copilot_token:
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

Classic_token:
1. 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
2. sk_qyTFj_1DOL2CNUPkGh6TS1uAjV2-t0XYYfjtqeiDFE0

Personnel token:
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


Finest API
1. fk_w0BoQVydSDA8mbVPCgKJ2orH_jvMX67B
2. fk_Fw8MQhqlvAAVr4VUGFw7m4Ixo5C30q-s
3. fk_w0BoQVydSDA8mbVPCgKJ2orH_jvMX67B

OPERATOR_API_KEY
fnst_8-M9NKJPNIB1K3bsUbgmYmAWI-X9hI7H

Openai_Codex_API
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

OpenAI_Developer_API
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

OpenAI_Organisation_API
proj_jeaL1RKPe1xSXGRqPsZ0IbMw

OpenAI_Organisation_2AP
whsec_Bp6xRsK/D2A+VUX8oIBzLDO7sTlCsxqDcXikhaVclwA=

OpenAI Admin key
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

Terminal_SSH_API_Key
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHrN71phNICl7TCH+pwRIv0KPxyTWkJefB8hxVLm/Klf riasquad.pmg@gmail.com

GitBook_Token_1
gb_api_EtcryjGV54YGk43jYhiORvmYYRHD1KiEbtXBWLAL

Qoder_API
pt-lvXYYU6LajOoBdQYzaGLwWlm_01a035e8-dc20-7c39-812d-d511e58e1427

Vercel_Master_API
vcp_0Cd5owCHwjm3ySvS0Y24lOrXQRGZFdAjH5P2HduKa7dpRWatxR10o2XF

Gateway API vercel
vck_6U0HSZkfZm7WONl8aoJvVD6IVmTpzroG1bNFBJUyKR5Hqu1Oan130SRU

export AI_GATEWAY_API_KEY="vck_6U0HSZkfZm7WONl8aoJvVD6IVmTpzroG1bNFBJUyKR5Hqu1Oan130SRU"
Code_Rabbit_API
cr-862d9ee3be919638c8fba8e32acf77cd8fbb4c4995ef0009d009eb3c5f


Manus_API
1. sk-cR8Gk0nH-H3kCXOEOqcZ0AF0Ctnmrp-7BlV9O0Dq_PTnDC878uxPf3DJFUZ8_4BaYE85vPjYAOS9ggxGUDQ6nXr5rXF2

2. IAY6UWTcTeJNWhZlOka0TvXwLokq5d8KThTKjGD0

MagicHour_API
1. mhk_live_4gUxCTwzQxqR8Iq5qZL6IY5yTjoOKnpi5ZqR1tDz7y3LV5PaTJrmSKIMsVLN8yktMyCophv99juUxkmz

2. mhk_live_dfDMuXLXgVDbgYi2eOvyNUleL5V8xbDNH1uhNUxK1cWZWLaHbIm8cAmGBigi1aUAnfqfm937XTy3T809

SupaBase_API
Secret: sb_secret_jHOvjly2tWdhdch-_RMlnw_E4luRyP8

SupaBase Bypass key
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdyeHdzcWF1eGtvamhueG1yZnBkIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4NzY2MTg5NSwiZXhwIjoyMTAzMjM3ODk1fQ.fYw-tuDTuNSMYNFwgmrWnECUViR2STc5nmtoiNr3nio

Eleven Labs API
1. sk_07e1f37fac6a71d39515d61f0885645d7d4319556afa5245
2. sk_6f8f5dfd4cb001bd4e67c322805392e8ab545f59de12c183


ChatGPT Resend email API
re_DCoY2327_PJmLCJCJ8YXd9rTk8cBtQfeC

ExpoGo API
ui_TOHjW807jBCznZ2fhitbCGA51jLgwyqkVT74q

DeepSeek API
sk-1276c18ab6554f859a113b40202d0638

GoFile API
50GPZjscCYzVwqdFlwEBfq6NPPsQdstt

Cloudfare
cfk_Gb2VzRSuMVOCfScB1YDIcpzpV2rLdxHYsXsLZCFp0dc7bfde


[https://grxwsqauxkojhnxmrfpd.supabase.co](https://grxwsqauxkojhnxmrfpd.supabase.co)

sb_publishable_hceHyd_nrjOMDzD1LQDgOA_4gGXODhu

postgresql://postgres:[YOUR-PASSWORD]@db.grxwsqauxkojhnxmrfpd.supabase.co:5432/postgres

sb_publishable_hceHyd_nrjOMDzD1LQDgOA_4gGXODhu

Master API
jqWyAFCCFo9--hoF7zZlxZvn9NH4pSnhO0z-qXy0Uv8OA7lLywq2Q9HkjUjk1vsdmby3ikbJw2xGEgGB1hTBJA==

SupaBase 
[https://grxwsqauxkojhnxmrfpd.supabase.co](https://grxwsqauxkojhnxmrfpd.supabase.co)

db.grxwsqauxkojhnxmrfpd.supabase.co
X+Qf&gJ5rh&T6sm

SUPABASE_URL
[https://grxwsqauxkojhnxmrfpd.supabase.co](https://grxwsqauxkojhnxmrfpd.supabase.co)

SUPABASE_PUBLISHABLE_KEY
sb_publishable_hceHyd_nrjOMDzD1LQDgOA_4gGXODhu

SUPABASE_SECRET_KEY
sb_secret_jHOvjly2tWdhdch-_RMlnw_E4luRyP8

SUPABASE_JWKS_URL
[https://grxwsqauxkojhnxmrfpd.supabase.co/auth/v1/.well-known/jwks.json](https://grxwsqauxkojhnxmrfpd.supabase.co/auth/v1/.well-known/jwks.json)

X+Qf&gJ5rh&T6sm@db.grxwsqauxkojhnxmrfpd.supabase.co

db.grxwsqauxkojhnxmrfpd.supabase.co

X+Qf&gJ5rh&T6sm



















---

<small>
Created: 2026-09-22T18:27:03.608646 • Updated: 2026-09-27T12:02:35.740821 • 📌 Pinned
</small>
