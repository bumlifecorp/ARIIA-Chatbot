# API Key Generation & Verification Skill

## Purpose

Provide a reusable, production-oriented Node.js implementation for generating URL-safe API keys and securely storing/verifying them using PBKDF2 with per-key random salts and constant-time comparison.

## Capabilities

- Generate cryptographically random, URL-safe API keys.
- Support configurable key length and optional prefixes such as `sk_`.
- Hash API keys with PBKDF2, a random salt, configurable iterations, digest, and derived-key length.
- Verify supplied keys against stored PBKDF2 records.
- Use constant-time comparison via `crypto.timingSafeEqual`.
- Return `false` rather than throwing for malformed stored hashes during verification.

## Reference implementation

```javascript
/**
 * apiKeyGenerator.js
 *
 * Minimal, production-ready API key generator + secure hashing/verification utilities.
 */

const crypto = require('crypto');

const DEFAULTS = {
  apiKeyLength: 40,
  pbkdf2Iterations: 200_000,
  pbkdf2KeyLen: 32,
  pbkdf2Digest: 'sha256',
  saltLen: 16
};

function base64url(buf) {
  return buf
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function generateApiKey({
  length = DEFAULTS.apiKeyLength,
  prefix = ''
} = {}) {
  if (!Number.isInteger(length) || length <= 0) {
    throw new TypeError('length must be a positive integer');
  }

  const bytesNeeded = Math.ceil((length * 3) / 4);
  const buf = crypto.randomBytes(bytesNeeded);
  const key = base64url(buf).slice(0, length);

  return prefix + key;
}

function hashApiKey(apiKey, {
  iterations = DEFAULTS.pbkdf2Iterations,
  keyLen = DEFAULTS.pbkdf2KeyLen,
  digest = DEFAULTS.pbkdf2Digest,
  saltLen = DEFAULTS.saltLen
} = {}) {
  if (typeof apiKey !== 'string' || apiKey.length === 0) {
    throw new TypeError('apiKey must be a non-empty string');
  }

  const salt = crypto.randomBytes(saltLen);
  const derived = crypto.pbkdf2Sync(
    apiKey,
    salt,
    iterations,
    keyLen,
    digest
  );

  return [
    'pbkdf2',
    String(iterations),
    salt.toString('hex'),
    derived.toString('hex')
  ].join('$');
}

function verifyApiKey(storedHash, apiKey) {
  try {
    if (typeof storedHash !== 'string' || typeof apiKey !== 'string') {
      return false;
    }

    const parts = storedHash.split('$');

    if (parts.length !== 4 || parts[0] !== 'pbkdf2') {
      return false;
    }

    const iterations = Number.parseInt(parts[1], 10);

    if (!Number.isSafeInteger(iterations) || iterations <= 0) {
      return false;
    }

    const salt = Buffer.from(parts[2], 'hex');
    const derived = Buffer.from(parts[3], 'hex');

    if (salt.length === 0 || derived.length === 0) {
      return false;
    }

    const computed = crypto.pbkdf2Sync(
      apiKey,
      salt,
      iterations,
      derived.length,
      DEFAULTS.pbkdf2Digest
    );

    if (computed.length !== derived.length) {
      return false;
    }

    return crypto.timingSafeEqual(computed, derived);
  } catch {
    return false;
  }
}

module.exports = {
  generateApiKey,
  hashApiKey,
  verifyApiKey
};
```

## Usage

```javascript
const {
  generateApiKey,
  hashApiKey,
  verifyApiKey
} = require('./apiKeyGenerator');

const apiKey = generateApiKey({
  length: 48,
  prefix: 'sk_'
});

console.log('API Key:', apiKey);

// Store only this value in the database.
const storedHash = hashApiKey(apiKey);

console.log('Stored hash:', storedHash);

console.log(
  'Verify (correct):',
  verifyApiKey(storedHash, apiKey)
);

console.log(
  'Verify (wrong):',
  verifyApiKey(storedHash, apiKey + 'x')
);
```

## Storage model

Store the generated API key only at issuance time, or otherwise provide a secure recovery/rotation mechanism. Persist the PBKDF2 record instead of the plaintext key.

Example stored value:

```text
pbkdf2$200000$<salt-hex>$<derived-key-hex>
```

The salt is not secret and is stored alongside the derived value.

## Security requirements

1. Use Node.js `crypto.randomBytes()` for key and salt generation.
2. Never log plaintext API keys in production.
3. Never store plaintext API keys when verification can be performed from a derived value.
4. Use a unique random salt for every stored API key.
5. Use constant-time comparison for derived values.
6. Protect API keys in transit with TLS.
7. Provide revocation and rotation mechanisms for long-lived keys.
8. Apply authentication, authorization, rate limiting, and audit logging around API-key endpoints.
9. Treat API keys as bearer credentials: possession should be sufficient to authenticate the caller, so exposure must be handled as credential compromise.
10. Review PBKDF2 parameters against the current deployment's security requirements and benchmark them on the target hardware before production use.

## Important implementation note

The serialized format above stores the PBKDF2 iteration count but uses the module's configured digest during verification. If parameters may change over time, include the digest and derived-key length in the serialized format so records remain self-describing and verifiable after configuration changes.

A future format can be:

```text
pbkdf2$sha256$200000$32$<salt-hex>$<derived-key-hex>
```

For a new production system, version the format as well, for example:

```text
v1$pbkdf2$sha256$200000$32$<salt-hex>$<derived-key-hex>
```

## Skill behavior

When this skill is invoked for API-key work:

- Prefer Node.js built-in `crypto` primitives.
- Preserve compatibility with the serialized hash format unless migration is explicitly requested.
- Do not expose secrets in logs, examples, telemetry, or error messages.
- Validate untrusted parameters before passing them to cryptographic APIs.
- Keep generation, hashing, and verification separate so they can be tested independently.
- For an existing codebase, inspect its runtime version, module system, storage layer, and authentication flow before changing the implementation.
- For migrations, support old hashes while issuing new hashes in the new versioned format until migration is complete.
- Add automated tests covering generation, uniqueness, hashing, successful verification, failed verification, malformed records, and parameter validation.

## Suggested test cases

```javascript
const assert = require('node:assert/strict');

const key = generateApiKey({ length: 40, prefix: 'sk_' });

assert.equal(key.startsWith('sk_'), true);
assert.equal(key.length, 43);

const stored = hashApiKey(key);

assert.equal(verifyApiKey(stored, key), true);
assert.equal(verifyApiKey(stored, `${key}x`), false);
assert.equal(verifyApiKey('invalid', key), false);
assert.equal(verifyApiKey(stored, ''), false);
```

## Scope

This skill covers API-key generation, hashing, verification, storage-format design, and related implementation guidance. It does not replace application-level authorization, secret management, TLS configuration, access control, incident response, or key lifecycle policy.
