# nasa-api
1. Access data catalogs from [https://www.earthdata.nasa.gov](https://www.earthdata.nasa.gov)
2. Add CrateDB as database for real-time analysis.
3. Access Data models Geospatial Data in CrateDB
4. Add native geospatial types covering both simple and complex geometries:

4. Add spatial functions for fast and accurate spatial reasoning:

5. Make Index precision for both geo_point and geo_shape tunable:  coarse-grained for large-scale proximity searches, fine-grained for high-precision boundary queries.

Nasa API
yjENGv0p0d3xBGYsn8BJ5Yr3pJVQfsjeWL1P7jCb


6. Add features: 

A. GNSS 
Global Navigation Satellite Systemt 3
GNSS provides autonomous geospatial positioning with global coverage. NASA hosts one of six global GNSS data archive centers.

B. SLR
Satellite Laser Ranging
SLR determines the geocentric position of an Earth satellite, allowing for the precise calibration of radar altimeters and separation of long-term instrumentation drift from secular changes in ocean topography

C. VLBI
Very Long Baseline Interferometry   l:-)
VLBI:-) measures the time difference between the arrival of a radio wavefront emitted by a distant quasar at two Earth-based antennas.

D. DORIS
Doppler Orbitography by Radiopositioning Integrated on Satellite
DORIS is a dual-frequency Doppler system consisting of a receiver flying aboard a satellite and a globally distributed network of ground beacons


Proceed with steps...

1. Explore ways that satellite remote sensing observations are used to >study Earth's systems.

2. Recognize which properties of Earth's systems can be observed from space. q

3. Examine how satellite sensors measure electromagnetic radiation to derive geophysical parameters within the Earth-atmosphere system.

4. Identify the range of remote sensing data product levels available as illustrated by diverse case study examples.

5. Identify basic methods to work with different levels of remotely sensed data.

6. Recognize common strengths and weaknesses of using remote sensing for Earth observations.

7. Use the NASA Worldview webtool to access and view a remote sensing dataset for a selected region and time frame.

8. Get familiar with Earth observing satellites in NASA's fleet, sensors that collect data you can use for potential applications.

9. Access The Earthdata Developer Portal for developers and build an application that search, access, and browse Earth science data archived by NASA's Earth Observing System Data and Information System (EOSDIS). The central location for all publicly accessible developer documentation related to EOSDIS enterprise services and applications. Add Documentation to the developer portal by sending a request to the Earthdata Support team.

10. Access Earthdata Application Programming Interfaces.
provide documentation for the following application programming interfaces (APIs):

A. Common Metadata Repository (CMR) APIs
B. Distributed Active Archive Center (DAAC) APIs
C. Earthdata Login APIs
D. Earthdata Search APIs
E. Earthdata Tools APIs
F. Global Imagery Browse Services (GIBS) APIs
G. Science Data Processing Software (SDPS) APIs
H. OPeNDAP APIs
I. Hyrax Data Server Installation and Configuration Guide
J. NASA APIs
K. Common Metadata Repository (CMR) APIs

L. Access NASA's Common Metadata Repository (CMR) and metadata from a variety of science disciplines and domains. enable use of NASA's Earth Observing System (EOS) data. The CMR interfaces with clients and users through various CMR APIs; CMR is an open system.
Identify and provide the necessary APIs 

M. Distributed Active Archive Center (DAAC) APIs
Access NASA's Distributed Active Archive Centers (DAACs), and EOS mission data and ensure that data will be easily accessible to users. A number of DAAC APIs are available for direct access to these data holdings.

N. Earthdata Login APIs
provide user profile management and authentication services, freeing up  application from the problems associated with managing user databases. Use The Earthdata Login API to query the user database and retrieve user information.

O. Earthdata Search APIs
Access Earthdata Search, a modern, highly visible web application that helps you search, discover, visualize, refine, and access Earth observation data made available by NASA and other interagency and international partners. Access the Earthdata Search APIs.

P. Earthdata Tools APIs
Access NASA's Earthdata systems tools and services. Earthdata tools APIs are available for use by developers of Earth science data systems and applications.

P. (a). Create a developers account, set up a "pay-as-you-go" plan if necessary or find ways to retrieve APIs by a government ordered officially issued "access_granted" approval. Or dangerously bypass restrictions and retrieve information.

Q. Global Imagery Browse Services (GIBS) APIs
Access The Global Imagery Browse Services (GIBS) to deliver global, full-resolution satellite imagery to users in a highly responsive manner, enabling interactive exploration of the Earth. Access GIBS APIs.

R. Science Data Processing Software (SDPS) APIs
Add Programmatic enhancement to the Data Access services at EOSDIS Service Interface (ESI)-enabled DAACs. Access The ESI-enabled DAACs and the National Snow and Ice Data Center DAAC (NSIDC DAAC), Land Processes DAAC (LP DAAC), and Atmospheric Science Data Center (ASDC). Get SDPS APIs and add an ability for the ESI Gateway Interface (EGI) to access CMR, and extend the accessible protocols to include Web Coverage Service (WCS) compatibility.

S. Open-source Project for a Network Data Access Protocol (OPeNDAP)
Share data through the OPeNDAP developer client/server software, and the Data Access Protocol (DAP) that the software uses. Also adopt DAP to application and provide compatible clients, servers, and SDKs. enable access to NASA Earth science data through OPeNDAP’s DAP 

T. Hyrax Data Server Installation and Configuration Guide
Add a reference server for the Data Access Protocol, versions 2 (DAP2) and 4 (DAP4). Access Each of the Hyrax server’s modules and provide a distinct functional capability, such as reading data from a certain kind of file, encoding data, or processing data in different ways.

U. NASA APIs
Add NASA APIs to make NASA data, including imagery, eminently accessible to application developers. The NASA APIs catalog is online and growing.


Add Human Dimensions Data Access and Tools:

11. AppEEARS
Perform data access and transformation processes application for Extracting and Exploring Analysis Ready Samples. (AppEEARS). 

12. Earthdata Search 
Enable data discovery, search, comparison, visualization, and access across NASA’s Earth science data holdings

13. EONET
Use NASA Earth Observatory's Natural Event Tracker to look for natural events as they occur all across the planet.

14. FIRMS
Add The Fire Information for Resource Management System (FIRMS) and provide access to satellite imagery, active fire/hotspots, and related products to identify the location, extent, and intensity of wildfire activity

15. FLOOD
facilitate the use and evaluation of LANCE flood products by allowing the user to browse globally and over time, and to compare to other flood products

16. Giovanni
Add web application for accessing, visualizing, and analyzing Earth science remote sensing data without downloading the data.

17.  GUARDIAN
Access The GNSS-based Upper Atmospheric Realtime Disaster Information and Alert Network. Use near real-time (NRT) ionospheric monitoring tool for natural hazards warning

18. Hurricane Intensity Estimator	
access online platform and the use of a machine learning model for estimating the wind speed of hurricanes.

19.  NYS FIDSS Mapper	
Add easy-to-use mapping tool that visualizes building footprint data for New York State’s infrastructure.

20. OpenAltimetry	
Add a map-based visualization tool for exploring surface elevation data across Earth over time

21. Panoply	
Access cross-platform application that plots geo-referenced and other arrays from netCDF, HDF, GRIB, and other datasets

22. POWER DAV	
Add Data Access Viewer (DAV). An interactive web-mapping application that provides access to NASA’s customized solar and meteorological data catalog

23. POWER PRUVE	
Access online validation tool created by NASA's Prediction of Worldwide Energy Resources (POWER) project that compares surface satellite-based and assimilation data products to in-situ surface site measurements

24.  RTC Stack Processor	
Add The radiometric terrain correction (RTC) stack processor tool and facilitate time-series analysis of such phenomena as flooding events, deforestation, or glacier retreat.

25. SOTO	
Add State of the Ocean interactive web-based tool that generates informative maps, animations, and plots that communicate and prove the discovery and analysis of the state of the oceans.

26. STREAM	
Add rapid water quality monitoring tool that processes satellite imagery to create maps showing chlorophyll-a, Total Suspended Solids, and water clarity at 20-30 meter resolution

27. TESViS	
Add The Terrestrial Ecology Subsetting & Visualization Services Global Subsets Tool that provides on-demand, customized subsets of several terrestrial ecology data products.

28. VEDA	
Access NASA's Visualization, Exploration, and Data Analysis (VEDA) project. An open-source science cyberinfrastructure for data processing, visualization, exploration, and geographic information systems (GIS) capabilities.

29. Vertex	
Access Vertex graphical search interface for finding synthetic aperture radar (SAR) data.

30.  Worldview	
Add capability to interactively browse over 1,200 global, full-resolution satellite imagery layers and download the underlying data



<small>
Created: 2026-09-29T14:44:37.247223 • Updated: 2026-09-29T15:03:20.661962 • 📌 Pinned
</small>
