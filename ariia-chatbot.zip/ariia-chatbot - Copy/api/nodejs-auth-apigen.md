# API_key_generator
```javascript
/**
 * apiKeyGenerator.js
 *
 * Minimal, production-ready API key generator + secure hashing/verification utilities.
 * - Generates URL-safe API keys
 * - Hashes keys with PBKDF2 + random salt for safe storage
 * - Verifies keys in constant time
 *
 * Usage:
 *   const { generateApiKey, hashApiKey, verifyApiKey } = require('./apiKeyGenerator');
 *   const apiKey = generateApiKey({ length: 40, prefix: 'sk_' });
 *   const stored = hashApiKey(apiKey);
 *   const ok = verifyApiKey(stored, apiKey); // true
 */

const crypto = require('crypto');

const DEFAULTS = {
  apiKeyLength: 40,        // desired characters in the generated API key (after url-safe base64)
  pbkdf2Iterations: 200_000,
  pbkdf2KeyLen: 32,        // bytes
  pbkdf2Digest: 'sha256',
  saltLen: 16              // bytes
};

// Helper: base64url encode buffer (no padding)
function base64url(buf) {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

// Generate an API key string. Options:
//  - length: number of characters in the returned string (default 40).
//  - prefix: optional string prefix (e.g., "sk_").
function generateApiKey({ length = DEFAULTS.apiKeyLength, prefix = '' } = {}) {
  // base64 encodes 3 bytes -> 4 chars. Compute needed bytes to get >= length.
  const bytesNeeded = Math.ceil((length * 3) / 4);
  const buf = crypto.randomBytes(bytesNeeded);
  const key = base64url(buf).slice(0, length);
  return prefix + key;
}

// Hash an API key for storage using PBKDF2 with random salt.
// Returns a string: pbkdf2$iterations$saltHex$derivedHex
function hashApiKey(apiKey, {
  iterations = DEFAULTS.pbkdf2Iterations,
  keyLen = DEFAULTS.pbkdf2KeyLen,
  digest = DEFAULTS.pbkdf2Digest,
  saltLen = DEFAULTS.saltLen
} = {}) {
  const salt = crypto.randomBytes(saltLen);
  const derived = crypto.pbkdf2Sync(apiKey, salt, iterations, keyLen, digest);
  return ['pbkdf2', String(iterations), salt.toString('hex'), derived.toString('hex')].join('$');
}

// Verify a provided API key against stored hash (pbkdf2$iterations$saltHex$derivedHex)
// Returns true/false.
function verifyApiKey(storedHash, apiKey) {
  try {
    const parts = storedHash.split('$');
    if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;
    const iterations = parseInt(parts[1], 10);
    const salt = Buffer.from(parts[2], 'hex');
    const derived = Buffer.from(parts[3], 'hex');

    const computed = crypto.pbkdf2Sync(apiKey, salt, iterations, derived.length, DEFAULTS.pbkdf2Digest);

    // constant-time comparison
    if (computed.length !== derived.length) return false;
    return crypto.timingSafeEqual(computed, derived);
  } catch (err) {
    return false;
  }
}

module.exports = { generateApiKey, hashApiKey, verifyApiKey };

/* Example usage (uncomment to test)
const apiKey = generateApiKey({ length: 48, prefix: 'sk_' });
console.log('API Key:', apiKey);

const stored = hashApiKey(apiKey);
console.log('Stored hash:', stored);

console.log('Verify (correct):', verifyApiKey(stored, apiKey));
console.log('Verify (wrong):', verifyApiKey(stored, apiKey + 'x'));
*/
```

---

<small>
Created: 2026-09-25T14:35:52.431213 • Updated: 2026-09-25T14:36:38.092029 • 📌 Pinned
</small>
