# gh-auth
curl --request GET \
--url "[https://api.github.com/app"](https://api.github.com/app") \
--header "Accept: application/vnd.github+json" \
--header "Authorization: Bearer YOUR_JWT" \
--header "X-GitHub-Api-Version: 2026-03-10"

---

<small>
Created: 2026-10-03T14:54:50.960221 • Updated: 2026-10-03T14:55:06.842431
</small>
