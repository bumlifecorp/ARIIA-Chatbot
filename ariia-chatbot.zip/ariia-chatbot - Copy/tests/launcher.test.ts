import { describe, expect, it } from "vitest";
import { filterLauncherApps, routeOrbitIntent } from "../lib/launcher";

const apps = [
  { id: "notes", name: "Notes", category: "Create" },
  { id: "calendar", name: "Calendar", category: "Plan" },
  { id: "browser", name: "Browser", category: "Explore" },
];

describe("launcher utilities", () => {
  it("filters apps by name or category without case sensitivity", () => {
    expect(filterLauncherApps(apps, "plan").map((app) => app.id)).toEqual(["calendar"]);
    expect(filterLauncherApps(apps, "NOTE").map((app) => app.id)).toEqual(["notes"]);
  });

  it("returns the full catalog for an empty query", () => {
    expect(filterLauncherApps(apps, " ")).toEqual(apps);
  });

  it("routes common natural-language intents", () => {
    expect(routeOrbitIntent("help me concentrate")).toBe("focus");
    expect(routeOrbitIntent("I need to write")).toBe("notes");
    expect(routeOrbitIntent("plan tomorrow")).toBe("calendar");
    expect(routeOrbitIntent("show apps")).toBe("drawer");
  });
});
