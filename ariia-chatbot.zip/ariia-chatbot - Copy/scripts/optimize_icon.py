from pathlib import Path
from PIL import Image

root = Path('/home/ubuntu/ai-orbit-launcher/assets/images')
source = Image.open('/home/ubuntu/webdev-static-assets/ai-orbit-launcher-icon.png').convert('RGBA')
source.thumbnail((512, 512), Image.Resampling.LANCZOS)
for name in ['icon.png', 'splash-icon.png', 'favicon.png', 'android-icon-foreground.png']:
    source.save(root / name, format='PNG', optimize=True, compress_level=9)
