package com.example.data

import com.squareup.moshi.JsonClass
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class DeepSeekPerson(
    val id: String,
    val name: String,
    val role: String,
    val clearanceLevel: String,
    val department: String,
    val biometricsStatus: String,
    val livenessScore: Float,
    val avatarUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class DeepSeekAiRequest(
    val model: String = "deepseek-chat",
    val messages: List<DeepSeekMessage>,
    val temperature: Double = 0.7
)

@JsonClass(generateAdapter = true)
data class DeepSeekMessage(
    val role: String, // "system", "user", "assistant"
    val content: String
)

@JsonClass(generateAdapter = true)
data class DeepSeekAiResponse(
    val id: String?,
    val choices: List<DeepSeekChoice>?
)

@JsonClass(generateAdapter = true)
data class DeepSeekChoice(
    val message: DeepSeekMessage?
)

interface DeepSeekApiService {
    @POST("v1/chat/completions")
    suspend fun queryDeepSeekAi(
        @Header("Authorization") apiKey: String,
        @Body request: DeepSeekAiRequest
    ): DeepSeekAiResponse

    @GET("v1/people/directory")
    suspend fun getDeepSeekPeople(
        @Header("Authorization") apiKey: String,
        @Query("query") query: String? = null
    ): List<DeepSeekPerson>

    companion object {
        const val BASE_URL = "https://api.deepseek.com/"

        fun create(): DeepSeekApiService {
            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
            return retrofit.create(DeepSeekApiService::class.java)
        }
    }
}
