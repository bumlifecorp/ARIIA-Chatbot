package com.example.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class AriiaActuatorMode(val label: String) {
    STANDBY("Standby / Idle"),
    MANUAL_TELEOP("Manual Teleoperation"),
    AUTONOMOUS_PATROL("Autonomous SLAM Patrol"),
    VISION_TRACKING("Teachable Vision Tracking"),
    EMERGENCY_HALT("EMERGENCY STOP")
}

data class AriiaServoJoint(
    val id: String,
    val name: String,
    val currentAngle: Float,
    val minAngle: Float = 0f,
    val maxAngle: Float = 180f,
    val loadPercentage: Int,
    val temperatureCelsius: Float
)

data class AriiaRobotTelemetry(
    val unitId: String = "ARIIA-ROBOT-01",
    val modelName: String = "ARIIA Quad-Recon Actuator Mark IV",
    val mode: AriiaActuatorMode = AriiaActuatorMode.STANDBY,
    val batteryPercent: Int = 94,
    val motorRpm: Int = 1850,
    val internalTempCelsius: Float = 36.4f,
    val gripperOpen: Boolean = false,
    val pitchAngle: Float = 1.2f,
    val rollAngle: Float = -0.8f,
    val lidarDistancesCm: List<Int> = listOf(145, 180, 210, 85, 45, 110, 195, 230),
    val connectionLink: String = "ARIIA DDS Mesh Link (2.4 GHz)",
    val isCalibrated: Boolean = true
)

class AriiaRoboticsManager(private val scope: CoroutineScope) {

    private val _robotTelemetry = MutableStateFlow(AriiaRobotTelemetry())
    val robotTelemetry: StateFlow<AriiaRobotTelemetry> = _robotTelemetry.asStateFlow()

    private val _joints = MutableStateFlow<List<AriiaServoJoint>>(
        listOf(
            AriiaServoJoint("J1", "Base Yaw", 90f, 0f, 180f, 22, 34.5f),
            AriiaServoJoint("J2", "Shoulder Pitch", 45f, 0f, 180f, 38, 38.2f),
            AriiaServoJoint("J3", "Elbow Pitch", 120f, 0f, 180f, 41, 37.8f),
            AriiaServoJoint("J4", "Wrist Pitch", 75f, 0f, 180f, 18, 33.1f),
            AriiaServoJoint("J5", "Wrist Roll", 90f, 0f, 180f, 15, 32.0f),
            AriiaServoJoint("J6", "Tactile Gripper", 30f, 0f, 100f, 28, 31.4f)
        )
    )
    val joints: StateFlow<List<AriiaServoJoint>> = _joints.asStateFlow()

    private val _robotLogs = MutableStateFlow<List<String>>(
        listOf(
            "[ARIIA Robotics] Tactical Firmware v4.2.0 loaded.",
            "[ARIIA Robotics] 6-DOF Inverse Kinematics solver initialized.",
            "[ARIIA Robotics] Ultrasonic sonar & 360 LIDAR telemetry online.",
            "[ARIIA Robotics] Ready for ARIIA Tactical Launcher teleoperation commands."
        )
    )
    val robotLogs: StateFlow<List<String>> = _robotLogs.asStateFlow()

    private var teleoperationJob: Job? = null

    init {
        startTelemetryLoop()
    }

    private fun startTelemetryLoop() {
        teleoperationJob?.cancel()
        teleoperationJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(1200)
                val current = _robotTelemetry.value
                if (current.mode != AriiaActuatorMode.EMERGENCY_HALT) {
                    val newLidar = current.lidarDistancesCm.map { d ->
                        (d + Random.nextInt(-5, 6)).coerceIn(20, 350)
                    }
                    _robotTelemetry.value = current.copy(
                        batteryPercent = (current.batteryPercent - (if (Random.nextFloat() > 0.96f) 1 else 0)).coerceAtLeast(10),
                        pitchAngle = current.pitchAngle + (Random.nextFloat() * 0.4f - 0.2f),
                        rollAngle = current.rollAngle + (Random.nextFloat() * 0.4f - 0.2f),
                        lidarDistancesCm = newLidar,
                        motorRpm = if (current.mode == AriiaActuatorMode.AUTONOMOUS_PATROL) Random.nextInt(2400, 3100) else Random.nextInt(1200, 1900)
                    )
                }
            }
        }
    }

    fun setJointAngle(jointId: String, angle: Float) {
        val updated = _joints.value.map { j ->
            if (j.id == jointId) {
                j.copy(currentAngle = angle.coerceIn(j.minAngle, j.maxAngle))
            } else j
        }
        _joints.value = updated
    }

    fun toggleGripper() {
        val currentOpen = _robotTelemetry.value.gripperOpen
        _robotTelemetry.value = _robotTelemetry.value.copy(gripperOpen = !currentOpen)
        val targetAngle = if (!currentOpen) 95f else 15f
        setJointAngle("J6", targetAngle)
        appendLog("[ARIIA Robotics] Gripper state switched to: ${if (!currentOpen) "OPEN (95mm)" else "CLAMPED (15mm)"}")
    }

    fun setOperationalMode(newMode: AriiaActuatorMode) {
        _robotTelemetry.value = _robotTelemetry.value.copy(mode = newMode)
        appendLog("[ARIIA System] Robotics mode changed to: ${newMode.label}")
    }

    fun calibrateAllServos() {
        val calibrated = _joints.value.map { j ->
            j.copy(currentAngle = 90f, loadPercentage = 15, temperatureCelsius = 32.0f)
        }
        _joints.value = calibrated
        _robotTelemetry.value = _robotTelemetry.value.copy(isCalibrated = true, mode = AriiaActuatorMode.STANDBY)
        appendLog("[ARIIA Robotics] Full 6-DOF zero-point homing & calibration complete.")
    }

    fun triggerEmergencyHalt() {
        _robotTelemetry.value = _robotTelemetry.value.copy(mode = AriiaActuatorMode.EMERGENCY_HALT, motorRpm = 0)
        appendLog("[ARIIA OVERRIDE] Emergency stop triggered! Actuators de-energized.")
    }

    private fun appendLog(log: String) {
        val current = _robotLogs.value.toMutableList()
        if (current.size > 20) current.removeAt(0)
        current.add(log)
        _robotLogs.value = current
    }
}
