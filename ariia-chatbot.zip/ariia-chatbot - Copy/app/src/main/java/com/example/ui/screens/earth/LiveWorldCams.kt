package com.example.ui.screens.earth

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

@Composable
fun LiveWorldCams(
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val cameras = remember {
        listOf(
            WorldCamera(
                id = "cam-iss",
                title = "ISS Earth Orbit 4K",
                location = "International Space Station (LEO)",
                country = "Low Earth Orbit",
                latitude = 25.14f,
                longitude = -42.80f,
                category = "Orbital",
                resolution = "3840x2160 (4K)",
                fps = 60,
                bitrateKbps = 12500,
                description = "High-definition optical downlink from the ISS Columbus module showing Earth curvature and auroras."
            ),
            WorldCamera(
                id = "cam-tokyo",
                title = "Tokyo Shibuya Crossing",
                location = "Shibuya Ward, Tokyo",
                country = "Japan",
                latitude = 35.6595f,
                longitude = 139.7005f,
                category = "Urban",
                resolution = "1920x1080 (FHD)",
                fps = 30,
                bitrateKbps = 4800,
                description = "World famous pedestrian scramble with autonomous traffic AI and multi-spectral neon signage."
            ),
            WorldCamera(
                id = "cam-times-sq",
                title = "Times Square Recon Matrix",
                location = "Broadway & 7th Ave, New York",
                country = "United States",
                latitude = 40.7580f,
                longitude = -73.9855f,
                category = "Urban",
                resolution = "1920x1080 (FHD)",
                fps = 30,
                bitrateKbps = 5200,
                description = "Tactical urban intersection telemetry, digital billboards, and municipal surveillance node."
            ),
            WorldCamera(
                id = "cam-cern",
                title = "CERN Main Control Center",
                location = "Prévessin, Geneva Border",
                country = "Switzerland / France",
                latitude = 46.2330f,
                longitude = 6.0557f,
                category = "Scientific",
                resolution = "1920x1080 (FHD)",
                fps = 30,
                bitrateKbps = 3800,
                description = "Large Hadron Collider beam status displays, cryogenic magnet telemetry, and beam dump detectors."
            ),
            WorldCamera(
                id = "cam-cape",
                title = "Cape Canaveral Pad 39A",
                location = "Merritt Island, Florida",
                country = "United States",
                latitude = 28.6083f,
                longitude = -80.6042f,
                category = "Spaceport",
                resolution = "2560x1440 (2K)",
                fps = 60,
                bitrateKbps = 8400,
                description = "Orbital rocket launch gantry, cryo propellant loading arms, and water deluge sound suppression system."
            ),
            WorldCamera(
                id = "cam-svalbard",
                title = "Svalbard Arctic Observatory",
                location = "Longyearbyen, Spitsbergen",
                country = "Norway",
                latitude = 78.2232f,
                longitude = 15.6267f,
                category = "Polar",
                resolution = "1920x1080 (FHD)",
                fps = 24,
                bitrateKbps = 3100,
                description = "High-latitude geomagnetic aurora borealis observation station and permafrost glaciers."
            ),
            WorldCamera(
                id = "cam-dubai",
                title = "Dubai Marina Aerial Node",
                location = "Dubai Marina Coastal",
                country = "United Arab Emirates",
                latitude = 25.0805f,
                longitude = 55.1403f,
                category = "Maritime",
                resolution = "1920x1080 (FHD)",
                fps = 30,
                bitrateKbps = 4600,
                description = "High-rise architectural canyon, autonomous maritime pleasure craft waterways, and desert illumination."
            )
        )
    }

    var activeCam by remember { mutableStateOf(cameras[0]) }
    var ptzZoom by remember { mutableFloatStateOf(1.0f) }
    var ptzPanX by remember { mutableFloatStateOf(0f) }
    var ptzPanY by remember { mutableFloatStateOf(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "CamFeed")
    val scanlineY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2500, easing = LinearEasing), RepeatMode.Restart),
        label = "Scanline"
    )
    val liveBlink by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "LiveDot"
    )
    val cloudOrbitOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 100f,
        animationSpec = infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Restart),
        label = "CloudMotion"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF03060E)),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Camera Horizontal Selector
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(cameras) { cam ->
                val isSel = cam.id == activeCam.id
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSel) Color(0xFF003845) else Color(0xFF0A0F1D),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFF00F0FF) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable {
                        activeCam = cam
                        ptzZoom = 1.0f
                        ptzPanX = 0f
                        ptzPanY = 0f
                        onSpeak("Switching to live video feed: ${cam.title}, ${cam.location}. Resolution ${cam.resolution}.")
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(if (isSel) Color(0xFF39FF14) else Color(0xFF64748B), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(cam.title, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else Color(0xFFCBD5E1))
                            Text(cam.category, fontSize = 7.sp, color = if (isSel) Color(0xFF00F0FF) else Color(0xFF64748B))
                        }
                    }
                }
            }
        }

        // Live Video Viewport Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF01040A), RoundedCornerShape(14.dp))
                .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
        ) {
            // Simulated Live Video Frame Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Background environment rendering based on camera type
                when (activeCam.category) {
                    "Orbital" -> {
                        // Deep Space black + Earth Curve
                        drawRect(Color(0xFF01050F), Offset(0f, 0f), Size(w, h))

                        // Blue Earth Horizon
                        val earthCenter = Offset(w / 2f + ptzPanX, h * 1.5f + ptzPanY)
                        val earthRadius = (w * 0.95f) * ptzZoom
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xFF0C548A), Color(0xFF04203D), Color(0xFF010814)),
                                center = earthCenter,
                                radius = earthRadius
                            ),
                            radius = earthRadius,
                            center = earthCenter
                        )

                        // Atmospheric Blue Rim
                        drawCircle(
                            color = Color(0xFF00F0FF).copy(alpha = 0.6f),
                            radius = earthRadius,
                            center = earthCenter,
                            style = Stroke(3f * ptzZoom)
                        )

                        // Floating Cloud Wisps
                        drawOval(
                            color = Color.White.copy(alpha = 0.35f),
                            topLeft = Offset((w * 0.2f + cloudOrbitOffset) % w + ptzPanX, (h * 0.55f) + ptzPanY),
                            size = Size(140.dp.toPx() * ptzZoom, 35.dp.toPx() * ptzZoom)
                        )
                    }
                    "Urban" -> {
                        // Night city canyon
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF0A0F1E), Color(0xFF141C30)),
                                startY = 0f,
                                endY = h * 0.6f
                            ),
                            topLeft = Offset(0f, 0f),
                            size = Size(w, h * 0.6f)
                        )
                        drawRect(
                            color = Color(0xFF070B14),
                            topLeft = Offset(0f, h * 0.6f),
                            size = Size(w, h * 0.4f)
                        )

                        // Skyscraper silhouettes with illuminated neon windows
                        val buildings = listOf(
                            Triple(0.1f, 0.45f, Color(0xFF00F0FF)),
                            Triple(0.35f, 0.6f, Color(0xFFFF0055)),
                            Triple(0.65f, 0.5f, Color(0xFFFFCC00)),
                            Triple(0.85f, 0.4f, Color(0xFF39FF14))
                        )
                        buildings.forEach { (xPct, heightPct, neon) ->
                            val bx = (w * xPct) + ptzPanX
                            val bTop = (h * (1f - heightPct)) + ptzPanY
                            val bWidth = 40.dp.toPx() * ptzZoom
                            val bHeight = (h * heightPct) * ptzZoom

                            drawRect(Color(0xFF0C1322), Offset(bx - bWidth / 2f, bTop), Size(bWidth, bHeight))
                            drawRect(neon.copy(alpha = 0.4f), Offset(bx - bWidth / 2f, bTop), Size(bWidth, bHeight), style = Stroke(1f))
                            // Neon beacon atop
                            drawCircle(color = neon, radius = 3.dp.toPx(), center = Offset(bx, bTop))
                        }
                    }
                    else -> {
                        // Facility / Spaceport / Polar
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF060F1A), Color(0xFF0E2238)),
                                startY = 0f,
                                endY = h
                            ),
                            topLeft = Offset(0f, 0f),
                            size = Size(w, h)
                        )
                        // Gantry / Facility structure lines
                        val cx = (w / 2f) + ptzPanX
                        val cy = (h * 0.6f) + ptzPanY
                        drawLine(Color(0xFF00F0FF).copy(alpha = 0.5f), Offset(cx - 60.dp.toPx(), cy), Offset(cx + 60.dp.toPx(), cy), strokeWidth = 2f)
                        drawLine(Color(0xFF39FF14).copy(alpha = 0.5f), Offset(cx, cy - 80.dp.toPx()), Offset(cx, cy), strokeWidth = 2f)
                    }
                }

                // CRT Scanline Sweeping Effect
                val scanY = scanlineY * h
                drawLine(
                    color = Color(0xFF00F0FF).copy(alpha = 0.25f),
                    start = Offset(0f, scanY),
                    end = Offset(w, scanY),
                    strokeWidth = 2.5f
                )

                // Tactical Reticle
                val rSize = 18.dp.toPx()
                drawCircle(color = Color(0xFF00F0FF).copy(alpha = 0.3f), radius = rSize, center = Offset(w / 2f, h / 2f), style = Stroke(1f))
                drawLine(Color(0xFF00F0FF).copy(alpha = 0.5f), Offset(w / 2f - 6.dp.toPx(), h / 2f), Offset(w / 2f + 6.dp.toPx(), h / 2f), strokeWidth = 1f)
                drawLine(Color(0xFF00F0FF).copy(alpha = 0.5f), Offset(w / 2f, h / 2f - 6.dp.toPx()), Offset(w / 2f, h / 2f + 6.dp.toPx()), strokeWidth = 1f)
            }

            // Top Status Bar Overlay (Live Dot & Timestamp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopStart)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Color(0xFFFF0055).copy(alpha = liveBlink), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "LIVE FEED",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFF0055),
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Badge(containerColor = Color(0xFF002430), contentColor = Color(0xFF00F0FF)) {
                        Text(activeCam.resolution, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                Text(
                    text = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date()),
                    fontSize = 8.sp,
                    color = Color(0xFF39FF14),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            // Bottom-Left Telemetry Overlay
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            ) {
                Text(
                    text = "SRC: [${activeCam.id.uppercase()}] ${activeCam.title}",
                    fontSize = 9.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "BITRATE: ${activeCam.bitrateKbps} kbps | FPS: ${activeCam.fps} | PTZ: ${"%.1f".format(ptzZoom)}x",
                    fontSize = 7.sp,
                    color = Color(0xFF94A3B8),
                    fontFamily = FontFamily.Monospace
                )
            }

            // Bottom-Right PTZ Controls
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                IconButton(
                    onClick = { ptzPanY -= 20f },
                    modifier = Modifier.size(22.dp).background(Color(0xFF08121E).copy(alpha = 0.8f), CircleShape)
                ) {
                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Tilt Up", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(
                        onClick = { ptzPanX -= 20f },
                        modifier = Modifier.size(22.dp).background(Color(0xFF08121E).copy(alpha = 0.8f), CircleShape)
                    ) {
                        Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Pan Left", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                    }
                    IconButton(
                        onClick = {
                            ptzZoom = 1.0f
                            ptzPanX = 0f
                            ptzPanY = 0f
                        },
                        modifier = Modifier.size(22.dp).background(Color(0xFF08121E).copy(alpha = 0.8f), CircleShape)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset PTZ", tint = Color(0xFF39FF14), modifier = Modifier.size(14.dp))
                    }
                    IconButton(
                        onClick = { ptzPanX += 20f },
                        modifier = Modifier.size(22.dp).background(Color(0xFF08121E).copy(alpha = 0.8f), CircleShape)
                    ) {
                        Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Pan Right", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                    }
                }
                IconButton(
                    onClick = { ptzPanY += 20f },
                    modifier = Modifier.size(22.dp).background(Color(0xFF08121E).copy(alpha = 0.8f), CircleShape)
                ) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Tilt Down", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = { ptzZoom = (ptzZoom + 0.2f).coerceAtMost(3.0f) },
                        modifier = Modifier.size(22.dp).background(Color(0xFF08121E).copy(alpha = 0.8f), CircleShape)
                    ) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                    }
                    IconButton(
                        onClick = { ptzZoom = (ptzZoom - 0.2f).coerceAtLeast(1.0f) },
                        modifier = Modifier.size(22.dp).background(Color(0xFF08121E).copy(alpha = 0.8f), CircleShape)
                    ) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        // Camera Feed Details & Audio Briefing Card
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF080D18),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(activeCam.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF))
                    Button(
                        onClick = {
                            val speech = "World Cam ${activeCam.title}, located in ${activeCam.location}, ${activeCam.country}. Stream status: ${activeCam.status}. Telemetry: ${activeCam.fps} frames per second at ${activeCam.resolution}. ${activeCam.description}"
                            onSpeak(speech)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003F4D)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Audio Feed", fontSize = 8.sp, color = Color(0xFF00F0FF))
                    }
                }

                Text(
                    text = "${activeCam.location} • ${activeCam.country} • Lat: ${activeCam.latitude}° Lon: ${activeCam.longitude}°",
                    fontSize = 8.sp,
                    color = Color(0xFF39FF14),
                    fontFamily = FontFamily.Monospace
                )

                Text(
                    text = activeCam.description,
                    fontSize = 9.sp,
                    color = Color(0xFFCBD5E1),
                    lineHeight = 13.sp
                )
            }
        }
    }
}
