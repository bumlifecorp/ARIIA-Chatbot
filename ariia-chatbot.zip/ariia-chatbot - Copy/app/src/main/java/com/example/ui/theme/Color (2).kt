package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI Palette
val ImmersiveBg = Color(0xFF1C1B1F)
val ImmersiveSurface = Color(0xFF2B2930)
val ImmersiveCardBg = Color(0xFF211F26)
val ImmersiveBorder = Color(0xFF49454F)
val ImmersiveDivider = Color(0xFF49454F)

// Accent Colors
val ImmersiveLavender = Color(0xFFD0BCFF)
val ImmersiveOnLavender = Color(0xFF381E72)
val ImmersiveLavenderContainer = Color(0xFF4F378B)
val ImmersiveOnLavenderContainer = Color(0xFFEADDFF)

// Text Colors
val ImmersiveTextPrimary = Color(0xFFE6E1E5)
val ImmersiveTextSecondary = Color(0xFFC9C5D0)
val ImmersiveTextMuted = Color(0xFF938F99)

// Status Accents
val ImmersiveEmerald = Color(0xFF80DCA0)
val ImmersiveAmber = Color(0xFFFFD56B)
val ImmersiveRose = Color(0xFFF2B8B5)

// Aliases for compatibility
val CyberBlack = ImmersiveBg
val CyberDarkSurface = ImmersiveSurface
val CyberCardBg = ImmersiveCardBg
val CyberCardBorder = ImmersiveBorder

val NeonCyan = ImmersiveLavender
val NeonCyanDim = Color(0x33D0BCFF)
val NeonPurple = ImmersiveLavender
val NeonEmerald = ImmersiveEmerald
val NeonAmber = ImmersiveAmber
val NeonRose = ImmersiveRose

val TextPrimary = ImmersiveTextPrimary
val TextSecondary = ImmersiveTextSecondary
val TextMuted = ImmersiveTextMuted

