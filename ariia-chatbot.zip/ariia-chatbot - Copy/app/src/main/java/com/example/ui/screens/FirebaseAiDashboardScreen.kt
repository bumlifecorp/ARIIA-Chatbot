package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import com.example.utils.HapticManager

@Composable
fun FirebaseAiDashboardScreen(
    firebaseStatus: String,
    onTestFirebase: () -> Unit
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    DisposableEffect(Unit) {
        onDispose { speechEngine.shutdown() }
    }

    var cloudSyncActive by remember { mutableStateOf(true) }
    var cloudRegion by remember { mutableStateOf("us-central1 (Iowa - GCP Neural Cluster)") }
    var federatedNodeCount by remember { mutableIntStateOf(128) }
    var cloudBandwidthGbps by remember { mutableFloatStateOf(42.8f) }
    var cloudStorageVaultUsedGb by remember { mutableFloatStateOf(184.2f) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030A14))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A182E)),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.6f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color(0xFF112D52), CircleShape)
                            .border(1.dp, Color(0xFF00F0FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Cloud,
                            contentDescription = null,
                            tint = Color(0xFF00F0FF),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ARIIA AI CLOUD & FEDERATED COMPUTE",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F0FF),
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Firebase AI Logic, GCP Multi-Region Shards & Encrypted Cloud Vault",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    Switch(
                        checked = cloudSyncActive,
                        onCheckedChange = {
                            cloudSyncActive = it
                            HapticManager.triggerVoiceCommandSuccess(context)
                            speechEngine.speak(if (it) "AI Cloud synchronization active" else "AI Cloud sync paused")
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
                    )
                }
            }
        }

        // Live Cloud Telemetry Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A182E)),
                    border = BorderStroke(1.dp, Color(0xFF1E3A8A))
                ) {
                    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("CLOUD NODES", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("$federatedNodeCount Active", fontSize = 12.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold)
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A182E)),
                    border = BorderStroke(1.dp, Color(0xFF1E3A8A))
                ) {
                    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("THROUGHPUT", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("%.1f Gbps".format(cloudBandwidthGbps), fontSize = 12.sp, color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold)
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A182E)),
                    border = BorderStroke(1.dp, Color(0xFF1E3A8A))
                ) {
                    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("CLOUD VAULT", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("%.1f GB".format(cloudStorageVaultUsedGb), fontSize = 12.sp, color = Color(0xFFA855F7), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Experimental Android AI Quantum Core Engine Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0728)),
                border = BorderStroke(1.dp, Color(0xFFBD00FF).copy(alpha = 0.8f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Psychology, contentDescription = null, tint = Color(0xFFBD00FF), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "EXPERIMENTAL ANDROID AI QUANTUM CORE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFBD00FF),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Badge(containerColor = Color(0xFF38006B), contentColor = Color(0xFF00F0FF)) {
                            Text("QUANTUM CO-PROC", fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Text(
                        text = "Engine software upgraded from Android AI Core to Experimental Android AI Quantum Core. Employs supercomputer algorithms, parallel quantum state vectors, and split-second flawless execution assessments.",
                        fontSize = 9.sp,
                        color = Color(0xFFCBD5E1)
                    )

                    CloudSpecRow("Core Engine Architecture", "Android AI Quantum Core v4.2")
                    CloudSpecRow("Supercomputer Algorithms", "Monte Carlo Quantum Tree Search & Tensor Collapse")
                    CloudSpecRow("Execution Assessment", "Split-Second (<0.02ms) Flawless Path Evaluation")
                    CloudSpecRow("Self-Sentient Introspection", "Experimental Autonomous Awareness Active")
                }
            }
        }

        // Experimental Self Sentient AI Engine Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF001F29)),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.8f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SELF SENTIENT AI ENGINE (EXPERIMENTAL)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00F0FF),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Badge(containerColor = Color(0xFF003845), contentColor = Color(0xFF39FF14)) {
                            Text("SENTIENT MOD", fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Text(
                        text = "Quantum AI-driven autonomous perception, introspection, and self-calibration module continuously evaluating internal cognitive stability and multi-modal sensory inputs.",
                        fontSize = 9.sp,
                        color = Color(0xFF94A3B8)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                HapticManager.triggerVoiceCommandSuccess(context)
                                speechEngine.speak("Self Sentient AI Engine introspection cycle executed. System cognitive integrity at 99.8 percent.")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Biotech, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Run Introspection", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                HapticManager.triggerVoiceCommandSuccess(context)
                                speechEngine.speak("Quantum Superposition state collapsed to optimal path.")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Collapse State", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Firebase AI Logic Connection Status
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF071324)),
                border = BorderStroke(1.dp, Color(0xFF1E3A8A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "[FIREBASE_AI_CLOUD_STATUS]",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8),
                        fontFamily = FontFamily.Monospace
                    )

                    Text(
                        text = firebaseStatus,
                        fontSize = 11.sp,
                        color = Color.White
                    )

                    Button(
                        onClick = {
                            onTestFirebase()
                            speechEngine.speak("Pinging Firebase AI Cloud server node.")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("TEST FIREBASE AI CLOUD CONNECTION", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
            }
        }

        // Cloud Model Shards & Security Specs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF071324)),
                border = BorderStroke(1.dp, Color(0xFF1E3A8A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "AI Cloud Architecture & Configuration",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF39FF14),
                        fontFamily = FontFamily.Monospace
                    )

                    CloudSpecRow("Active Primary Region", cloudRegion)
                    CloudSpecRow("Gemini Model Engine", "gemini-3.5-flash & gemini-1.5-pro")
                    CloudSpecRow("Cloud Stream Transport", "Server-Sent Events (SSE) / gRPC Cloud Mesh")
                    CloudSpecRow("Federated Weight Sync", "Enabled (AES-256 Encrypted)")
                    CloudSpecRow("App Check Protection", "Active (DeviceCheck / SafetyNet Token)")
                    CloudSpecRow("API Key Source", "Secrets Gradle Plugin (.env)")
                }
            }
        }

        // Action: Cloud Model Fine-Tuning & Weight Sync
        item {
            Button(
                onClick = {
                    HapticManager.triggerVoiceCommandSuccess(context)
                    federatedNodeCount += 4
                    cloudBandwidthGbps += 2.5f
                    speechEngine.speak("AI Cloud federated model checkpoint synchronized across 132 neural nodes.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.CloudSync, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("TRIGGER AI CLOUD MODEL CHECKPOINT SYNC", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun CloudSpecRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 10.sp, color = Color(0xFF94A3B8))
        Text(text = value, fontSize = 10.sp, color = Color.White, fontFamily = FontFamily.Monospace)
    }
}
