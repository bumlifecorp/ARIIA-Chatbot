package com.example.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

enum class BrokerProtocol(val defaultPort: Int) {
    MQTT(1883),
    APACHE_KAFKA(9092)
}

enum class QoSLevel(val level: Int, val label: String) {
    AT_MOST_ONCE(0, "QoS 0 - Fire & Forget"),
    AT_LEAST_ONCE(1, "QoS 1 - Acknowledged Delivery"),
    EXACTLY_ONCE(2, "QoS 2 - Assured Exactly Once")
}

data class PubSubMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val topic: String,
    val payload: String,
    val senderId: String,
    val qos: QoSLevel = QoSLevel.AT_LEAST_ONCE,
    val timestamp: Long = System.currentTimeMillis()
)

data class EndpointTelemetry(
    val endpointId: String,
    val unitType: String,
    val sector: String,
    val latitude: Double,
    val longitude: Double,
    val batteryPercent: Int,
    val signalDbm: Int,
    val status: String,
    val lastPingTime: Long
)

class PubSubBrokerClient(private val scope: CoroutineScope) {

    private val _currentBroker = MutableStateFlow(BrokerProtocol.MQTT)
    val currentBroker: StateFlow<BrokerProtocol> = _currentBroker.asStateFlow()

    private val _isConnected = MutableStateFlow(true)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _subscribedTopics = MutableStateFlow<Set<String>>(
        setOf(
            "tactical/surveillance/nodes/telemetry",
            "tactical/perimeter/alerts",
            "public_safety/anomalies/events",
            "sensors/gps/broadcasting"
        )
    )
    val subscribedTopics: StateFlow<Set<String>> = _subscribedTopics.asStateFlow()

    private val _receivedMessages = MutableStateFlow<List<PubSubMessage>>(emptyList())
    val receivedMessages: StateFlow<List<PubSubMessage>> = _receivedMessages.asStateFlow()

    private val _activeEndpoints = MutableStateFlow<List<EndpointTelemetry>>(emptyList())
    val activeEndpoints: StateFlow<List<EndpointTelemetry>> = _activeEndpoints.asStateFlow()

    private val _totalMessagesProcessed = MutableStateFlow(14250L)
    val totalMessagesProcessed: StateFlow<Long> = _totalMessagesProcessed.asStateFlow()

    private var broadcastJob: Job? = null

    init {
        initializeSyntheticEndpoints()
        startEndpointBroadcastSimulation()
    }

    private fun initializeSyntheticEndpoints() {
        val initialEndpoints = mutableListOf<EndpointTelemetry>()
        val sectors = listOf("Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Perimeter-Core")
        val types = listOf("Patrol Drone", "ANPR Sensor", "Acoustic Node", "Mobile Recon", "Static Optical")

        for (i in 1..12) {
            val sector = sectors[i % sectors.size]
            val type = types[i % types.size]
            val lat = 34.0522 + (Random.nextDouble(-0.08, 0.08))
            val lon = -118.2437 + (Random.nextDouble(-0.08, 0.08))
            initialEndpoints.add(
                EndpointTelemetry(
                    endpointId = "EP-$sector-${String.format(Locale.US, "%03d", i)}",
                    unitType = type,
                    sector = "Sector $sector",
                    latitude = lat,
                    longitude = lon,
                    batteryPercent = Random.nextInt(65, 100),
                    signalDbm = Random.nextInt(-85, -55),
                    status = "ONLINE - BROADCASTING",
                    lastPingTime = System.currentTimeMillis()
                )
            )
        }
        _activeEndpoints.value = initialEndpoints
    }

    private fun startEndpointBroadcastSimulation() {
        broadcastJob?.cancel()
        broadcastJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(2200)
                if (!_isConnected.value) continue

                // Pick a random endpoint to broadcast status over MQTT/Kafka
                val endpoints = _activeEndpoints.value.toMutableList()
                if (endpoints.isNotEmpty()) {
                    val idx = Random.nextInt(endpoints.size)
                    val ep = endpoints[idx]
                    val updatedEp = ep.copy(
                        batteryPercent = (ep.batteryPercent - (if (Random.nextFloat() > 0.85f) 1 else 0)).coerceAtLeast(15),
                        signalDbm = Random.nextInt(-90, -50),
                        lastPingTime = System.currentTimeMillis()
                    )
                    endpoints[idx] = updatedEp
                    _activeEndpoints.value = endpoints

                    val topic = "tactical/surveillance/nodes/telemetry"
                    val payload = "{\"endpointId\":\"${ep.endpointId}\",\"unit\":\"${ep.unitType}\",\"lat\":${String.format(Locale.US, "%.4f", updatedEp.latitude)},\"lon\":${String.format(Locale.US, "%.4f", updatedEp.longitude)},\"bat\":${updatedEp.batteryPercent},\"sig\":${updatedEp.signalDbm}}"
                    publish(topic, payload, ep.endpointId, QoSLevel.AT_LEAST_ONCE)
                }
            }
        }
    }

    fun switchBroker(protocol: BrokerProtocol) {
        _currentBroker.value = protocol
        val message = PubSubMessage(
            topic = "broker/system/lifecycle",
            payload = "Switched broker engine to ${protocol.name} (Port ${protocol.defaultPort}). Subscriptions re-established.",
            senderId = "LOCAL_HUB",
            qos = QoSLevel.EXACTLY_ONCE
        )
        deliverMessage(message)
    }

    fun publish(topic: String, payload: String, senderId: String = "OPERATOR_CONSOLE", qos: QoSLevel = QoSLevel.AT_LEAST_ONCE) {
        val msg = PubSubMessage(
            topic = topic,
            payload = payload,
            senderId = senderId,
            qos = qos
        )
        _totalMessagesProcessed.value += 1
        if (_subscribedTopics.value.any { it == topic || it == "#" || (it.endsWith("/#") && topic.startsWith(it.removeSuffix("/#"))) }) {
            deliverMessage(msg)
        }
    }

    fun subscribe(topic: String) {
        val set = _subscribedTopics.value.toMutableSet()
        set.add(topic)
        _subscribedTopics.value = set
    }

    fun unsubscribe(topic: String) {
        val set = _subscribedTopics.value.toMutableSet()
        set.remove(topic)
        _subscribedTopics.value = set
    }

    private fun deliverMessage(msg: PubSubMessage) {
        val current = _receivedMessages.value.toMutableList()
        if (current.size > 50) current.removeAt(0)
        current.add(msg)
        _receivedMessages.value = current
    }
}
