package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val AmoledUvNeonColorScheme =
  darkColorScheme(
      primary = Color(0xFFBD00FF), // Electric Violet
      onPrimary = Color.White,
      primaryContainer = Color(0xFF38006B),
      onPrimaryContainer = Color(0xFFF3E5F5),
      secondary = Color(0xFF00F0FF), // UV Neon Cyan
      onSecondary = Color(0xFF000000),
      secondaryContainer = Color(0xFF00363D),
      onSecondaryContainer = Color(0xFFE0F7FA),
      tertiary = Color(0xFF39FF14), // Neon Lime
      onTertiary = Color(0xFF000000),
      tertiaryContainer = Color(0xFF0A3800),
      onTertiaryContainer = Color(0xFFF1F8E9),
      background = Color(0xFF000000), // Pure AMOLED Pitch Black
      onBackground = Color(0xFFE2E8F0),
      surface = Color(0xFF0A0A0E),
      onSurface = Color(0xFFF8FAFC),
      surfaceVariant = Color(0xFF14141C),
      onSurfaceVariant = Color(0xFF94A3B8),
      outline = Color(0xFF334155)
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false, // Default to AMOLED UV Neon theme as requested!
  content: @Composable () -> Unit,
) {
  val colorScheme = AmoledUvNeonColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
