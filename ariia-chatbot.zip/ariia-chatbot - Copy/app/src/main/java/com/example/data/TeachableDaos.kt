package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import kotlinx.coroutines.flow.Flow

@Dao
interface SpeechReminderDao {
    @Query("SELECT * FROM speech_reminders ORDER BY id DESC")
    fun getAllReminders(): Flow<List<SpeechReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: SpeechReminderEntity): Long

    @Update
    suspend fun updateReminder(reminder: SpeechReminderEntity)

    @Delete
    suspend fun deleteReminder(reminder: SpeechReminderEntity)

    @Query("DELETE FROM speech_reminders")
    suspend fun clearAll()
}

@Dao
interface TeachableVoiceCommandDao {
    @Query("SELECT * FROM teachable_voice_commands ORDER BY id DESC")
    fun getAllCommands(): Flow<List<TeachableVoiceCommandEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommand(command: TeachableVoiceCommandEntity): Long

    @Delete
    suspend fun deleteCommand(command: TeachableVoiceCommandEntity)

    @Query("SELECT * FROM teachable_voice_commands")
    suspend fun getAllCommandsList(): List<TeachableVoiceCommandEntity>
}

@Dao
interface TrainedVisionObjectDao {
    @Query("SELECT * FROM trained_vision_objects ORDER BY id DESC")
    fun getAllTrainedObjects(): Flow<List<TrainedVisionObjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrainedObject(obj: TrainedVisionObjectEntity): Long

    @Delete
    suspend fun deleteTrainedObject(obj: TrainedVisionObjectEntity)

    @Query("SELECT * FROM trained_vision_objects")
    suspend fun getAllObjectsList(): List<TrainedVisionObjectEntity>
}
