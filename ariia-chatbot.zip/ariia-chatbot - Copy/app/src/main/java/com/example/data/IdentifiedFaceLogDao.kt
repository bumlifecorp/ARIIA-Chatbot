package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface IdentifiedFaceLogDao {
    @Query("SELECT * FROM identified_faces_log ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<IdentifiedFaceLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: IdentifiedFaceLogEntity)

    @Query("DELETE FROM identified_faces_log")
    suspend fun clearLogs()
}
