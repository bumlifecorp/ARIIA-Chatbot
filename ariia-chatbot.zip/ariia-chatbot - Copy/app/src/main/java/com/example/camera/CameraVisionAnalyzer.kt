package com.example.camera

import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.example.model.DetectedObjectInfo
import com.example.model.NormalizedRect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions

class CameraVisionAnalyzer(
    private val onObjectsDetected: (List<DetectedObjectInfo>, String) -> Unit,
    private val getConfidenceThreshold: () -> Int = { 60 }
) : ImageAnalysis.Analyzer {

    private val options = ObjectDetectorOptions.Builder()
        .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
        .enableClassification()
        .enableMultipleObjects()
        .build()

    private val detector = ObjectDetection.getClient(options)

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val rotationDegrees = imageProxy.imageInfo.rotationDegrees
        val image = InputImage.fromMediaImage(mediaImage, rotationDegrees)
        
        // Calculate image dimensions accounting for rotation
        val isRotated = rotationDegrees == 90 || rotationDegrees == 270
        val imageWidth = if (isRotated) mediaImage.height.toFloat() else mediaImage.width.toFloat()
        val imageHeight = if (isRotated) mediaImage.width.toFloat() else mediaImage.height.toFloat()

        detector.process(image)
            .addOnSuccessListener { detectedObjects ->
                if (detectedObjects.isEmpty()) {
                    onObjectsDetected(emptyList(), "Inget objekt identifierat")
                } else {
                    val results = mutableListOf<DetectedObjectInfo>()
                    val summaryList = mutableListOf<String>()

                    detectedObjects.forEachIndexed { index, obj ->
                        val box = obj.boundingBox
                        val normRect = if (imageWidth > 0 && imageHeight > 0) {
                            NormalizedRect(
                                left = (box.left.toFloat() / imageWidth).coerceIn(0f, 1f),
                                top = (box.top.toFloat() / imageHeight).coerceIn(0f, 1f),
                                right = (box.right.toFloat() / imageWidth).coerceIn(0f, 1f),
                                bottom = (box.bottom.toFloat() / imageHeight).coerceIn(0f, 1f)
                            )
                        } else null

                        val topLabel = obj.labels.maxByOrNull { it.confidence }
                        val labelText = topLabel?.text ?: "Okänt objekt"
                        val confidence = topLabel?.let { (it.confidence * 100).toInt() } ?: 60
                        if (confidence < getConfidenceThreshold()) return@forEachIndexed

                        results.add(
                            DetectedObjectInfo(
                                id = index,
                                label = labelText,
                                confidence = confidence,
                                boundingBoxRatio = normRect
                            )
                        )

                        if (topLabel != null) {
                            summaryList.add("$labelText ($confidence%)")
                        } else {
                            summaryList.add("Objekt #$index")
                        }
                    }

                    val summary = if (summaryList.isNotEmpty()) {
                        "Identifierat: ${summaryList.joinToString(", ")}"
                    } else {
                        "Objekt hittat (okänd kategori)"
                    }

                    onObjectsDetected(results, summary)
                }
            }
            .addOnFailureListener {
                // Ignore transient frame analysis errors
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }
}
