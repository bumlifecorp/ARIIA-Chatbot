package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "painted_objects")
data class PaintedObjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String, // "PERSON", "VEHICLE", "DRONE", "VESSEL", "FACILITY"
    val paintColorHex: String, // e.g. "#00F0FF"
    val paintColorName: String, // e.g. "Cyan Hunter"
    val priority: String, // "CRITICAL_P1", "HIGH_P2", "CONTINUOUS_P3"
    val facialMatchScore: Float,
    val facialProfileId: String,
    val coordinates: String,
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Double,
    val velocityKmh: Float,
    val headingDegrees: Float,
    val currentFeedId: String,
    val currentFeedName: String,
    val lockStatus: String, // "LOCKED_DRYING", "STABLE_TRACK", "SATELLITE_HANDOFF"
    val dryStatusPercent: Int,
    val isMonitoring: Boolean,
    val detectionSource: String,
    val notes: String,
    val timestamp: Long = System.currentTimeMillis()
)
