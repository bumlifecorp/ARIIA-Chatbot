package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import com.example.utils.HapticManager
import kotlinx.coroutines.delay

enum class ChefProtocol(val title: String, val badge: String, val icon: @Composable () -> Unit) {
    FLAVOR_MATRIX("CBRN Ration Matrix", "CALORIE & TOXIN AUDIT", { Icon(Icons.Default.Biotech, contentDescription = null) }),
    SOUS_VIDE("Thermal Decontamination", "STERILIZATION", { Icon(Icons.Default.Thermostat, contentDescription = null) }),
    ZERO_WASTE("Tactical Stock Depot", "DEPOT INVENTORY", { Icon(Icons.Default.Inventory, contentDescription = null) }),
    SEAR_CALIBRATION("Thermal Incineration", "INCINERATION", { Icon(Icons.Default.Whatshot, contentDescription = null) }),
    SOMMELIER("Field Garrison Logistics", "FIELD MESS", { Icon(Icons.Default.LocalDining, contentDescription = null) })
}

@Composable
fun ChefProgramScreen(
    onNavigateTab: (Int) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    DisposableEffect(Unit) {
        onDispose { speechEngine.shutdown() }
    }

    var activeProtocol by remember { mutableStateOf(ChefProtocol.FLAVOR_MATRIX) }
    var isAutomationEngineActive by remember { mutableStateOf(true) }

    // Field Ration & CBRN Defense States
    var rationPurityPct by remember { mutableFloatStateOf(99.4f) }
    var targetDeconTempC by remember { mutableFloatStateOf(85.0f) }
    var actualDeconTempC by remember { mutableFloatStateOf(84.8f) }
    var calorieOutputKcal by remember { mutableIntStateOf(3400) }

    // Thermal Sterilization States
    var isSterilizing by remember { mutableStateOf(false) }

    // Automation Decision Loop
    LaunchedEffect(isAutomationEngineActive) {
        while (isAutomationEngineActive) {
            delay(2800)
            if (actualDeconTempC < targetDeconTempC - 2f) {
                actualDeconTempC += 0.5f
            }
            rationPurityPct = 98.5f + (kotlin.random.Random.nextFloat() * 1.4f)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF040A12))
            .padding(12.dp)
    ) {
        // Program Header Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1626)),
            border = BorderStroke(1.dp, Color(0xFF1B365D)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(0xFF11223A), CircleShape)
                        .border(1.dp, Color(0xFFFF8C00), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Biotech,
                        contentDescription = null,
                        tint = Color(0xFFFF8C00),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "[FIELD_RATION_DEFENSE]",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = Color(0xFFFF8C00).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "CBRN MESS OPS",
                                fontSize = 8.sp,
                                color = Color(0xFFFF8C00),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Text(
                        text = "CBRN Field Ration Defense, Decontamination & Garrison Logistics",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("ENGINE", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Switch(
                        checked = isAutomationEngineActive,
                        onCheckedChange = {
                            isAutomationEngineActive = it
                            speechEngine.speak(if (it) "Field Ration Defense Automation Engine active" else "Automation paused")
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFFF8C00))
                    )
                }
            }
        }

        // Quick Stats Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ChefStatChip("RATION PURITY", "%.1f%%".format(rationPurityPct), Color(0xFF39FF14), Modifier.weight(1f))
            ChefStatChip("DECON TEMP", "%.1f°C".format(actualDeconTempC), Color(0xFFFF8C00), Modifier.weight(1f))
            ChefStatChip("ENERGY YIELD", "$calorieOutputKcal kcal", Color(0xFF00F0FF), Modifier.weight(1f))
            ChefStatChip("DEPOT AUDIT", "NOMINAL", Color(0xFFA855F7), Modifier.weight(1f))
        }

        // Protocol Selector Navigation Tabs
        LazyRow(
            modifier = Modifier.padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ChefProtocol.values()) { protocol ->
                val isSelected = activeProtocol == protocol
                Card(
                    modifier = Modifier.clickable {
                        activeProtocol = protocol
                        HapticManager.triggerVoiceCommandInitiation(context)
                        speechEngine.speak("Switched to ${protocol.title}")
                    },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFFFF8C00).copy(alpha = 0.2f) else Color(0xFF0B1626)
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) Color(0xFFFF8C00) else Color(0xFF1B365D)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        protocol.icon()
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = protocol.title,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        // Active Protocol Detail Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (activeProtocol) {
                ChefProtocol.FLAVOR_MATRIX -> CBRNRationMatrixContent(
                    rationPurity = rationPurityPct,
                    calorieKcal = calorieOutputKcal,
                    onAnalyzeRations = {
                        HapticManager.triggerVoiceCommandSuccess(context)
                        speechEngine.speak("CBRN Field Ration Matrix scan complete. Zero chemical neurotoxins detected. Calorie density optimized to 3,400 kilocalories per unit.")
                    }
                )

                ChefProtocol.SOUS_VIDE -> ThermalDeconContent(
                    targetTemp = targetDeconTempC,
                    actualTemp = actualDeconTempC,
                    isSterilizing = isSterilizing,
                    onToggleDecon = {
                        isSterilizing = !isSterilizing
                        speechEngine.speak(if (isSterilizing) "Thermal decontamination bath active at 85 degrees Celsius." else "Thermal decontamination paused.")
                    }
                )

                ChefProtocol.ZERO_WASTE -> TacticalDepotContent()
                ChefProtocol.SEAR_CALIBRATION -> ThermalIncinerationContent()
                ChefProtocol.SOMMELIER -> FieldGarrisonMessContent()
            }
        }
    }
}

@Composable
fun ChefStatChip(label: String, value: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1626)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 11.sp, color = color, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CBRNRationMatrixContent(
    rationPurity: Float,
    calorieKcal: Int,
    onAnalyzeRations: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[CBRN_RATION_MATRIX] - Combat Chemical Neutralization & Calorie Audit",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF8C00),
                fontFamily = FontFamily.Monospace
            )

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("TOXIN SPECTROGRAPH AUDIT", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text("Chemical Contaminant Screening: Purity %.1f%%".format(rationPurity), fontSize = 11.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onAnalyzeRations,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8C00)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Biotech, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RUN CBRN SPECTROGRAPH & CALORIE SCAN", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ThermalDeconContent(
    targetTemp: Float,
    actualTemp: Float,
    isSterilizing: Boolean,
    onToggleDecon: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[THERMAL_DECONTAMINATION] - Precision Field Sterilization Controller",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF8C00),
                fontFamily = FontFamily.Monospace
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("ACTUAL BATH TEMP", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text("%.1f°C".format(actualTemp), fontSize = 12.sp, color = Color(0xFFFF8C00), fontWeight = FontWeight.Bold)
                    }
                }
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("TARGET DECON TEMP", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text("%.1f°C".format(targetTemp), fontSize = 12.sp, color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold)
                    }
                }
            }

            Button(
                onClick = onToggleDecon,
                colors = ButtonDefaults.buttonColors(containerColor = if (isSterilizing) Color(0xFFFF0055) else Color(0xFFFF8C00)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Thermostat, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isSterilizing) "STOP THERMAL DECONTAMINATION" else "START THERMAL STERILIZATION BATH", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun TacticalDepotContent() {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[TACTICAL_STOCK_DEPOT] - Inventory Audit & Ration Generator",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF8C00),
                fontFamily = FontFamily.Monospace
            )
            Text("Depot Level: 14,200 High-Calorie Combat Packs Available", fontSize = 11.sp, color = Color.White)
        }
    }
}

@Composable
fun ThermalIncinerationContent() {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[THERMAL_INCINERATION] - High-Temp Waste Sterilization",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF8C00),
                fontFamily = FontFamily.Monospace
            )
            Text("Incinerator Core: 1,200°C Active | Zero Bio-Waste Contamination", fontSize = 11.sp, color = Color.White)
        }
    }
}

@Composable
fun FieldGarrisonMessContent() {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[FIELD_GARRISON_LOGISTICS] - Combat Mess & Hydration Radar",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF8C00),
                fontFamily = FontFamily.Monospace
            )
            Text("Garrison Hydration & Electrolyte Levels: 100% Optimal", fontSize = 11.sp, color = Color.White)
        }
    }
}
