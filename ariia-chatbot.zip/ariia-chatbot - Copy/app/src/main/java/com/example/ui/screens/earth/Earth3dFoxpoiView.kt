package com.example.ui.screens.earth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.VoiceActionExecutor
import kotlin.math.*

data class FoxpoiPoiItem(
    val id: String,
    val name: String,
    val category: String,
    val rating: Float,
    val lat: Float,
    val lon: Float,
    val city: String,
    val country: String,
    val description: String
)

@Composable
fun Earth3dFoxpoiView(
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val foxpoiCategories = remember {
        listOf("All POIs", "Landmarks", "Viewpoints", "Transit", "Hotels", "Dining")
    }
    var selectedCategory by remember { mutableStateOf("All POIs") }

    val foxpoiList = remember {
        listOf(
            FoxpoiPoiItem("fox-1", "Golden Gate Bridge 3D", "Landmarks", 4.9f, 37.8199f, -122.4783f, "San Francisco", "USA", "Iconic orange suspension bridge spanning the Golden Gate strait."),
            FoxpoiPoiItem("fox-2", "Mount Fuji Crest 3D", "Viewpoints", 5.0f, 35.3606f, 138.7274f, "Honshu", "Japan", "Active volcano and Japan's highest peak with snow-capped cone."),
            FoxpoiPoiItem("fox-3", "Sydney Opera House 3D", "Landmarks", 4.8f, -33.8568f, 151.2153f, "Sydney", "Australia", "Multi-venue performing arts centre in Sydney Harbour."),
            FoxpoiPoiItem("fox-4", "Machu Picchu Citadel 3D", "Landmarks", 5.0f, -13.1631f, -72.5450f, "Cusco", "Peru", "15th-century Inca citadel set high in the Andes Mountains."),
            FoxpoiPoiItem("fox-5", "Shibuya Crossing 3D", "Transit", 4.7f, 35.6595f, 139.7004f, "Tokyo", "Japan", "World's busiest pedestrian scramble crossing in Tokyo."),
            FoxpoiPoiItem("fox-6", "Burj Al Arab 3D", "Hotels", 4.9f, 25.1412f, 55.1852f, "Dubai", "UAE", "Sail-shaped luxury hotel on a private artificial island.")
        )
    }

    val filteredPois = remember(selectedCategory) {
        if (selectedCategory == "All POIs") foxpoiList
        else foxpoiList.filter { it.category == selectedCategory }
    }

    var selectedPoi by remember { mutableStateOf(foxpoiList[0]) }
    var pitchDeg by remember { mutableStateOf(50f) }
    var yawDeg by remember { mutableStateOf(30f) }
    var zoomLevel by remember { mutableStateOf(1.4f) }
    var show3dMesh by remember { mutableStateOf(true) }
    var showPoiPins by remember { mutableStateOf(true) }
    var showElevationContours by remember { mutableStateOf(true) }

    val infiniteTransition = rememberInfiniteTransition(label = "Foxpoi3DAnim")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse),
        label = "FoxpoiPulse"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF040B14))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // FoxPOI Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0D1B2A), RoundedCornerShape(10.dp))
                .border(1.dp, Color(0xFFFF9900), RoundedCornerShape(10.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Public, contentDescription = null, tint = Color(0xFFFF9900), modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text("FOXPOI EARTH 3D MAP", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFFF9900), fontFamily = FontFamily.Monospace)
                    Text("High-Precision 3D Mesh Terrain & Point-of-Interest Engine", fontSize = 8.sp, color = Color(0xFFCBD5E1))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        VoiceActionExecutor.launchGoogleEarth(context, selectedPoi.lat, selectedPoi.lon)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9900)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.Public, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Launch Earth 3D", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // POI Category Selector
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(foxpoiCategories) { cat ->
                val isSel = cat == selectedCategory
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) Color(0xFF331F00) else Color(0xFF0F172A),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFFFF9900) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable { selectedCategory = cat }
                ) {
                    Text(
                        text = cat,
                        fontSize = 8.sp,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSel) Color(0xFFFF9900) else Color(0xFFCBD5E1),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // 3D Viewport
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF02060D), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFFFF9900).copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        yawDeg = (yawDeg - dragAmount.x * 0.4f) % 360f
                        pitchDeg = (pitchDeg + dragAmount.y * 0.4f).coerceIn(10f, 85f)
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val center = Offset(w / 2f, h / 2f)

                // 3D Contour Grid Render
                val steps = 12
                val dx = w / steps
                val dy = h / steps

                for (i in 0..steps) {
                    val x = i * dx
                    drawLine(
                        color = Color(0xFFFF9900).copy(alpha = 0.2f),
                        start = Offset(x, 0f),
                        end = Offset(x, h),
                        strokeWidth = 1f
                    )
                }

                if (showElevationContours) {
                    val path = Path().apply {
                        moveTo(0f, h * 0.6f)
                        quadraticTo(w * 0.25f, h * 0.4f, w * 0.5f, h * 0.65f)
                        quadraticTo(w * 0.75f, h * 0.8f, w, h * 0.55f)
                    }
                    drawPath(path, color = Color(0xFF00F0FF).copy(alpha = 0.5f), style = Stroke(width = 2f))
                }

                // 3D POI Marker Pin Render
                if (showPoiPins) {
                    val pinX = center.x + sin(Math.toRadians(yawDeg.toDouble())).toFloat() * 40f
                    val pinY = center.y - cos(Math.toRadians(pitchDeg.toDouble())).toFloat() * 30f

                    // Draw Pin Drop Shadow & Pulsing Base
                    drawCircle(
                        color = Color(0xFFFF9900).copy(alpha = pulseAlpha),
                        radius = 18f * zoomLevel,
                        center = Offset(pinX, pinY)
                    )

                    drawCircle(
                        color = Color(0xFFFF9900),
                        radius = 6f,
                        center = Offset(pinX, pinY)
                    )

                    // Pin Stem
                    drawLine(
                        color = Color(0xFFFF9900),
                        start = Offset(pinX, pinY),
                        end = Offset(pinX, pinY - 45f),
                        strokeWidth = 3f
                    )

                    // Pin Head Badge
                    drawCircle(
                        color = Color(0xFFFF9900),
                        radius = 12f,
                        center = Offset(pinX, pinY - 45f)
                    )
                }
            }

            // HUD Metadata Card
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.8f),
                    border = BorderStroke(1.dp, Color(0xFFFF9900))
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text("FOXPOI 3D: ${selectedPoi.name}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9900))
                        Text("CAT: ${selectedPoi.category} | RATING: ★ ${selectedPoi.rating}", fontSize = 8.sp, color = Color.White)
                        Text("LAT: ${selectedPoi.lat}° | LON: ${selectedPoi.lon}° | ${selectedPoi.city}", fontSize = 8.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // View Controls Bottom Bar
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChip(
                    selected = show3dMesh,
                    onClick = { show3dMesh = !show3dMesh },
                    label = { Text("3D Mesh", fontSize = 8.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFF9900), selectedLabelColor = Color.Black)
                )
                FilterChip(
                    selected = showElevationContours,
                    onClick = { showElevationContours = !showElevationContours },
                    label = { Text("Contours", fontSize = 8.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF00F0FF), selectedLabelColor = Color.Black)
                )
            }
        }

        // POI Selection List
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filteredPois) { poi ->
                val isSel = poi.id == selectedPoi.id
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) Color(0xFF331F00) else Color(0xFF0F172A),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFFFF9900) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable {
                        selectedPoi = poi
                        onSpeak("Locked FoxPOI 3D viewport on ${poi.name} in ${poi.city}, ${poi.country}.")
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Place, contentDescription = null, tint = if (isSel) Color(0xFFFF9900) else Color(0xFF64748B), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(poi.name, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("${poi.city}, ${poi.country} • ★ ${poi.rating}", fontSize = 7.sp, color = Color(0xFF94A3B8))
                        }
                    }
                }
            }
        }

        // Active POI Briefing Card
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF0D1B2A),
            border = BorderStroke(1.dp, Color(0xFFFF9900).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("${selectedPoi.name} (${selectedPoi.category})", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9900))
                    Text(selectedPoi.description, fontSize = 8.sp, color = Color(0xFFCBD5E1))
                }

                Button(
                    onClick = {
                        val speech = "FoxPOI 3D view target ${selectedPoi.name} in ${selectedPoi.city}, ${selectedPoi.country}. Rating ${selectedPoi.rating} stars out of 5. Latitude ${selectedPoi.lat}, Longitude ${selectedPoi.lon}. ${selectedPoi.description}"
                        onSpeak(speech)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9900)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Audio Brief", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
