package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StreamPubSubSecurityScreen() {
    val coroutineScope = rememberCoroutineScope()

    val streamManager = remember { StreamIngestionManager(coroutineScope) }
    val pubSubBroker = remember { PubSubBrokerClient(coroutineScope) }
    val anomalyEngine = remember { PublicSafetyAnomalyEngine(coroutineScope, pubSubBroker) }

    val activeStream by streamManager.activeStream.collectAsState()
    val availableStreams by streamManager.availableStreams.collectAsState()
    val streamMetrics by streamManager.streamMetrics.collectAsState()
    val streamLogs by streamManager.streamStatusLog.collectAsState()

    val currentBroker by pubSubBroker.currentBroker.collectAsState()
    val isBrokerConnected by pubSubBroker.isConnected.collectAsState()
    val subscribedTopics by pubSubBroker.subscribedTopics.collectAsState()
    val receivedMessages by pubSubBroker.receivedMessages.collectAsState()
    val activeEndpoints by pubSubBroker.activeEndpoints.collectAsState()
    val totalPubSubCount by pubSubBroker.totalMessagesProcessed.collectAsState()

    val incidents by anomalyEngine.incidents.collectAsState()
    val isAnalyzingStreams by anomalyEngine.isAnalyzingStreams.collectAsState()
    val processingRate by anomalyEngine.streamProcessingRate.collectAsState()

    var selectedSection by remember { mutableStateOf(0) } // 0: Video Streams (RTSP/WebRTC), 1: Pub/Sub Broker, 2: Anomaly Detection
    var publishTopicInput by remember { mutableStateOf("tactical/manual/override") }
    var publishPayloadInput by remember { mutableStateOf("{\"command\":\"SURVEILLANCE_ENHANCE\",\"level\":5}") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0A0A10),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TACTICAL STREAMING & PUB/SUB HUB",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F0FF),
                            fontFamily = FontFamily.Monospace
                        )
                        Badge(containerColor = Color(0xFF003038), contentColor = Color(0xFF39FF14)) {
                            Text("SUB-SECOND WEBRTC", fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                    }
                    Text(
                        text = "Real-time RTSP/WebRTC sub-second video ingestion, MQTT/Kafka telemetry brokerage, and ALPR/AGDS anomaly detection.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            // Section Selector Tabs
            TabRow(
                selectedTabIndex = selectedSection,
                containerColor = Color(0xFF101018),
                contentColor = Color(0xFF00F0FF)
            ) {
                Tab(
                    selected = selectedSection == 0,
                    onClick = { selectedSection = 0 },
                    text = { Text("Stream Ingestion", fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedSection == 1,
                    onClick = { selectedSection = 1 },
                    text = { Text("Pub/Sub Broker", fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.Hub, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedSection == 2,
                    onClick = { selectedSection = 2 },
                    text = { Text("Anomaly Detection", fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }

            // Section Content
            when (selectedSection) {
                0 -> StreamIngestionSection(
                    activeStream = activeStream,
                    availableStreams = availableStreams,
                    metrics = streamMetrics,
                    logs = streamLogs,
                    onSelectStream = { streamManager.selectStream(it) },
                    onToggleProtocol = { streamManager.toggleProtocol(it) }
                )
                1 -> PubSubBrokerSection(
                    broker = currentBroker,
                    isConnected = isBrokerConnected,
                    totalCount = totalPubSubCount,
                    endpoints = activeEndpoints,
                    messages = receivedMessages,
                    topics = subscribedTopics,
                    publishTopic = publishTopicInput,
                    publishPayload = publishPayloadInput,
                    onPublishTopicChange = { publishTopicInput = it },
                    onPublishPayloadChange = { publishPayloadInput = it },
                    onSwitchBroker = { pubSubBroker.switchBroker(it) },
                    onPublish = { t, p -> pubSubBroker.publish(t, p) }
                )
                2 -> AnomalyDetectionSection(
                    incidents = incidents,
                    isAnalyzing = isAnalyzingStreams,
                    rate = processingRate,
                    onToggleAnalysis = { anomalyEngine.toggleStreamAnalysis(it) },
                    onAcknowledge = { anomalyEngine.acknowledgeIncident(it) },
                    onClearAll = { anomalyEngine.clearAllIncidents() }
                )
            }
        }
    }
}

@Composable
fun StreamIngestionSection(
    activeStream: StreamEndpoint,
    availableStreams: List<StreamEndpoint>,
    metrics: StreamMetrics,
    logs: List<String>,
    onSelectStream: (StreamEndpoint) -> Unit,
    onToggleProtocol: (StreamingProtocol) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Stream Preview Canvas with Tactical Overlay
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFF04060A),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.7f)),
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Simulated Low-latency Video Feed
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    // Crosshair grid
                    drawLine(Color(0xFF00F0FF).copy(alpha = 0.2f), Offset(0f, h / 2f), Offset(w, h / 2f), strokeWidth = 1f)
                    drawLine(Color(0xFF00F0FF).copy(alpha = 0.2f), Offset(w / 2f, 0f), Offset(w / 2f, h), strokeWidth = 1f)
                    drawCircle(Color(0xFF00F0FF).copy(alpha = 0.15f), radius = h * 0.35f, center = Offset(w / 2f, h / 2f), style = Stroke(1.5f))

                    // Simulated target boxes
                    val box1 = androidx.compose.ui.geometry.Rect(w * 0.28f, h * 0.3f, w * 0.44f, h * 0.65f)
                    drawRect(Color(0xFF39FF14).copy(alpha = 0.7f), topLeft = box1.topLeft, size = box1.size, style = Stroke(2f))

                    val box2 = androidx.compose.ui.geometry.Rect(w * 0.62f, h * 0.45f, w * 0.78f, h * 0.78f)
                    drawRect(Color(0xFFBD00FF).copy(alpha = 0.7f), topLeft = box2.topLeft, size = box2.size, style = Stroke(2f))
                }

                // Feed Overlay Badges
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Badge(containerColor = Color(0xFF990000), contentColor = Color.White) {
                        Text("LIVE FEED", fontSize = 8.sp, modifier = Modifier.padding(2.dp))
                    }
                    Badge(
                        containerColor = if (activeStream.protocol == StreamingProtocol.WEBRTC) Color(0xFF003D45) else Color(0xFF452600),
                        contentColor = if (activeStream.protocol == StreamingProtocol.WEBRTC) Color(0xFF00F0FF) else Color(0xFFFF9900)
                    ) {
                        Text(activeStream.protocol.name, fontSize = 8.sp, modifier = Modifier.padding(2.dp))
                    }
                    Badge(containerColor = Color(0xFF0A2210), contentColor = Color(0xFF39FF14)) {
                        Text("${metrics.latencyMs} ms", fontSize = 8.sp, modifier = Modifier.padding(2.dp))
                    }
                }

                // Feed Info at Bottom
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = activeStream.name,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = activeStream.uri,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF00F0FF),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Protocol Toggle Switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Ingestion Protocol:", style = MaterialTheme.typography.labelMedium, color = Color.White)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = activeStream.protocol == StreamingProtocol.WEBRTC,
                    onClick = { onToggleProtocol(StreamingProtocol.WEBRTC) },
                    label = { Text("WebRTC (Sub-Second)", fontSize = 11.sp) },
                    leadingIcon = { if (activeStream.protocol == StreamingProtocol.WEBRTC) Icon(Icons.Default.Check, null, modifier = Modifier.size(14.dp)) }
                )
                FilterChip(
                    selected = activeStream.protocol == StreamingProtocol.RTSP,
                    onClick = { onToggleProtocol(StreamingProtocol.RTSP) },
                    label = { Text("RTSP Stream", fontSize = 11.sp) },
                    leadingIcon = { if (activeStream.protocol == StreamingProtocol.RTSP) Icon(Icons.Default.Check, null, modifier = Modifier.size(14.dp)) }
                )
            }
        }

        // Telemetry Metrics Grid
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF0D0F18),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                MetricItem("LATENCY", "${metrics.latencyMs} ms", if (metrics.latencyMs < 120) Color(0xFF39FF14) else Color(0xFFFF9900))
                MetricItem("FRAMERATE", "${metrics.currentFps} FPS", Color(0xFF00F0FF))
                MetricItem("BITRATE", "${metrics.bitrateKbps} Kbps", Color(0xFFBD00FF))
                MetricItem("JITTER", "${metrics.jitterMs} ms", Color(0xFFE2E8F0))
                MetricItem("ICE STATUS", metrics.iceState.name, Color(0xFF39FF14))
            }
        }

        // Available Streams List
        Text(
            text = "AVAILABLE SURVEILLANCE ENDPOINTS (${availableStreams.size})",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF00F0FF),
            fontFamily = FontFamily.Monospace
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(availableStreams) { st ->
                val isSelected = st.id == activeStream.id
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) Color(0xFF00222A) else Color(0xFF0A0C14),
                    border = BorderStroke(1.dp, if (isSelected) Color(0xFF00F0FF) else Color(0xFF1E293B)),
                    onClick = { onSelectStream(st) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(st.name, style = MaterialTheme.typography.bodyMedium, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${st.protocol.name} • ${st.resolution} @ ${st.targetFps}fps", style = MaterialTheme.typography.bodySmall, color = Color(0xFF94A3B8))
                        }
                        if (isSelected) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Active", tint = Color(0xFF39FF14), modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricItem(label: String, value: String, valueColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 9.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
        Text(value, fontSize = 12.sp, color = valueColor, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun PubSubBrokerSection(
    broker: BrokerProtocol,
    isConnected: Boolean,
    totalCount: Long,
    endpoints: List<EndpointTelemetry>,
    messages: List<PubSubMessage>,
    topics: Set<String>,
    publishTopic: String,
    publishPayload: String,
    onPublishTopicChange: (String) -> Unit,
    onPublishPayloadChange: (String) -> Unit,
    onSwitchBroker: (BrokerProtocol) -> Unit,
    onPublish: (String, String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Broker Status Bar
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF0D0F18),
            border = BorderStroke(1.dp, Color(0xFFBD00FF).copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "BROKER: ${broker.name}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFBD00FF),
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Badge(containerColor = Color(0xFF003810), contentColor = Color(0xFF39FF14)) {
                            Text(if (isConnected) "CONNECTED" else "OFFLINE", fontSize = 8.sp)
                        }
                    }
                    Text(
                        text = "Processed: $totalCount messages • Endpoints: ${endpoints.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = { onSwitchBroker(if (broker == BrokerProtocol.MQTT) BrokerProtocol.APACHE_KAFKA else BrokerProtocol.MQTT) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("Switch to ${if (broker == BrokerProtocol.MQTT) "Kafka" else "MQTT"}", fontSize = 10.sp)
                    }
                }
            }
        }

        // Active Endpoints Broadcasting Grid
        Text(
            text = "ENDPOINTS BROADCASTING STATUS (${endpoints.size})",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF00F0FF),
            fontFamily = FontFamily.Monospace
        )

        LazyColumn(
            modifier = Modifier.weight(0.5f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(endpoints) { ep ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF0E101A),
                    border = BorderStroke(1.dp, Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${ep.endpointId} (${ep.unitType})", style = MaterialTheme.typography.bodySmall, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("${ep.sector} • GPS: ${String.format(Locale.US, "%.4f, %.4f", ep.latitude, ep.longitude)}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF94A3B8), fontSize = 10.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Badge(containerColor = Color(0xFF0A2612), contentColor = Color(0xFF39FF14)) {
                                Text("${ep.batteryPercent}% BAT", fontSize = 9.sp)
                            }
                            Badge(containerColor = Color(0xFF1A1A26), contentColor = Color(0xFF00F0FF)) {
                                Text("${ep.signalDbm} dBm", fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }

        // Real-Time Pub/Sub Message Feed
        Text(
            text = "LIVE TOPIC MESSAGES (${messages.size})",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF39FF14),
            fontFamily = FontFamily.Monospace
        )

        LazyColumn(
            modifier = Modifier.weight(0.5f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(messages.reversed()) { msg ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF0A0D14),
                    border = BorderStroke(1.dp, Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(msg.topic, style = MaterialTheme.typography.labelSmall, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                            Text(msg.qos.label, style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B), fontSize = 9.sp)
                        }
                        Text(
                            text = msg.payload,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFE2E8F0),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AnomalyDetectionSection(
    incidents: List<PublicSafetyIncident>,
    isAnalyzing: Boolean,
    rate: String,
    onToggleAnalysis: (Boolean) -> Unit,
    onAcknowledge: (String) -> Unit,
    onClearAll: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Status & Controls
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF140A10),
            border = BorderStroke(1.dp, Color(0xFFFF3366).copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "PUBLIC SAFETY ANOMALY RADAR",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFF3366),
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Badge(containerColor = Color(0xFF380010), contentColor = Color(0xFFFF6688)) {
                            Text(if (isAnalyzing) "INGESTING" else "PAUSED", fontSize = 8.sp)
                        }
                    }
                    Text(
                        text = "Aggregated non-sensitive stream rate: $rate (ALPR + Acoustic)",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = { onToggleAnalysis(!isAnalyzing) },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isAnalyzing) Color(0xFFFF3366) else Color(0xFF39FF14)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text(if (isAnalyzing) "Pause" else "Resume", fontSize = 10.sp, color = Color.Black)
                    }
                }
            }
        }

        // Incidents List
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "DETECTED INCIDENTS & ANOMALIES (${incidents.size})",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFFF9900),
                fontFamily = FontFamily.Monospace
            )
            if (incidents.isNotEmpty()) {
                TextButton(onClick = onClearAll, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) {
                    Text("Clear All", fontSize = 10.sp, color = Color(0xFF94A3B8))
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(incidents) { inc ->
                val borderColor = when (inc.severity) {
                    AnomalySeverity.CRITICAL -> Color(0xFFFF0033)
                    AnomalySeverity.HIGH -> Color(0xFFFF6600)
                    AnomalySeverity.MEDIUM -> Color(0xFFFFCC00)
                    AnomalySeverity.INFORMATIONAL -> Color(0xFF00F0FF)
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF100E14),
                    border = BorderStroke(1.dp, borderColor),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Badge(
                                containerColor = borderColor.copy(alpha = 0.2f),
                                contentColor = borderColor
                            ) {
                                Text(inc.severity.label, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(2.dp))
                            }
                            Text(
                                text = "Confidence: ${(inc.confidenceScore * 100).toInt()}%",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF39FF14),
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = inc.headline,
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = inc.details,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFCBD5E1)
                        )

                        Text(
                            text = "Location: ${inc.locationDescription} (${inc.coordinates})",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )

                        // Telemetry Metadata chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            inc.telemetryMetadata.entries.take(3).forEach { (k, v) ->
                                Badge(containerColor = Color(0xFF1A1A24), contentColor = Color(0xFF00F0FF)) {
                                    Text("$k: $v", fontSize = 8.sp, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            if (!inc.isAcknowledged) {
                                OutlinedButton(
                                    onClick = { onAcknowledge(inc.id) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF39FF14)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Acknowledge / Dispatch", fontSize = 10.sp)
                                }
                            } else {
                                Badge(containerColor = Color(0xFF002B12), contentColor = Color(0xFF39FF14)) {
                                    Text("DISPATCH ACKNOWLEDGED", fontSize = 9.sp, modifier = Modifier.padding(4.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
