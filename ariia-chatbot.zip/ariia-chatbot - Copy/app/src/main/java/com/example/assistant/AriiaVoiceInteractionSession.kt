package com.example.assistant

import android.content.Context
import android.content.Intent
import android.service.voice.VoiceInteractionSession
import com.example.MainActivity

class AriiaVoiceInteractionSession(context: Context) : VoiceInteractionSession(context) {
    override fun onHandleAssist(
        data: android.os.Bundle?,
        structure: android.app.assist.AssistStructure?,
        content: android.app.assist.AssistContent?
    ) {
        super.onHandleAssist(data, structure, content)
        val intent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("voice_assistant_launch", true)
        }
        context.startActivity(intent)
        finish()
    }
}
