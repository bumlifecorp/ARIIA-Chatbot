package com.example.ui.screens
import com.example.ui.screens.earth.AltoMapsOutdoorNav
import com.example.ui.screens.earth.GoPhotoSphereView



import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.earth.*
import com.example.util.AriiaSpeechEngine
import com.example.util.VoiceActionExecutor
import kotlinx.coroutines.launch
import kotlin.math.*

import com.example.ui.MainViewModel

@Composable
fun AriiaEarthScreen(
    viewModel: MainViewModel,
    onNavigateToCommsWithTarget: ((String, Float, Float) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }
    val coroutineScope = rememberCoroutineScope()

    var activeMode by remember { mutableStateOf(EarthViewMode.GLOBE_3D) }
    var selectedLayer by remember { mutableStateOf(EarthLayer.OPTICAL) }
    var isAutoRotating by remember { mutableStateOf(true) }
    var is3dElevationMode by remember { mutableStateOf(true) }
    var showWeatherRadar by remember { mutableStateOf(true) }
    var showDayNightTerminator by remember { mutableStateOf(true) }

    var yawDeg by remember { mutableFloatStateOf(0f) }
    var pitchDeg by remember { mutableFloatStateOf(20f) }
    var zoomLevel by remember { mutableFloatStateOf(1.0f) }

    val animYaw = remember { Animatable(0f) }
    val animPitch = remember { Animatable(20f) }

    val cachedLocations by viewModel.earthRepository.allLocations.collectAsState(initial = emptyList())

    // Preset Strategic Recon Targets
    val presetTargets = remember {
        listOf(
            TacticalTarget(
                id = "tgt-pentagon",
                name = "Pentagon Defense Concourse",
                callsign = "APEX-COMMAND",
                country = "United States",
                timezone = "UTC-4 (EDT)",
                latitude = 38.8719f,
                longitude = -77.0563f,
                altitudeMeters = 15,
                classification = "TOP SECRET // SI-TK",
                summary = "DoD strategic headquarters, underground command node, and primary defense satellite downlink hub.",
                weatherTempC = 22,
                weatherCondition = "Clear"
            ),
            TacticalTarget(
                id = "tgt-cern",
                name = "CERN Large Hadron Collider",
                callsign = "QUANTUM-RING",
                country = "Switzerland",
                timezone = "UTC+2 (CEST)",
                latitude = 46.2330f,
                longitude = 6.0557f,
                altitudeMeters = 430,
                classification = "LEVEL 5 SCIENTIFIC",
                summary = "Subterranean 27km particle accelerator complex, cryogenic computing grid, and antimatter containment.",
                weatherTempC = 18,
                weatherCondition = "Partly Cloudy"
            ),
            TacticalTarget(
                id = "tgt-tokyo",
                name = "Tokyo Autonomous Grid Node",
                callsign = "NEO-SHINJUKU",
                country = "Japan",
                timezone = "UTC+9 (JST)",
                latitude = 35.6762f,
                longitude = 139.6503f,
                altitudeMeters = 40,
                classification = "RESTRICTED MESH",
                summary = "Primary high-density telecommunication gateway, automated robotics transit terminal, and quantum crypto node.",
                weatherTempC = 26,
                weatherCondition = "Humid"
            ),
            TacticalTarget(
                id = "tgt-svalbard",
                name = "Svalbard Arctic Seed Vault",
                callsign = "BOREALIS-ARCHIVE",
                country = "Norway",
                timezone = "UTC+2 (CEST)",
                latitude = 78.2357f,
                longitude = 15.4913f,
                altitudeMeters = 130,
                classification = "GLOBAL ASSET",
                summary = "Deep permafrost subterranean vault securing planetary biological gene bank against catastrophic failure.",
                weatherTempC = -4,
                weatherCondition = "Snow Flurries"
            ),
            TacticalTarget(
                id = "tgt-cape",
                name = "Cape Canaveral Space Force Pad",
                callsign = "ORBITAL-GATE",
                country = "United States",
                timezone = "UTC-4 (EDT)",
                latitude = 28.3922f,
                longitude = -80.6077f,
                altitudeMeters = 3,
                classification = "SECRET // NOFORN",
                summary = "Heavy orbital booster launch facility, cryogenic propellant farm, and Atlantic telemetry range tracking.",
                weatherTempC = 29,
                weatherCondition = "Scattered Clouds"
            ),
            TacticalTarget(
                id = "tgt-dubai",
                name = "Dubai Cyber & Maritime Nexus",
                callsign = "GULF-SPIRE",
                country = "United Arab Emirates",
                timezone = "UTC+4 (GST)",
                latitude = 25.2048f,
                longitude = 55.2708f,
                altitudeMeters = 10,
                classification = "CIVIL DEFENSE",
                summary = "Autonomous drone maritime traffic surveillance corridor and regional fiber optic undersea interconnect.",
                weatherTempC = 37,
                weatherCondition = "Clear & Sunny"
            )
        )
    }

    val dynamicTargets = remember(cachedLocations) {
        val mappedCached = cachedLocations.filter { it.type == "POI" }.map {
            TacticalTarget(
                id = it.id,
                name = it.name,
                callsign = "CACHED",
                country = "Offline Cache",
                timezone = "UTC",
                latitude = it.latitude.toFloat(),
                longitude = it.longitude.toFloat(),
                altitudeMeters = 50,
                classification = "OFFLINE_CACHE",
                summary = "Cached coordinate point for offline access."
            )
        }
        presetTargets + mappedCached
    }

    var activeTarget by remember(dynamicTargets) { mutableStateOf(dynamicTargets.firstOrNull() ?: presetTargets[0]) }

    val satellites = remember {
        listOf(
            OrbitalSatellite("ARIIA-KH11 Optical Eye", "NORAD 43872", 380, 7.68f, 97.4f, "0.15m Ground Res", Color(0xFF00F0FF)),
            OrbitalSatellite("COSMO-SkyMed SAR-4", "NORAD 37216", 620, 7.55f, 97.9f, "1.00m Radar Res", Color(0xFF39FF14)),
            OrbitalSatellite("Landsat-9 Multispectral", "NORAD 49260", 705, 7.50f, 98.2f, "15m Spectral Res", Color(0xFFFFCC00)),
            OrbitalSatellite("ARIIA-Mesh Interlink-01", "NORAD 55102", 550, 7.59f, 53.0f, "Laser Crosslink", Color(0xFFFF3366))
        )
    }
    var selectedSatellite by remember { mutableStateOf(satellites[0]) }

    var showCoordinatesDialog by remember { mutableStateOf(false) }
    var latInput by remember { mutableStateOf("") }
    var lonInput by remember { mutableStateOf("") }

    fun flyTo(target: TacticalTarget) {
        activeTarget = target
        coroutineScope.launch {
            launch { animYaw.animateTo(target.longitude, animationSpec = tween(1200, easing = FastOutSlowInEasing)) }
            launch { animPitch.animateTo(target.latitude, animationSpec = tween(1200, easing = FastOutSlowInEasing)) }
        }
        speechEngine.speak("Aligning ARIIA Earth View cameras to ${target.name}. Callsign ${target.callsign}. Coordinates: ${target.latitude} degrees north, ${target.longitude} degrees east.")
    }

    // Auto-rotation engine
    LaunchedEffect(isAutoRotating) {
        if (isAutoRotating) {
            while (true) {
                withFrameNanos {
                    yawDeg = (yawDeg + 0.15f) % 360f
                }
                animYaw.snapTo(yawDeg)
            }
        }
    }

    LaunchedEffect(yawDeg, pitchDeg) {
        if (!isAutoRotating && !animYaw.isRunning && !animPitch.isRunning) {
            animYaw.snapTo(yawDeg)
            animPitch.snapTo(pitchDeg)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF03060D))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Master Tactical Top Bar
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF080D18),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Public, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ARIIA EARTH VIEW",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = Color(0xFF00F0FF),
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Badge(containerColor = Color(0xFF002936), contentColor = Color(0xFF39FF14)) {
                            Text(activeMode.badge, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Text(
                        text = "Unified Planetary Mapping, 3D Elevation & Street Reconnaissance",
                        fontSize = 8.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // 3D Isometric Elevation Toggle
                    IconButton(
                        onClick = {
                            is3dElevationMode = !is3dElevationMode
                            speechEngine.speak(if (is3dElevationMode) "3D isometric building elevation activated." else "Planetary elevation flattened.")
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Layers,
                            contentDescription = "3D Elevation",
                            tint = if (is3dElevationMode) Color(0xFFFF9900) else Color(0xFF64748B),
                            modifier = Modifier.size(17.dp)
                        )
                    }

                    // Solar Terminator Toggle
                    IconButton(
                        onClick = {
                            showDayNightTerminator = !showDayNightTerminator
                            speechEngine.speak(if (showDayNightTerminator) "Day night solar terminator enabled." else "Terminator shadow disabled.")
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            if (showDayNightTerminator) Icons.Default.WbSunny else Icons.Default.NightsStay,
                            contentDescription = "Day/Night",
                            tint = if (showDayNightTerminator) Color(0xFFFFCC00) else Color(0xFF64748B),
                            modifier = Modifier.size(17.dp)
                        )
                    }

                    // Weather Radar Toggle
                    IconButton(
                        onClick = {
                            showWeatherRadar = !showWeatherRadar
                            speechEngine.speak(if (showWeatherRadar) "Atmospheric storm radar layer enabled." else "Weather radar deactivated.")
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Cloud,
                            contentDescription = "Weather Radar",
                            tint = if (showWeatherRadar) Color(0xFF39FF14) else Color(0xFF64748B),
                            modifier = Modifier.size(17.dp)
                        )
                    }

                    // Coordinate Search Dialog
                    IconButton(
                        onClick = { showCoordinatesDialog = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Coordinate Search", tint = Color(0xFF00F0FF), modifier = Modifier.size(17.dp))
                    }

                    // Audio Overview
                    IconButton(
                        onClick = {
                            val msg = "ARIIA Earth View operational in ${activeMode.label} mode. Target ${activeTarget.name}, coordinates latitude ${"%.2f".format(animPitch.value)}, longitude ${"%.2f".format(animYaw.value)}."
                            speechEngine.speak(msg)
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Voice Briefing", tint = Color(0xFF00F0FF), modifier = Modifier.size(17.dp))
                    }
                }
            }
        }

        // Earth View Launcher Dock (Live Earth Map Launcher Mode Bar)
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(EarthViewMode.values()) { mode ->
                val isSel = activeMode == mode
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSel) Color(0xFF003845) else Color(0xFF090E18),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFF00F0FF) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable {
                        activeMode = mode
                        speechEngine.speak("Switching Earth View to ${mode.label}.")
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val icon = when (mode) {
                            EarthViewMode.GLOBE_3D -> Icons.Default.Public
                            EarthViewMode.ALTO_MAPS -> Icons.Default.Terrain
                            EarthViewMode.LIVE_EARTH_3D_DROID -> Icons.Default.Map
                            EarthViewMode.EARTH_3D_FOXPOI -> Icons.Default.Language
                            EarthViewMode.MINIFINDER_SUITE -> Icons.Default.GpsFixed
                            EarthViewMode.PHOTO_SPHERE -> Icons.Default.PanoramaPhotosphere
                            EarthViewMode.STREET_VIEW -> Icons.Default.Streetview
                            EarthViewMode.WORLD_CAMS -> Icons.Default.Videocam
                            EarthViewMode.GPS_ROUTE -> Icons.Default.Navigation
                            EarthViewMode.SPEEDO_COMPASS -> Icons.Default.Speed
                            EarthViewMode.MEASURE_TOOL -> Icons.Default.Straighten
                        }
                        Icon(icon, contentDescription = null, tint = if (isSel) Color(0xFF00F0FF) else Color(0xFF64748B), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = mode.label,
                            fontSize = 8.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSel) Color.White else Color(0xFFCBD5E1),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Active Mode Content
        when (activeMode) {
            EarthViewMode.GLOBE_3D -> {
                // Spectral Layer Selector
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(EarthLayer.values()) { layer ->
                        val isSel = selectedLayer == layer
                        val chipColor = when (layer) {
                            EarthLayer.OPTICAL -> Color(0xFF00F0FF)
                            EarthLayer.SAR_RADAR -> Color(0xFF39FF14)
                            EarthLayer.THERMAL_IR -> Color(0xFFFF0055)
                            EarthLayer.NIGHT_OPS -> Color(0xFFFFCC00)
                            EarthLayer.TOPOGRAPHICAL -> Color(0xFFBD00FF)
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) chipColor.copy(alpha = 0.2f) else Color(0xFF0B101D),
                            border = BorderStroke(1.dp, if (isSel) chipColor else Color(0xFF1E293B)),
                            modifier = Modifier.clickable {
                                selectedLayer = layer
                                speechEngine.speak("Earth sensor layer calibrated to ${layer.label}.")
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(chipColor, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = layer.label,
                                    fontSize = 8.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) Color.White else Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }

                // 3D Globe Canvas Viewport
                Globe3DView(
                    activeTarget = activeTarget,
                    presetTargets = presetTargets,
                    satellites = satellites,
                    selectedSatellite = selectedSatellite,
                    selectedLayer = selectedLayer,
                    is3dElevationMode = is3dElevationMode,
                    showWeatherRadar = showWeatherRadar,
                    showDayNightTerminator = showDayNightTerminator,
                    yawDeg = animYaw.value,
                    pitchDeg = animPitch.value,
                    zoomLevel = zoomLevel,
                    onYawPitchChange = { ny, np ->
                        isAutoRotating = false
                        yawDeg = ny
                        pitchDeg = np
                    },
                    onZoomChange = { zoomLevel = it },
                    onTargetSelected = { flyTo(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )

                // Strategic Targets Fly-To Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("STRATEGIC FLY-TO TARGETS:", fontSize = 9.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    IconButton(
                        onClick = { isAutoRotating = !isAutoRotating },
                        modifier = Modifier.size(22.dp)
                    ) {
                        Icon(
                            if (isAutoRotating) Icons.Default.Pause else Icons.Default.RotateRight,
                            contentDescription = "Auto Rotate",
                            tint = if (isAutoRotating) Color(0xFF39FF14) else Color(0xFF64748B),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(presetTargets) { target ->
                        val isAct = target.id == activeTarget.id
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isAct) Color(0xFF003F4D) else Color(0xFF090E18),
                            border = BorderStroke(1.dp, if (isAct) Color(0xFF00F0FF) else Color(0xFF1E293B)),
                            modifier = Modifier.clickable { flyTo(target) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Place,
                                    contentDescription = null,
                                    tint = if (isAct) Color(0xFFFF3366) else Color(0xFF00F0FF),
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Column {
                                    Text(target.name, fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("${target.latitude.toInt()}°, ${target.longitude.toInt()}°", fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }

                // Active Target Intelligence Dossier
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF080D18),
                    border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = activeTarget.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00F0FF),
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Badge(containerColor = Color(0xFF330011), contentColor = Color(0xFFFF3366)) {
                                    Text(activeTarget.classification, fontSize = 7.sp)
                                }
                            }
                            Text(
                                text = "CALLSIGN: ${activeTarget.callsign}",
                                fontSize = 8.sp,
                                color = Color(0xFF39FF14),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = activeTarget.summary,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFCBD5E1),
                            fontSize = 9.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${activeTarget.country} | ${activeTarget.timezone} | Elev: ${activeTarget.altitudeMeters}m | WX: ${activeTarget.weatherTempC}°C ${activeTarget.weatherCondition}",
                                fontSize = 7.sp,
                                color = Color(0xFF64748B),
                                fontFamily = FontFamily.Monospace
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = {
                                        VoiceActionExecutor.launchGoogleEarth(context, activeTarget.latitude, activeTarget.longitude)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Icon(Icons.Default.Public, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Google Earth 3D", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        VoiceActionExecutor.launchLiveEarthMap(context, activeTarget.latitude, activeTarget.longitude)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34A853)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Icon(Icons.Default.Map, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Live Earth Map", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        val speech = "Target ${activeTarget.name}, callsign ${activeTarget.callsign}. Classification: ${activeTarget.classification}. Located in ${activeTarget.country}, timezone ${activeTarget.timezone}. Coordinates: Latitude ${activeTarget.latitude}, Longitude ${activeTarget.longitude}. Elevation ${activeTarget.altitudeMeters} meters. Current weather: ${activeTarget.weatherTempC} degrees Celsius, ${activeTarget.weatherCondition}. ${activeTarget.summary}"
                                        speechEngine.speak(speech)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003845)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Recon Audio", fontSize = 8.sp, color = Color(0xFF00F0FF))
                                }

                                if (onNavigateToCommsWithTarget != null) {
                                    Button(
                                        onClick = {
                                            onNavigateToCommsWithTarget(activeTarget.name, activeTarget.latitude, activeTarget.longitude)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(26.dp)
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Dispatch", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            EarthViewMode.ALTO_MAPS -> {
                AltoMapsOutdoorNav(
                    viewModel = viewModel,
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }

            EarthViewMode.LIVE_EARTH_3D_DROID -> {
                LiveEarthMap3dDroidView(
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }

            EarthViewMode.EARTH_3D_FOXPOI -> {
                Earth3dFoxpoiView(
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }

            EarthViewMode.MINIFINDER_SUITE -> {
                MiniFinderSuiteView(
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }

            EarthViewMode.PHOTO_SPHERE -> {
                GoPhotoSphereView(
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }

            EarthViewMode.STREET_VIEW -> {
                StreetViewPanorama(
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }

            EarthViewMode.WORLD_CAMS -> {
                LiveWorldCams(
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }

            EarthViewMode.GPS_ROUTE -> {
                TacticalGpsRouteFinder(
                    presetTargets = presetTargets,
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }

            EarthViewMode.SPEEDO_COMPASS -> {
                TacticalGpsSpeedoCompass(
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }

            EarthViewMode.MEASURE_TOOL -> {
                TacticalGeodesicMeasureTool(
                    presetTargets = presetTargets,
                    onSpeak = { text -> speechEngine.speak(text) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
            }
        }
    }

    // Custom Coordinate Dialog
    if (showCoordinatesDialog) {
        AlertDialog(
            onDismissRequest = { showCoordinatesDialog = false },
            title = { Text("ARIIA Earth View Coordinate Entry", color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace, fontSize = 13.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter target latitude and longitude for planetary camera realignment:", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                    OutlinedTextField(
                        value = latInput,
                        onValueChange = { latInput = it },
                        label = { Text("Latitude (-90.0 to 90.0)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00F0FF))
                    )
                    OutlinedTextField(
                        value = lonInput,
                        onValueChange = { lonInput = it },
                        label = { Text("Longitude (-180.0 to 180.0)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00F0FF))
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val lat = latInput.toFloatOrNull()
                        val lon = lonInput.toFloatOrNull()
                        if (lat != null && lon != null) {
                            val custom = TacticalTarget(
                                id = "custom-${System.currentTimeMillis()}",
                                name = "Custom Recon Point",
                                callsign = "RECON-CUSTOM",
                                country = "User Defined",
                                timezone = "UTC",
                                latitude = lat.coerceIn(-90f, 90f),
                                longitude = lon.coerceIn(-180f, 180f),
                                altitudeMeters = 50,
                                classification = "UNVERIFIED",
                                summary = "User-designated satellite reconnaissance coordinates."
                            )
                            coroutineScope.launch {
                                viewModel.earthRepository.insert(
                                    com.example.data.local.EarthViewLocationEntity(
                                        id = custom.id,
                                        name = custom.name,
                                        latitude = custom.latitude.toDouble(),
                                        longitude = custom.longitude.toDouble(),
                                        type = "POI"
                                    )
                                )
                            }
                            flyTo(custom)
                            showCoordinatesDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF))
                ) {
                    Text("Fly to Coordinates", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCoordinatesDialog = false }) { Text("Cancel") }
            },
            containerColor = Color(0xFF0A0F1D)
        )
    }
}
