package com.example.service

import com.example.ui.SurveillanceNode
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import kotlin.random.Random

/**
 * InfluxDB Data Point representation supporting InfluxDB 2.x Line Protocol formatting.
 * Syntax: <measurement>[,<tag_key>=<tag_value>...] <field_key>=<field_value>... [timestamp_ns]
 */
data class InfluxDataPoint(
    val measurement: String,
    val tags: Map<String, String>,
    val fields: Map<String, Any>,
    val timestampNs: Long = System.currentTimeMillis() * 1_000_000L
) {
    fun toLineProtocol(): String {
        val tagStr = if (tags.isNotEmpty()) {
            "," + tags.entries.sortedBy { it.key }.joinToString(",") { "${it.key}=${it.value.replace(" ", "\\ ")}" }
        } else ""

        val fieldStr = fields.entries.joinToString(",") { (k, v) ->
            when (v) {
                is Float, is Double -> "$k=${String.format(Locale.US, "%.2f", (v as Number).toDouble())}"
                is Int, is Long -> "${k}=${v}i"
                is Boolean -> "$k=$v"
                else -> "$k=\"$v\""
            }
        }

        return "$measurement$tagStr $fieldStr $timestampNs"
    }
}

/**
 * Real-time InfluxDB streamed telemetry for an individual surveillance node.
 */
data class InfluxNodeTelemetry(
    val nodeId: String,
    val sector: String,
    val category: String,
    val latencyMs: Int,
    val bitrateMbps: Float,
    val fps: Int,
    val thermalTempC: Float,
    val packetLossPct: Float,
    val aiConfidencePct: Float,
    val signalRssiDbm: Int,
    val threatScore: Int,
    val isAnomaly: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class InfluxAlert(
    val id: String = UUID.randomUUID().toString(),
    val nodeId: String,
    val metric: String,
    val message: String,
    val severity: String, // "INFO", "WARNING", "CRITICAL"
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * InfluxDB Service Wrapper for ARIIA Autonomous Reconnaissance & Intelligence Integration.
 * Manages high-frequency streaming of surveillance node sensor metrics, line protocol generation,
 * time-series buffer storage, anomaly detection, and Flux query simulation.
 */
object InfluxDbServiceWrapper {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var streamingJob: Job? = null

    // InfluxDB Connection Configuration
    const val INFLUX_SERVER_URL = "http://127.0.0.1:8086"
    const val INFLUX_ORG = "ARIIA_TACTICAL_ORG"
    const val INFLUX_BUCKET = "tactical-surveillance"
    const val INFLUX_RETENTION = "90 Days"
    const val INFLUX_TOKEN = "ariia-supercomputer-tsm-token-88f"

    // State Flows
    private val _isStreamingActive = MutableStateFlow(true)
    val isStreamingActive: StateFlow<Boolean> = _isStreamingActive.asStateFlow()

    private val _writeRatePps = MutableStateFlow(124.0f) // Points per second
    val writeRatePps: StateFlow<Float> = _writeRatePps.asStateFlow()

    private val _totalPointsIngested = MutableStateFlow(482_920L)
    val totalPointsIngested: StateFlow<Long> = _totalPointsIngested.asStateFlow()

    private val _latestLineProtocol = MutableStateFlow("")
    val latestLineProtocol: StateFlow<String> = _latestLineProtocol.asStateFlow()

    private val _nodeTelemetryMap = MutableStateFlow<Map<String, InfluxNodeTelemetry>>(emptyMap())
    val nodeTelemetryMap: StateFlow<Map<String, InfluxNodeTelemetry>> = _nodeTelemetryMap.asStateFlow()

    // History buffers for real-time HUD sparkline waveforms (last 30 samples)
    private val _latencyHistoryMap = MutableStateFlow<Map<String, List<Float>>>(emptyMap())
    val latencyHistoryMap: StateFlow<Map<String, List<Float>>> = _latencyHistoryMap.asStateFlow()

    private val _thermalHistoryMap = MutableStateFlow<Map<String, List<Float>>>(emptyMap())
    val thermalHistoryMap: StateFlow<Map<String, List<Float>>> = _thermalHistoryMap.asStateFlow()

    private val _bitrateHistoryMap = MutableStateFlow<Map<String, List<Float>>>(emptyMap())
    val bitrateHistoryMap: StateFlow<Map<String, List<Float>>> = _bitrateHistoryMap.asStateFlow()

    private val _recentLineProtocolFeed = MutableStateFlow<List<String>>(emptyList())
    val recentLineProtocolFeed: StateFlow<List<String>> = _recentLineProtocolFeed.asStateFlow()

    private val _activeAlerts = MutableStateFlow<List<InfluxAlert>>(emptyList())
    val activeAlerts: StateFlow<List<InfluxAlert>> = _activeAlerts.asStateFlow()

    private val _anomalyActiveNode = MutableStateFlow<String?>(null)
    val anomalyActiveNode: StateFlow<String?> = _anomalyActiveNode.asStateFlow()

    // Registered surveillance nodes cache
    private var registeredNodes: List<SurveillanceNode> = emptyList()

    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    init {
        startStreamingService()
    }

    /**
     * Registers current surveillance nodes to be ingested into InfluxDB.
     */
    fun registerNodes(nodes: List<SurveillanceNode>) {
        registeredNodes = nodes
        if (_nodeTelemetryMap.value.isEmpty()) {
            val initialMap = nodes.associate { node ->
                node.id to createInitialTelemetry(node)
            }
            _nodeTelemetryMap.value = initialMap
        }
    }

    private fun createInitialTelemetry(node: SurveillanceNode): InfluxNodeTelemetry {
        val baseTemp = when (node.category) {
            "TACTICAL" -> 36.5f
            "WORLD_CAMS" -> 28.0f
            "HARDWARE_AI" -> 44.0f
            else -> 31.0f
        }
        return InfluxNodeTelemetry(
            nodeId = node.id,
            sector = node.sector,
            category = node.category,
            latencyMs = node.latencyMs,
            bitrateMbps = node.bitrateMbps,
            fps = node.fps,
            thermalTempC = baseTemp,
            packetLossPct = 0.02f,
            aiConfidencePct = 94.5f,
            signalRssiDbm = -62,
            threatScore = if (node.threatLevel == "High") 88 else if (node.threatLevel == "Elevated") 62 else 15
        )
    }

    /**
     * Starts continuous background time-series streaming into InfluxDB buffer.
     */
    fun startStreamingService() {
        if (streamingJob?.isActive == true) return
        _isStreamingActive.value = true

        streamingJob = scope.launch {
            while (isActive) {
                delay(650L) // Ingest every ~650ms
                ingestSurveillanceMetricsCycle()
            }
        }
    }

    fun pauseStreaming() {
        _isStreamingActive.value = false
        streamingJob?.cancel()
    }

    fun toggleStreaming() {
        if (_isStreamingActive.value) {
            pauseStreaming()
        } else {
            startStreamingService()
        }
    }

    /**
     * Executes one cycle of sampling and ingesting metrics into InfluxDB Line Protocol.
     */
    private fun ingestSurveillanceMetricsCycle() {
        val nodes = registeredNodes
        if (nodes.isEmpty()) return

        val currentMap = _nodeTelemetryMap.value.toMutableMap()
        val latHistory = _latencyHistoryMap.value.toMutableMap()
        val thermHistory = _thermalHistoryMap.value.toMutableMap()
        val bitHistory = _bitrateHistoryMap.value.toMutableMap()
        val newLines = mutableListOf<String>()

        var newPointsCount = 0

        nodes.forEach { node ->
            if (!node.isConnected) return@forEach

            val existing = currentMap[node.id] ?: createInitialTelemetry(node)
            val isAnomaly = _anomalyActiveNode.value == node.id

            // Simulate natural sensor fluctuations
            val latencyDelta = if (isAnomaly) Random.nextInt(40, 120) else Random.nextInt(-3, 4)
            val updatedLatency = (existing.latencyMs + latencyDelta).coerceIn(8, if (isAnomaly) 350 else 120)

            val bitrateDelta = (Random.nextFloat() - 0.5f) * 0.4f
            val updatedBitrate = (existing.bitrateMbps + bitrateDelta).coerceIn(0.5f, 48.0f)

            val tempDelta = if (isAnomaly) 0.8f else (Random.nextFloat() - 0.48f) * 0.3f
            val updatedTemp = (existing.thermalTempC + tempDelta).coerceIn(20.0f, if (isAnomaly) 68.0f else 49.0f)

            val updatedLoss = if (isAnomaly) Random.nextFloat() * 12.0f else (Random.nextFloat() * 0.4f)
            val updatedAiConfidence = (existing.aiConfidencePct + (Random.nextFloat() - 0.5f) * 1.5f).coerceIn(82.0f, 99.8f)
            val updatedRssi = (existing.signalRssiDbm + Random.nextInt(-1, 2)).coerceIn(-92, -45)
            val updatedThreat = if (isAnomaly) 96 else existing.threatScore

            val updatedTelemetry = existing.copy(
                latencyMs = updatedLatency,
                bitrateMbps = updatedBitrate,
                thermalTempC = updatedTemp,
                packetLossPct = updatedLoss,
                aiConfidencePct = updatedAiConfidence,
                signalRssiDbm = updatedRssi,
                threatScore = updatedThreat,
                isAnomaly = isAnomaly,
                timestamp = System.currentTimeMillis()
            )
            currentMap[node.id] = updatedTelemetry

            // Sparkline history ring buffers (max 30 items)
            val latList = (latHistory[node.id] ?: emptyList()).toMutableList().apply {
                add(updatedLatency.toFloat())
                if (size > 30) removeAt(0)
            }
            latHistory[node.id] = latList

            val thermList = (thermHistory[node.id] ?: emptyList()).toMutableList().apply {
                add(updatedTemp)
                if (size > 30) removeAt(0)
            }
            thermHistory[node.id] = thermList

            val bitList = (bitHistory[node.id] ?: emptyList()).toMutableList().apply {
                add(updatedBitrate)
                if (size > 30) removeAt(0)
            }
            bitHistory[node.id] = bitList

            // Build InfluxDB Line Protocol points
            val point = InfluxDataPoint(
                measurement = "surveillance_telemetry",
                tags = mapOf(
                    "node_id" to node.id,
                    "sector" to node.sector.replace(" ", "_"),
                    "category" to node.category,
                    "protocol" to node.protocol.replace(" ", "_"),
                    "threat_level" to node.threatLevel
                ),
                fields = mapOf(
                    "latency_ms" to updatedLatency,
                    "bitrate_mbps" to updatedBitrate,
                    "fps" to node.fps,
                    "thermal_temp_c" to updatedTemp,
                    "packet_loss_pct" to updatedLoss,
                    "ai_confidence" to updatedAiConfidence,
                    "signal_rssi" to updatedRssi,
                    "threat_score" to updatedThreat
                )
            )

            val line = point.toLineProtocol()
            newLines.add(line)
            newPointsCount++

            // Check for threshold alerts
            if (isAnomaly || updatedTemp > 50.0f || updatedLatency > 150) {
                emitAlertIfNeeded(node.id, updatedLatency, updatedTemp, updatedLoss)
            }
        }

        _nodeTelemetryMap.value = currentMap
        _latencyHistoryMap.value = latHistory
        _thermalHistoryMap.value = thermHistory
        _bitrateHistoryMap.value = bitHistory

        if (newLines.isNotEmpty()) {
            _latestLineProtocol.value = newLines.first()
            val combinedFeed = (newLines + _recentLineProtocolFeed.value).take(40)
            _recentLineProtocolFeed.value = combinedFeed
        }

        _totalPointsIngested.value += newPointsCount
        _writeRatePps.value = 110f + Random.nextFloat() * 35f
    }

    private fun emitAlertIfNeeded(nodeId: String, latency: Int, temp: Float, loss: Float) {
        val currentAlerts = _activeAlerts.value.toMutableList()
        val alreadyAlerted = currentAlerts.any { it.nodeId == nodeId && System.currentTimeMillis() - it.timestamp < 10_000 }
        if (!alreadyAlerted) {
            val alert = InfluxAlert(
                nodeId = nodeId,
                metric = if (temp > 50.0f) "THERMAL_OVERHEAT" else "NETWORK_LATENCY_SPIKE",
                message = if (temp > 50.0f) "FLIR Sensor Temp reached ${String.format(Locale.US, "%.1f", temp)}°C exceeding safe operating limits!" else "Latency spiked to ${latency}ms with ${String.format(Locale.US, "%.1f", loss)}% packet loss.",
                severity = "CRITICAL"
            )
            currentAlerts.add(0, alert)
            if (currentAlerts.size > 15) currentAlerts.removeAt(currentAlerts.lastIndex)
            _activeAlerts.value = currentAlerts
        }
    }

    /**
     * Triggers an anomaly injection for demonstration and HUD alerting.
     */
    fun triggerAnomaly(nodeId: String) {
        _anomalyActiveNode.value = nodeId
        scope.launch {
            delay(12_000) // Reset after 12s
            if (_anomalyActiveNode.value == nodeId) {
                _anomalyActiveNode.value = null
            }
        }
    }

    fun clearAnomaly() {
        _anomalyActiveNode.value = null
    }

    fun clearAlerts() {
        _activeAlerts.value = emptyList()
    }

    /**
     * Executes a mock Flux query simulation against the active time-series database.
     */
    fun queryFlux(query: String): List<Map<String, String>> {
        val currentMap = _nodeTelemetryMap.value
        return currentMap.values.map { telem ->
            mapOf(
                "_time" to timeFormat.format(Date(telem.timestamp)),
                "_measurement" to "surveillance_telemetry",
                "node_id" to telem.nodeId,
                "sector" to telem.sector,
                "latency_ms" to "${telem.latencyMs}",
                "bitrate_mbps" to String.format(Locale.US, "%.2f", telem.bitrateMbps),
                "thermal_temp_c" to String.format(Locale.US, "%.1f", telem.thermalTempC),
                "ai_confidence" to String.format(Locale.US, "%.1f%%", telem.aiConfidencePct),
                "threat_score" to "${telem.threatScore}"
            )
        }
    }
}
