package com.example

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.delay

import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppGrid
import com.example.ui.components.CameraPreviewView
import com.example.ui.components.LauncherDock
import com.example.ui.components.LauncherHeader
import com.example.ui.components.VisionOverlay
import com.example.ui.components.VoiceAssistantDialog
import com.example.ui.components.SettingsDialog
import com.example.ui.theme.ImmersiveBg
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.LauncherViewModel
import com.example.viewmodel.LauncherViewMode
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                RiaOSLauncherScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun RiaOSLauncherScreen(viewModel: LauncherViewModel) {
    val context = LocalContext.current

    val viewMode by viewModel.viewMode.collectAsStateWithLifecycle()
    val filteredApps by viewModel.filteredApps.collectAsStateWithLifecycle()
    val favoriteApps by viewModel.favoriteApps.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val isTorchOn by viewModel.isTorchOn.collectAsStateWithLifecycle()
    val detectedObjects by viewModel.detectedObjects.collectAsStateWithLifecycle()
    val summaryText by viewModel.detectedSummaryText.collectAsStateWithLifecycle()
    val isVisionOverlayVisible by viewModel.isVisionOverlayVisible.collectAsStateWithLifecycle()
    val isCameraActive by viewModel.isCameraActive.collectAsStateWithLifecycle()
    val feedbackVisual by viewModel.feedbackVisual.collectAsStateWithLifecycle()
    val feedbackAuditory by viewModel.feedbackAuditory.collectAsStateWithLifecycle()
    val feedbackHaptic by viewModel.feedbackHaptic.collectAsStateWithLifecycle()
    val confidenceThreshold by viewModel.detectionConfidenceThreshold.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val recentCommands by viewModel.recentCommands.collectAsStateWithLifecycle()
    val iconShape by viewModel.iconShape.collectAsStateWithLifecycle()
    val iconSize by viewModel.iconSize.collectAsStateWithLifecycle()

    var showSettings by remember { mutableStateOf(false) }
    var showCustomActions by remember { mutableStateOf(false) }
    val customActions by viewModel.customActions.collectAsStateWithLifecycle()
    val wallpaperUri by viewModel.wallpaperUri.collectAsStateWithLifecycle()
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }


    // Gesture Drawing State
    val drawnPath = remember { mutableStateOf(Path()) }
    val isDrawing = remember { mutableStateOf(false) }
    
    // Auto-submit mechanism
    LaunchedEffect(isDrawing.value) {
        if (!isDrawing.value && !drawnPath.value.isEmpty) {
            delay(800) // Wait 800ms to see if they continue drawing
            if (!isDrawing.value) {
                // Submit to Gemini
                viewModel.submitGesture(drawnPath.value)
                drawnPath.value = Path() // Clear
            }
        }
    }

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }


    // Wallpaper picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.setWallpaperUri(uri.toString())
        }
    }

    // Permission request launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasCameraPermission = permissions[Manifest.permission.CAMERA] == true
        hasAudioPermission = permissions[Manifest.permission.RECORD_AUDIO] == true
        if (!hasCameraPermission) {
            Toast.makeText(context, "Kameratillstånd krävs för AI Vision", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission || !hasAudioPermission) {
            permissionsLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    // Speech Recognizer Intent Launcher (exact speech recognition from prompt)
    val speechRecognitionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val spokenMatches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = spokenMatches?.firstOrNull() ?: ""
            if (spokenText.isNotBlank()) {
                viewModel.handleVoiceResult(context, spokenText)
            }
        }
    }

    val triggerVoiceRecognition = {
        val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Tala till RiaOS...")
        }
        try {
            speechRecognitionLauncher.launch(speechIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "Röststyrning stöds inte på denna enhet.", Toast.LENGTH_SHORT).show()
        }
    }

    // Prevent launcher from closing on back press, or minimize drawer
    BackHandler(enabled = true) {
        if (viewMode == LauncherViewMode.DRAWER) {
            viewModel.setViewMode(LauncherViewMode.VISION_HUD)
        }
        // Keeps user on launcher home screen
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = androidx.compose.ui.graphics.Color.Transparent
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {


            // Layer 0: Wallpaper or MuksOS style vibrant gradient background
            if (wallpaperUri != null) {
                coil.compose.AsyncImage(
                    model = wallpaperUri,
                    contentDescription = "Wallpaper",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                )
            } else {
                Box(modifier = Modifier.fillMaxSize()) {

                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasWidth = size.width
                        val canvasHeight = size.height
                    
                        drawRect(
                        brush = androidx.compose.ui.graphics.Brush.linearGradient(
                            colors = listOf(
                                androidx.compose.ui.graphics.Color(0xFF2B0B3F), // Deep Purple
                                androidx.compose.ui.graphics.Color(0xFF6B1F5F), // Magenta
                                androidx.compose.ui.graphics.Color(0xFF0F1A3A)  // Deep Blue
                            ),
                            start = androidx.compose.ui.geometry.Offset(0f, 0f),
                            end = androidx.compose.ui.geometry.Offset(canvasWidth, canvasHeight)
                        )
                    )
                    
                        drawCircle(
                        brush = androidx.compose.ui.graphics.Brush.radialGradient(
                            colors = listOf(
                                androidx.compose.ui.graphics.Color(0xFFE91E63).copy(alpha = 0.5f), // Pink
                                androidx.compose.ui.graphics.Color.Transparent
                            ),
                            center = androidx.compose.ui.geometry.Offset(canvasWidth * 0.2f, canvasHeight * 0.3f),
                            radius = canvasWidth * 0.8f
                        ),
                        radius = canvasWidth * 0.8f,
                        center = androidx.compose.ui.geometry.Offset(canvasWidth * 0.2f, canvasHeight * 0.3f)
                    )
                    
                        drawCircle(
                        brush = androidx.compose.ui.graphics.Brush.radialGradient(
                            colors = listOf(
                                androidx.compose.ui.graphics.Color(0xFF00BCD4).copy(alpha = 0.4f), // Cyan
                                androidx.compose.ui.graphics.Color.Transparent
                            ),
                            center = androidx.compose.ui.geometry.Offset(canvasWidth * 0.8f, canvasHeight * 0.7f),
                            radius = canvasWidth * 0.7f
                        ),
                        radius = canvasWidth * 0.7f,
                        center = androidx.compose.ui.geometry.Offset(canvasWidth * 0.8f, canvasHeight * 0.7f)
                    )
                }
            }
            // Layer 1: Camera Preview with ML Kit Object Detection
            if (hasCameraPermission && isCameraActive) {
                CameraPreviewView(
                    onObjectsDetected = { objects, summary ->
                        viewModel.onObjectsDetected(objects, summary)
                    }
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(androidx.compose.ui.graphics.Color.Transparent)
                )
            }

            // Layer 2: AR Vision HUD Overlay
            if (isVisionOverlayVisible) {
                VisionOverlay(
                    feedbackVisual = feedbackVisual,
                    feedbackAuditory = feedbackAuditory,
                    feedbackHaptic = feedbackHaptic,
                    onToggleVisual = { viewModel.toggleFeedbackVisual() },
                    onToggleAuditory = { viewModel.toggleFeedbackAuditory() },
                    onToggleHaptic = { viewModel.toggleFeedbackHaptic() },
                    detectedObjects = detectedObjects,
                    summaryText = summaryText
                )
            }


            // Layer 2.5: Central AI Eye Icon for Voice Assistant
            AnimatedVisibility(
                visible = viewMode != LauncherViewMode.DRAWER,
                enter = fadeIn() + scaleIn(initialScale = 0.8f),
                exit = fadeOut() + scaleOut(targetScale = 0.8f),
                modifier = Modifier.align(Alignment.Center)
            ) {
                com.example.ui.components.AiEyeIcon(
                    onClick = {
                        viewModel.openVoiceDialog()
                        triggerVoiceRecognition()
                    }
                )
            }

            // Layer 3: App Drawer Layer (Full or Sliding)
            AnimatedVisibility(
                visible = viewMode == LauncherViewMode.DRAWER,
                enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut()
            ) {
                AppGrid(
                    apps = filteredApps,
                    favoriteApps = favoriteApps,
                    searchQuery = searchQuery,
                    selectedCategory = selectedCategory,
                    onSearchChange = { viewModel.setSearchQuery(it) },
                    onCategorySelected = { viewModel.setSelectedCategory(it) },
                    onAppClick = { pkgName ->
                        viewModel.launchApp(context, pkgName)
                    },
                    onToggleFavorite = { pkgName ->
                        viewModel.toggleFavorite(pkgName)
                    },
                    iconShape = iconShape,
                    iconSize = iconSize
                )
            }

            // Layer 4: Top Header HUD
            LauncherHeader(
                viewMode = viewMode,
                isCameraActive = isCameraActive && hasCameraPermission,
                onSwitchMode = { newMode -> viewModel.setViewMode(newMode) },
                modifier = Modifier.align(Alignment.TopCenter)
            )

            // Layer 5: Bottom Floating Dock
            LauncherDock(
                isTorchOn = isTorchOn,
                isVisionVisible = isVisionOverlayVisible,
                viewMode = viewMode,
                iconShape = iconShape,
                onToggleTorch = { viewModel.toggleTorch(context) },
                onOpenVoice = {
                    viewModel.openVoiceDialog()
                    triggerVoiceRecognition()
                },
                onToggleVision = { viewModel.toggleVisionOverlay() },
                onToggleDrawer = {
                    val nextMode = if (viewMode == LauncherViewMode.DRAWER) {
                        LauncherViewMode.VISION_HUD
                    } else {
                        LauncherViewMode.DRAWER
                    }
                    viewModel.setViewMode(nextMode)
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
            )

            // Layer 6: Voice Assistant Dialog / Modal
            VoiceAssistantDialog(
                voiceState = voiceState,
                onClose = { viewModel.closeVoiceDialog() },
                onTriggerSpeechIntent = { triggerVoiceRecognition() },
                onExecuteCommand = { cmd -> viewModel.handleVoiceResult(context, cmd) }
            )
        }
    }
}
}
