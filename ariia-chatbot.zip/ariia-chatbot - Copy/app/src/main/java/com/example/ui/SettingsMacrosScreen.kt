package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.VoiceMacro

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsMacrosScreen(
    viewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModelFactory(LocalContext.current)
    )
) {
    val micSensitivity by viewModel.micSensitivity.collectAsState()
    val speechTimeout by viewModel.speechTimeout.collectAsState()
    val macros by viewModel.macros.collectAsState()

    var newTrigger by remember { mutableStateOf("") }
    var newProtocol by remember { mutableStateOf("") }

    val protocols = listOf(
        "Painter Protocol",
        "Earth View",
        "Secure Comms",
        "Photographer Protocol",
        "Sculptor Protocol",
        "Interior Designer Protocol",
        "System Accelerator"
    )

    var expanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            Text("Voice Assistant Settings", style = MaterialTheme.typography.headlineMedium)
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Microphone Sensitivity: ${micSensitivity.toInt()}%")
                    Slider(
                        value = micSensitivity,
                        onValueChange = { viewModel.updateMicSensitivity(it) },
                        valueRange = 0f..100f
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Speech Recognition Timeout: ${speechTimeout.toInt()}ms")
                    Slider(
                        value = speechTimeout,
                        onValueChange = { viewModel.updateSpeechTimeout(it) },
                        valueRange = 1000f..10000f
                    )
                }
            }
        }

        item {
            Text("Macros Configuration", style = MaterialTheme.typography.titleLarge)
            Text("Map custom voice triggers to existing app protocols.", style = MaterialTheme.typography.bodyMedium)
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = newTrigger,
                        onValueChange = { newTrigger = it },
                        label = { Text("Voice Trigger Phrase (e.g. 'Prepare Workspace')") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            value = newProtocol,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Target Protocol") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            protocols.forEach { selectionOption ->
                                DropdownMenuItem(
                                    text = { Text(selectionOption) },
                                    onClick = {
                                        newProtocol = selectionOption
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (newTrigger.isNotBlank() && newProtocol.isNotBlank()) {
                                viewModel.addMacro(newTrigger, newProtocol)
                                newTrigger = ""
                                newProtocol = ""
                            }
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Add Macro")
                    }
                }
            }
        }

        items(macros) { macro ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Trigger: \"${macro.trigger}\"", style = MaterialTheme.typography.bodyLarge)
                        Text("Action: ${macro.actionProtocol}", style = MaterialTheme.typography.bodyMedium)
                    }
                    IconButton(onClick = { viewModel.removeMacro(macro) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Macro")
                    }
                }
            }
        }
    }
}
