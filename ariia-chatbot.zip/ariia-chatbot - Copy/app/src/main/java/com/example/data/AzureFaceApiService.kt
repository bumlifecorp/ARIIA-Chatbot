package com.example.data

import com.squareup.moshi.JsonClass
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

@JsonClass(generateAdapter = true)
data class FaceDetectRequest(
    val url: String? = null,
    val returnFaceId: Boolean = true,
    val returnFaceLandmarks: Boolean = true,
    val returnFaceAttributes: List<String> = listOf("age", "gender", "smile", "facialHair", "glasses", "emotion")
)

@JsonClass(generateAdapter = true)
data class FaceDetectResponse(
    val faceId: String?,
    val faceRectangle: FaceRectangle?,
    val faceAttributes: FaceAttributes?
)

@JsonClass(generateAdapter = true)
data class FaceRectangle(
    val top: Int,
    val left: Int,
    val width: Int,
    val height: Int
)

@JsonClass(generateAdapter = true)
data class FaceAttributes(
    val age: Double?,
    val gender: String?,
    val smile: Double?,
    val glasses: String?,
    val emotion: Map<String, Double>?
)

@JsonClass(generateAdapter = true)
data class LivenessVerifyRequest(
    val imageByteArrayBase64: String,
    val deviceId: String,
    val sessionId: String,
    val version: String = "1.4"
)

@JsonClass(generateAdapter = true)
data class LivenessVerifyResponse(
    val status: String, // "Verified", "ChallengeFailed", "Pending"
    val livenessScore: Float,
    val confidence: Float,
    val faceToken: String?
)

interface AzureFaceApiService {
    @POST("face/v1.0/detect")
    suspend fun detectFaces(
        @Header("Ocp-Apim-Subscription-Key") apiKey: String,
        @Body request: FaceDetectRequest
    ): List<FaceDetectResponse>

    @POST
    suspend fun verifyLiveness(
        @Url endpointUrl: String,
        @Header("Authorization") token: String,
        @Body request: LivenessVerifyRequest
    ): LivenessVerifyResponse

    companion object {
        const val DEFAULT_BASE_URL = "https://facial.ai/api/v1.4/"

        fun create(): AzureFaceApiService {
            val retrofit = Retrofit.Builder()
                .baseUrl(DEFAULT_BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
            return retrofit.create(AzureFaceApiService::class.java)
        }
    }
}
