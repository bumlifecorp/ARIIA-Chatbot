package com.example.network

import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

@JsonClass(generateAdapter = true)
data class ManusText(val type: String = "text", val text: String)

@JsonClass(generateAdapter = true)
data class ManusMessage(val role: String = "user", val content: List<ManusText>)

@JsonClass(generateAdapter = true)
data class ManusTaskCreateRequest(val prompt: String? = null, val message: ManusMessage? = null)

@JsonClass(generateAdapter = true)
data class ManusTaskSendRequest(val taskId: String, val message: ManusMessage)

@JsonClass(generateAdapter = true)
data class ManusApiEnvelope<T>(val ok: Boolean, val task: T? = null, val error: ManusError? = null)

@JsonClass(generateAdapter = true)
data class ManusError(val code: String? = null, val message: String? = null)

@JsonClass(generateAdapter = true)
data class ManusTask(val id: String? = null, val status: String? = null)

interface ManusApiService {
    @POST("/v2/task.create")
    suspend fun createTask(@Body request: ManusTaskCreateRequest): ManusApiEnvelope<ManusTask>

    @POST("/v2/task.sendMessage")
    suspend fun sendMessage(@Body request: ManusTaskSendRequest): ManusApiEnvelope<ManusTask>
}

private class ManusAuthInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val key = BuildConfig.MANUS_API_KEY
        val request = chain.request().newBuilder().apply {
            if (key.isNotBlank() && key != "MY_MANUS_API_KEY") {
                addHeader("x-manus-api-key", key)
            }
        }.build()
        return chain.proceed(request)
    }
}

object ManusApiClient {
    val service: ManusApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.manus.ai/")
            .client(OkHttpClient.Builder().addInterceptor(ManusAuthInterceptor()).build())
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(ManusApiService::class.java)
    }
}
