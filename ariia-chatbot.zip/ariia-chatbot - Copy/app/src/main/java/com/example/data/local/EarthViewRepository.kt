package com.example.data.local

import kotlinx.coroutines.flow.Flow

class EarthViewRepository(private val dao: EarthViewDao) {
    val allLocations: Flow<List<EarthViewLocationEntity>> = dao.getAllLocations()
    
    fun getLocationsByType(type: String): Flow<List<EarthViewLocationEntity>> = dao.getLocationsByType(type)

    suspend fun insert(location: EarthViewLocationEntity) = dao.insertLocation(location)

    suspend fun deleteById(id: String) = dao.deleteLocationById(id)
}
