package com.example.data.repository

import android.content.Context
import com.example.utils.EncryptionHelper
import org.json.JSONArray
import org.json.JSONObject

class SecureCommsRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("secure_comms_logs", Context.MODE_PRIVATE)
    private val LOGS_KEY = "encrypted_logs"

    fun saveMessageLog(channelId: String, message: String, senderCallsign: String, timestamp: String, priority: String) {
        val logsArray = getDecryptedLogs()
        val newLog = JSONObject().apply {
            put("channelId", channelId)
            put("message", message)
            put("sender", senderCallsign)
            put("timestamp", timestamp)
            put("priority", priority)
        }
        logsArray.put(newLog)
        val encrypted = EncryptionHelper.encrypt(logsArray.toString())
        prefs.edit().putString(LOGS_KEY, encrypted).apply()
    }

    fun getDecryptedLogs(): JSONArray {
        val encrypted = prefs.getString(LOGS_KEY, null) ?: return JSONArray()
        val decrypted = EncryptionHelper.decrypt(encrypted)
        return try {
            JSONArray(decrypted)
        } catch (e: Exception) {
            JSONArray()
        }
    }

    fun clearLogs() {
        prefs.edit().remove(LOGS_KEY).apply()
    }
}
