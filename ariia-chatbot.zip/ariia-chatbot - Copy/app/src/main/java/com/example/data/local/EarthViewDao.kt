package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EarthViewDao {
    @Query("SELECT * FROM earth_view_locations ORDER BY timestamp DESC")
    fun getAllLocations(): Flow<List<EarthViewLocationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocation(location: EarthViewLocationEntity)

    @Query("DELETE FROM earth_view_locations WHERE id = :id")
    suspend fun deleteLocationById(id: String)
    
    @Query("SELECT * FROM earth_view_locations WHERE type = :type ORDER BY timestamp DESC")
    fun getLocationsByType(type: String): Flow<List<EarthViewLocationEntity>>
}
