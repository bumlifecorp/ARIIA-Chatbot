package com.example.model

import android.graphics.drawable.Drawable

data class AppItem(
    val packageName: String,
    val label: String,
    val icon: Drawable? = null,
    val isSystemApp: Boolean = false,
    val isFavorite: Boolean = false,
    val category: String = "App",
    val launchCount: Int = 0
)

data class DetectedObjectInfo(
    val id: Int,
    val label: String,
    val confidence: Int,
    val boundingBoxRatio: NormalizedRect? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class NormalizedRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
)
