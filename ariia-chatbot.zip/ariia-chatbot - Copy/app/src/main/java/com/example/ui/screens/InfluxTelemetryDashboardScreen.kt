package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.MiniFinderTrackingService
import com.example.service.InfluxDbServiceWrapper
import com.example.ui.screens.earth.MiniFinderDevice
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

data class InfluxBucket(
    val name: String,
    val retentionPeriod: String,
    val totalPoints: Long,
    val diskSizeBytes: Long,
    val org: String = "ARIIA_TACTICAL_ORG"
)

data class InfluxTask(
    val name: String,
    val cron: String,
    val status: String,
    val description: String
)

data class FluxQueryResultRow(
    val timestamp: String,
    val measurement: String,
    val field: String,
    val value: String,
    val deviceId: String
)

@Composable
fun InfluxTelemetryDashboardScreen(
    onSpeak: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val devices by MiniFinderTrackingService.devices.collectAsState()
    val isTrackingActive by MiniFinderTrackingService.isLiveTrackingActive.collectAsState()

    var activeTab by remember { mutableStateOf("METRICS_CHART") } // METRICS_CHART, LINE_PROTOCOL, FLUX_QUERY, BUCKETS_TASKS
    var selectedTimeRange by remember { mutableStateOf("-15m") } // -5m, -15m, -1h, -6h, -24h
    var selectedMetricField by remember { mutableStateOf("Speed (km/h)") } // Speed, Battery, Bark Rate, RSSI

    // Influx Buckets
    val buckets = remember {
        listOf(
            InfluxBucket("minifinder-telemetry", "30 Days", 1420890L, 48200000L),
            InfluxBucket("earth-satellite-recon", "7 Days", 680400L, 18500000L),
            InfluxBucket("quantum-diagnostics", "Infinite", 3200150L, 128000000L),
            InfluxBucket("tactical-surveillance", "90 Days", 890300L, 34100000L)
        )
    }

    // Influx Tasks
    val tasks = remember {
        listOf(
            InfluxTask("downsample_1m_rollups", "every 1m", "ACTIVE", "Aggregates 1.5s raw telemetry into 1m mean & max windows"),
            InfluxTask("speed_limit_alert_task", "every 10s", "ACTIVE", "Triggers critical alert when asset speed > 100 km/h"),
            InfluxTask("bark_bay_alarm_task", "every 5s", "ACTIVE", "Triggers hunter bay alert when dog bark BPM > 75"),
            InfluxTask("low_battery_guard_task", "every 5m", "ACTIVE", "Notifies system when device battery falls below 15%")
        )
    }

    // Flux Query Console State
    val defaultFluxQueries = remember {
        mapOf(
            "Device Speed Mean (-1h)" to """from(bucket: "minifinder-telemetry")
  |> range(start: -1h)
  |> filter(fn: (r) => r._measurement == "minifinder_gps")
  |> filter(fn: (r) => r._field == "speed_kmh")
  |> aggregateWindow(every: 1m, fn: mean, createEmpty: false)
  |> yield(name: "mean_speed")""",
            "Hunting Dog Bark Frequency (-15m)" to """from(bucket: "minifinder-telemetry")
  |> range(start: -15m)
  |> filter(fn: (r) => r._measurement == "hunting_dog")
  |> filter(fn: (r) => r._field == "barks_bpm")
  |> filter(fn: (r) => r.dog_id == "rex-1")
  |> yield(name: "bark_rate")""",
            "Battery Discharge Curve (-24h)" to """from(bucket: "minifinder-telemetry")
  |> range(start: -24h)
  |> filter(fn: (r) => r._field == "battery_percent")
  |> aggregateWindow(every: 15m, fn: last)
  |> yield(name: "battery_status")"""
        )
    }

    var selectedFluxQueryTitle by remember { mutableStateOf("Device Speed Mean (-1h)") }
    var currentFluxQueryText by remember { mutableStateOf(defaultFluxQueries["Device Speed Mean (-1h)"] ?: "") }
    var queryExecutionStatus by remember { mutableStateOf("Query executed successfully in 3.2 ms. 18 rows returned.") }

    // Generate Flux Query Result Table Rows from live devices
    val fluxRows = remember(devices, selectedFluxQueryTitle) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        devices.mapIndexed { idx, dev ->
            FluxQueryResultRow(
                timestamp = sdf.format(Date(System.currentTimeMillis() - (idx * 30000L))),
                measurement = if (dev.category == "Hunting Dog") "hunting_dog" else "minifinder_gps",
                field = when {
                    selectedFluxQueryTitle.contains("Speed") -> "speed_kmh"
                    selectedFluxQueryTitle.contains("Bark") -> "barks_bpm"
                    else -> "battery_percent"
                },
                value = when {
                    selectedFluxQueryTitle.contains("Speed") -> "${dev.speedKmh}.0"
                    selectedFluxQueryTitle.contains("Bark") -> "${dev.barksPerMinute ?: 0}.0"
                    else -> "${dev.batteryPercent}.0"
                },
                deviceId = dev.id
            )
        }
    }

    // Generate Influx Line Protocol Text Buffer from Live Devices
    val lineProtocolBuffer = remember(devices) {
        val ts = System.currentTimeMillis() * 1000000L // nanoseconds
        devices.joinToString("\n") { dev ->
            if (dev.category == "Hunting Dog") {
                "hunting_dog,device_id=${dev.id},breed=${dev.dogBreed?.replace(" ", "_") ?: "Dog"} barks_bpm=${dev.barksPerMinute ?: 0}i,distance_m=${dev.distanceToUserMeters ?: 0}i,lat=${dev.lat},lon=${dev.lon} $ts"
            } else {
                "minifinder_gps,device_id=${dev.id},model=${dev.model.replace(" ", "_")} speed_kmh=${dev.speedKmh}.0,battery_percent=${dev.batteryPercent}i,rssi_dbm=${dev.signalDbm}i,sats=${dev.satellites}i,lat=${dev.lat},lon=${dev.lon} $ts"
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "InfluxAnim")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Reverse),
        label = "Pulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030914))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Top InfluxDB Engine Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A192F), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF9333EA), RoundedCornerShape(12.dp))
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Timeline,
                    contentDescription = null,
                    tint = Color(0xFFC084FC),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("INFLUXDB TIME-SERIES ENGINE", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFC084FC), fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = CircleShape,
                            color = if (isTrackingActive) Color(0xFF39FF14) else Color(0xFFFF0055)
                        ) {
                            Box(modifier = Modifier.size(6.dp))
                        }
                    }
                    Text("v2.7.5 • TSM Engine • Org: ARIIA_TACTICAL_ORG • 245.8 PPS", fontSize = 8.sp, color = Color(0xFF94A3B8))
                }
            }

            Button(
                onClick = {
                    val speech = "InfluxDB Time-Series Engine Status: Ingesting 245 points per second across four buckets. MiniFinder live telemetry line protocol actively writing."
                    onSpeak(speech)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9333EA)),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(26.dp)
            ) {
                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Audio Status", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        // Navigation Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf(
                "METRICS_CHART" to "Metrics",
                "LINE_PROTOCOL" to "Line Proto",
                "FLUX_QUERY" to "Flux QL",
                "BUCKETS_TASKS" to "Buckets",
                "SURVEILLANCE_TSM" to "Surveillance TSM"
            ).forEach { (tabKey, tabLabel) ->
                val isSel = activeTab == tabKey
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) Color(0xFF9333EA).copy(alpha = 0.25f) else Color(0xFF0F172A),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFFC084FC) else Color(0xFF1E293B)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            activeTab = tabKey
                            onSpeak("InfluxDB view switched to $tabLabel.")
                        }
                ) {
                    Text(
                        text = tabLabel,
                        fontSize = 8.sp,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSel) Color(0xFFC084FC) else Color(0xFFCBD5E1),
                        modifier = Modifier
                            .padding(vertical = 6.dp)
                            .wrapContentWidth(Alignment.CenterHorizontally)
                    )
                }
            }
        }

        // Main Tab Views
        when (activeTab) {
            "METRICS_CHART" -> {
                InfluxMetricsChartView(
                    devices = devices,
                    selectedTimeRange = selectedTimeRange,
                    onTimeRangeChange = { selectedTimeRange = it },
                    selectedField = selectedMetricField,
                    onFieldChange = { selectedMetricField = it },
                    pulseAlpha = pulseAlpha,
                    onSpeak = onSpeak
                )
            }

            "LINE_PROTOCOL" -> {
                InfluxLineProtocolView(
                    lineProtocolBuffer = lineProtocolBuffer,
                    onSpeak = onSpeak
                )
            }

            "FLUX_QUERY" -> {
                InfluxFluxConsoleView(
                    queries = defaultFluxQueries,
                    selectedTitle = selectedFluxQueryTitle,
                    onSelectQuery = { title ->
                        selectedFluxQueryTitle = title
                        currentFluxQueryText = defaultFluxQueries[title] ?: ""
                    },
                    queryText = currentFluxQueryText,
                    onQueryTextChange = { currentFluxQueryText = it },
                    queryResultStatus = queryExecutionStatus,
                    resultRows = fluxRows,
                    onExecute = {
                        queryExecutionStatus = "Executing Flux Query on bucket 'minifinder-telemetry'..."
                        onSpeak("Executing Flux Query.")
                    },
                    onSpeak = onSpeak
                )
            }

            "BUCKETS_TASKS" -> {
                InfluxBucketsTasksView(
                    buckets = buckets,
                    tasks = tasks,
                    onSpeak = onSpeak
                )
            }

            "SURVEILLANCE_TSM" -> {
                InfluxSurveillanceStreamView(
                    onSpeak = onSpeak
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 1. INFLUX TIME-SERIES METRICS CHART VIEW
// -----------------------------------------------------------------------------
@Composable
fun ColumnScope.InfluxMetricsChartView(
    devices: List<MiniFinderDevice>,
    selectedTimeRange: String,
    onTimeRangeChange: (String) -> Unit,
    selectedField: String,
    onFieldChange: (String) -> Unit,
    pulseAlpha: Float,
    onSpeak: (String) -> Unit
) {
    // Controls Bar
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Field Selector Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(listOf("Speed (km/h)", "Battery (%)", "Bark Rate (BPM)", "RSSI (dBm)")) { field ->
                val isSel = field == selectedField
                FilterChip(
                    selected = isSel,
                    onClick = {
                        onFieldChange(field)
                        onSpeak("Visualizing Influx metric $field over time.")
                    },
                    label = { Text(field, fontSize = 8.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF9333EA),
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Time Range Chips
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("-5m", "-15m", "-1h", "-24h").forEach { range ->
                val isSel = range == selectedTimeRange
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (isSel) Color(0xFFC084FC) else Color(0xFF0F172A),
                    border = BorderStroke(1.dp, Color(0xFFC084FC)),
                    modifier = Modifier.clickable {
                        onTimeRangeChange(range)
                        onSpeak("Time range set to $range.")
                    }
                ) {
                    Text(
                        range,
                        fontSize = 8.sp,
                        color = if (isSel) Color.Black else Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }

    // Time-Series Canvas Chart
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .background(Color(0xFF020712), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF9333EA).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Horizontal & Vertical Grid Lines
            val gridY = 5
            val gridX = 8
            for (i in 0..gridY) {
                val y = h * (i / gridY.toFloat())
                drawLine(Color(0xFF334155).copy(alpha = 0.3f), Offset(0f, y), Offset(w, y))
            }
            for (j in 0..gridX) {
                val x = w * (j / gridX.toFloat())
                drawLine(Color(0xFF334155).copy(alpha = 0.3f), Offset(x, 0f), Offset(x, h))
            }

            // Draw Series for Devices
            devices.forEachIndexed { devIdx, dev ->
                val color = when (devIdx % 4) {
                    0 -> Color(0xFF39FF14) // Neon Green
                    1 -> Color(0xFF00F0FF) // Cyan
                    2 -> Color(0xFFFF9900) // Orange
                    else -> Color(0xFFC084FC) // Purple
                }

                val pointsCount = 20
                val path = Path()

                for (i in 0 until pointsCount) {
                    val x = w * (i / (pointsCount - 1).toFloat())
                    val baseVal = when (selectedField) {
                        "Speed (km/h)" -> dev.speedKmh.toFloat()
                        "Battery (%)" -> dev.batteryPercent.toFloat()
                        "Bark Rate (BPM)" -> (dev.barksPerMinute ?: 0).toFloat()
                        else -> (100 + dev.signalDbm).toFloat() // RSSI scaled 0-100
                    }

                    // Add simulated fluctuation per point
                    val valFluct = baseVal + sin((i + devIdx * 3).toDouble()).toFloat() * 8f
                    val normalized = (valFluct / 120f).coerceIn(0.05f, 0.95f)
                    val y = h - (h * normalized)

                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)

                    if (i == pointsCount - 1) {
                        // Draw current value pulse marker
                        drawCircle(color = color, radius = 5f, center = Offset(x, y))
                    }
                }

                drawPath(path, color = color, style = Stroke(width = 2.5f))
            }
        }

        // Live Series Legend HUD
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, Color(0xFF9333EA))
            ) {
                Column(modifier = Modifier.padding(6.dp)) {
                    Text("INFLUXDB REAL-TIME METRICS: $selectedField", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC084FC))
                    Text("BUCKET: minifinder-telemetry | RANGE: $selectedTimeRange", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                }
            }
        }
    }

    // Active Devices Telemetry Summary Row
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(devices) { dev ->
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0F172A),
                border = BorderStroke(1.dp, Color(0xFF1E293B))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (dev.category == "Hunting Dog") Icons.Default.Pets else Icons.Default.GpsFixed,
                        contentDescription = null,
                        tint = Color(0xFFC084FC),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(dev.name, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Spd: ${dev.speedKmh} km/h | Batt: ${dev.batteryPercent}%", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 2. INFLUX LINE PROTOCOL INGESTION VIEW
// -----------------------------------------------------------------------------
@Composable
fun ColumnScope.InfluxLineProtocolView(
    lineProtocolBuffer: String,
    onSpeak: (String) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF02070D),
        border = BorderStroke(1.dp, Color(0xFF9333EA).copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("INFLUXDB LINE PROTOCOL INGESTION BUFFER", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC084FC), fontFamily = FontFamily.Monospace)
                Text("Format: measurement,tag_set field_set timestamp", fontSize = 7.sp, color = Color(0xFF94A3B8))
            }

            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black,
                border = BorderStroke(1.dp, Color(0xFF334155)),
                modifier = Modifier.weight(1f)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(lineProtocolBuffer.split("\n")) { line ->
                        Text(line, fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Button(
                onClick = {
                    onSpeak("Copied InfluxDB Line Protocol buffer containing live telemetry points.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9333EA)),
                modifier = Modifier.align(Alignment.End)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Copy Line Protocol", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 3. INFLUX FLUX QUERY CONSOLE VIEW
// -----------------------------------------------------------------------------
@Composable
fun ColumnScope.InfluxFluxConsoleView(
    queries: Map<String, String>,
    selectedTitle: String,
    onSelectQuery: (String) -> Unit,
    queryText: String,
    onQueryTextChange: (String) -> Unit,
    queryResultStatus: String,
    resultRows: List<FluxQueryResultRow>,
    onExecute: () -> Unit,
    onSpeak: (String) -> Unit
) {
    // Template Selector Row
    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items(queries.keys.toList()) { title ->
            val isSel = title == selectedTitle
            FilterChip(
                selected = isSel,
                onClick = { onSelectQuery(title) },
                label = { Text(title, fontSize = 8.sp) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF9333EA), selectedLabelColor = Color.White)
            )
        }
    }

    // Flux Query Editor
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF02070D),
        border = BorderStroke(1.dp, Color(0xFF9333EA)),
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
    ) {
        Column(modifier = Modifier.padding(6.dp)) {
            Text("FLUX QUERY CONSOLE", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC084FC), fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            OutlinedTextField(
                value = queryText,
                onValueChange = onQueryTextChange,
                modifier = Modifier.fillMaxSize(),
                textStyle = LocalTextStyle.current.copy(fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF39FF14)),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent)
            )
        }
    }

    // Execute Button Row
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(queryResultStatus, fontSize = 8.sp, color = Color(0xFF34A853), fontFamily = FontFamily.Monospace)
        Button(
            onClick = onExecute,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9333EA)),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Run Flux Query", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
        }
    }

    // Flux Result Table
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF0B1424),
        border = BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
    ) {
        Column(modifier = Modifier.padding(6.dp)) {
            Text("FLUX QUERY RESULT TABLE", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(4.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                items(resultRows) { row ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF02070D), RoundedCornerShape(4.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${row.timestamp} | ${row.measurement}", fontSize = 7.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                        Text("${row.field}: ${row.value}", fontSize = 7.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("dev: ${row.deviceId}", fontSize = 7.sp, color = Color(0xFFC084FC), fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 4. INFLUX BUCKETS & TASKS VIEW
// -----------------------------------------------------------------------------
@Composable
fun ColumnScope.InfluxBucketsTasksView(
    buckets: List<InfluxBucket>,
    tasks: List<InfluxTask>,
    onSpeak: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("MANAGED INFLUXDB BUCKETS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC084FC), fontFamily = FontFamily.Monospace)
        }

        items(buckets) { b ->
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0B1424),
                border = BorderStroke(1.dp, Color(0xFF9333EA).copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(b.name, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Retention: ${b.retentionPeriod} | Org: ${b.org}", fontSize = 8.sp, color = Color(0xFF94A3B8))
                    }
                    Text("${b.totalPoints / 1000}k points", fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text("CONTINUOUS INFLUX DOWNSTREAM TASKS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34A853), fontFamily = FontFamily.Monospace)
        }

        items(tasks) { t ->
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF02070D),
                border = BorderStroke(1.dp, Color(0xFF34A853).copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(t.name, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14))
                        Text("Schedule: ${t.cron}", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    }
                    Text(t.description, fontSize = 8.sp, color = Color(0xFFCBD5E1))
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 5. INFLUX SURVEILLANCE TSM REAL-TIME STREAM VIEW
// -----------------------------------------------------------------------------
@Composable
fun ColumnScope.InfluxSurveillanceStreamView(
    onSpeak: (String) -> Unit
) {
    val isStreaming by InfluxDbServiceWrapper.isStreamingActive.collectAsState()
    val writeRatePps by InfluxDbServiceWrapper.writeRatePps.collectAsState()
    val totalPoints by InfluxDbServiceWrapper.totalPointsIngested.collectAsState()
    val telemetryMap by InfluxDbServiceWrapper.nodeTelemetryMap.collectAsState()
    val recentFeeds by InfluxDbServiceWrapper.recentLineProtocolFeed.collectAsState()
    val anomalyNode by InfluxDbServiceWrapper.anomalyActiveNode.collectAsState()

    LazyColumn(
        modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            // Header stats banner
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0D1527),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if (isStreaming) Color(0xFF39FF14) else Color(0xFFFF9900)))
                            Text("BUCKET: ${InfluxDbServiceWrapper.INFLUX_BUCKET}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilledTonalButton(
                                onClick = {
                                    InfluxDbServiceWrapper.toggleStreaming()
                                    onSpeak(if (isStreaming) "Surveillance telemetry paused" else "Surveillance telemetry active")
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text(if (isStreaming) "PAUSE" else "STREAM", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    InfluxDbServiceWrapper.triggerAnomaly("CAM-01")
                                    onSpeak("Triggered anomaly spike on CAM-01")
                                },
                                border = BorderStroke(1.dp, Color(0xFFFF3366)),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text("ANOMALY", fontSize = 8.sp, color = Color(0xFFFF3366), fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Rate: ${String.format(Locale.US, "%.1f", writeRatePps)} PPS", fontSize = 9.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                        Text("Points: $totalPoints", fontSize = 9.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                        Text("Nodes: ${telemetryMap.size}", fontSize = 9.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        if (anomalyNode != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF38000E),
                    border = BorderStroke(1.dp, Color(0xFFFF3366))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("ALERT: Anomaly active on Node $anomalyNode! Thermal & latency spike detected.", color = Color(0xFFFF99AA), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        TextButton(
                            onClick = { InfluxDbServiceWrapper.clearAnomaly() },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                            modifier = Modifier.height(22.dp)
                        ) {
                            Text("CLEAR", color = Color(0xFFFF3366), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Text("LIVE SURVEILLANCE NODE TELEMETRY", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
        }

        items(telemetryMap.values.toList()) { telem ->
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF090D1A),
                border = BorderStroke(1.dp, if (telem.isAnomaly) Color(0xFFFF3366) else Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(if (telem.isAnomaly) Color(0xFFFF3366) else Color(0xFF39FF14)))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(telem.nodeId, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("${telem.category} • RSSI ${telem.signalRssiDbm}dBm", fontSize = 8.sp, color = Color(0xFF94A3B8))
                        }
                        Text(telem.sector, fontSize = 8.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Lat: ${telem.latencyMs}ms", fontSize = 9.sp, color = if (telem.latencyMs > 100) Color(0xFFFF3366) else Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                        Text("FLIR: ${String.format(Locale.US, "%.1f", telem.thermalTempC)}°C", fontSize = 9.sp, color = if (telem.thermalTempC > 50f) Color(0xFFFF3366) else Color(0xFFFF9900), fontFamily = FontFamily.Monospace)
                        Text("Bps: ${String.format(Locale.US, "%.1f", telem.bitrateMbps)}M", fontSize = 9.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                        Text("Loss: ${String.format(Locale.US, "%.1f", telem.packetLossPct)}%", fontSize = 9.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("AI: ${String.format(Locale.US, "%.0f", telem.aiConfidencePct)}%", fontSize = 9.sp, color = Color(0xFFBD00FF), fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text("RECENT INFLUXDB LINE PROTOCOL INGEST STREAM", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
        }

        items(recentFeeds) { line ->
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xFF030508),
                border = BorderStroke(0.6.dp, Color(0xFF1E293B))
            ) {
                Text(
                    text = line,
                    fontSize = 8.sp,
                    color = Color(0xFF39FF14),
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(6.dp)
                )
            }
        }
    }
}
