package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.ViewGroup
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.data.*
import com.example.ui.components.FaceLivenessAnalyzer
import com.example.ui.components.HapticFeedbackManager
import com.example.ui.components.SphericalShellCanvas
import com.example.util.VoiceActionExecutor
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sin

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun VisionVoiceControlScreen(
    onCommandRecognized: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()
    val hapticManager = remember { HapticFeedbackManager(context) }
    val metadataRepo = remember { AzureFaceMetadataRepository() }
    val reasoningBridge = remember { DualEngineReasoningBridge() }
    val database = remember { AppDatabase.getDatabase(context) }
    val logDao = database.identifiedFaceLogDao()

    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
    )

    var detectedFacesCount by remember { mutableStateOf(0) }
    var livenessScore by remember { mutableStateOf(0.99f) }
    var azureStatus by remember { mutableStateOf("Azure Face API v1.4 & Room DB Active") }
    var voiceText by remember { mutableStateOf("Tap mic to speak voice command...") }
    var isListening by remember { mutableStateOf(false) }
    var currentScale by remember { mutableStateOf(1f) }
    var audioRmsDb by remember { mutableStateOf(0f) }
    var currentIdentifiedSubject by remember { mutableStateOf("Scanning known personnel...") }

    // Speech Recognizer setup
    val speechRecognizer = remember {
        SpeechRecognizer.createSpeechRecognizer(context)
    }

    DisposableEffect(Unit) {
        val listener = object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                audioRmsDb = rmsdB.coerceIn(0f, 20f)
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { isListening = false }
            override fun onError(error: Int) {
                isListening = false
                voiceText = "Voice Error Code: $error"
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val command = matches[0]
                    voiceText = "Command: \"$command\""
                    hapticManager.vibrateTouchGesture()

                    // Execute specific voice action or fallback to dual engine reasoning
                    val result = VoiceActionExecutor.executeCommand(context, command)
                    when (result) {
                        is VoiceActionExecutor.VoiceExecutionResult.Handled -> {
                            azureStatus = "Voice Action Executed: ${result.message}"
                            com.example.utils.HapticManager.triggerVoiceCommandSuccess(context)
                        }
                        is VoiceActionExecutor.VoiceExecutionResult.KnowledgeAnswer -> {
                            azureStatus = "ARIIA Knowledge: ${result.answer}"
                        }
                        is VoiceActionExecutor.VoiceExecutionResult.NotHandled -> {
                            coroutineScope.launch {
                                val dualResult = reasoningBridge.queryDualEngines(command)
                                azureStatus = "Dual Engine: ${dualResult.synthesizedConclusion}"
                                onCommandRecognized(command)
                            }
                        }
                    }
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
        speechRecognizer.setRecognitionListener(listener)
        onDispose {
            speechRecognizer.destroy()
        }
    }

    LaunchedEffect(permissionsState.allPermissionsGranted) {
        if (!permissionsState.allPermissionsGranted) {
            permissionsState.launchMultiplePermissionRequest()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0A0A0E),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AZURE FACE + ROOM DB HUD",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F0FF),
                            fontFamily = FontFamily.Monospace
                        )
                        Badge(
                            containerColor = Color(0xFF00363D),
                            contentColor = Color(0xFFE0F7FA)
                        ) {
                            Text("ROOM PERSISTENCE", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp)
                        }
                    }
                    Text(
                        text = "Real-time face tracking, Room database logging, gesture zoom scaling, and voice actions (WhatsApp, Wi-Fi, Alarms, Music).",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            if (permissionsState.allPermissionsGranted) {
                // 3D Spherical Shell Canvas Framing Camera Feed
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF05070B),
                    border = BorderStroke(1.dp, Color(0xFFBD00FF).copy(alpha = 0.6f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    SphericalShellCanvas(
                        modifier = Modifier.fillMaxSize(),
                        symmetryFolds = 8,
                        rotationSpeed = 1.0f,
                        onScaleChanged = { currentScale = it }
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AndroidView(
                                factory = { ctx ->
                                    PreviewView(ctx).apply {
                                        layoutParams = ViewGroup.LayoutParams(
                                            ViewGroup.LayoutParams.MATCH_PARENT,
                                            ViewGroup.LayoutParams.MATCH_PARENT
                                        )
                                        scaleType = PreviewView.ScaleType.FILL_CENTER
                                    }
                                },
                                modifier = Modifier.fillMaxSize(),
                                update = { previewView ->
                                    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                                    cameraProviderFuture.addListener({
                                        val cameraProvider = cameraProviderFuture.get()
                                        val preview = Preview.Builder().build().also {
                                            it.setSurfaceProvider(previewView.surfaceProvider)
                                        }

                                        val cameraExecutor = Executors.newSingleThreadExecutor()
                                        val analyzer = FaceLivenessAnalyzer { count, score ->
                                            detectedFacesCount = count
                                            livenessScore = score
                                            if (count > 0) {
                                                val identified = metadataRepo.mapBoundingBoxToUser(0, null)
                                                currentIdentifiedSubject = "${identified.name} (${identified.clearance})"

                                                // Persist identified face log to Room Database asynchronously
                                                coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                                    try {
                                                        logDao.insertLog(
                                                            IdentifiedFaceLogEntity(
                                                                subjectName = identified.name,
                                                                clearanceLevel = identified.clearance,
                                                                department = identified.department,
                                                                livenessScore = identified.livenessScore,
                                                                confidenceScore = 0.98f
                                                            )
                                                        )
                                                    } catch (e: Exception) {
                                                        // Ignore DB errors in analysis loop
                                                    }
                                                }
                                            } else {
                                                currentIdentifiedSubject = "Searching for known personnel..."
                                            }
                                        }

                                        val imageAnalysis = ImageAnalysis.Builder()
                                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                            .build()
                                            .also { analysis ->
                                                analysis.setAnalyzer(cameraExecutor, analyzer)
                                            }

                                        try {
                                            cameraProvider.unbindAll()
                                            cameraProvider.bindToLifecycle(
                                                lifecycleOwner,
                                                CameraSelector.DEFAULT_FRONT_CAMERA,
                                                preview,
                                                imageAnalysis
                                            )
                                        } catch (exc: Exception) {
                                            exc.printStackTrace()
                                        }
                                    }, ContextCompat.getMainExecutor(context))
                                }
                            )

                            // Telemetry Overlay inside 3D Spherical Shell
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "SUBJECT: $currentIdentifiedSubject",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFF39FF14),
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "LIVENESS: ${(livenessScore * 100).toInt()}% | SCALE: ${String.format(Locale.US, "%.2f", currentScale)}x",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF00F0FF),
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = azureStatus,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF0A0A0E),
                    border = BorderStroke(1.dp, Color(0xFFFF3333)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Camera & Audio Permissions Required",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFFFF3333)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { permissionsState.launchMultiplePermissionRequest() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF))
                        ) {
                            Text("Grant Permissions", color = Color.Black)
                        }
                    }
                }
            }

            // Voice Control Card with Active Listening Waveform Animation & Voice Actions
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF14141C),
                border = BorderStroke(1.dp, if (isListening) Color(0xFF39FF14) else Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isListening) "LISTENING (Active Waveform)" else "Voice Control & Quick Actions",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isListening) Color(0xFF39FF14) else Color(0xFF00F0FF)
                            )
                            if (isListening) {
                                Badge(containerColor = Color(0xFF0A3800), contentColor = Color(0xFF39FF14)) {
                                    Text("REC", fontSize = 8.sp)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = voiceText,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )

                        if (isListening) {
                            Spacer(modifier = Modifier.height(8.dp))
                            // Audio Amplitude Waveform Animation
                            Canvas(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(24.dp)
                            ) {
                                val width = size.width
                                val height = size.height
                                val bars = 24
                                val barWidth = width / (bars * 2)
                                for (i in 0 until bars) {
                                    val x = i * barWidth * 2f
                                    val waveFactor = sin((i + System.currentTimeMillis() * 0.015) ).toFloat()
                                    val barHeight = (height * 0.2f + (audioRmsDb * 0.8f * abs(waveFactor))).coerceIn(4f, height)
                                    drawRect(
                                        color = Color(0xFF39FF14),
                                        topLeft = Offset(x, height / 2f - barHeight / 2f),
                                        size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
                                    )
                                }
                            }
                        }
                    }

                    FloatingActionButton(
                        onClick = {
                            hapticManager.vibrateTouchGesture()
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                val settings = com.example.data.SettingsRepository(context)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Say 'Open Wi-Fi', 'WhatsApp Hello', 'Play Music', 'Set Alarm', etc.")
                                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, settings.speechTimeout.toLong())
                                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, settings.speechTimeout.toLong())
                                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, (100f - settings.micSensitivity).toLong() * 20)
                            }
                            speechRecognizer.startListening(intent)
                        },
                        containerColor = if (isListening) Color(0xFFFF3333) else Color(0xFFBD00FF)
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                            contentDescription = "Voice Control",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
