package com.example.util

object OfflineKnowledgeEngine {

    private val knowledgeBase = mapOf(
        "passion" to "Passion is an intense emotion, compelling enthusiasm, or boundless desire for a concept, cause, or endeavor. It acts as the internal fuel for relentless perseverance, high creative flow, and purposeful mastery.",
        "epithelial" to "Epithelial cells are specialized cellular building blocks that form continuous protective sheets covering all external body surfaces, lining body cavities, hollow organs, and blood vessels. They provide crucial barriers against pathogens, chemical toxins, and dehydration while facilitating selective absorption and secretion.",
        "chess" to "Chess is a venerable two-player turn-based strategy game played on an 8-by-8 checkered grid with 64 squares. Each player commands 16 pieces: 1 King, 1 Queen, 2 Rooks, 2 Knights, 2 Bishops, and 8 Pawns. The objective is to place the opposing King into checkmate, where it is under inevitable attack with no legal escape moves.",
        "galileo" to "Galileo Galilei (1564–1642) was an Italian astronomer, physicist, and polymath celebrated as the father of modern observational astronomy, classical physics, and the scientific method. He pioneered the telescopic discovery of Jupiter's moons, lunar craters, and sunspots, famously defending the Copernican heliocentric model."
    )

    fun queryOffline(query: String): String? {
        val lower = query.lowercase().trim()

        // Exact & substring matches
        for ((key, answer) in knowledgeBase) {
            if (lower.contains(key)) {
                return answer
            }
        }

        // Additional offline queries
        return when {
            lower.contains("who are you") || lower.contains("your name") ->
                "I am A.R.I.I.A. (Autonomous Reconnaissance & Intelligent Integration Assistant). I provide complete offline intelligence, teachable vision recognition, speech alarms, and direct device navigation."

            lower.contains("time") && (lower.contains("what") || lower.contains("current")) -> {
                val now = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
                "The current local system time is $now."
            }

            lower.contains("date") && (lower.contains("what") || lower.contains("today")) -> {
                val today = java.text.SimpleDateFormat("EEEE, MMMM dd, yyyy", java.util.Locale.getDefault()).format(java.util.Date())
                "Today is $today."
            }

            lower.contains("gravity") ->
                "Gravity is a fundamental physical interaction causing mutual attraction between all entities with mass or energy, described by Einstein's General Relativity as the curvature of spacetime."

            lower.contains("quantum") ->
                "Quantum mechanics is the foundational theory in physics describing nature at the atomic and subatomic scales, where energy, momentum, and angular momentum are quantized."

            lower.contains("photosynthesis") ->
                "Photosynthesis is the biological process by which green plants, algae, and cyanobacteria synthesize glucose and oxygen from sunlight, water, and carbon dioxide."

            lower.contains("offline") ->
                "A.R.I.I.A. operates fully offline. Local neural models, speech synthesis, teachable vision heuristics, and system triggers function seamlessly without internet access."

            else -> null
        }
    }
}
