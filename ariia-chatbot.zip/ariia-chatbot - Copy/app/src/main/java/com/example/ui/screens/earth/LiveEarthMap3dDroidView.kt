package com.example.ui.screens.earth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.VoiceActionExecutor
import kotlin.math.*

data class DroidLandmark3D(
    val id: String,
    val name: String,
    val city: String,
    val country: String,
    val lat: Float,
    val lon: Float,
    val elevationM: Int,
    val description: String
)

@Composable
fun LiveEarthMap3dDroidView(
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val famousLandmarks = remember {
        listOf(
            DroidLandmark3D("eiffel", "Eiffel Tower 3D", "Paris", "France", 48.8584f, 2.2945f, 330, "Iron lattice tower on the Champ de Mars in Paris."),
            DroidLandmark3D("pyramids", "Giza Pyramids 3D", "Cairo", "Egypt", 29.9792f, 31.1342f, 138, "Ancient Egyptian stone pyramids and Great Sphinx."),
            DroidLandmark3D("colosseum", "Colosseum 3D", "Rome", "Italy", 41.8902f, 12.4922f, 48, "Flavian Amphitheatre in the centre of Rome."),
            DroidLandmark3D("statue", "Statue of Liberty 3D", "New York", "USA", 40.6892f, -74.0445f, 93, "Neoclassical copper statue on Liberty Island."),
            DroidLandmark3D("taj", "Taj Mahal 3D", "Agra", "India", 27.1751f, 78.0421f, 73, "Ivory-white marble mausoleum on the Yamuna river."),
            DroidLandmark3D("everest", "Mount Everest 3D", "Solukhumbu", "Nepal", 27.9881f, 86.9250f, 8849, "Earth's highest mountain above sea level."),
            DroidLandmark3D("burj", "Burj Khalifa 3D", "Dubai", "UAE", 25.1972f, 55.2744f, 828, "World's tallest building and 3D architectural landmark.")
        )
    }

    var selectedLandmark by remember { mutableStateOf(famousLandmarks[0]) }
    var pitchDeg by remember { mutableStateOf(45f) }
    var yawDeg by remember { mutableStateOf(15f) }
    var zoomLevel by remember { mutableStateOf(1.2f) }
    var showTraffic by remember { mutableStateOf(true) }
    var show3dBuildings by remember { mutableStateOf(true) }
    var showSatelliteLayer by remember { mutableStateOf(true) }
    var isDownloadingMap by remember { mutableStateOf(false) }
    var downloadProgress by remember { mutableStateOf(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "Droid3DAnim")
    val gridPulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Reverse),
        label = "Pulse"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF060A12))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Droid Developer Top Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0B1426), RoundedCornerShape(10.dp))
                .border(1.dp, Color(0xFF34A853), RoundedCornerShape(10.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Map, contentDescription = null, tint = Color(0xFF34A853), modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text("LIVE EARTH MAP 3D", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF34A853), fontFamily = FontFamily.Monospace)
                    Text("Droid Developer Interactive 3D Satellite & Terrain Engine", fontSize = 8.sp, color = Color(0xFF94A3B8))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        VoiceActionExecutor.launchGoogleEarth(context, selectedLandmark.lat, selectedLandmark.lon)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.Public, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Google Earth", fontSize = 8.sp, color = Color.White)
                }

                Button(
                    onClick = {
                        VoiceActionExecutor.launchLiveEarthMap(context, selectedLandmark.lat, selectedLandmark.lon)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34A853)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Live Recon App", fontSize = 8.sp, color = Color.White)
                }
            }
        }

        // Famous 3D Landmarks Bar
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(famousLandmarks) { landmark ->
                val isSel = landmark.id == selectedLandmark.id
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) Color(0xFF00382B) else Color(0xFF0F172A),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFF34A853) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable {
                        selectedLandmark = landmark
                        onSpeak("Navigating Live Earth 3D viewport to ${landmark.name} in ${landmark.city}.")
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.LocationCity, contentDescription = null, tint = if (isSel) Color(0xFF34A853) else Color(0xFF64748B), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(landmark.name, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("${landmark.city}, ${landmark.country}", fontSize = 7.sp, color = Color(0xFF94A3B8))
                        }
                    }
                }
            }
        }

        // 3D Viewport Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF030712), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF34A853).copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        yawDeg = (yawDeg - dragAmount.x * 0.4f) % 360f
                        pitchDeg = (pitchDeg + dragAmount.y * 0.4f).coerceIn(10f, 80f)
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val center = Offset(w / 2f, h / 2f)

                // Render 3D Grid Terrain
                val gridLines = 14
                val stepX = w / gridLines
                val stepY = h / gridLines

                val gridColor = if (showSatelliteLayer) Color(0xFF004D40) else Color(0xFF1A237E)
                for (i in 0..gridLines) {
                    val x = i * stepX
                    drawLine(gridColor.copy(alpha = 0.3f), Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
                    val y = i * stepY
                    drawLine(gridColor.copy(alpha = 0.3f), Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                }

                // Render 3D Extruded Landmark Box
                if (show3dBuildings) {
                    val boxWidth = 80f * zoomLevel
                    val boxHeight = 140f * zoomLevel * (selectedLandmark.elevationM.toFloat() / 500f).coerceIn(0.5f, 2.5f)

                    val topCenter = Offset(center.x + sin(Math.toRadians(yawDeg.toDouble())).toFloat() * 30f, center.y - cos(Math.toRadians(pitchDeg.toDouble())).toFloat() * 40f)

                    // Draw 3D Building Base
                    drawRect(
                        brush = Brush.verticalGradient(listOf(Color(0xFF34A853).copy(alpha = 0.6f), Color(0xFF004D40).copy(alpha = 0.2f))),
                        topLeft = Offset(topCenter.x - boxWidth / 2, topCenter.y - boxHeight),
                        size = Size(boxWidth, boxHeight)
                    )

                    drawRect(
                        color = Color(0xFF34A853),
                        topLeft = Offset(topCenter.x - boxWidth / 2, topCenter.y - boxHeight),
                        size = Size(boxWidth, boxHeight),
                        style = Stroke(width = 2f)
                    )

                    // Beacon Top
                    drawCircle(
                        color = Color(0xFFFFCC00),
                        radius = 6f * gridPulse,
                        center = Offset(topCenter.x, topCenter.y - boxHeight - 10f)
                    )
                }

                // Traffic Flow Overlay
                if (showTraffic) {
                    drawPath(
                        path = Path().apply {
                            moveTo(center.x - 120, center.y + 80)
                            quadraticTo(center.x, center.y + 20, center.x + 120, center.y + 100)
                        },
                        color = Color(0xFFFF3366),
                        style = Stroke(width = 4f)
                    )
                    drawPath(
                        path = Path().apply {
                            moveTo(center.x - 100, center.y - 60)
                            quadraticTo(center.x + 40, center.y - 10, center.x + 140, center.y - 80)
                        },
                        color = Color(0xFF39FF14),
                        style = Stroke(width = 4f)
                    )
                }
            }

            // HUD Overlay Controls
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, Color(0xFF34A853))
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text("TARGET: ${selectedLandmark.name}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34A853))
                        Text("LAT: ${selectedLandmark.lat}° | LON: ${selectedLandmark.lon}°", fontSize = 8.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        Text("ELEV: ${selectedLandmark.elevationM}m | TILT: ${pitchDeg.toInt()}° | ROT: ${yawDeg.toInt()}°", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // View Mode Toggles (3D Buildings, Satellite, Traffic)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChip(
                    selected = show3dBuildings,
                    onClick = { show3dBuildings = !show3dBuildings },
                    label = { Text("3D Buildings", fontSize = 8.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF34A853), selectedLabelColor = Color.White)
                )
                FilterChip(
                    selected = showTraffic,
                    onClick = { showTraffic = !showTraffic },
                    label = { Text("Live Traffic", fontSize = 8.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFF3366), selectedLabelColor = Color.White)
                )
                FilterChip(
                    selected = showSatelliteLayer,
                    onClick = { showSatelliteLayer = !showSatelliteLayer },
                    label = { Text("Satellite", fontSize = 8.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF4285F4), selectedLabelColor = Color.White)
                )
            }
        }

        // Landmark Briefing & Speech
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF0F172A),
            border = BorderStroke(1.dp, Color(0xFF34A853).copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(selectedLandmark.name, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(selectedLandmark.description, fontSize = 8.sp, color = Color(0xFFCBD5E1))
                }

                Button(
                    onClick = {
                        val msg = "Live Earth Map 3D Droid Developer viewport locked on ${selectedLandmark.name} in ${selectedLandmark.city}, ${selectedLandmark.country}. Latitude ${selectedLandmark.lat}, Longitude ${selectedLandmark.lon}. Elevation ${selectedLandmark.elevationM} meters. ${selectedLandmark.description}"
                        onSpeak(msg)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34A853)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Audio Brief", fontSize = 8.sp, color = Color.White)
                }
            }
        }
    }
}
