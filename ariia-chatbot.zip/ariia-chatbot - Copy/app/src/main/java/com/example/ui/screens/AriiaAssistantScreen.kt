package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ChatMessage
import com.example.util.AriiaSpeechEngine
import com.example.util.VoiceActionExecutor
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import kotlinx.coroutines.launch
import java.util.Locale

// Card metadata for rich phone assistant response cards
data class AssistantActionCardData(
    val id: String = java.util.UUID.randomUUID().toString(),
    val userQuery: String,
    val actionType: String, // TORCH, TIMER, ALARM, CALL, SMS, BATTERY, VOLUME, NAVIGATION, WEATHER, SEARCH, APP
    val headline: String,
    val speechResponse: String,
    val details: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun AriiaAssistantScreen(
    ariiaMessages: List<ChatMessage>,
    isProcessing: Boolean,
    onQueryAriia: (String) -> Unit,
    onAddMessage: ((String, String) -> Unit)? = null,
    onNavigateTab: ((Int) -> Unit)? = null
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val speechEngine = remember { AriiaSpeechEngine(context) }
    DisposableEffect(Unit) {
        onDispose {
            speechEngine.shutdown()
        }
    }

    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(
            Manifest.permission.RECORD_AUDIO
        )
    )

    var queryInput by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    var recognizedLiveTranscript by remember { mutableStateOf("") }
    var audioRmsDb by remember { mutableStateOf(0f) }
    var isTorchOn by remember { mutableStateOf(VoiceActionExecutor.isTorchActive) }
    var batteryState by remember { mutableStateOf(VoiceActionExecutor.getBatteryInfo(context)) }
    var isSpeechMuted by remember { mutableStateOf(false) }
    var activeActionCards by remember { mutableStateOf(listOf<AssistantActionCardData>()) }

    // Speech Recognizer setup
    val speechRecognizer = remember {
        SpeechRecognizer.createSpeechRecognizer(context)
    }

    // Function to execute any command (voice or typed)
    fun processCommand(commandText: String) {
        val trimmed = commandText.trim()
        if (trimmed.isBlank()) return

        // Post user message
        onAddMessage?.invoke("User", trimmed)

        // Execute through VoiceActionExecutor
        val activeEngine = if (isSpeechMuted) null else speechEngine
        val execResult = VoiceActionExecutor.executeCommand(
            context = context,
            command = trimmed,
            speechEngine = activeEngine,
            scope = coroutineScope
        )

        when (execResult) {
            is VoiceActionExecutor.VoiceExecutionResult.Handled -> {
                val speechResp = execResult.speechResponse ?: execResult.message
                onAddMessage?.invoke("Assistant", speechResp)
                isTorchOn = VoiceActionExecutor.isTorchActive
                batteryState = VoiceActionExecutor.getBatteryInfo(context)
                com.example.utils.HapticManager.triggerVoiceCommandSuccess(context)

                val newCard = AssistantActionCardData(
                    userQuery = trimmed,
                    actionType = execResult.actionType,
                    headline = execResult.message,
                    speechResponse = speechResp,
                    details = execResult.details
                )
                activeActionCards = activeActionCards + newCard
            }
            is VoiceActionExecutor.VoiceExecutionResult.KnowledgeAnswer -> {
                onAddMessage?.invoke("Assistant", execResult.answer)
                val newCard = AssistantActionCardData(
                    userQuery = trimmed,
                    actionType = "SEARCH",
                    headline = "Knowledge Engine",
                    speechResponse = execResult.answer,
                    details = "Verified Intelligence"
                )
                activeActionCards = activeActionCards + newCard
            }
            is VoiceActionExecutor.VoiceExecutionResult.NotHandled -> {
                // Delegate to Gemini AI
                onQueryAriia(trimmed)
            }
        }
    }

    DisposableEffect(Unit) {
        val listener = object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                recognizedLiveTranscript = "Listening... Speak your command"
            }
            override fun onBeginningOfSpeech() {
                recognizedLiveTranscript = "Recognizing voice input..."
            }
            override fun onRmsChanged(rmsdB: Float) {
                audioRmsDb = rmsdB.coerceIn(0f, 25f)
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isListening = false
            }
            override fun onError(error: Int) {
                isListening = false
                recognizedLiveTranscript = "Voice recognizer code: $error"
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val command = matches[0]
                    com.example.utils.HapticManager.triggerVoiceCommandProcessing(context)
                    recognizedLiveTranscript = "\"$command\""
                    processCommand(command)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    recognizedLiveTranscript = matches[0]
                }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
        speechRecognizer.setRecognitionListener(listener)
        onDispose {
            speechRecognizer.destroy()
        }
    }

    // Function to start listening
    fun startListening() {
        com.example.utils.HapticManager.triggerVoiceCommandInitiation(context)
        if (!permissionsState.allPermissionsGranted) {
            permissionsState.launchMultiplePermissionRequest()
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                val settings = com.example.data.SettingsRepository(context)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Google Voice Command: Try 'Set timer for 5 minutes', 'Call Mom', 'Turn on flashlight'")
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, settings.speechTimeout.toLong())
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, settings.speechTimeout.toLong())
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, (100f - settings.micSensitivity).toLong() * 20)
            }
            speechRecognizer.startListening(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Voice recognizer initialization issue", Toast.LENGTH_SHORT).show()
        }
    }

    // Auto-scroll when messages or cards arrive
    LaunchedEffect(ariiaMessages.size, activeActionCards.size) {
        coroutineScope.launch {
            val totalCount = ariiaMessages.size + activeActionCards.size
            if (totalCount > 0) {
                listState.animateScrollToItem(totalCount)
            }
        }
    }

    // Infinite breathing pulse for mic
    val infiniteTransition = rememberInfiniteTransition(label = "AssistantPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 600 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080C14))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Google Assistant Header & Phone Controls HUD
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0F172A),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Google 4-Color Indicator Dots
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF4285F4))) // Google Blue
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFEA4335))) // Google Red
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFBBC05))) // Google Yellow
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF34A853))) // Google Green
                            }
                            Column {
                                Text(
                                    text = "GOOGLE VOICE ASSISTANT",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "Standard Phone Assistant & System Controls",
                                    fontSize = 10.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }

                        // Right Action Controls: Mute Voice & Google Voice Search Intent
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            IconButton(
                                onClick = { isSpeechMuted = !isSpeechMuted },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (isSpeechMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = "Toggle Speech",
                                    tint = if (isSpeechMuted) Color(0xFFEF4444) else Color(0xFF38BDF8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Button(
                                onClick = {
                                    VoiceActionExecutor.launchGoogleVoiceSearch(context)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF1E293B),
                                    contentColor = Color(0xFF38BDF8)
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Search", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    // Live Phone Hardware Status Chips Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Torch Chip
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isTorchOn) Color(0xFFEAB308).copy(alpha = 0.2f) else Color(0xFF1E293B),
                            border = BorderStroke(1.dp, if (isTorchOn) Color(0xFFEAB308) else Color(0xFF334155)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    VoiceActionExecutor.toggleTorch(context)
                                    isTorchOn = VoiceActionExecutor.isTorchActive
                                    val state = if (isTorchOn) "ON" else "OFF"
                                    if (!isSpeechMuted) speechEngine.speak("Flashlight $state")
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FlashOn,
                                    contentDescription = null,
                                    tint = if (isTorchOn) Color(0xFFFBBF24) else Color(0xFF94A3B8),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isTorchOn) "Torch ON" else "Torch OFF",
                                    fontSize = 11.sp,
                                    color = if (isTorchOn) Color(0xFFFDE047) else Color(0xFFCBD5E1),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Battery Chip
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF334155)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    batteryState = VoiceActionExecutor.getBatteryInfo(context)
                                    val (pct, charging) = batteryState
                                    val statusMsg = "Battery $pct% ${if (charging) "charging" else ""}"
                                    if (!isSpeechMuted) speechEngine.speak(statusMsg)
                                    Toast.makeText(context, statusMsg, Toast.LENGTH_SHORT).show()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.BatteryFull,
                                    contentDescription = null,
                                    tint = if (batteryState.second) Color(0xFF34D399) else Color(0xFF60A5FA),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${batteryState.first}% ${if (batteryState.second) "⚡" else ""}",
                                    fontSize = 11.sp,
                                    color = Color(0xFFCBD5E1),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Quick Navigation Chip
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF334155)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    processCommand("navigate to nearest gas station")
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Place,
                                    contentDescription = null,
                                    tint = Color(0xFFF43F5E),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Navigate",
                                    fontSize = 11.sp,
                                    color = Color(0xFFCBD5E1),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // 2. Standard Phone Assistant Quick Action Carousel
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    AssistantQuickChip(
                        icon = Icons.Default.Call,
                        label = "Call Mom",
                        badgeColor = Color(0xFF3B82F6),
                        onClick = { processCommand("call mom") }
                    )
                }
                item {
                    AssistantQuickChip(
                        icon = Icons.Default.Timer,
                        label = "5 Min Timer",
                        badgeColor = Color(0xFF10B981),
                        onClick = { processCommand("set timer for 5 minutes") }
                    )
                }
                item {
                    AssistantQuickChip(
                        icon = Icons.Default.Alarm,
                        label = "7 AM Alarm",
                        badgeColor = Color(0xFFF59E0B),
                        onClick = { processCommand("set alarm for 7:00 am") }
                    )
                }
                item {
                    AssistantQuickChip(
                        icon = Icons.Default.Email,
                        label = "Send SMS",
                        badgeColor = Color(0xFF8B5CF6),
                        onClick = { processCommand("send message to Alex saying I will arrive soon") }
                    )
                }
                item {
                    AssistantQuickChip(
                        icon = Icons.Default.WbSunny,
                        label = "Weather",
                        badgeColor = Color(0xFF06B6D4),
                        onClick = { processCommand("what is the weather today") }
                    )
                }
                item {
                    AssistantQuickChip(
                        icon = Icons.Default.PlayArrow,
                        label = "Play Music",
                        badgeColor = Color(0xFFEC4899),
                        onClick = { processCommand("play music on youtube") }
                    )
                }
                item {
                    AssistantQuickChip(
                        icon = Icons.Default.CameraAlt,
                        label = "Camera",
                        badgeColor = Color(0xFF64748B),
                        onClick = { processCommand("open camera") }
                    )
                }
                item {
                    AssistantQuickChip(
                        icon = Icons.Default.Settings,
                        label = "Wi-Fi Config",
                        badgeColor = Color(0xFF6366F1),
                        onClick = { processCommand("open wifi settings") }
                    )
                }
            }

            // 3. Conversation & Executed Actions Feed
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0F172A),
                border = BorderStroke(1.dp, Color(0xFF1E293B))
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Action cards list
                    items(activeActionCards) { card ->
                        AssistantActionCardView(card = card, onProcessCommand = { processCommand(it) })
                    }

                    // Existing Chat Messages
                    items(ariiaMessages) { msg ->
                        AriiaBubble(message = msg)
                    }

                    if (isProcessing) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color(0xFF38BDF8),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Assistant processing instruction...",
                                    fontSize = 12.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            }

            // 4. Live Speech Transcript Bar (Animated when recognizing)
            AnimatedVisibility(visible = recognizedLiveTranscript.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B),
                    border = BorderStroke(1.dp, if (isListening) Color(0xFF38BDF8) else Color(0xFF334155)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            if (isListening) {
                                // Animated Voice Wave Bars
                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    val wave1 = (audioRmsDb * 1.2f).coerceIn(4f, 22f)
                                    val wave2 = (audioRmsDb * 0.9f + 5f).coerceIn(4f, 24f)
                                    val wave3 = (audioRmsDb * 1.4f).coerceIn(4f, 26f)
                                    val wave4 = (audioRmsDb * 0.8f + 3f).coerceIn(4f, 20f)
                                    Box(modifier = Modifier.width(3.dp).height(wave1.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF4285F4)))
                                    Box(modifier = Modifier.width(3.dp).height(wave2.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFFEA4335)))
                                    Box(modifier = Modifier.width(3.dp).height(wave3.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFFFBBC05)))
                                    Box(modifier = Modifier.width(3.dp).height(wave4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF34A853)))
                                }
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = recognizedLiveTranscript,
                                fontSize = 12.sp,
                                color = if (isListening) Color(0xFF38BDF8) else Color.White,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        if (!isListening) {
                            IconButton(
                                onClick = { recognizedLiveTranscript = "" },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            // 5. Central Google Voice Command Console & Input Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Large Pulsating Google Voice Mic Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(56.dp)
                ) {
                    // Pulsating outer aura
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(
                                if (isListening) {
                                    Brush.radialGradient(
                                        listOf(
                                            Color(0xFF4285F4).copy(alpha = 0.6f),
                                            Color(0xFFEA4335).copy(alpha = 0.3f),
                                            Color.Transparent
                                        )
                                    )
                                } else {
                                    Brush.radialGradient(
                                        listOf(
                                            Color(0xFF0284C7).copy(alpha = 0.3f),
                                            Color.Transparent
                                        )
                                    )
                                }
                            )
                    )

                    IconButton(
                        onClick = {
                            if (isListening) {
                                speechRecognizer.stopListening()
                                isListening = false
                            } else {
                                startListening()
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (isListening) {
                                    Brush.linearGradient(
                                        listOf(Color(0xFFEA4335), Color(0xFFFBBC05), Color(0xFF34A853), Color(0xFF4285F4))
                                    )
                                } else {
                                    Brush.linearGradient(
                                        listOf(Color(0xFF2563EB), Color(0xFF0284C7))
                                    )
                                }
                            )
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                            contentDescription = "Google Voice Command Mic",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                // Text Input fallback for commands
                OutlinedTextField(
                    value = queryInput,
                    onValueChange = { queryInput = it },
                    modifier = Modifier.weight(1f),
                    placeholder = {
                        Text(
                            text = "Say \"Hey Google\" or type...",
                            fontSize = 13.sp,
                            color = Color(0xFF64748B)
                        )
                    },
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF0F172A),
                        unfocusedContainerColor = Color(0xFF0F172A)
                    ),
                    maxLines = 2,
                    trailingIcon = {
                        if (queryInput.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    processCommand(queryInput)
                                    queryInput = ""
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Execute Command",
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun AssistantQuickChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    badgeColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1E293B),
        border = BorderStroke(1.dp, Color(0xFF334155)),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(badgeColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(12.dp)
                )
            }
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFE2E8F0)
            )
        }
    }
}

@Composable
fun AssistantActionCardView(
    card: AssistantActionCardData,
    onProcessCommand: (String) -> Unit
) {
    val context = LocalContext.current

    val (badgeIcon, accentColor, typeLabel) = when (card.actionType) {
        "TORCH" -> Triple(Icons.Default.FlashOn, Color(0xFFFBBF24), "HARDWARE TORCH")
        "TIMER" -> Triple(Icons.Default.Timer, Color(0xFF34D399), "SYSTEM TIMER")
        "ALARM" -> Triple(Icons.Default.Alarm, Color(0xFFF97316), "SYSTEM ALARM")
        "CALL" -> Triple(Icons.Default.Call, Color(0xFF3B82F6), "PHONE DIALER")
        "SMS" -> Triple(Icons.Default.Email, Color(0xFFA855F7), "MESSAGING")
        "BATTERY" -> Triple(Icons.Default.BatteryFull, Color(0xFF06B6D4), "POWER METRICS")
        "VOLUME" -> Triple(Icons.Default.VolumeUp, Color(0xFFEC4899), "AUDIO CONTROL")
        "NAVIGATION" -> Triple(Icons.Default.Place, Color(0xFFEF4444), "GOOGLE MAPS")
        "WEATHER" -> Triple(Icons.Default.WbSunny, Color(0xFFF59E0B), "WEATHER INTEL")
        else -> Triple(Icons.Default.Search, Color(0xFF38BDF8), "ASSISTANT ACTION")
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF131D31),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(accentColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(badgeIcon, contentDescription = null, tint = accentColor, modifier = Modifier.size(14.dp))
                    }
                    Text(
                        text = typeLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = accentColor,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "EXECUTED",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF10B981),
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF10B981).copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            Text(
                text = card.headline,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )

            if (!card.details.isNullOrBlank()) {
                Text(
                    text = card.details,
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            // Interactive action button based on card action type
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                when (card.actionType) {
                    "TORCH" -> {
                        Button(
                            onClick = {
                                VoiceActionExecutor.toggleTorch(context)
                                onProcessCommand("toggle flashlight")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor.copy(alpha = 0.25f), contentColor = accentColor),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Toggle Torch", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    "TIMER" -> {
                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                                        putExtra(AlarmClock.EXTRA_LENGTH, 300)
                                        putExtra(AlarmClock.EXTRA_MESSAGE, "Assistant Timer")
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor.copy(alpha = 0.25f), contentColor = accentColor),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Open Clock App", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    "ALARM" -> {
                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor.copy(alpha = 0.25f), contentColor = accentColor),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("View Alarms", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    "CALL" -> {
                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_DIAL).apply {
                                        data = Uri.parse("tel:")
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor.copy(alpha = 0.25f), contentColor = accentColor),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Open Dialer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    "SEARCH" -> {
                        Button(
                            onClick = {
                                VoiceActionExecutor.launchGoogleVoiceSearch(context, card.headline.replace("Google: ", ""))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor.copy(alpha = 0.25f), contentColor = accentColor),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Open Google", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AriiaBubble(message: ChatMessage) {
    val isUser = message.sender == "User"
    val backgroundColor = if (isUser) Color(0xFF1E3A8A) else Color(0xFF131C2E)
    val borderColor = if (isUser) Color(0xFF3B82F6) else Color(0xFF00E5FF).copy(alpha = 0.5f)
    val textColor = Color.White
    val alignment = if (isUser) Alignment.End else Alignment.Start

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Text(
            text = if (isUser) "OPERATOR" else "ASSISTANT",
            style = MaterialTheme.typography.labelSmall,
            color = if (isUser) Color(0xFF93C5FD) else Color(0xFF00E5FF),
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = backgroundColor,
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Text(
                text = message.text,
                style = MaterialTheme.typography.bodyMedium,
                color = textColor,
                modifier = Modifier.padding(14.dp)
            )
        }
    }
}
