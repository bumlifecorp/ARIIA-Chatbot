package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun SettingsDialog(
    confidenceThreshold: Int,
    onConfidenceThresholdChange: (Int) -> Unit,
    iconShape: String = "Squircle",
    onIconShapeChange: (String) -> Unit = {},
    iconSize: String = "Medium",
    onIconSizeChange: (String) -> Unit = {},
    onPickWallpaper: () -> Unit = {},
    onOpenCustomActions: () -> Unit = {},
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = ImmersiveSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INSTÄLLNINGAR",
                        style = MaterialTheme.typography.titleMedium,
                        color = ImmersiveLavender,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Stäng",
                            tint = ImmersiveTextSecondary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
                
                Text(
                    text = "AI Objektigenkänning Känslighet",
                    color = ImmersiveTextPrimary,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Justera tröskelvärdet för när kameran ska rapportera ett objekt. Högre värde ger färre fel, lägre värde hittar fler objekt.",
                    color = ImmersiveTextMuted,
                    style = MaterialTheme.typography.bodySmall,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Känslighet:", color = ImmersiveTextSecondary, style = MaterialTheme.typography.bodyMedium)
                    Text("$confidenceThreshold%", color = ImmersiveLavender, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                }
                
                Slider(
                    value = confidenceThreshold.toFloat(),
                    onValueChange = { onConfidenceThresholdChange(it.toInt()) },
                    valueRange = 10f..95f,
                    steps = 16,
                    colors = SliderDefaults.colors(
                        thumbColor = ImmersiveLavender,
                        activeTrackColor = ImmersiveLavender,
                        inactiveTrackColor = ImmersiveBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                

                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "THEME CUSTOMIZATION",
                    color = ImmersiveTextPrimary,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                Text("Ikonform", color = ImmersiveTextSecondary, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(4.dp))
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val shapes = listOf("Default", "Circle", "Squircle", "Teardrop")
                    items(shapes.size) { i ->
                        val shape = shapes[i]
                        val isSelected = shape == iconShape
                        FilterChip(
                            selected = isSelected,
                            onClick = { onIconShapeChange(shape) },
                            label = { Text(shape) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ImmersiveLavender,
                                selectedLabelColor = ImmersiveOnLavender
                            )
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Text("Ikonstorlek", color = ImmersiveTextSecondary, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(4.dp))
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val sizes = listOf("Small", "Medium", "Large")
                    items(sizes.size) { i ->
                        val size = sizes[i]
                        val isSelected = size == iconSize
                        FilterChip(
                            selected = isSelected,
                            onClick = { onIconSizeChange(size) },
                            label = { Text(size) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ImmersiveLavender,
                                selectedLabelColor = ImmersiveOnLavender
                            )
                        )
                    }
                }


                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "PERSONALIZATION",
                    color = ImmersiveTextPrimary,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                Button(
                    onClick = onPickWallpaper,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ImmersiveCardBg, contentColor = ImmersiveTextPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Byt Bakgrundsbild")
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Button(
                    onClick = {
                        onDismiss()
                        onOpenCustomActions()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ImmersiveLavender, contentColor = ImmersiveOnLavender),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Anpassade Röstkommandon")
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ImmersiveLavender,
                        contentColor = ImmersiveOnLavender
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Spara inställningar", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
