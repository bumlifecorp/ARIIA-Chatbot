package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "identified_faces_log")
data class IdentifiedFaceLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val subjectName: String,
    val clearanceLevel: String,
    val department: String,
    val livenessScore: Float,
    val confidenceScore: Float,
    val timestamp: Long = System.currentTimeMillis()
)
