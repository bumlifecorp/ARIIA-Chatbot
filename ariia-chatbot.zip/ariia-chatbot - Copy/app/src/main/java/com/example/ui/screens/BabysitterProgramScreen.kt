package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import com.example.utils.HapticManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

enum class BabysitterProtocol(val title: String, val badge: String, val icon: @Composable () -> Unit) {
    PACIFIER("Asset Shield Protocol", "DEFENSE COUNTERMEASURE", { Icon(Icons.Default.Shield, contentDescription = null) }),
    BABY_MONITOR("Tactical Telemetry Protocol", "SURVEILLANCE", { Icon(Icons.Default.Visibility, contentDescription = null) }),
    KINDERGARDEN("Bunker Geo-Fence Protocol", "SECURE ZONE", { Icon(Icons.Default.Fort, contentDescription = null) }),
    SANDMAN("Acoustic Cloak Protocol", "ACOUSTIC JAMMING", { Icon(Icons.Default.NightsStay, contentDescription = null) }),
    PLAYDATE("Convoy Extradition Protocol", "TACTICAL CONVOY", { Icon(Icons.Default.GroupWork, contentDescription = null) })
}

@Composable
fun BabysitterProgramScreen(
    onNavigateTab: (Int) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }
    val scope = rememberCoroutineScope()

    DisposableEffect(Unit) {
        onDispose { speechEngine.shutdown() }
    }

    var activeProtocol by remember { mutableStateOf(BabysitterProtocol.PACIFIER) }
    var isAutomationEngineActive by remember { mutableStateOf(true) }

    // Government & Military Protection Metrics
    var threatDecibels by remember { mutableFloatStateOf(42f) }
    var vipStatusState by remember { mutableStateOf("SECURE") } // SECURE, ELEVATED_THREAT, LOCKDOWN, EVACUATING
    var vipHeartRateBpm by remember { mutableIntStateOf(72) }
    var vipBreathRateRpm by remember { mutableIntStateOf(16) }
    var safehouseTempC by remember { mutableFloatStateOf(21.4f) }
    var perimeterIntegrity by remember { mutableStateOf("100% NOMINAL") }

    // Asset Shield Protocol States
    var shieldDispensed by remember { mutableStateOf(false) }
    var counterPulseHz by remember { mutableFloatStateOf(432f) }
    var hapticRhythmEnabled by remember { mutableStateOf(true) }

    // Acoustic Cloak Protocol States
    var acousticJammerPlaying by remember { mutableStateOf(false) }
    var twilightIRDimLevel by remember { mutableFloatStateOf(15f) }
    var currentTrack by remember { mutableStateOf("Military-Grade Audio White Noise Counter-Grid #4") }

    // Bunker Geo-Fence Protocol States
    var activeMilestone by remember { mutableStateOf("Level 3 Perimeter Geo-Fence & CBRN Airlock") }
    var safeZoneStatus by remember { mutableStateOf("INSIDE HARDENED SAFE ZONE") }

    // Convoy Extradition Protocol States
    var escortVehicleCount by remember { mutableIntStateOf(4) }
    var hazardAlertCount by remember { mutableIntStateOf(0) }

    // System Decision Automation Loop
    LaunchedEffect(isAutomationEngineActive) {
        while (isAutomationEngineActive) {
            delay(2500)
            if (threatDecibels > 65f && vipStatusState != "LOCKDOWN") {
                vipStatusState = "ELEVATED_THREAT"
                HapticManager.triggerVoiceCommandProcessing(context)
                if (!shieldDispensed) {
                    shieldDispensed = true
                    speechEngine.speak("Asset Shield Protocol engaged. Acoustic spike detected at 68 decibels. Deploying electromagnetic non-lethal counter-frequency pulse.")
                }
            } else if (threatDecibels <= 45f && vipStatusState == "ELEVATED_THREAT") {
                vipStatusState = "SECURE"
                speechEngine.speak("Threat perimeter stabilized. Executive vitals nominal at 72 BPM.")
            }

            vipHeartRateBpm = (68..88).random()
            vipBreathRateRpm = (14..22).random()
            threatDecibels = (threatDecibels + (-3..3).random()).coerceIn(30f, 90f)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF040A12))
            .padding(12.dp)
    ) {
        // Program Header Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1626)),
            border = BorderStroke(1.dp, Color(0xFF1B365D)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(0xFF11223A), CircleShape)
                        .border(1.dp, Color(0xFF00F0FF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Shield,
                        contentDescription = null,
                        tint = Color(0xFF00F0FF),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "[VIP_PROTECTION_PROGRAM]",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = Color(0xFF00F0FF).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "GOVT & MILITARY",
                                fontSize = 8.sp,
                                color = Color(0xFF00F0FF),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Text(
                        text = "Autonomous Executive Protection & Tactical Asset Surveillance",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                // Automation Toggle Switch
                Column(horizontalAlignment = Alignment.End) {
                    Text("AUTOMATION", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Switch(
                        checked = isAutomationEngineActive,
                        onCheckedChange = {
                            isAutomationEngineActive = it
                            speechEngine.speak(if (it) "VIP Protection Automation Engine active" else "Automation paused")
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
                    )
                }
            }
        }

        // Quick Stats Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BabysitterStatChip(
                label = "VIP STATUS",
                value = vipStatusState,
                color = when (vipStatusState) {
                    "ELEVATED_THREAT", "LOCKDOWN" -> Color(0xFFFF0055)
                    "EVACUATING" -> Color(0xFFFFCC00)
                    else -> Color(0xFF39FF14)
                },
                modifier = Modifier.weight(1f)
            )
            BabysitterStatChip(
                label = "VIP VITALS",
                value = "$vipHeartRateBpm BPM",
                color = Color(0xFF00F0FF),
                modifier = Modifier.weight(1f)
            )
            BabysitterStatChip(
                label = "THREAT AUDIO",
                value = "${threatDecibels.toInt()} dB",
                color = if (threatDecibels > 60f) Color(0xFFFF0055) else Color(0xFF38BDF8),
                modifier = Modifier.weight(1f)
            )
            BabysitterStatChip(
                label = "SAFEOUSE TEMP",
                value = "%.1f°C".format(safehouseTempC),
                color = Color(0xFFA855F7),
                modifier = Modifier.weight(1f)
            )
        }

        // Protocol Selector Navigation Tabs
        LazyRow(
            modifier = Modifier.padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(BabysitterProtocol.values()) { protocol ->
                val isSelected = activeProtocol == protocol
                Card(
                    modifier = Modifier.clickable {
                        activeProtocol = protocol
                        HapticManager.triggerVoiceCommandInitiation(context)
                        speechEngine.speak("Switched to ${protocol.title}")
                    },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.2f) else Color(0xFF0B1626)
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) Color(0xFF00F0FF) else Color(0xFF1B365D)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        protocol.icon()
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = protocol.title.replace(" Protocol", ""),
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        // Active Protocol Detail View
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (activeProtocol) {
                BabysitterProtocol.PACIFIER -> AssetShieldProtocolContent(
                    threatDecibels = threatDecibels,
                    isShieldDispensed = shieldDispensed,
                    counterPulseHz = counterPulseHz,
                    isHapticOn = hapticRhythmEnabled,
                    onToggleShield = {
                        shieldDispensed = !shieldDispensed
                        HapticManager.triggerVoiceCommandSuccess(context)
                        speechEngine.speak(if (shieldDispensed) "Asset Shield counter-frequency active" else "Counter pulse standby")
                    },
                    onAdjustCounterHz = { counterPulseHz = it },
                    onToggleHaptic = { hapticRhythmEnabled = it }
                )

                BabysitterProtocol.BABY_MONITOR -> TacticalTelemetryProtocolContent(
                    vipHeartRateBpm = vipHeartRateBpm,
                    vipBreathRateRpm = vipBreathRateRpm,
                    safehouseTempC = safehouseTempC,
                    perimeterIntegrity = perimeterIntegrity
                )

                BabysitterProtocol.KINDERGARDEN -> BunkerGeoFenceProtocolContent(
                    activeMilestone = activeMilestone,
                    safeZoneStatus = safeZoneStatus,
                    onTriggerBriefing = { speechEngine.speak(it) }
                )

                BabysitterProtocol.SANDMAN -> AcousticCloakProtocolContent(
                    isPlaying = acousticJammerPlaying,
                    track = currentTrack,
                    dimLevel = twilightIRDimLevel,
                    onToggleJammer = {
                        acousticJammerPlaying = !acousticJammerPlaying
                        speechEngine.speak(if (acousticJammerPlaying) "Acoustic jamming active: $currentTrack" else "Jammer paused")
                    },
                    onAdjustDim = { twilightIRDimLevel = it }
                )

                BabysitterProtocol.PLAYDATE -> ConvoyExtraditionProtocolContent(
                    escortCount = escortVehicleCount,
                    hazardAlerts = hazardAlertCount,
                    onTriggerAudit = {
                        HapticManager.triggerVoiceCommandSuccess(context)
                        speechEngine.speak("Convoy extradition route clear. Zero hostile incursions detected on vector.")
                    }
                )
            }
        }
    }
}

@Composable
fun BabysitterStatChip(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1626)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 11.sp, color = color, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AssetShieldProtocolContent(
    threatDecibels: Float,
    isShieldDispensed: Boolean,
    counterPulseHz: Float,
    isHapticOn: Boolean,
    onToggleShield: () -> Unit,
    onAdjustCounterHz: (Float) -> Unit,
    onToggleHaptic: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "[ASSET_SHIELD_PROTOCOL] - Non-Lethal Electromagnetic & Acoustic Counter-Pulse",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF00F0FF),
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Acoustic threat detector & tactical electromagnetic pulse frequency grid",
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32)),
                    border = BorderStroke(1.dp, Color(0xFF1E3558))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("THREAT AUDIO SPECTRUM", fontSize = 9.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                            Text("${threatDecibels.toInt()} dB SPL", fontSize = 10.sp, color = if (threatDecibels > 60f) Color(0xFFFF0055) else Color(0xFF39FF14), fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp)
                                .background(Color(0xFF060B14), RoundedCornerShape(6.dp))
                        ) {
                            val width = size.width
                            val height = size.height
                            val midY = height / 2f

                            for (x in 0..width.toInt() step 6) {
                                val normX = x / width
                                val wave = sin(normX * 25f + (System.currentTimeMillis() % 1000) / 100f) * (threatDecibels / 90f) * (height / 2.5f)
                                drawLine(
                                    color = if (threatDecibels > 60f) Color(0xFFFF0055) else Color(0xFF00F0FF),
                                    start = Offset(x.toFloat(), midY - wave),
                                    end = Offset(x.toFloat(), midY + wave),
                                    strokeWidth = 3f
                                )
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onToggleShield,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isShieldDispensed) Color(0xFFFF0055) else Color(0xFF00F0FF)
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (isShieldDispensed) "DE-ENERGIZE COUNTER SHIELD" else "EMIT NON-LETHAL COUNTER PULSE",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            item {
                Text("COUNTER PULSE FREQUENCY: ${counterPulseHz.toInt()} Hz", fontSize = 10.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                Slider(
                    value = counterPulseHz,
                    onValueChange = onAdjustCounterHz,
                    valueRange = 100f..800f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF00F0FF), activeTrackColor = Color(0xFF00F0FF))
                )
            }
        }
    }
}

@Composable
fun TacticalTelemetryProtocolContent(
    vipHeartRateBpm: Int,
    vipBreathRateRpm: Int,
    safehouseTempC: Float,
    perimeterIntegrity: String
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[TACTICAL_TELEMETRY_PROTOCOL] - Multi-Sensor Surveillance & Bio-Vitals",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F0FF),
                fontFamily = FontFamily.Monospace
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("PERIMETER STATUS", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text(perimeterIntegrity, fontSize = 12.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("RESPIRATION", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text("$vipBreathRateRpm RPM", fontSize = 12.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(Color(0xFF04140B), RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFF39FF14).copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Videocam, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("INFRARED THERMAL SAFEHOUSE CAM - ONLINE", fontSize = 10.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    Text("Executive Position: Command Desk | Anti-Sniper Shield: LOCKED", fontSize = 9.sp, color = Color(0xFF86EFAC))
                }
            }
        }
    }
}

@Composable
fun BunkerGeoFenceProtocolContent(
    activeMilestone: String,
    safeZoneStatus: String,
    onTriggerBriefing: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[BUNKER_GEO_FENCE_PROTOCOL] - Hardened Facility & CBRN Integrity",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F0FF),
                fontFamily = FontFamily.Monospace
            )

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("DEFENSE MILESTONE", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text(activeMilestone, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("GEO-FENCE: $safeZoneStatus", fontSize = 9.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                }
            }

            Button(
                onClick = {
                    onTriggerBriefing("Perimeter defense report: Hardened bunker airlocks pressure positive. CBRN filtration fully online.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Security, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("TRIGGER TACTICAL DEFENSE BRIEFING", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun AcousticCloakProtocolContent(
    isPlaying: Boolean,
    track: String,
    dimLevel: Float,
    onToggleJammer: () -> Unit,
    onAdjustDim: (Float) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[ACOUSTIC_CLOAK_PROTOCOL] - Counter-Surveillance Audio Jamming & Night Vision",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F0FF),
                fontFamily = FontFamily.Monospace
            )

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("ACOUSTIC JAMMING MASK", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text(track, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onToggleJammer,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPlaying) Color(0xFFFF0055) else Color(0xFF38BDF8)
                        )
                    ) {
                        Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isPlaying) "PAUSE ACOUSTIC JAMMER" else "ENGAGE ACOUSTIC MASKING FREQUENCY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text("IR TACTICAL LIGHTING LEVEL: ${dimLevel.toInt()}%", fontSize = 10.sp, color = Color.White, fontFamily = FontFamily.Monospace)
            Slider(
                value = dimLevel,
                onValueChange = onAdjustDim,
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = Color(0xFFA855F7), activeTrackColor = Color(0xFFA855F7))
            )
        }
    }
}

@Composable
fun ConvoyExtraditionProtocolContent(
    escortCount: Int,
    hazardAlerts: Int,
    onTriggerAudit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[CONVOY_EXTRADITION_PROTOCOL] - Tactical Escort & Counter-Intelligence Audit",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F0FF),
                fontFamily = FontFamily.Monospace
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("ESCORT VEHICLES", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text("$escortCount Armored Units", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("HOSTILE INCURSIONS", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text("$hazardAlerts Detected", fontSize = 11.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold)
                    }
                }
            }

            Button(
                onClick = onTriggerAudit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("RUN CONVOY ROUTE & COUNTER-INTEL AUDIT", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}
