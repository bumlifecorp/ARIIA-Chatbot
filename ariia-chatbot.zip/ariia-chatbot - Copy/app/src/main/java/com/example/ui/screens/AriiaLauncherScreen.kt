package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.util.AriiaSpeechEngine
import com.example.util.VoiceActionExecutor
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AriiaLauncherScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val roboticsManager = remember { AriiaRoboticsManager(coroutineScope) }
    val speechEngine = remember { AriiaSpeechEngine(context) }
    DisposableEffect(Unit) {
        onDispose {
            speechEngine.shutdown()
        }
    }

    val telemetry by roboticsManager.robotTelemetry.collectAsState()
    val joints by roboticsManager.joints.collectAsState()

    // Custom App Grid State
    var customApps by remember {
        mutableStateOf(
            listOf(
                AriiaAppItem("app-painter", "Painter Recon", null, "open painter protocol", "Tactical", "palette", true, 0),
                AriiaAppItem("app-photographer", "Surveillance Cam", null, "open photographer protocol", "Surveillance", "camera", true, 1),
                AriiaAppItem("app-sculptor", "Fortification", null, "open sculptor protocol", "Military", "build", true, 2),
                AriiaAppItem("app-interiordesigner", "Tactical HQ", null, "open interior designer protocol", "Government", "design_services", true, 3),
                AriiaAppItem("app-babysitter", "VIP Protection", null, "open vip protection program", "Government", "child_care", true, 4),
                AriiaAppItem("app-farmer", "Strategic Recon", null, "open strategic recon program", "Military", "agriculture", true, 5),
                AriiaAppItem("app-chef", "Field Defense", null, "open field defense program", "Military", "restaurant", true, 6),
                AriiaAppItem("app-detective", "Deep Detective AI", null, "open deep detective ai program", "Surveillance", "psychology", true, 7),
                AriiaAppItem("app-aicloud", "AI Cloud", null, "open ai cloud", "Surveillance", "cloud", true, 8),
                AriiaAppItem("app-centrifuge", "300% Centrifuge", null, "open automated centrifuge", "Tactical", "speed", true, 9),
                AriiaAppItem("app-studio", "Android Studio", null, "open android studio", "System", "build", true, 10),
                AriiaAppItem("app-sdkmanager", "SDK Manager", null, "open sdk manager", "System", "settings", true, 11),
                AriiaAppItem("app-apksigner", "APK Signer", null, "open apk signer", "System", "verified", true, 12),
                AriiaAppItem("app-googleearth", "Google Earth 3D", "com.google.earth", "open google earth app", "Sensors", "public", true, 14),
                AriiaAppItem("app-liveearthmap", "Live Earth Map Launcher", null, "open live earth map launcher", "Sensors", "map", true, 15),
                AriiaAppItem("app-liveearth3ddroid", "Live Earth Map 3D Droid", null, "open live earth map 3d", "Sensors", "public", true, 14),
                AriiaAppItem("app-earth3dfoxpoi", "Earth 3D Map FoxPOI", null, "open earth 3d map foxpoi", "Sensors", "public", true, 14),
                AriiaAppItem("app-gophotospherefoxpoi", "Go Photo Sphere FoxPOI", null, "open go street view photo sphere foxpoi", "Sensors", "panorama", true, 14),
                AriiaAppItem("app-minifindergo", "MiniFinder Go GPS", null, "open minifinder go app", "Sensors", "gps_fixed", true, 14),
                AriiaAppItem("app-minifinderlive", "MiniFinder Live Fleet", null, "open minifinder live app", "Sensors", "satellite_alt", true, 14),
                AriiaAppItem("app-minifinderhunter", "MiniFinder Hunter GPS", null, "open minifinder hunter app", "Sensors", "pets", true, 14),
                AriiaAppItem("app-influx", "Influx Telemetry DB", null, "open influx telemetry database", "Sensors", "timeline", true, 26),
                AriiaAppItem("app-insecam", "Insecam CCTV Directory", null, "open insecam camera directory", "Sensors", "videocam", true, 27),
                AriiaAppItem("app-mobotix", "MOBOTIX Edge Surveillance", null, "open mobotix surveillance", "Sensors", "camera_indoor", true, 28),
                AriiaAppItem("app-earth", "Earth View", null, "open earth view", "Sensors", "public", true, 13),
                AriiaAppItem("app-altomaps", "AltoMaps Outdoor Nav", null, "open altomaps outdoor navigation", "Sensors", "terrain", true, 11),
                AriiaAppItem("app-photosphere", "Photo Sphere", null, "open go photo sphere", "Sensors", "panorama", true, 12),
                AriiaAppItem("app-comms", "Secure Comms", null, "open secure comms", "Comms", "forum", true, 13),
                AriiaAppItem("app-1", "Comms Mom", "com.google.android.dialer", "call to mom", "Comms", "phone", true, 8),
                AriiaAppItem("app-2", "WhatsApp", "com.whatsapp", "open whatsapp", "Comms", "whatsapp", true, 9),
                AriiaAppItem("app-3", "Tactical Cam", "com.android.camera", "open camera", "Sensors", "camera", true, 10),
                AriiaAppItem("app-4", "Contacts Base", "com.google.android.contacts", "open contacts", "Comms", "contacts", false, 11),
                AriiaAppItem("app-5", "Secure Chat", "com.google.android.apps.messaging", "open messages", "Comms", "messages", false, 12),
                AriiaAppItem("app-6", "Chrome Intel", "com.android.chrome", "open chrome", "Tactical", "terminal", true, 13),
                AriiaAppItem("app-7", "Wi-Fi Config", null, "open wifi settings", "System", "settings", false, 14),
                AriiaAppItem("app-8", "Bluetooth Link", null, "open bluetooth settings", "System", "settings", false, 15),
                AriiaAppItem("app-9", "Battery Grid", null, "open battery settings", "System", "settings", false, 16),
                AriiaAppItem("app-10", "Display Array", null, "open display settings", "System", "settings", false, 17),
                AriiaAppItem("app-11", "Tactical Alarm", null, "wake me at 7.00 a.m.", "System", "alarm", true, 18),
                AriiaAppItem("app-12", "Meds Reminder", null, "set reminder for medicine at 9.00 p.m.", "System", "alarm", false, 19)
            )
        )
    }

    var activeViewTab by remember { mutableStateOf(0) } // 0: Custom Grid + HUD Overlay, 1: Actuator Robotics Hub
    var gridColumnCount by remember { mutableStateOf(3) } // 2, 3, or 4 columns
    var selectedCategory by remember { mutableStateOf("All") }
    var isEditMode by remember { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }

    // HUD Overlay state
    var targetedAppId by remember { mutableStateOf<String?>("app-1") }
    var isHudOverlayEnabled by remember { mutableStateOf(true) }
    var hudFeedbackText by remember { mutableStateOf("ARIIA HUD active. Tactical lock-on ready.") }

    val infiniteTransition = rememberInfiniteTransition(label = "AriiaHudSweep")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(3800, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "SweepAngle"
    )

    val reticlePulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(animation = tween(900, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "ReticlePulse"
    )

    val currentTime = remember { mutableStateOf(SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            currentTime.value = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        }
    }

    // Direct Launch Intent Handler
    fun launchAppDirectly(app: AriiaAppItem) {
        targetedAppId = app.id
        hudFeedbackText = "HUD Lock-On: Executing [${app.label}]"
        speechEngine.speak("Target confirmed. Directing interface to ${app.label}.")

        // Attempt package launch first if package available
        var launched = false
        if (!app.packageName.isNullOrBlank()) {
            try {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    launched = true
                }
            } catch (e: Exception) {
                launched = false
            }
        }

        if (!launched) {
            val result = VoiceActionExecutor.executeCommand(context, app.command, speechEngine, coroutineScope)
            if (result is VoiceActionExecutor.VoiceExecutionResult.Handled) {
                com.example.utils.HapticManager.triggerVoiceCommandSuccess(context)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF020409))
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // ARIIA Tactical Header
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF080C14),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "KALEIDOPHONE - ARIIA AI ASSISTANT",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF00F0FF),
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Badge(containerColor = Color(0xFF002F38), contentColor = Color(0xFF39FF14)) {
                                Text("EAGLE EYE", fontSize = 8.sp, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                            }
                        }
                        Text(
                            text = hudFeedbackText,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            maxLines = 1
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = currentTime.value,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF39FF14),
                            fontFamily = FontFamily.Monospace
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Badge(containerColor = Color(0xFF0F1A24), contentColor = Color(0xFF00F0FF)) {
                                Text("${telemetry.batteryPercent}% BAT", fontSize = 8.sp)
                            }
                            Badge(containerColor = Color(0xFF003816), contentColor = Color(0xFF39FF14)) {
                                Text("25 FEEDS LINKED", fontSize = 8.sp)
                            }
                            Badge(
                                containerColor = if (isHudOverlayEnabled) Color(0xFF003828) else Color(0xFF281400),
                                contentColor = if (isHudOverlayEnabled) Color(0xFF39FF14) else Color(0xFFFF9900)
                            ) {
                                Text(if (isHudOverlayEnabled) "HUD ON" else "HUD OFF", fontSize = 8.sp)
                            }
                        }
                    }
                }
            }

            // View Tabs: Custom Grid vs Actuators
            TabRow(
                selectedTabIndex = activeViewTab,
                containerColor = Color(0xFF0A0F1A),
                contentColor = Color(0xFF00F0FF)
            ) {
                Tab(
                    selected = activeViewTab == 0,
                    onClick = { activeViewTab = 0 },
                    text = { Text("HUD App Grid", fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.GridView, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = activeViewTab == 1,
                    onClick = { activeViewTab = 1 },
                    text = { Text("ARIIA Robotics", fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.PrecisionManufacturing, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }

            // Tab 0: Custom Grid with Interactive HUD Overlay
            if (activeViewTab == 0) {
                // Toolbar: Filter chips & Grid Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Category selector
                    val categories = listOf("All", "Favorites", "Government", "Military", "Surveillance", "Comms", "Tactical")
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        categories.forEach { cat ->
                            val isSel = selectedCategory == cat
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 9.sp) },
                                modifier = Modifier.height(26.dp)
                            )
                        }
                    }

                    // Column count toggle (2x, 3x, 4x) & Edit mode
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { isHudOverlayEnabled = !isHudOverlayEnabled },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.Layers,
                                contentDescription = "Toggle HUD Overlay",
                                tint = if (isHudOverlayEnabled) Color(0xFF00F0FF) else Color(0xFF64748B),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = {
                                gridColumnCount = when (gridColumnCount) {
                                    2 -> 3
                                    3 -> 4
                                    else -> 2
                                }
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.ViewColumn, contentDescription = "Columns", tint = Color(0xFF39FF14), modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = { isEditMode = !isEditMode },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                if (isEditMode) Icons.Default.Check else Icons.Default.Tune,
                                contentDescription = "Organize Grid",
                                tint = if (isEditMode) Color(0xFFFF9900) else Color(0xFFBD00FF),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { showAddDialog = true },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Add App", tint = Color(0xFF00F0FF), modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // Filtered apps
                val filteredApps = remember(customApps, selectedCategory) {
                    customApps.filter { app ->
                        when (selectedCategory) {
                            "All" -> true
                            "Favorites" -> app.isFavorite
                            else -> app.category.equals(selectedCategory, ignoreCase = true)
                        }
                    }.sortedBy { it.orderIndex }
                }

                // App Grid Container with HUD Overlay
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(gridColumnCount),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredApps, key = { it.id }) { app ->
                            val isTargeted = targetedAppId == app.id
                            AriiaAppTile(
                                app = app,
                                isTargeted = isTargeted,
                                isEditMode = isEditMode,
                                reticleScale = if (isTargeted) reticlePulse else 1f,
                                onTileClick = { launchAppDirectly(app) },
                                onMoveUp = {
                                    val idx = customApps.indexOfFirst { it.id == app.id }
                                    if (idx > 0) {
                                        val list = customApps.toMutableList()
                                        val temp = list[idx]
                                        list[idx] = list[idx - 1]
                                        list[idx - 1] = temp
                                        customApps = list.mapIndexed { i, a -> a.copy(orderIndex = i) }
                                    }
                                },
                                onMoveDown = {
                                    val idx = customApps.indexOfFirst { it.id == app.id }
                                    if (idx >= 0 && idx < customApps.size - 1) {
                                        val list = customApps.toMutableList()
                                        val temp = list[idx]
                                        list[idx] = list[idx + 1]
                                        list[idx + 1] = temp
                                        customApps = list.mapIndexed { i, a -> a.copy(orderIndex = i) }
                                    }
                                },
                                onToggleFavorite = {
                                    customApps = customApps.map {
                                        if (it.id == app.id) it.copy(isFavorite = !it.isFavorite) else it
                                    }
                                },
                                onDelete = {
                                    customApps = customApps.filterNot { it.id == app.id }
                                }
                            )
                        }
                    }

                    // Direct Interactive HUD Overlay Canvas
                    if (isHudOverlayEnabled) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable(enabled = false) {}
                        ) {
                            val w = size.width
                            val h = size.height

                            // Draw subtle tactical grid lines
                            val gridSpacing = 40.dp.toPx()
                            var x = 0f
                            while (x < w) {
                                drawLine(
                                    Color(0xFF00F0FF).copy(alpha = 0.05f),
                                    start = Offset(x, 0f),
                                    end = Offset(x, h),
                                    strokeWidth = 0.8f
                                )
                                x += gridSpacing
                            }

                            // Corner tactical bracketing
                            val bracketLen = 20.dp.toPx()
                            val bracketColor = Color(0xFF00F0FF).copy(alpha = 0.4f)
                            // Top-Left
                            drawLine(bracketColor, Offset(0f, 0f), Offset(bracketLen, 0f), strokeWidth = 2f)
                            drawLine(bracketColor, Offset(0f, 0f), Offset(0f, bracketLen), strokeWidth = 2f)
                            // Top-Right
                            drawLine(bracketColor, Offset(w, 0f), Offset(w - bracketLen, 0f), strokeWidth = 2f)
                            drawLine(bracketColor, Offset(w, 0f), Offset(w, bracketLen), strokeWidth = 2f)
                            // Bottom-Left
                            drawLine(bracketColor, Offset(0f, h), Offset(bracketLen, h), strokeWidth = 2f)
                            drawLine(bracketColor, Offset(0f, h), Offset(0f, h - bracketLen), strokeWidth = 2f)
                            // Bottom-Right
                            drawLine(bracketColor, Offset(w, h), Offset(w - bracketLen, h), strokeWidth = 2f)
                            drawLine(bracketColor, Offset(w, h), Offset(w, h - bracketLen), strokeWidth = 2f)

                            // Animated scanline beam
                            val scanY = (sweepAngle / 360f) * h
                            drawLine(
                                Brush.horizontalGradient(
                                    colors = listOf(Color.Transparent, Color(0xFF39FF14).copy(alpha = 0.25f), Color.Transparent)
                                ),
                                start = Offset(0f, scanY),
                                end = Offset(w, scanY),
                                strokeWidth = 2f
                            )

                            // Connected HUD Feeds Node Blips around periphery
                            val hudNodePositions = listOf(
                                Offset(w * 0.08f, h * 0.15f),
                                Offset(w * 0.92f, h * 0.15f),
                                Offset(w * 0.08f, h * 0.85f),
                                Offset(w * 0.92f, h * 0.85f),
                                Offset(w * 0.50f, h * 0.05f),
                                Offset(w * 0.50f, h * 0.95f)
                            )
                            val hudNodeLabels = listOf("CAM-01", "CAM-ISS", "RADAR-01", "SHIBUYA", "STREAM-07", "LIDAR-01")
                            hudNodePositions.forEachIndexed { idx, pos ->
                                drawCircle(
                                    color = Color(0xFF00F0FF).copy(alpha = 0.6f),
                                    radius = 4f,
                                    center = pos
                                )
                                drawCircle(
                                    color = Color(0xFF39FF14).copy(alpha = 0.35f),
                                    radius = 8f,
                                    center = pos,
                                    style = Stroke(1f)
                                )
                            }
                        }
                    }
                }
            } else {
                // Tab 1: ARIIA Actuators & 360° LIDAR Subsystem
                AriiaRoboticsSubsystem(
                    telemetry = telemetry,
                    joints = joints,
                    sweepAngle = sweepAngle,
                    onJointAngleChange = { id, angle -> roboticsManager.setJointAngle(id, angle) },
                    onToggleGripper = {
                        roboticsManager.toggleGripper()
                        speechEngine.speak(if (!telemetry.gripperOpen) "Gripper opened." else "Gripper clamped.")
                    },
                    onModeChange = { mode ->
                        roboticsManager.setOperationalMode(mode)
                        speechEngine.speak("ARIIA Robotics mode: ${mode.label}")
                    },
                    onCalibrate = {
                        roboticsManager.calibrateAllServos()
                        speechEngine.speak("All robot servos calibrated to zero reference.")
                    },
                    onEmergencyStop = {
                        roboticsManager.triggerEmergencyHalt()
                        speechEngine.speak("Emergency stop engaged. Actuators de-energized.")
                    }
                )
            }
        }

        // Add Custom App Dialog
        if (showAddDialog) {
            AriiaAddAppDialog(
                onDismiss = { showAddDialog = false },
                onAddApp = { newApp ->
                    customApps = customApps + newApp.copy(orderIndex = customApps.size)
                    showAddDialog = false
                    hudFeedbackText = "Added [${newApp.label}] to custom grid."
                    speechEngine.speak("Application ${newApp.label} registered in ARIIA grid.")
                }
            )
        }
    }
}

@Composable
fun AriiaAppTile(
    app: AriiaAppItem,
    isTargeted: Boolean,
    isEditMode: Boolean,
    reticleScale: Float,
    onTileClick: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    val borderColor = if (isTargeted) Color(0xFF00F0FF) else Color(0xFF1E293B)
    val glowColor = if (isTargeted) Color(0xFF00F0FF).copy(alpha = 0.2f) else Color.Transparent

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF090D16),
        border = BorderStroke(if (isTargeted) 1.8.dp else 1.dp, borderColor),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTileClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(glowColor)
                .padding(10.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Icon with holographic target circle
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(44.dp)
                ) {
                    if (isTargeted) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val r = (size.minDimension / 2f) * reticleScale
                            drawCircle(Color(0xFF39FF14).copy(alpha = 0.5f), radius = r, style = Stroke(1.5f))
                        }
                    }

                    val icon = when (app.iconType) {
                        "palette", "painter" -> Icons.Default.Palette
                        "build" -> Icons.Default.Build
                        "design_services" -> Icons.Default.DesignServices
                        "public" -> Icons.Default.Public
                        "terrain" -> Icons.Default.Terrain
                        "panorama", "photosphere" -> Icons.Default.PanoramaPhotosphere
                        "forum" -> Icons.Default.Forum
                        "phone" -> Icons.Default.Phone
                        "whatsapp" -> Icons.Default.Chat
                        "camera" -> Icons.Default.PhotoCamera
                        "contacts" -> Icons.Default.Contacts
                        "messages" -> Icons.Default.Send
                        "settings" -> Icons.Default.Settings
                        "alarm" -> Icons.Default.Alarm
                        "terminal" -> Icons.Default.Terminal
                        else -> Icons.Default.Apps
                    }

                    Icon(
                        icon,
                        contentDescription = app.label,
                        tint = if (isTargeted) Color(0xFF00F0FF) else Color(0xFFCBD5E1),
                        modifier = Modifier.size(24.dp)
                    )
                }

                // App Label
                Text(
                    text = app.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )

                // Category badge & Favorite indicator
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = app.category,
                        fontSize = 8.sp,
                        color = Color(0xFF64748B),
                        fontFamily = FontFamily.Monospace
                    )
                    if (app.isFavorite) {
                        Icon(Icons.Default.Star, contentDescription = "Favorite", tint = Color(0xFFFFCC00), modifier = Modifier.size(10.dp))
                    }
                }

                // Edit Mode Reorder Controls
                if (isEditMode) {
                    Divider(color = Color(0xFF1E293B), thickness = 1.dp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(onClick = onMoveUp, modifier = Modifier.size(22.dp)) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Move Left", tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                        }
                        IconButton(onClick = onToggleFavorite, modifier = Modifier.size(22.dp)) {
                            Icon(
                                if (app.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "Favorite",
                                tint = Color(0xFFFFCC00),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        IconButton(onClick = onMoveDown, modifier = Modifier.size(22.dp)) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Move Right", tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                        }
                        IconButton(onClick = onDelete, modifier = Modifier.size(22.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Delete", tint = Color(0xFFFF3366), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AriiaRoboticsSubsystem(
    telemetry: AriiaRobotTelemetry,
    joints: List<AriiaServoJoint>,
    sweepAngle: Float,
    onJointAngleChange: (String, Float) -> Unit,
    onToggleGripper: () -> Unit,
    onModeChange: (AriiaActuatorMode) -> Unit,
    onCalibrate: () -> Unit,
    onEmergencyStop: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // 360 LIDAR Radar
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF060910),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val center = Offset(w / 2f, h / 2f)
                    val maxRadius = minOf(w, h) * 0.42f

                    drawCircle(Color(0xFF00F0FF).copy(alpha = 0.15f), radius = maxRadius * 0.5f, center = center, style = Stroke(1f))
                    drawCircle(Color(0xFF00F0FF).copy(alpha = 0.3f), radius = maxRadius, center = center, style = Stroke(1.2f))

                    // Sweep line
                    val sweepRad = Math.toRadians(sweepAngle.toDouble())
                    val endX = center.x + (maxRadius * cos(sweepRad)).toFloat()
                    val endY = center.y + (maxRadius * sin(sweepRad)).toFloat()
                    drawLine(Color(0xFF39FF14), center, Offset(endX, endY), strokeWidth = 1.8f)

                    // LIDAR Obstacles
                    val stepAngle = 360f / telemetry.lidarDistancesCm.size
                    telemetry.lidarDistancesCm.forEachIndexed { i, distCm ->
                        val angRad = Math.toRadians((i * stepAngle).toDouble())
                        val normDist = (distCm / 350f).coerceIn(0.1f, 1f) * maxRadius
                        val px = center.x + (normDist * cos(angRad)).toFloat()
                        val py = center.y + (normDist * sin(angRad)).toFloat()
                        drawCircle(Color(0xFFFF3366), radius = 3.5f, center = Offset(px, py))
                    }
                }

                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Badge(containerColor = Color(0xFF00222B), contentColor = Color(0xFF00F0FF)) {
                        Text("360° LIDAR", fontSize = 8.sp)
                    }
                    Badge(containerColor = Color(0xFF0A2610), contentColor = Color(0xFF39FF14)) {
                        Text("${telemetry.motorRpm} RPM", fontSize = 8.sp)
                    }
                }

                Button(
                    onClick = onEmergencyStop,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0033)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .height(24.dp)
                ) {
                    Text("HALT ACTUATORS", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Mode Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Actuator Mode:", fontSize = 10.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(
                    onClick = { onModeChange(AriiaActuatorMode.AUTONOMOUS_PATROL) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003D45)),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.height(24.dp)
                ) {
                    Text("Autonomous", fontSize = 8.sp, color = Color(0xFF00F0FF))
                }
                Button(
                    onClick = { onModeChange(AriiaActuatorMode.VISION_TRACKING) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF350A45)),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.height(24.dp)
                ) {
                    Text("Vision Track", fontSize = 8.sp, color = Color(0xFFBD00FF))
                }
                Button(
                    onClick = onCalibrate,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A2E16)),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.height(24.dp)
                ) {
                    Text("Calibrate", fontSize = 8.sp, color = Color(0xFF39FF14))
                }
            }
        }

        // 6-DOF Joint Sliders
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(joints) { j ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF0B0F18),
                    border = BorderStroke(1.dp, Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${j.id}: ${j.name}", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("${j.currentAngle.toInt()}° (Load: ${j.loadPercentage}%)", fontSize = 9.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                        }
                        Slider(
                            value = j.currentAngle,
                            onValueChange = { onJointAngleChange(j.id, it) },
                            valueRange = j.minAngle..j.maxAngle,
                            colors = SliderDefaults.colors(thumbColor = Color(0xFF00F0FF), activeTrackColor = Color(0xFF00F0FF))
                        )
                    }
                }
            }
        }

        Button(
            onClick = onToggleGripper,
            colors = ButtonDefaults.buttonColors(containerColor = if (telemetry.gripperOpen) Color(0xFF39FF14) else Color(0xFFBD00FF)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (telemetry.gripperOpen) "CLAMP TACTILE GRIPPER" else "RELEASE / OPEN GRIPPER", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
        }
    }
}

@Composable
fun AriiaAddAppDialog(
    onDismiss: () -> Unit,
    onAddApp: (AriiaAppItem) -> Unit
) {
    var labelInput by remember { mutableStateOf("") }
    var commandInput by remember { mutableStateOf("") }
    var categoryInput by remember { mutableStateOf("Tactical") }
    var iconInput by remember { mutableStateOf("terminal") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add App to ARIIA Grid", color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = labelInput,
                    onValueChange = { labelInput = it },
                    label = { Text("Display Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00F0FF))
                )
                OutlinedTextField(
                    value = commandInput,
                    onValueChange = { commandInput = it },
                    label = { Text("Voice / Launch Command (e.g. open camera)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00F0FF))
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Tactical", "Comms", "System", "Sensors").forEach { cat ->
                        FilterChip(
                            selected = categoryInput == cat,
                            onClick = { categoryInput = cat },
                            label = { Text(cat, fontSize = 9.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (labelInput.isNotBlank() && commandInput.isNotBlank()) {
                        val id = "custom-${System.currentTimeMillis()}"
                        onAddApp(AriiaAppItem(id, labelInput, null, commandInput, categoryInput, iconInput, false, 0))
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF))
            ) {
                Text("Add to Grid", color = Color.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        containerColor = Color(0xFF0D121F)
    )
}
