package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.app.SearchManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeepSeekPerson
import com.example.util.AriiaSpeechEngine
import com.example.util.VoiceActionExecutor
import com.example.utils.HapticManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class DeepSeekHubTab(val title: String, val icon: @Composable () -> Unit) {
    PEOPLE_RECON("People Recon", { Icon(Icons.Default.People, contentDescription = null) }),
    DEEPSEEK_AI("DeepSeek AI Core", { Icon(Icons.Default.Psychology, contentDescription = null) }),
    GOOGLE_SEARCH("Google Search", { Icon(Icons.Default.Search, contentDescription = null) })
}

@Composable
fun DeepSeekPeopleScreen(
    onQueryDeepSeekAi: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }
    val coroutineScope = rememberCoroutineScope()

    DisposableEffect(Unit) {
        onDispose { speechEngine.shutdown() }
    }

    var selectedHubTab by remember { mutableStateOf(DeepSeekHubTab.PEOPLE_RECON) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030712))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Main Screen Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.6f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(Color(0xFF00363D), CircleShape)
                        .border(1.dp, Color(0xFF00F0FF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.TravelExplore,
                        contentDescription = null,
                        tint = Color(0xFF00F0FF),
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "DEEPSEEK INTELLIGENCE & GOOGLE SEARCH HUB",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00F0FF),
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Personnel Biometrics Recon, DeepSeek-R1 Reasoning Engine & Google Web Search Integration",
                        fontSize = 9.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
                Surface(
                    color = Color(0xFFBD00FF).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "R1-REASONING ONLINE",
                        fontSize = 8.sp,
                        color = Color(0xFFBD00FF),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Sub-Tab Navigation Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DeepSeekHubTab.values().forEach { tab ->
                val isSelected = selectedHubTab == tab
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            selectedHubTab = tab
                            HapticManager.triggerVoiceCommandInitiation(context)
                            speechEngine.speak("Switched to ${tab.title}")
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.2f) else Color(0xFF0F172A)
                    ),
                    border = BorderStroke(1.dp, if (isSelected) Color(0xFF00F0FF) else Color(0xFF1E293B)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        tab.icon()
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tab.title,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        // Screen Body Content
        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            when (selectedHubTab) {
                DeepSeekHubTab.PEOPLE_RECON -> DeepSeekPeopleReconTab(speechEngine, context)
                DeepSeekHubTab.DEEPSEEK_AI -> DeepSeekAiEngineTab(onQueryDeepSeekAi, speechEngine, context)
                DeepSeekHubTab.GOOGLE_SEARCH -> GoogleSearchHubTab(speechEngine, context)
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 1. DEEPSEEK PEOPLE RECON TAB
// ----------------------------------------------------------------------------
@Composable
fun DeepSeekPeopleReconTab(speechEngine: AriiaSpeechEngine, context: Context) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedClearanceFilter by remember { mutableStateOf("ALL") }
    var selectedPersonForDossier by remember { mutableStateOf<DeepSeekPerson?>(null) }

    val initialPeople = remember {
        mutableStateListOf(
            DeepSeekPerson("DS-001", "Dr. Elena Vance", "Chief Neural Architect", "Level 5 - Omega", "AI Research", "Verified Liveness", 0.99f),
            DeepSeekPerson("DS-002", "Marcus Thorne", "Director of Cyber Defense", "Level 4 - Secured", "Security Ops", "Verified Liveness", 0.96f),
            DeepSeekPerson("DS-003", "Aria Lin", "Quantum Cryptographer", "Level 4 - Secured", "Core Encryption", "Verified Liveness", 0.98f),
            DeepSeekPerson("DS-004", "Viktor Sterling", "Robotics & Telemetry Lead", "Level 3 - Standard", "Hardware Engineering", "Pending Recertification", 0.82f),
            DeepSeekPerson("DS-005", "Dr. Sarah Chen", "Bio-Metric Intelligence Lead", "Level 5 - Omega", "Biometrics", "Verified Liveness", 0.99f),
            DeepSeekPerson("DS-006", "Commander Alex Mercer", "Tactical Recon Lead", "Level 5 - Omega", "Special Operations", "Verified Liveness", 0.97f),
            DeepSeekPerson("DS-007", "Kaelen Voss", "Autonomous Systems Spec", "Level 3 - Standard", "Field Garrison", "Pending Recertification", 0.79f)
        )
    }

    val filteredPeople = initialPeople.filter { person ->
        val matchesQuery = person.name.contains(searchQuery, ignoreCase = true) ||
                person.department.contains(searchQuery, ignoreCase = true) ||
                person.role.contains(searchQuery, ignoreCase = true)

        val matchesFilter = when (selectedClearanceFilter) {
            "LEVEL 5" -> person.clearanceLevel.contains("Level 5")
            "LEVEL 4" -> person.clearanceLevel.contains("Level 4")
            "LEVEL 3" -> person.clearanceLevel.contains("Level 3")
            else -> true
        }

        matchesQuery && matchesFilter
    }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Search & Filter Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search personnel by name, role, or department...", color = Color(0xFF64748B), fontSize = 11.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF00F0FF)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color(0xFF94A3B8))
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF00F0FF),
                unfocusedBorderColor = Color(0xFF1E293B),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            singleLine = true
        )

        // Clearance Filter Pills
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val filters = listOf("ALL", "LEVEL 5", "LEVEL 4", "LEVEL 3")
            items(filters) { filter ->
                val isSel = selectedClearanceFilter == filter
                FilterChip(
                    selected = isSel,
                    onClick = { selectedClearanceFilter = filter },
                    label = { Text(filter, fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF00F0FF),
                        selectedLabelColor = Color.Black,
                        containerColor = Color(0xFF0F172A),
                        labelColor = Color(0xFF94A3B8)
                    )
                )
            }
        }

        // Personnel List
        LazyColumn(
            modifier = Modifier.fillMaxSize().weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredPeople) { person ->
                DeepSeekPersonCard(
                    person = person,
                    onInspectDossier = {
                        selectedPersonForDossier = person
                        HapticManager.triggerVoiceCommandSuccess(context)
                        speechEngine.speak("Opening intelligence dossier for ${person.name}")
                    },
                    onRecertify = {
                        val index = initialPeople.indexOf(person)
                        if (index != -1) {
                            initialPeople[index] = person.copy(
                                biometricsStatus = "Verified Liveness",
                                livenessScore = 0.99f
                            )
                            HapticManager.triggerVoiceCommandSuccess(context)
                            speechEngine.speak("Biometrics recertified for ${person.name}")
                        }
                    }
                )
            }
        }
    }

    // Dossier Dialog Modal
    selectedPersonForDossier?.let { person ->
        AlertDialog(
            onDismissRequest = { selectedPersonForDossier = null },
            confirmButton = {
                TextButton(onClick = { selectedPersonForDossier = null }) {
                    Text("CLOSE DOSSIER", color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF39FF14))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("DOSSIER: ${person.name}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ID: ${person.id} | Department: ${person.department}", fontSize = 10.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Text("Clearance: ${person.clearanceLevel}", fontSize = 11.sp, color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold)
                    Text("Role: ${person.role}", fontSize = 11.sp, color = Color.White)
                    Divider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 4.dp))
                    Text("Biometrics Status: ${person.biometricsStatus}", fontSize = 10.sp, color = Color(0xFF39FF14))
                    Text("Liveness Verification Score: ${(person.livenessScore * 100).toInt()}%", fontSize = 10.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                    Text("Cyber Activity Index: NOMINAL (0.02 Risk Vector)", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    Text("Encrypted Hash: 0x8F9A...B31D", fontSize = 9.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = Color(0xFF0A0A0E),
            shape = RoundedCornerShape(14.dp)
        )
    }
}

@Composable
fun DeepSeekPersonCard(
    person: DeepSeekPerson,
    onInspectDossier: () -> Unit,
    onRecertify: () -> Unit
) {
    val isVerified = person.biometricsStatus.contains("Verified")

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF0A0A0E),
        border = BorderStroke(1.5.dp, if (isVerified) Color(0xFF39FF14).copy(alpha = 0.7f) else Color(0xFFFF9900).copy(alpha = 0.7f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color(0xFF1E293B), CircleShape)
                            .border(1.dp, if (isVerified) Color(0xFF39FF14) else Color(0xFFFF9900), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(person.name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(person.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(person.role, fontSize = 9.sp, color = Color(0xFF00F0FF))
                    }
                }

                Surface(
                    color = Color(0xFF00363D),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        person.clearanceLevel,
                        fontSize = 8.sp,
                        color = Color(0xFFE0F7FA),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Dept: ${person.department}", fontSize = 10.sp, color = Color(0xFF94A3B8))
                Text("Liveness: ${(person.livenessScore * 100).toInt()}%", fontSize = 10.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onInspectDossier,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.weight(1f).height(32.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Icon(Icons.Default.AssignmentInd, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("DOSSIER", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }

                if (!isVerified) {
                    Button(
                        onClick = onRecertify,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9900)),
                        modifier = Modifier.weight(1f).height(32.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("RECERTIFY", fontSize = 9.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 2. DEEPSEEK AI ENGINE TAB (V3 & R1)
// ----------------------------------------------------------------------------
@Composable
fun DeepSeekAiEngineTab(
    onQueryDeepSeekAi: (String) -> Unit,
    speechEngine: AriiaSpeechEngine,
    context: Context
) {
    val coroutineScope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var selectedModel by remember { mutableStateOf("deepseek-r1") }
    var temperature by remember { mutableFloatStateOf(0.7f) }
    var isThinking by remember { mutableStateOf(false) }

    var reasoningLogs by remember {
        mutableStateOf(
            "DeepSeek-R1 CoT Engine v3.2 Standing By.\n" +
                    "[SYSTEM] Ready for complex logical reasoning, code synthesis, and threat vector analysis."
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0B132B)),
                border = BorderStroke(1.dp, Color(0xFFBD00FF).copy(alpha = 0.6f)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "[DEEPSEEK_NEURAL_REASONING_ENGINE]",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFBD00FF),
                        fontFamily = FontFamily.Monospace
                    )

                    // Model Selection Buttons
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { selectedModel = "deepseek-r1" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedModel == "deepseek-r1") Color(0xFFBD00FF) else Color(0xFF1E293B)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("DeepSeek-R1 (CoT)", fontSize = 10.sp, color = Color.White)
                        }
                        Button(
                            onClick = { selectedModel = "deepseek-v3" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedModel == "deepseek-v3") Color(0xFF00F0FF) else Color(0xFF1E293B)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("DeepSeek-V3", fontSize = 10.sp, color = if (selectedModel == "deepseek-v3") Color.Black else Color.White)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Temperature: ${String.format("%.2f", temperature)}", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Slider(
                            value = temperature,
                            onValueChange = { temperature = it },
                            valueRange = 0.0f..1.0f,
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                            colors = SliderDefaults.colors(thumbColor = Color(0xFFBD00FF), activeTrackColor = Color(0xFFBD00FF))
                        )
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                placeholder = { Text("Ask DeepSeek AI for strategic reasoning, code analysis, or threat evaluation...", color = Color(0xFF64748B), fontSize = 11.sp) },
                modifier = Modifier.fillMaxWidth().height(100.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFBD00FF),
                    unfocusedBorderColor = Color(0xFF1E293B),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
        }

        item {
            Button(
                onClick = {
                    if (prompt.isNotBlank()) {
                        isThinking = true
                        HapticManager.triggerVoiceCommandInitiation(context)
                        speechEngine.speak("Querying $selectedModel reasoning engine.")

                        coroutineScope.launch {
                            reasoningLogs = "[$selectedModel] INITIATING PROMPT EVALUATION...\n" +
                                    "[CoT Step 1] Deconstructing input query: \"$prompt\"\n" +
                                    "[CoT Step 2] Fetching knowledge graph nodes & threat matrices...\n" +
                                    "[CoT Step 3] Computing optimal token trajectory (TTFT: 140ms)...\n" +
                                    "[RESPONSE GENERATED]: Analysis complete. Target parameter \"$prompt\" processed with 99.4% confidence score. Security posture nominal."
                            isThinking = false
                            onQueryDeepSeekAi(prompt)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Psychology, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isThinking) "DEEPSEEK REASONING..." else "EXECUTE DEEPSEEK REASONING", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF020617)),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("Chain-of-Thought (CoT) & Token Output Stream", fontSize = 10.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        item {
                            Text(reasoningLogs, fontSize = 10.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// 3. GOOGLE SEARCH HUB TAB
// ----------------------------------------------------------------------------
@Composable
fun GoogleSearchHubTab(speechEngine: AriiaSpeechEngine, context: Context) {
    var searchQuery by remember { mutableStateOf("") }
    var searchHistory = remember { mutableStateListOf("DeepSeek AI news", "Android 15 SDK documentation", "Quantum Cryptography standards", "ARIIA Earth View maps") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = BorderStroke(1.dp, Color(0xFF4285F4)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF4285F4))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "GOOGLE SEARCH ENGINE INTEGRATION",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4285F4),
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search Google web or enter search prompt...", color = Color(0xFF64748B), fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF4285F4)) },
                        trailingIcon = {
                            IconButton(onClick = {
                                VoiceActionExecutor.launchGoogleVoiceSearch(context, searchQuery)
                            }) {
                                Icon(Icons.Default.Mic, contentDescription = "Voice Search", tint = Color(0xFFEA4335))
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF4285F4),
                            unfocusedBorderColor = Color(0xFF1E293B),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (searchQuery.isNotBlank()) {
                                    if (!searchHistory.contains(searchQuery)) searchHistory.add(0, searchQuery)
                                    VoiceActionExecutor.launchGoogleVoiceSearch(context, searchQuery)
                                } else {
                                    VoiceActionExecutor.launchGoogleVoiceSearch(context, "")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SEARCH WEB", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                VoiceActionExecutor.launchGoogleVoiceSearch(context, "")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34A853)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("VOICE SEARCH", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Text("Recent Search Queries", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
        }

        items(searchHistory) { historyItem ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        searchQuery = historyItem
                        VoiceActionExecutor.launchGoogleVoiceSearch(context, historyItem)
                    },
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0A0E)),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(historyItem, fontSize = 11.sp, color = Color.White)
                    }
                    Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color(0xFF4285F4), modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}
