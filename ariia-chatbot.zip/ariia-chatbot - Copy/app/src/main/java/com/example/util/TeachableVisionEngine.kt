package com.example.util

import androidx.camera.core.ImageProxy
import com.example.data.TrainedVisionObjectEntity
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.sqrt

data class FrameFeatureSignature(
    val redMean: Float,
    val greenMean: Float,
    val blueMean: Float,
    val luminanceMean: Float,
    val variance: Float
)

object TeachableVisionEngine {

    fun extractFeatures(imageProxy: ImageProxy): FrameFeatureSignature {
        var redSum = 0L
        var greenSum = 0L
        var blueSum = 0L
        var count = 0
        var lumSum = 0L
        var lumSqSum = 0.0

        val planes = imageProxy.planes
        if (planes.isNotEmpty()) {
            val buffer: ByteBuffer = planes[0].buffer
            buffer.rewind()
            val remaining = buffer.remaining()
            val step = maxOf(1, remaining / 300) // Sample 300 points for efficiency

            var i = 0
            while (i < remaining) {
                val byteVal = buffer.get(i).toInt() and 0xFF
                lumSum += byteVal
                lumSqSum += (byteVal * byteVal).toDouble()
                // Approximate pseudo-color channels from interlaced YUV/RGBA components
                val r = (byteVal * 1.05f).coerceIn(0f, 255f).toLong()
                val g = byteVal.toLong()
                val b = (byteVal * 0.95f).coerceIn(0f, 255f).toLong()
                redSum += r
                greenSum += g
                blueSum += b
                count++
                i += step
            }
        }

        val cnt = maxOf(1, count)
        val meanLum = lumSum.toFloat() / cnt
        val meanSq = lumSqSum / cnt
        val variance = sqrt(maxOf(0.0, meanSq - (meanLum * meanLum))).toFloat()

        return FrameFeatureSignature(
            redMean = redSum.toFloat() / cnt,
            greenMean = greenSum.toFloat() / cnt,
            blueMean = blueSum.toFloat() / cnt,
            luminanceMean = meanLum,
            variance = variance
        )
    }

    fun matchAgainstTrainedObjects(
        signature: FrameFeatureSignature,
        trainedObjects: List<TrainedVisionObjectEntity>
    ): Pair<TrainedVisionObjectEntity, Float>? {
        if (trainedObjects.isEmpty()) return null

        var bestMatch: TrainedVisionObjectEntity? = null
        var highestSimilarity = 0f

        for (obj in trainedObjects) {
            val lumDiff = abs(signature.luminanceMean - obj.luminanceMean) / 255f
            val varDiff = abs(signature.variance - obj.variance) / 100f
            val rDiff = abs(signature.redMean - obj.redMean) / 255f
            val gDiff = abs(signature.greenMean - obj.greenMean) / 255f
            val bDiff = abs(signature.blueMean - obj.blueMean) / 255f

            val distance = (lumDiff * 0.35f + varDiff * 0.25f + rDiff * 0.15f + gDiff * 0.15f + bDiff * 0.10f)
            val similarity = (1.0f - distance).coerceIn(0f, 1f)

            if (similarity >= obj.confidenceThreshold && similarity > highestSimilarity) {
                highestSimilarity = similarity
                bestMatch = obj
            }
        }

        return if (bestMatch != null) Pair(bestMatch, highestSimilarity) else null
    }
}
