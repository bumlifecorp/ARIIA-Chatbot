package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import com.example.utils.HapticManager
import kotlinx.coroutines.delay
import java.util.Locale

enum class FarmerProtocol(val title: String, val badge: String, val icon: @Composable () -> Unit) {
    HARVESTING("Strategic Resource Harvesting", "HARVESTING RECON", { Icon(Icons.Default.PrecisionManufacturing, contentDescription = null) }),
    IRRIGATION("Fuel & Water Supply Line", "LOGISTICS PIPELINE", { Icon(Icons.Default.WaterDrop, contentDescription = null) }),
    PEST_CONTROL("CBRN Bio-Defense Shield", "BIO-SECURITY", { Icon(Icons.Default.BugReport, contentDescription = null) }),
    BARNYARD("Outpost Garrison Protocol", "GARRISON LOGISTICS", { Icon(Icons.Default.Castle, contentDescription = null) }),
    MARKET_YIELD("Strategic Reserve Yield", "COMMODITY RADAR", { Icon(Icons.Default.ShowChart, contentDescription = null) })
}

@Composable
fun FarmerProgramScreen(
    onNavigateTab: (Int) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    DisposableEffect(Unit) {
        onDispose { speechEngine.shutdown() }
    }

    var activeProtocol by remember { mutableStateOf(FarmerProtocol.HARVESTING) }
    var isPrecisionEngineActive by remember { mutableStateOf(true) }

    // Strategic Resource & Military Logistics Telemetry
    var fuelReservePct by remember { mutableFloatStateOf(78.5f) }
    var ndviResourceIndex by remember { mutableFloatStateOf(0.84f) }
    var bioHazardRiskScore by remember { mutableFloatStateOf(8.2f) }
    var estReserveTons by remember { mutableFloatStateOf(1420f) }

    // Fuel Line States
    var flowRateLpm by remember { mutableFloatStateOf(120.4f) }
    var valvePressurePsi by remember { mutableFloatStateOf(42.8f) }
    var isPipelinePulseOn by remember { mutableStateOf(true) }

    // CBRN Bio-Shield States
    var bioDroneDispatched by remember { mutableStateOf(false) }
    var targetAreaHa by remember { mutableFloatStateOf(45f) }

    // Outpost Garrison States
    var garrisonHealth by remember { mutableStateOf("100% COMBAT READY") }
    var rationLevelPct by remember { mutableIntStateOf(92) }

    // Strategic Decision Automation Loop
    LaunchedEffect(isPrecisionEngineActive) {
        while (isPrecisionEngineActive) {
            delay(3000)
            if (fuelReservePct < 25f && isPipelinePulseOn) {
                flowRateLpm = 250f
                speechEngine.speak("Critical fuel reserve threshold reached. Boost pulse valve sequence engaged.")
            }

            fuelReservePct = (fuelReservePct + (kotlin.random.Random.nextFloat() - 0.5f)).coerceIn(10f, 100f)
            bioHazardRiskScore = (bioHazardRiskScore + (kotlin.random.Random.nextFloat() - 0.5f)).coerceIn(1f, 50f)
            valvePressurePsi = 40f + (kotlin.random.Random.nextFloat() * 8f)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF040A12))
            .padding(12.dp)
    ) {
        // Program Header Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1626)),
            border = BorderStroke(1.dp, Color(0xFF1B365D)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(0xFF11223A), CircleShape)
                        .border(1.dp, Color(0xFF39FF14), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.PrecisionManufacturing,
                        contentDescription = null,
                        tint = Color(0xFF39FF14),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "[STRATEGIC_RECON_PROGRAM]",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = Color(0xFF39FF14).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "MILITARY LOGISTICS",
                                fontSize = 8.sp,
                                color = Color(0xFF39FF14),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Text(
                        text = "Resource Recon, Strategic Supply Line & CBRN Bio-Security",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("ENGINE", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Switch(
                        checked = isPrecisionEngineActive,
                        onCheckedChange = {
                            isPrecisionEngineActive = it
                            speechEngine.speak(if (it) "Strategic Recon Precision Engine active" else "Engine paused")
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF39FF14))
                    )
                }
            }
        }

        // Quick Telemetry Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FarmerStatChip("FUEL RESERVES", "${fuelReservePct.toInt()}%", Color(0xFF38BDF8), Modifier.weight(1f))
            FarmerStatChip("RESOURCE INDEX", "%.2f".format(ndviResourceIndex), Color(0xFF39FF14), Modifier.weight(1f))
            FarmerStatChip("BIO-HAZARD RISK", "${bioHazardRiskScore.toInt()}%", Color(0xFFFFCC00), Modifier.weight(1f))
            FarmerStatChip("EST. SUPPLY", "%.0f T".format(estReserveTons), Color(0xFFA855F7), Modifier.weight(1f))
        }

        // Protocol Selection Tabs
        LazyRow(
            modifier = Modifier.padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(FarmerProtocol.values()) { protocol ->
                val isSelected = activeProtocol == protocol
                Card(
                    modifier = Modifier.clickable {
                        activeProtocol = protocol
                        HapticManager.triggerVoiceCommandInitiation(context)
                        speechEngine.speak("Switched to ${protocol.title}")
                    },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF39FF14).copy(alpha = 0.2f) else Color(0xFF0B1626)
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) Color(0xFF39FF14) else Color(0xFF1B365D)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        protocol.icon()
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = protocol.title,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        // Active Protocol Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (activeProtocol) {
                FarmerProtocol.HARVESTING -> HarvestingProtocolContent(
                    fuelReservePct = fuelReservePct,
                    ndviResourceIndex = ndviResourceIndex,
                    onTriggerRecon = {
                        HapticManager.triggerVoiceCommandSuccess(context)
                        speechEngine.speak("Autonomous tactical harvesting drone fleet deployed to sector Bravo. Mineral yield optimization complete.")
                    }
                )

                FarmerProtocol.IRRIGATION -> IrrigationProtocolContent(
                    flowRateLpm = flowRateLpm,
                    valvePressurePsi = valvePressurePsi,
                    isPulseOn = isPipelinePulseOn,
                    onTogglePulse = {
                        isPipelinePulseOn = !isPipelinePulseOn
                        speechEngine.speak(if (isPipelinePulseOn) "Automated fuel pulse valves engaged." else "Pipeline pulse valves paused.")
                    }
                )

                FarmerProtocol.PEST_CONTROL -> PestControlProtocolContent(
                    bioHazardRiskScore = bioHazardRiskScore,
                    isDroneDispatched = bioDroneDispatched,
                    onDispatchShield = {
                        bioDroneDispatched = true
                        speechEngine.speak("Multispectral CBRN bio-defense spray drone launched over 45 hectares. Aerosol neutralization in progress.")
                    }
                )

                FarmerProtocol.BARNYARD -> BarnyardMonitorProtocolContent(
                    garrisonHealth = garrisonHealth,
                    rationLevelPct = rationLevelPct
                )

                FarmerProtocol.MARKET_YIELD -> MarketYieldProtocolContent(
                    estReserveTons = estReserveTons
                )
            }
        }
    }
}

@Composable
fun FarmerStatChip(label: String, value: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1626)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 11.sp, color = color, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HarvestingProtocolContent(
    fuelReservePct: Float,
    ndviResourceIndex: Float,
    onTriggerRecon: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[STRATEGIC_RESOURCE_HARVESTING] - Autonomous Mineral & Fuel Recon",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF39FF14),
                fontFamily = FontFamily.Monospace
            )

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("RESOURCE DENSITY MAP", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text("Tactical Satellite Spectrum: High Mineral Concentration Detected", fontSize = 11.sp, color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onTriggerRecon,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF39FF14)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PrecisionManufacturing, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("LAUNCH HARVESTING RECON FLEET", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun IrrigationProtocolContent(
    flowRateLpm: Float,
    valvePressurePsi: Float,
    isPulseOn: Boolean,
    onTogglePulse: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[FUEL_WATER_SUPPLY_LINE] - Tactical Pipeline Pulse Controller",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF39FF14),
                fontFamily = FontFamily.Monospace
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("PIPELINE FLOW", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text("%.1f L/min".format(flowRateLpm), fontSize = 12.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                    }
                }
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("PRESSURE PSI", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text("%.1f PSI".format(valvePressurePsi), fontSize = 12.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold)
                    }
                }
            }

            Button(
                onClick = onTogglePulse,
                colors = ButtonDefaults.buttonColors(containerColor = if (isPulseOn) Color(0xFFFF0055) else Color(0xFF38BDF8)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.WaterDrop, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isPulseOn) "PAUSE PIPELINE PULSE VALVES" else "ENGAGE AUTOMATED PULSE VALVES", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PestControlProtocolContent(
    bioHazardRiskScore: Float,
    isDroneDispatched: Boolean,
    onDispatchShield: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[CBRN_BIO_DEFENSE_SHIELD] - Toxin Neutralization & Biological Shield",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF39FF14),
                fontFamily = FontFamily.Monospace
            )

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("BIO-HAZARD RISK ASSESSOR", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text("Risk Rating: ${bioHazardRiskScore.toInt()}% - ${if (bioHazardRiskScore > 20) "ELEVEATED TOXIN LEVEL" else "CLEARED"}", fontSize = 11.sp, color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onDispatchShield,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFCC00)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isDroneDispatched) "NEUTRALIZING ATMOSPHERIC TOXINS..." else "DISPATCH CBRN AEROSOL NEUTRALIZER", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun BarnyardMonitorProtocolContent(garrisonHealth: String, rationLevelPct: Int) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[OUTPOST_GARRISON_PROTOCOL] - Outpost Readiness & Ration Telemetry",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF39FF14),
                fontFamily = FontFamily.Monospace
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("GARRISON READINESS", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text(garrisonHealth, fontSize = 11.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold)
                    }
                }
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("RATION RESERVES", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                        Text("$rationLevelPct% Full", fontSize = 11.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun MarketYieldProtocolContent(estReserveTons: Float) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08101C)),
        border = BorderStroke(1.dp, Color(0xFF1B2E4A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "[STRATEGIC_RESERVE_YIELD] - Military Supply Forecast & Commodity Threat Radar",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF39FF14),
                fontFamily = FontFamily.Monospace
            )

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111E32))) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("STRATEGIC GRAIN & FUEL RESERVES", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text("%.0f Metric Tons".format(estReserveTons), fontSize = 16.sp, color = Color(0xFFA855F7), fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Supply Buffer: 180 Days Garrison Readiness", fontSize = 10.sp, color = Color(0xFF94A3B8))
                }
            }
        }
    }
}
