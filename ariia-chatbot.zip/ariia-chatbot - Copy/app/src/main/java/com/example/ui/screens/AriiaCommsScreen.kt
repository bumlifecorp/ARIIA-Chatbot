package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class CommsPriority(val label: String, val color: Color) {
    FLASH("FLASH [TOP SECRET]", Color(0xFFFF0055)),
    URGENT("URGENT", Color(0xFFFF9900)),
    ROUTINE("ROUTINE", Color(0xFF00F0FF))
}

data class CommsChannel(
    val id: String,
    val name: String,
    val type: String, // "SPACE" or "DM"
    val topic: String,
    val unreadCount: Int = 0,
    val securityLevel: String = "LEVEL-5"
)

data class CommsMessage(
    val id: String,
    val channelId: String,
    val senderCallsign: String,
    val senderRole: String,
    val content: String,
    val timestamp: String,
    val priority: CommsPriority = CommsPriority.ROUTINE,
    val geoCoordinates: String? = null,
    val isFromSelf: Boolean = false,
    val reactions: List<String> = emptyList()
)

@Composable
fun AriiaCommsScreen(
    initialTargetPayload: String? = null,
    initialTargetLat: Float? = null,
    initialTargetLon: Float? = null,
    onNavigateToEarth: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    val commsRepo = remember { com.example.data.repository.SecureCommsRepository(context) }
    val listState = rememberLazyListState()

    val speechEngine = remember { AriiaSpeechEngine(context) }
    DisposableEffect(Unit) {
        onDispose { speechEngine.shutdown() }
    }

    // Channels / Spaces (rebranded from Google Chat Spaces & Direct Messages)
    val channels = remember {
        listOf(
            CommsChannel("space-recon", "#orbital-recon", "SPACE", "Planetary satellite imagery downlink and anomaly tracking", 2, "LEVEL-4"),
            CommsChannel("space-operatives", "#field-operatives", "SPACE", "Ground operatives tactical coordination and perimeter sensors", 0, "LEVEL-5"),
            CommsChannel("space-ai", "#ai-command", "SPACE", "Direct encrypted uplink to ARIIA Neural Core", 1, "LEVEL-6"),
            CommsChannel("space-dispatch", "#emergency-dispatch", "SPACE", "Priority alerts, containment protocols, and system halts", 0, "LEVEL-5"),
            CommsChannel("dm-alpha", "Operative Alpha-1", "DM", "Forward Reconnaissance Lead - Sector 7", 0, "LEVEL-4"),
            CommsChannel("dm-orbital", "Cmdr. Vance (Orbital)", "DM", "Station Commander - ARIIA-KH11 Platform", 0, "LEVEL-6")
        )
    }

    var selectedChannel by remember { mutableStateOf(channels[0]) }

    // Message Store
    var messages by remember {
        mutableStateOf(
            listOf(
                CommsMessage(
                    "m1",
                    "space-recon",
                    "ARIIA-ORBITAL-EYE",
                    "Satellite Recon",
                    "Orbital pass confirmed over coordinates 38.8719° N, 77.0563° W. SAR synthetic aperture scan complete. Zero anomalous thermal plumes detected.",
                    "15:42",
                    CommsPriority.ROUTINE,
                    "38.8719° N, 77.0563° W",
                    false,
                    listOf("Roger", "Target Acquired")
                ),
                CommsMessage(
                    "m2",
                    "space-recon",
                    "VANCE-ORBITAL",
                    "Station Commander",
                    "Be advised: Solar coronal mass ejection warning. Re-aligning telemetry antenna dish toward primary ground station at Cape Canaveral.",
                    "15:48",
                    CommsPriority.URGENT,
                    null,
                    false,
                    listOf("Acknowledged")
                ),
                CommsMessage(
                    "m3",
                    "space-ai",
                    "ARIIA NEURAL CORE",
                    "Tactical AI",
                    "Neural diagnostics nominal. All 6-DOF robotics joints homed to zero reference. 360 LIDAR sweep clean. Awaiting tactical commands.",
                    "15:50",
                    CommsPriority.ROUTINE,
                    null,
                    false,
                    listOf("Standing By")
                ),
                CommsMessage(
                    "m4",
                    "space-operatives",
                    "ALPHA-LEAD",
                    "Ground Recon",
                    "Perimeter sensors established. Acoustic gunshot radar node deployed and synchronized with MQTT broker.",
                    "15:51",
                    CommsPriority.ROUTINE,
                    "46.2330° N, 6.0557° E",
                    false,
                    listOf("Roger")
                )
            )
        )
    }

    LaunchedEffect(Unit) {
        val saved = commsRepo.getDecryptedLogs()
        val loadedMessages = mutableListOf<CommsMessage>()
        for (i in 0 until saved.length()) {
            val obj = saved.getJSONObject(i)
            loadedMessages.add(CommsMessage(id = "repo-$i", channelId = obj.getString("channelId"), senderCallsign = obj.getString("sender"), senderRole = "Offline Log", content = com.example.utils.EncryptionHelper.encrypt(obj.getString("message")), timestamp = obj.getString("timestamp"), priority = CommsPriority.valueOf(obj.getString("priority")), geoCoordinates = null, isFromSelf = obj.getString("sender") == "COMMAND-CONSOLE", reactions = emptyList()))
        }
        if (loadedMessages.isNotEmpty()) {
            messages = messages + loadedMessages
        }
    }

    // Process Initial Target Payload from Orbital Earth if passed
    LaunchedEffect(initialTargetPayload, initialTargetLat, initialTargetLon) {
        if (initialTargetPayload != null && initialTargetLat != null && initialTargetLon != null) {
            val coords = "${"%.4f".format(initialTargetLat)}°, ${"%.4f".format(initialTargetLon)}°"
            val newMsg = CommsMessage(
                id = "m-${System.currentTimeMillis()}",
                channelId = selectedChannel.id,
                senderCallsign = "COMMAND-CONSOLE",
                senderRole = "Tactical Operator",
                content = "DISPATCH FROM ORBITAL EARTH: Priority target locked on [$initialTargetPayload]. Re-tasking planetary sensors.",
                timestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                priority = CommsPriority.FLASH,
                geoCoordinates = coords,
                isFromSelf = true
            )
            messages = messages + newMsg
        }
    }

    var messageInput by remember { mutableStateOf("") }
    var selectedPriority by remember { mutableStateOf(CommsPriority.ROUTINE) }
    var attachCoordinates by remember { mutableStateOf(false) }

    fun sendCommsMessage() {
        if (messageInput.trim().isEmpty()) return
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val encryptedContent = com.example.utils.EncryptionHelper.encrypt(messageInput.trim())
        val userMsg = CommsMessage(
            id = "user-${System.currentTimeMillis()}",
            channelId = selectedChannel.id,
            senderCallsign = "COMMAND-CONSOLE",
            senderRole = "Tactical Operator",
            content = encryptedContent,
            timestamp = timeStr,
            priority = selectedPriority,
            geoCoordinates = if (attachCoordinates) "38.8719° N, 77.0563° W" else null,
            isFromSelf = true
        )
        messages = messages + userMsg
        commsRepo.saveMessageLog(selectedChannel.id, messageInput.trim(), "COMMAND-CONSOLE", timeStr, selectedPriority.name)
        
        val sentText = messageInput.trim()
        messageInput = ""
        attachCoordinates = false

        // Automated Tactical AI Response
        coroutineScope.launch {
            delay(1000)
            val aiReply = when {
                selectedChannel.id == "space-ai" || sentText.contains("@ARIIA", ignoreCase = true) -> {
                    "ARIIA Neural Core has logged your dispatch: \"$sentText\". Strategic telemetry updated. Actuators stand by."
                }
                selectedChannel.id == "space-recon" -> {
                    "Orbital Earth Recon confirms message received. Satellite SAR aperture re-pointing to target sector."
                }
                else -> {
                    "Copy that, Command. All ground units roger. Maintaining encrypted frequency."
                }
            }
            val encryptedAiReply = com.example.utils.EncryptionHelper.encrypt(aiReply)
            val aiSender = if (selectedChannel.id == "space-ai") "ARIIA NEURAL CORE" else "DISPATCH-NODE"
            messages = messages + CommsMessage(
                id = "ai-${System.currentTimeMillis()}",
                channelId = selectedChannel.id,
                senderCallsign = aiSender,
                senderRole = "Tactical Network",
                content = encryptedAiReply,
                timestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                priority = CommsPriority.ROUTINE,
                geoCoordinates = null,
                isFromSelf = false
            )
            commsRepo.saveMessageLog(selectedChannel.id, aiReply, aiSender, SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), CommsPriority.ROUTINE.name)
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val currentChannelMessages = remember(messages, selectedChannel) {
        messages.filter { it.channelId == selectedChannel.id }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03060E))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Comms Top Bar
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF080D18),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Forum, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ARIIA SECURE COMMS",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = Color(0xFF00F0FF),
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        text = "Encrypted Tactical Spaces & Multi-Channel Dispatch Network",
                        fontSize = 9.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (onNavigateToEarth != null) {
                        IconButton(
                            onClick = onNavigateToEarth,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Public, contentDescription = "Open Earth", tint = Color(0xFF00F0FF), modifier = Modifier.size(18.dp))
                        }
                    }
                    IconButton(
                        onClick = {
                            val last = currentChannelMessages.lastOrNull()
                            if (last != null) {
                                speechEngine.speak("Last transmission from ${last.senderCallsign}: ${last.content}")
                            } else {
                                speechEngine.speak("Channel ${selectedChannel.name} is quiet.")
                            }
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Read Comms", tint = Color(0xFF39FF14), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Channel / Spaces Selector (Google Chat Spaces Rebranded)
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(channels) { ch ->
                val isSel = ch.id == selectedChannel.id
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSel) Color(0xFF002B36) else Color(0xFF0A0F1D),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFF00F0FF) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable {
                        selectedChannel = ch
                        speechEngine.speak("Frequency shifted to ${ch.name}.")
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (ch.type == "SPACE") Icons.Default.Tag else Icons.Default.Person,
                            contentDescription = null,
                            tint = if (isSel) Color(0xFF00F0FF) else Color(0xFF64748B),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = ch.name,
                            fontSize = 10.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSel) Color.White else Color(0xFFCBD5E1)
                        )
                        if (ch.unreadCount > 0) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Badge(containerColor = Color(0xFFFF0055), contentColor = Color.White) {
                                Text("${ch.unreadCount}", fontSize = 7.sp)
                            }
                        }
                    }
                }
            }
        }

        // Channel Status Banner
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF080D1A),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = selectedChannel.topic,
                    fontSize = 8.sp,
                    color = Color(0xFF94A3B8),
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                Badge(containerColor = Color(0xFF0A202A), contentColor = Color(0xFF00F0FF)) {
                    Text(selectedChannel.securityLevel, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Message Thread List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(currentChannelMessages, key = { it.id }) { msg ->
                CommsMessageBubble(
                    message = msg,
                    onPlayAudio = {
                        speechEngine.speak("${msg.senderCallsign} transmits: ${msg.content}")
                    },
                    onAddReaction = { reaction ->
                        messages = messages.map {
                            if (it.id == msg.id) it.copy(reactions = it.reactions + reaction) else it
                        }
                    }
                )
            }
        }

        // Quick Tactical Macro Chips
        val macros = listOf("Status Check", "Coordinates Confirmed", "Request Satellite Recon", "Roger", "@ARIIA Analyze")
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(macros) { macro ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0C1322),
                    border = BorderStroke(1.dp, Color(0xFF1E293B)),
                    modifier = Modifier.clickable {
                        messageInput = if (messageInput.isEmpty()) macro else "$messageInput $macro"
                    }
                ) {
                    Text(
                        text = macro,
                        fontSize = 8.sp,
                        color = Color(0xFF00F0FF),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // Message Composer
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF080D18),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                // Priority Bar & Attachment Toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        CommsPriority.values().forEach { prio ->
                            val isSel = selectedPriority == prio
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSel) prio.color.copy(alpha = 0.2f) else Color.Transparent,
                                border = BorderStroke(1.dp, if (isSel) prio.color else Color(0xFF1E293B)),
                                modifier = Modifier.clickable { selectedPriority = prio }
                            ) {
                                Text(
                                    prio.label,
                                    fontSize = 7.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSel) prio.color else Color(0xFF64748B),
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { attachCoordinates = !attachCoordinates },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Place,
                                contentDescription = "Attach Coordinates",
                                tint = if (attachCoordinates) Color(0xFF39FF14) else Color(0xFF64748B),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        if (attachCoordinates) {
                            Text("GPS ATTACHED", fontSize = 7.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                // Input Field & Send Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = messageInput,
                        onValueChange = { messageInput = it },
                        placeholder = { Text("Transmit tactical dispatch...", fontSize = 11.sp, color = Color(0xFF64748B)) },
                        modifier = Modifier.weight(1f),
                        singleLine = false,
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00F0FF),
                            unfocusedBorderColor = Color(0xFF1E293B),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = { sendCommsMessage() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(42.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.Black, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun CommsMessageBubble(
    message: CommsMessage,
    onPlayAudio: () -> Unit,
    onAddReaction: (String) -> Unit
) {
    val bubbleColor = if (message.isFromSelf) Color(0xFF002F3A) else Color(0xFF0A0F1D)
    val borderColor = if (message.priority == CommsPriority.FLASH) Color(0xFFFF0055)
    else if (message.priority == CommsPriority.URGENT) Color(0xFFFF9900)
    else if (message.isFromSelf) Color(0xFF00F0FF).copy(alpha = 0.5f)
    else Color(0xFF1E293B)

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bubbleColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            // Header: Sender & Priority
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .background(
                                if (message.isFromSelf) Color(0xFF00F0FF) else Color(0xFF39FF14),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            message.senderCallsign.take(1),
                            color = Color.Black,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = message.senderCallsign,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = message.senderRole,
                            fontSize = 7.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (message.priority != CommsPriority.ROUTINE) {
                        Badge(containerColor = message.priority.color.copy(alpha = 0.2f), contentColor = message.priority.color) {
                            Text(message.priority.label, fontSize = 6.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(message.timestamp, fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    IconButton(onClick = onPlayAudio, modifier = Modifier.size(20.dp)) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Play Audio", tint = Color(0xFF00F0FF), modifier = Modifier.size(13.dp))
                    }
                }
            }

            // Body Content
            Text(
                text = com.example.utils.EncryptionHelper.decrypt(message.content),
                fontSize = 11.sp,
                color = Color(0xFFCBD5E1),
                lineHeight = 15.sp
            )

            // Geolocation Attachment
            if (message.geoCoordinates != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF05141C),
                    border = BorderStroke(1.dp, Color(0xFF39FF14).copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Place, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "GEO-TARGET ATTACHED: ${message.geoCoordinates}",
                            fontSize = 8.sp,
                            color = Color(0xFF39FF14),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Reactions / Acknowledgment Tags
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    message.reactions.forEach { reaction ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF00222B),
                            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f))
                        ) {
                            Text(reaction, fontSize = 7.sp, color = Color(0xFF00F0FF), modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    TextButton(
                        onClick = { onAddReaction("Roger") },
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                        modifier = Modifier.height(20.dp)
                    ) {
                        Text("+ Roger", fontSize = 7.sp, color = Color(0xFF94A3B8))
                    }
                }
            }
        }
    }
}
