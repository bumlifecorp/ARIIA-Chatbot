package com.example.ui.screens.earth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

@Composable
fun StreetViewPanorama(
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val locations = remember {
        listOf(
            PanoramaLocation(
                id = "p-pentagon",
                title = "Pentagon Defense Courtyard",
                sector = "Sector 1 - Washington DC",
                latitude = 38.8719f,
                longitude = -77.0563f,
                environmentType = "Military Hardened Zone",
                description = "Tactical inner courtyard with high-gain microwave relays and fiber trunk lines.",
                hotspots = listOf(
                    PanoramaHotspot("h1", "Central Secure Concourse", 15f, -5f, "Hardened underground entry blast door with biometric scanner."),
                    PanoramaHotspot("h2", "Microwave Array Tower", 110f, 25f, "Secure Ka-band satellite crosslink relay."),
                    PanoramaHotspot("h3", "South Portico Checkpoint", -95f, -2f, "Autonomous vehicle inspection gantry with radiation detectors.")
                )
            ),
            PanoramaLocation(
                id = "p-cern",
                title = "CERN ATLAS Detector Cavern",
                sector = "Sub-Surface 100m - Geneva",
                latitude = 46.2330f,
                longitude = 6.0557f,
                environmentType = "Quantum Accelerator",
                description = "Gigantic toroidal superconducting magnet system and subatomic calorimeter chambers.",
                hotspots = listOf(
                    PanoramaHotspot("h4", "Liquid Argon Calorimeter", 45f, 10f, "High-density particle shower energy measurement matrix."),
                    PanoramaHotspot("h5", "Cryogenic Nitrogen Feed", -40f, -12f, "Superconducting cooling conduit at 1.9 Kelvin."),
                    PanoramaHotspot("h6", "Optical Fiber Backbone", 160f, 30f, "Petabyte-per-second real-time collision data pipeline.")
                )
            ),
            PanoramaLocation(
                id = "p-tokyo",
                title = "Shibuya Autonomous Cyber Mesh",
                sector = "Tokyo Metropole - Sector 4",
                latitude = 35.6762f,
                longitude = 139.6503f,
                environmentType = "Mega-Urban Matrix",
                description = "Dense IoT sensor canopy, traffic AI vision nodes, and fiber optic street routing.",
                hotspots = listOf(
                    PanoramaHotspot("h7", "Autonomous Drone Roost", 75f, 35f, "Municipal surveillance quadcopter charging dock."),
                    PanoramaHotspot("h8", "Pedestrian Flow Sensor", -20f, -15f, "Infrared thermal pedestrian density optical sensor."),
                    PanoramaHotspot("h9", "Metro Substation Node", -135f, -8f, "Underground rapid transit grid telemetry station.")
                )
            ),
            PanoramaLocation(
                id = "p-canaveral",
                title = "Cape Canaveral Launch Complex 39A",
                sector = "Space Coast - Florida",
                latitude = 28.3922f,
                longitude = -80.6077f,
                environmentType = "Spaceport Facility",
                description = "Orbital rocket launch gantry, cryo LOX/RP1 tank farm, and flame trench exhaust deflectors.",
                hotspots = listOf(
                    PanoramaHotspot("h10", "Crew Access Arm", -30f, 28f, "Retractable swing arm for astronaut ingress into orbital capsule."),
                    PanoramaHotspot("h11", "Flame Trench Acoustic Dampener", 60f, -22f, "High-volume water deluge suppression nozzles."),
                    PanoramaHotspot("h12", "LOX Storage Sphere", 140f, 5f, "Vacuum-insulated cryogenic liquid oxygen tank.")
                )
            ),
            PanoramaLocation(
                id = "p-svalbard",
                title = "Svalbard Arctic Seed Vault",
                sector = "Spitsbergen - Arctic Circle",
                latitude = 78.2357f,
                longitude = 15.4913f,
                environmentType = "Permafrost Fortress",
                description = "Hardened planetary biological archive buried inside sandstone mountain permafrost.",
                hotspots = listOf(
                    PanoramaHotspot("h13", "Illuminated Entry Portal", 0f, 5f, "Fiber-optic crystal art installation atop sandstone entrance."),
                    PanoramaHotspot("h14", "Permafrost Cryo Tunnel", 120f, -10f, "130-meter subterranean access tunnel held at -18°C."),
                    PanoramaHotspot("h15", "Seismic Telemetry Array", -70f, 15f, "Arctic tectonic fault and glacial movement sensor.")
                )
            )
        )
    }

    var activeLoc by remember { mutableStateOf(locations[0]) }
    var yawDeg by remember { mutableFloatStateOf(0f) }
    var pitchDeg by remember { mutableFloatStateOf(0f) }
    var fovZoom by remember { mutableFloatStateOf(1.0f) } // 0.8x to 2.0x
    var selectedHotspot by remember { mutableStateOf<PanoramaHotspot?>(null) }
    var isGyroActive by remember { mutableStateOf(true) }

    // Compass heading string
    val headingDeg = ((yawDeg % 360f) + 360f) % 360f
    val headingLabel = when {
        headingDeg >= 337.5 || headingDeg < 22.5 -> "N"
        headingDeg in 22.5..67.5 -> "NE"
        headingDeg in 67.5..112.5 -> "E"
        headingDeg in 112.5..157.5 -> "SE"
        headingDeg in 157.5..202.5 -> "S"
        headingDeg in 202.5..247.5 -> "SW"
        headingDeg in 247.5..292.5 -> "W"
        else -> "NW"
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF03060E)),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Location Selector Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(locations) { loc ->
                val isSel = loc.id == activeLoc.id
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSel) Color(0xFF003F4D) else Color(0xFF0A0F1D),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFF00F0FF) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable {
                        activeLoc = loc
                        yawDeg = 0f
                        pitchDeg = 0f
                        selectedHotspot = null
                        onSpeak("Entering 360 street reconnaissance for ${loc.title}. ${loc.sector}.")
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Streetview, contentDescription = null, tint = if (isSel) Color(0xFF00F0FF) else Color(0xFF64748B), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(loc.title, fontSize = 9.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal, color = if (isSel) Color.White else Color(0xFFCBD5E1))
                    }
                }
            }
        }

        // 360 Viewport Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF01040A), RoundedCornerShape(14.dp))
                .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        yawDeg = (yawDeg - dragAmount.x * 0.35f)
                        pitchDeg = (pitchDeg + dragAmount.y * 0.35f).coerceIn(-50f, 50f)
                    }
                }
        ) {
            // Interactive Panorama Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val center = Offset(w / 2f, h / 2f)

                // 1. Horizon & Sky Dome Gradient
                val horizonY = center.y + (pitchDeg * 4.5f * fovZoom)
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF020712), Color(0xFF0A182F)),
                        startY = 0f,
                        endY = horizonY
                    ),
                    topLeft = Offset(0f, 0f),
                    size = Size(w, horizonY.coerceAtLeast(0f))
                )

                // Ground / Street Floor Grid
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF08101C), Color(0xFF020408)),
                        startY = horizonY,
                        endY = h
                    ),
                    topLeft = Offset(0f, horizonY),
                    size = Size(w, (h - horizonY).coerceAtLeast(0f))
                )

                // Grid perspective lines on floor
                val numGridLines = 14
                for (i in -numGridLines..numGridLines) {
                    val angleOffset = i * 20f - (yawDeg % 20f)
                    val bottomX = center.x + angleOffset * 18f * fovZoom
                    drawLine(
                        color = Color(0xFF00F0FF).copy(alpha = 0.15f),
                        start = Offset(center.x, horizonY),
                        end = Offset(bottomX, h),
                        strokeWidth = 1f
                    )
                }

                // Horizon glow line
                drawLine(
                    color = Color(0xFF00F0FF).copy(alpha = 0.5f),
                    start = Offset(0f, horizonY),
                    end = Offset(w, horizonY),
                    strokeWidth = 1.5f
                )

                // 2. Simulated Panoramic Landmarks on Horizon
                val landmarkAngles = listOf(
                    Triple(-120f, "Auxiliary Relay Tower", 60.dp.toPx()),
                    Triple(-60f, "Defense Perimeter Gantry", 80.dp.toPx()),
                    Triple(0f, activeLoc.title, 110.dp.toPx()),
                    Triple(60f, "Hardened Security Bunker", 70.dp.toPx()),
                    Triple(140f, "Cryogenic Substation", 55.dp.toPx())
                )

                landmarkAngles.forEach { (ang, lName, heightPx) ->
                    var relAng = (ang - yawDeg) % 360f
                    if (relAng > 180f) relAng -= 360f
                    if (relAng < -180f) relAng += 360f

                    // Visible in field of view
                    if (relAng in -70f..70f) {
                        val lx = center.x + (relAng * 10.5f * fovZoom)
                        val topY = horizonY - (heightPx * fovZoom)

                        // Landmark Building Silhouette
                        val bWidth = 50.dp.toPx() * fovZoom
                        drawRect(
                            color = Color(0xFF0A2234).copy(alpha = 0.7f),
                            topLeft = Offset(lx - bWidth / 2f, topY),
                            size = Size(bWidth, heightPx * fovZoom)
                        )
                        drawRect(
                            color = Color(0xFF00F0FF).copy(alpha = 0.4f),
                            topLeft = Offset(lx - bWidth / 2f, topY),
                            size = Size(bWidth, heightPx * fovZoom),
                            style = Stroke(1.2f)
                        )

                        // Vertical telemetry beacon
                        drawLine(
                            color = Color(0xFF39FF14).copy(alpha = 0.6f),
                            start = Offset(lx, topY),
                            end = Offset(lx, topY - 15.dp.toPx()),
                            strokeWidth = 1.5f
                        )
                        drawCircle(color = Color(0xFF39FF14), radius = 3.dp.toPx(), center = Offset(lx, topY - 15.dp.toPx()))
                    }
                }

                // 3. Hotspots plotted in 360 space
                activeLoc.hotspots.forEach { spot ->
                    var spotRelYaw = (spot.yawOffset - yawDeg) % 360f
                    if (spotRelYaw > 180f) spotRelYaw -= 360f
                    if (spotRelYaw < -180f) spotRelYaw += 360f

                    if (spotRelYaw in -75f..75f) {
                        val hx = center.x + (spotRelYaw * 10.5f * fovZoom)
                        val hy = horizonY - (spot.pitchOffset * 6.5f * fovZoom)

                        val isHotspotSel = selectedHotspot?.id == spot.id
                        val pinColor = if (isHotspotSel) Color(0xFFFF0055) else Color(0xFF39FF14)

                        // Pulsing Hotspot Target
                        drawCircle(color = pinColor.copy(alpha = 0.35f), radius = 14.dp.toPx(), center = Offset(hx, hy))
                        drawCircle(color = pinColor, radius = 5.dp.toPx(), center = Offset(hx, hy))
                        drawCircle(color = Color.White, radius = 2.dp.toPx(), center = Offset(hx, hy))

                        // Target Crosshair
                        val cLen = 16.dp.toPx()
                        drawLine(pinColor.copy(alpha = 0.8f), Offset(hx - cLen, hy), Offset(hx + cLen, hy), strokeWidth = 1f)
                        drawLine(pinColor.copy(alpha = 0.8f), Offset(hx, hy - cLen), Offset(hx, hy + cLen), strokeWidth = 1f)
                    }
                }

                // Center Reticle
                val rSize = 20.dp.toPx()
                drawCircle(color = Color(0xFF00F0FF).copy(alpha = 0.3f), radius = rSize, center = center, style = Stroke(1.2f))
                drawLine(Color(0xFF00F0FF).copy(alpha = 0.6f), Offset(center.x - 8.dp.toPx(), center.y), Offset(center.x + 8.dp.toPx(), center.y), strokeWidth = 1f)
                drawLine(Color(0xFF00F0FF).copy(alpha = 0.6f), Offset(center.x, center.y - 8.dp.toPx()), Offset(center.x, center.y + 8.dp.toPx()), strokeWidth = 1f)
            }

            // HUD Compass Tape (Top-Center)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF06101C).copy(alpha = 0.85f),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.5f)),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Explore, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "HEADING: ${headingDeg.toInt()}° $headingLabel | PITCH: ${pitchDeg.toInt()}°",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF00F0FF),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Street View Controls (Top-Right)
            Column(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = { fovZoom = (fovZoom + 0.2f).coerceAtMost(2.2f) },
                    modifier = Modifier
                        .size(28.dp)
                        .background(Color(0xFF0A1220), CircleShape)
                        .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f), CircleShape)
                ) {
                    Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                }
                IconButton(
                    onClick = { fovZoom = (fovZoom - 0.2f).coerceAtLeast(0.7f) },
                    modifier = Modifier
                        .size(28.dp)
                        .background(Color(0xFF0A1220), CircleShape)
                        .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f), CircleShape)
                ) {
                    Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                }
                IconButton(
                    onClick = {
                        yawDeg = 0f
                        pitchDeg = 0f
                        fovZoom = 1.0f
                    },
                    modifier = Modifier
                        .size(28.dp)
                        .background(Color(0xFF0A1220), CircleShape)
                        .border(1.dp, Color(0xFF39FF14).copy(alpha = 0.4f), CircleShape)
                ) {
                    Icon(Icons.Default.CompassCalibration, contentDescription = "Reset North", tint = Color(0xFF39FF14), modifier = Modifier.size(16.dp))
                }
            }

            // Street Walk Controls (Bottom-Center)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        onSpeak("Stepping forward 15 meters along tactical street grid.")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003845).copy(alpha = 0.85f)),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Step Forward", fontSize = 8.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                }

                Button(
                    onClick = {
                        onSpeak("Stepping backward 15 meters.")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A1220).copy(alpha = 0.85f)),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Step Back", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Active Street Recon Info & Hotspot Intel Dossier
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF080D18),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(activeLoc.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(6.dp))
                        Badge(containerColor = Color(0xFF002833), contentColor = Color(0xFF39FF14)) {
                            Text(activeLoc.environmentType, fontSize = 7.sp)
                        }
                    }
                    Text("${activeLoc.latitude}°, ${activeLoc.longitude}°", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                }

                Text(activeLoc.description, fontSize = 9.sp, color = Color(0xFFCBD5E1))

                // Hotspots Row
                Text("TACTICAL STREET POI HOTSPOTS:", fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(activeLoc.hotspots) { spot ->
                        val isSpotSel = selectedHotspot?.id == spot.id
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSpotSel) Color(0xFF004455) else Color(0xFF0D1826),
                            border = BorderStroke(1.dp, if (isSpotSel) Color(0xFF39FF14) else Color(0xFF1E293B)),
                            modifier = Modifier.clickable {
                                selectedHotspot = spot
                                yawDeg = spot.yawOffset
                                pitchDeg = spot.pitchOffset
                                onSpeak("${spot.title}. ${spot.info}")
                            }
                        ) {
                            Text(
                                text = spot.title,
                                fontSize = 8.sp,
                                color = if (isSpotSel) Color.White else Color(0xFF00F0FF),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                if (selectedHotspot != null) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF021B24),
                        border = BorderStroke(1.dp, Color(0xFF39FF14).copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${selectedHotspot?.title}: ${selectedHotspot?.info}",
                                fontSize = 8.sp,
                                color = Color(0xFFE2E8F0),
                                lineHeight = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
