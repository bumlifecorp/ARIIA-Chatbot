package com.example.assistant

import android.service.voice.VoiceInteractionService

class AriiaVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
    }
}
