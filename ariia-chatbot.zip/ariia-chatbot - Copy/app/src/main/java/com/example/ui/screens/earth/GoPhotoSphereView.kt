package com.example.ui.screens.earth
import com.example.ui.screens.earth.SphericalHotspot
import com.example.ui.screens.earth.PhotoSphereLocation
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.draw.clip

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.*

@Composable
fun GoPhotoSphereView(
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    // Curated World Photo Spheres (Foxpoi Go Street View Photo Sphere Suite)
    val spheres = remember {
        androidx.compose.runtime.mutableStateListOf(
            PhotoSphereLocation(
                id = "ps-matterhorn",
                title = "Matterhorn Hörnli Ridge",
                category = "Summits",
                locationName = "Zermatt, Valais, Switzerland",
                country = "Switzerland",
                latitude = 45.9765f,
                longitude = 7.6585f,
                elevationMeters = 4478,
                captureDate = "2026-08-14 11:20 CET",
                defaultFovDegrees = 75f,
                description = "Iconic pyramid rock horn rising above the Zmutt Glacier, sheer north face, and jagged alpine ridge crest.",
                visualTheme = "ALPINE_GLACIER",
                hotspots = listOf(
                    SphericalHotspot("h-mat-1", "Hörnli Hut High Camp", -35f, -15f, "ps-everest", "Mountain refuge perched at 3,260m below the northeast ridge.", true),
                    SphericalHotspot("h-mat-2", "Solvay Bivouac Emergency Shelter", 42f, 18f, null, "Survival shelter located at 4,003m on the narrow rock ledge.", false),
                    SphericalHotspot("h-mat-3", "Zmutt Glacier Crevasse Field", 120f, -40f, null, "Extensive fractured blue ice tongues and lateral moraines.", false)
                )
            ),
            PhotoSphereLocation(
                id = "ps-grand-canyon",
                title = "Toroweap Overlook Abyss",
                category = "Wilderness",
                locationName = "North Rim, Arizona, USA",
                country = "United States",
                latitude = 36.2162f,
                longitude = -113.0583f,
                elevationMeters = 1400,
                captureDate = "2026-07-22 17:45 MST",
                defaultFovDegrees = 85f,
                description = "Breathtaking 3,000-foot vertical drop down to the emerald Colorado River rapids and Vulcan's Throne volcanic cinder cone.",
                visualTheme = "DESERT_CANYON",
                hotspots = listOf(
                    SphericalHotspot("h-gc-1", "Lava Falls Rapids", 15f, -65f, null, "Class 10 legendary whitewater cataract on the Colorado River below.", false),
                    SphericalHotspot("h-gc-2", "Vulcan's Throne Volcanic Cone", -80f, 10f, null, "Pleistocene basalt cinder cone overlooking the canyon rim.", false),
                    SphericalHotspot("h-gc-3", "Prospect Canyon Portal", 150f, -12f, "ps-mauna-kea", "Geological fault canyon entering from the south rim.", true)
                )
            ),
            PhotoSphereLocation(
                id = "ps-everest",
                title = "Everest Base Camp & Khumbu Icefall",
                category = "Summits",
                locationName = "Solukhumbu, Sagarmatha, Nepal",
                country = "Nepal",
                latitude = 28.0026f,
                longitude = 86.8528f,
                elevationMeters = 5364,
                captureDate = "2026-05-19 09:15 NPT",
                defaultFovDegrees = 70f,
                description = "Expedition tent city on the shifting Khumbu Glacier beneath the treacherous icefall seracs and Pumori summit.",
                visualTheme = "ALPINE_GLACIER",
                hotspots = listOf(
                    SphericalHotspot("h-ev-1", "Khumbu Icefall Gateway", 0f, 14f, null, "Towering 100-foot ice seracs traversed by aluminum ladders.", false),
                    SphericalHotspot("h-ev-2", "Nuptse West Ridge", 95f, 32f, null, "Sheer 7,861m rock face guarding the Western Cwm.", false),
                    SphericalHotspot("h-ev-3", "Chorten Memorial & Flags", -110f, -8f, "ps-matterhorn", "Buddhist prayer flags fluttering in high altitude jet stream winds.", true)
                )
            ),
            PhotoSphereLocation(
                id = "ps-mauna-kea",
                title = "Mauna Kea Stellar Observatories",
                category = "Space/Sci",
                locationName = "Big Island, Hawaii, USA",
                country = "United States",
                latitude = 19.8207f,
                longitude = -155.4681f,
                elevationMeters = 4207,
                captureDate = "2026-08-30 20:40 HST",
                defaultFovDegrees = 80f,
                description = "World-premier astronomical observatories sitting above the Pacific cloud inversion layer under dark pristine skies.",
                visualTheme = "CYBER_OBSERVATORY",
                hotspots = listOf(
                    SphericalHotspot("h-mk-1", "Keck I & II Twin Domes", -45f, 8f, null, "10-meter optical and infrared telescopes with laser guide stars.", false),
                    SphericalHotspot("h-mk-2", "Subaru Telescope Enclosure", 60f, 12f, null, "8.2-meter optical telescope with prime focus wide-field camera.", false),
                    SphericalHotspot("h-mk-3", "Sea of Clouds & Pacific Horizon", -135f, -20f, "ps-svalbard", "Tropospheric thermal inversion sea blocking light pollution.", true)
                )
            ),
            PhotoSphereLocation(
                id = "ps-svalbard",
                title = "Svalbard Arctic Vault Portal",
                category = "Wilderness",
                locationName = "Longyearbyen, Spitsbergen, Norway",
                country = "Norway",
                latitude = 78.2357f,
                longitude = 15.4913f,
                elevationMeters = 130,
                captureDate = "2026-02-04 14:10 CET",
                defaultFovDegrees = 80f,
                description = "Monolithic portal jutting out of the snowbound arctic mountain, aurora borealis ribbons shimmering in polar night.",
                visualTheme = "ALPINE_GLACIER",
                hotspots = listOf(
                    SphericalHotspot("h-sv-1", "Vault Security Blast Doors", 0f, -5f, null, "Triple-hardened steel pressure doors opening into sandstone tunnel.", false),
                    SphericalHotspot("h-sv-2", "Aurora Borealis Curtains", 45f, 45f, null, "Green electromagnetic solar wind interaction with arctic atmosphere.", false),
                    SphericalHotspot("h-sv-3", "Adventfjorden Fjord Ice", -90f, -25f, "ps-grand-canyon", "Frozen arctic fjord and sea ice pack extending toward the pole.", true)
                )
            )
        )
    }

    var activeSphere by remember { mutableStateOf(spheres[0]) }
    var yawDeg by remember { mutableStateOf(0f) } // -180 to 180 deg
    var pitchDeg by remember { mutableStateOf(0f) } // -90 to 90 deg
    var fovDeg by remember { mutableStateOf(activeSphere.defaultFovDegrees) } // 30 to 120 deg
    var isVrMode by remember { mutableStateOf(false) } // Stereoscopic Dual-Lens VR
    var isStudioMode by remember { mutableStateOf(false) } // Photo Sphere Capture Studio Simulator
    var isAutoSpinning by remember { mutableStateOf(false) }
    var selectedHotspot by remember { mutableStateOf<SphericalHotspot?>(null) }

    // Auto-spin animation
    LaunchedEffect(isAutoSpinning) {
        if (isAutoSpinning) {
            while (true) {
                delay(30)
                yawDeg = (yawDeg + 0.35f + 180f) % 360f - 180f
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF030712)),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // FOXPOI GO PHOTO SPHERE BRANDING HEADER
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF0C1424),
            border = BorderStroke(1.dp, Color(0xFFBD00FF).copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(Color(0xFF280B3A), CircleShape)
                            .border(1.dp, Color(0xFFBD00FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PanoramaPhotosphere, contentDescription = null, tint = Color(0xFFBD00FF), modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("GO PHOTO SPHERE", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color(0xFFBD00FF), fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("360° VR", fontSize = 8.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                        }
                        Text("FOXPOI EQUIRECTANGULAR SPHERICAL SUITE", fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // VR Mode Toggle
                    Button(
                        onClick = {
                            isVrMode = !isVrMode
                            if (isVrMode) isStudioMode = false
                            onSpeak(if (isVrMode) "Stereoscopic dual lens VR mode engaged. Insert phone into VR headset." else "Standard 360 photo sphere view restored.")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isVrMode) Color(0xFFBD00FF) else Color(0xFF16253C)),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Icon(Icons.Default.Headset, contentDescription = null, tint = if (isVrMode) Color.White else Color(0xFFBD00FF), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(if (isVrMode) "VR ON" else "VR DUAL", fontSize = 7.sp, color = if (isVrMode) Color.White else Color(0xFFBD00FF), fontWeight = FontWeight.Bold)
                    }

                    // Photo Sphere Studio Capture Simulator
                    Button(
                        onClick = {
                            isStudioMode = !isStudioMode
                            if (isStudioMode) isVrMode = false
                            onSpeak(if (isStudioMode) "Foxpoi Photo Sphere Capture Studio activated. Align visual crosshairs with spherical nodes to stitch panorama." else "Photo sphere studio closed.")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isStudioMode) Color(0xFF39FF14) else Color(0xFF16253C)),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Icon(Icons.Default.Camera, contentDescription = null, tint = if (isStudioMode) Color.Black else Color(0xFF39FF14), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(if (isStudioMode) "STUDIO" else "CAPTURE 360", fontSize = 7.sp, color = if (isStudioMode) Color.Black else Color(0xFF39FF14), fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = {
                            val speech = "Photo Sphere: ${activeSphere.title}, located in ${activeSphere.locationName}. Elevation ${activeSphere.elevationMeters} meters. Coordinates: Latitude ${activeSphere.latitude}, Longitude ${activeSphere.longitude}. Captured with ${activeSphere.cameraSensor} on ${activeSphere.captureDate}. ${activeSphere.description}"
                            onSpeak(speech)
                        },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Audio Guide", tint = Color(0xFF00F0FF), modifier = Modifier.size(15.dp))
                    }
                }
            }
        }

        // PHOTO SPHERE ARCHIVE CAROUSEL
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(spheres) { sphere ->
                val isSel = sphere.id == activeSphere.id
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) Color(0xFF2B0A3A) else Color(0xFF09111F),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFFBD00FF) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable {
                        activeSphere = sphere
                        fovDeg = sphere.defaultFovDegrees
                        yawDeg = 0f
                        pitchDeg = 0f
                        selectedHotspot = null
                        onSpeak("Loading photo sphere: ${sphere.title} in ${sphere.country}.")
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.PanoramaPhotosphere,
                            contentDescription = null,
                            tint = if (isSel) Color(0xFFBD00FF) else Color(0xFF64748B),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(sphere.title, fontSize = 8.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal, color = if (isSel) Color.White else Color(0xFFCBD5E1))
                            Text("${sphere.category} | ${sphere.elevationMeters}m", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // SPHERICAL TELEMETRY HUD BAR
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFF050B16),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "YAW: ${yawDeg.toInt()}°  |  PITCH: ${pitchDeg.toInt()}°  |  FOV: ${fovDeg.toInt()}°",
                    fontSize = 8.sp,
                    color = Color(0xFF00F0FF),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { isAutoSpinning = !isAutoSpinning },
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            if (isAutoSpinning) Icons.Default.Pause else Icons.Default.RotateRight,
                            contentDescription = "Auto Spin",
                            tint = if (isAutoSpinning) Color(0xFF39FF14) else Color(0xFF64748B),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "${activeSphere.latitude.format(3)}°, ${activeSphere.longitude.format(3)}°",
                        fontSize = 7.sp,
                        color = Color(0xFF64748B),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // MAIN VIEWPORT: PHOTO SPHERE OR STUDIO CAPTURE SIMULATOR
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Black)
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
        ) {
            if (isStudioMode) {
                // PHOTO SPHERE CAPTURE STUDIO SIMULATOR
                PhotoSphereStudioView(
                    onComplete = { imgPath ->
                        isStudioMode = false
                        if (imgPath != null) {
                            val newSphere = PhotoSphereLocation(
                                id = "ps-custom-${System.currentTimeMillis()}",
                                title = "User Captured Sphere",
                                category = "User Data",
                                locationName = "Local Device Capture",
                                country = "Unknown",
                                latitude = 0f,
                                longitude = 0f,
                                elevationMeters = 0,
                                captureDate = "Just Now",
                                defaultFovDegrees = 75f,
                                description = "Live CameraX captured sphere.",
                                visualTheme = "CYBER_OBSERVATORY",
                                localImagePath = imgPath
                            )
                            spheres.add(0, newSphere)
                            activeSphere = newSphere
                        }
                        onSpeak("Photo sphere captured and equirectangular projection stitched successfully.")
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else if (isVrMode) {
                // DUAL-LENS STEREOSCOPIC VR MODE (Left Eye & Right Eye)
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .pointerInput(Unit) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    yawDeg = (yawDeg - dragAmount.x * 0.4f + 180f) % 360f - 180f
                                    pitchDeg = (pitchDeg - dragAmount.y * 0.4f).coerceIn(-85f, 85f)
                                }
                            }
                    ) {
                        SphericalCanvasRender(
                            sphere = activeSphere,
                            yawDeg = yawDeg - 1.5f, // Stereo parallax offset
                            pitchDeg = pitchDeg,
                            fovDeg = fovDeg,
                            onHotspotClick = { selectedHotspot = it }
                        )
                        // VR Crosshair reticle
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(12.dp)
                                .border(1.dp, Color(0xFFBD00FF), CircleShape)
                        )
                        Text("LEFT EYE", fontSize = 6.sp, color = Color(0xFF64748B), modifier = Modifier.align(Alignment.TopStart).padding(4.dp), fontFamily = FontFamily.Monospace)
                    }

                    // Divider line for VR Cardboard
                    Box(modifier = Modifier.width(2.dp).fillMaxHeight().background(Color(0xFF00F0FF)))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        SphericalCanvasRender(
                            sphere = activeSphere,
                            yawDeg = yawDeg + 1.5f, // Stereo parallax offset
                            pitchDeg = pitchDeg,
                            fovDeg = fovDeg,
                            onHotspotClick = { selectedHotspot = it }
                        )
                        // VR Crosshair reticle
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(12.dp)
                                .border(1.dp, Color(0xFFBD00FF), CircleShape)
                        )
                        Text("RIGHT EYE", fontSize = 6.sp, color = Color(0xFF64748B), modifier = Modifier.align(Alignment.TopEnd).padding(4.dp), fontFamily = FontFamily.Monospace)
                    }
                }
            } else {
                // SINGLE VIEWPORT INTERACTIVE PHOTO SPHERE
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                isAutoSpinning = false
                                yawDeg = (yawDeg - dragAmount.x * 0.35f + 180f) % 360f - 180f
                                pitchDeg = (pitchDeg - dragAmount.y * 0.35f).coerceIn(-85f, 85f)
                            }
                        }
                ) {
                    SphericalCanvasRender(
                        sphere = activeSphere,
                        yawDeg = yawDeg,
                        pitchDeg = pitchDeg,
                        fovDeg = fovDeg,
                        onHotspotClick = { selectedHotspot = it }
                    )

                    // Zoom / FOV Slider Overlay
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(8.dp)
                            .background(Color(0xFF070E1A).copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                            .padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        IconButton(
                            onClick = { fovDeg = (fovDeg - 10f).coerceAtLeast(30f) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                        }
                        Text("${fovDeg.toInt()}°", fontSize = 7.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                        IconButton(
                            onClick = { fovDeg = (fovDeg + 10f).coerceAtMost(110f) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                        }
                    }

                    // Reset Center View button
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF070E1A).copy(alpha = 0.85f),
                        border = BorderStroke(1.dp, Color(0xFF00F0FF)),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .size(28.dp)
                            .clickable {
                                yawDeg = 0f
                                pitchDeg = 0f
                                fovDeg = activeSphere.defaultFovDegrees
                            }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.CenterFocusStrong, contentDescription = "Center View", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // HOTSPOT DETAIL POPUP DIALOG
        if (selectedHotspot != null) {
            val hs = selectedHotspot!!
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0F1829),
                border = BorderStroke(1.dp, Color(0xFFBD00FF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (hs.isPortal) Icons.Default.MeetingRoom else Icons.Default.Info,
                                contentDescription = null,
                                tint = if (hs.isPortal) Color(0xFF39FF14) else Color(0xFFBD00FF),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(hs.title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Text(hs.info, fontSize = 8.sp, color = Color(0xFFCBD5E1))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = {
                                onSpeak("${hs.title}. ${hs.info}")
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                        }

                        if (hs.isPortal && hs.targetSphereId != null) {
                            val target = spheres.find { it.id == hs.targetSphereId }
                            if (target != null) {
                                Button(
                                    onClick = {
                                        activeSphere = target
                                        yawDeg = 0f
                                        pitchDeg = 0f
                                        selectedHotspot = null
                                        onSpeak("Transporting through 360 portal to ${target.title}.")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF39FF14)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(24.dp)
                                ) {
                                    Text("PORTAL JUMP", fontSize = 7.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        IconButton(
                            onClick = { selectedHotspot = null },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SPHERICAL CANVAS RENDERER (Equirectangular Projection Simulation)
// -------------------------------------------------------------

@Composable
private fun SphericalCanvasRender(
    sphere: PhotoSphereLocation,
    yawDeg: Float,
    pitchDeg: Float,
    fovDeg: Float,
    onHotspotClick: (SphericalHotspot) -> Unit
) {
    var imageBitmap by remember(sphere.localImagePath) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    LaunchedEffect(sphere.localImagePath) {
        if (sphere.localImagePath != null) {
            val bitmap = android.graphics.BitmapFactory.decodeFile(sphere.localImagePath)
            if (bitmap != null) {
                imageBitmap = bitmap.asImageBitmap()
            }
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f

        if (imageBitmap != null) {
            val img = imageBitmap!!
            val scaledWidth = (img.width * (h / img.height.toFloat())).toInt()
            // Map 360 yaw to the image width
            val normalizedYaw = ((yawDeg % 360f) + 360f) % 360f
            val xOffsetScaled = -(normalizedYaw / 360f * scaledWidth).toInt()
            val yOffset = ((pitchDeg / fovDeg) * h).toInt()

            translate(left = xOffsetScaled.toFloat(), top = yOffset.toFloat()) {
                drawImage(img, dstSize = IntSize(scaledWidth, h.toInt()))
                // Draw adjacently to allow infinite wrapping
                drawImage(img, dstOffset = IntOffset(scaledWidth, 0), dstSize = IntSize(scaledWidth, h.toInt()))
                drawImage(img, dstOffset = IntOffset(-scaledWidth, 0), dstSize = IntSize(scaledWidth, h.toInt()))
            }
        } else {
            // 1. Sky & Ground Gradient based on visual theme
        val (skyColor, groundColor) = when (sphere.visualTheme) {
            "ALPINE_GLACIER" -> Pair(Color(0xFF0A1C38), Color(0xFFE2E8F0)) // Deep alpine sky & snow
            "DESERT_CANYON" -> Pair(Color(0xFF1E2D4A), Color(0xFF8B3A1B)) // Arizona canyon red rock
            "CYBER_OBSERVATORY" -> Pair(Color(0xFF030510), Color(0xFF2C241B)) // Night star sky & volcanic cinder
            else -> Pair(Color(0xFF0A1E35), Color(0xFF1F3A2A))
        }

        val horizonY = cy + (pitchDeg / fovDeg) * h
        drawRect(
            Brush.verticalGradient(
                colors = listOf(skyColor, skyColor.copy(alpha = 0.5f)),
                startY = 0f,
                endY = horizonY.coerceIn(0f, h)
            ),
            size = Size(w, horizonY.coerceIn(0f, h))
        )
        drawRect(
            Brush.verticalGradient(
                colors = listOf(groundColor.copy(alpha = 0.6f), groundColor),
                startY = horizonY.coerceIn(0f, h),
                endY = h
            ),
            topLeft = Offset(0f, horizonY.coerceIn(0f, h)),
            size = Size(w, (h - horizonY).coerceAtLeast(0f))
        )

        // 2. Horizon Line
        drawLine(Color(0xFF00F0FF).copy(alpha = 0.3f), Offset(0f, horizonY), Offset(w, horizonY), strokeWidth = 1.5f)

        // 3. Spherical Perspective Grid (Equirectangular curvature lines)
        for (lat in -60..60 step 30) {
            val py = cy + ((lat + pitchDeg) / fovDeg) * h
            if (py in 0f..h) {
                drawLine(Color(0xFF1E293B).copy(alpha = 0.4f), Offset(0f, py), Offset(w, py), strokeWidth = 1f)
            }
        }

        // Longitude curves (vertical meridians wrapped around 360°)
        for (lon in -180..180 step 45) {
            val relLon = (lon - yawDeg + 180f) % 360f - 180f
            val px = cx + (relLon / fovDeg) * w
            if (px in -50f..(w + 50f)) {
                drawLine(Color(0xFF1E293B).copy(alpha = 0.4f), Offset(px, 0f), Offset(px, h), strokeWidth = 1f)
            }
        }

        // 4. Draw Landscape Silhouettes (Simulated Panoramic Features)
        val landscapePath = Path()
        val steps = 40
        for (s in 0..steps) {
            val angle = (s.toFloat() / steps) * fovDeg - (fovDeg / 2f) + yawDeg
            val peakH = when (sphere.visualTheme) {
                "ALPINE_GLACIER" -> (sin(Math.toRadians(angle.toDouble() * 3.0)).toFloat() * 60f + cos(Math.toRadians(angle.toDouble() * 5.0)).toFloat() * 40f)
                "DESERT_CANYON" -> (sin(Math.toRadians(angle.toDouble() * 2.0)).toFloat() * 40f - 20f)
                else -> (cos(Math.toRadians(angle.toDouble() * 4.0)).toFloat() * 50f)
            }
            val x = (s.toFloat() / steps) * w
            val y = horizonY - peakH
            if (s == 0) landscapePath.moveTo(x, y) else landscapePath.lineTo(x, y)
        }
        landscapePath.lineTo(w, h)
        landscapePath.lineTo(0f, h)
        landscapePath.close()
        drawPath(landscapePath, groundColor.copy(alpha = 0.85f))
        }

        // 5. Draw Interactive Spherical Hotspots
        sphere.hotspots.forEach { hs ->
            val relYaw = (hs.yawDeg - yawDeg + 180f) % 360f - 180f
            val relPitch = (hs.pitchDeg - pitchDeg)

            val hx = cx + (relYaw / fovDeg) * w
            val hy = cy - (relPitch / fovDeg) * h

            // Only draw if within field of view
            if (hx in 20f..(w - 20f) && hy in 20f..(h - 20f)) {
                val dotColor = if (hs.isPortal) Color(0xFF39FF14) else Color(0xFFBD00FF)
                // Pulse ring
                drawCircle(dotColor.copy(alpha = 0.25f), radius = 14f, center = Offset(hx, hy))
                drawCircle(dotColor, radius = 6f, center = Offset(hx, hy))
                drawCircle(Color.White, radius = 2.5f, center = Offset(hx, hy))
            }
        }
    }
}

// -------------------------------------------------------------
// PHOTO SPHERE CAPTURE STUDIO SIMULATOR (Foxpoi Stitching Viewfinder)
// -------------------------------------------------------------
@Composable
private fun PhotoSphereStudioView(
    onComplete: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var capturedCount by remember { mutableStateOf(0) }
    val totalNodes = 12
    var bubbleLevelX by remember { mutableStateOf(0.12f) }
    var bubbleLevelY by remember { mutableStateOf(-0.08f) }

    val imageCapture = remember { androidx.camera.core.ImageCapture.Builder().build() }
    var savedFilePath by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .background(Color(0xFF020408))
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF0A1322),
            border = BorderStroke(1.dp, Color(0xFF39FF14).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("PHOTO SPHERE STITCHING STUDIO", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                Text("STITCHED: $capturedCount / $totalNodes NODES", fontSize = 8.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
            }
        }

        Box(
            modifier = Modifier
                .size(240.dp)
                .background(Color(0xFF060D18), CircleShape)
                .border(2.dp, Color(0xFF39FF14).copy(alpha = 0.6f), CircleShape)
                .clip(CircleShape)
        ) {
            CameraCapturePreview(imageCapture = imageCapture)

            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f - 16f
                drawLine(Color(0xFF39FF14).copy(alpha = 0.5f), Offset(center.x - 25f, center.y), Offset(center.x + 25f, center.y), strokeWidth = 1.5f)
                drawLine(Color(0xFF39FF14).copy(alpha = 0.5f), Offset(center.x, center.y - 25f), Offset(center.x, center.y + 25f), strokeWidth = 1.5f)
                for (i in 0 until totalNodes) {
                    val angleRad = (i.toFloat() / totalNodes) * (2 * Math.PI).toFloat()
                    val pt = Offset(center.x + radius * cos(angleRad), center.y + radius * sin(angleRad))
                    val isNodeCaptured = i < capturedCount
                    drawCircle(if (isNodeCaptured) Color(0xFF39FF14) else Color(0xFFFFCC00), radius = 6f, center = pt)
                    if (isNodeCaptured) drawCircle(Color.Black, radius = 2f, center = pt)
                }
                val bubblePt = Offset(center.x + bubbleLevelX * 50f, center.y + bubbleLevelY * 50f)
                drawCircle(Color(0xFF00F0FF).copy(alpha = 0.4f), radius = 10f, center = bubblePt)
                drawCircle(Color(0xFF00F0FF), radius = 4f, center = bubblePt)
            }
            Text("HORIZON LEVEL", fontSize = 7.sp, color = Color(0xFF64748B), modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp), fontFamily = FontFamily.Monospace)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = {
                    if (capturedCount < totalNodes) capturedCount += 1
                    val file = java.io.File(context.filesDir, "sphere_${System.currentTimeMillis()}.jpg")
                    val outputOptions = androidx.camera.core.ImageCapture.OutputFileOptions.Builder(file).build()
                    imageCapture.takePicture(
                        outputOptions,
                        androidx.core.content.ContextCompat.getMainExecutor(context),
                        object : androidx.camera.core.ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(output: androidx.camera.core.ImageCapture.OutputFileResults) {
                                savedFilePath = file.absolutePath
                            }
                            override fun onError(exc: androidx.camera.core.ImageCaptureException) {}
                        }
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF39FF14)),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("CAPTURE NODE (${capturedCount + 1})", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { onComplete(savedFilePath) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF)),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("STITCH SPHERE", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun Float.format(decimals: Int): String = "%.${decimals}f".format(this)
