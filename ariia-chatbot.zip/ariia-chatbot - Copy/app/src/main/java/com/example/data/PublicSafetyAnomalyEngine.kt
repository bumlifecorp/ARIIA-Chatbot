package com.example.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

enum class AnomalyCategory(val displayName: String) {
    ALPR_WATCHLIST("Automated License Plate Reader (ALPR)"),
    ACOUSTIC_GUNSHOT("Acoustic Gunshot Detection (AGDS)"),
    PERIMETER_ANOMALY("Perimeter Sensor Boundary Trip"),
    TRANSIT_CONGESTION("Anomalous Transit Clustering")
}

enum class AnomalySeverity(val label: String) {
    CRITICAL("CRITICAL TIER-1"),
    HIGH("HIGH PRIORITY"),
    MEDIUM("MODERATE"),
    INFORMATIONAL("ADVISORY")
}

data class PublicSafetyIncident(
    val id: String,
    val category: AnomalyCategory,
    val severity: AnomalySeverity,
    val headline: String,
    val details: String,
    val locationDescription: String,
    val coordinates: String,
    val confidenceScore: Float,
    val telemetryMetadata: Map<String, String>,
    val timestamp: Long = System.currentTimeMillis(),
    val isAcknowledged: Boolean = false
)

class PublicSafetyAnomalyEngine(
    private val scope: CoroutineScope,
    private val pubSubBroker: PubSubBrokerClient? = null
) {

    private val _incidents = MutableStateFlow<List<PublicSafetyIncident>>(emptyList())
    val incidents: StateFlow<List<PublicSafetyIncident>> = _incidents.asStateFlow()

    private val _isAnalyzingStreams = MutableStateFlow(true)
    val isAnalyzingStreams: StateFlow<Boolean> = _isAnalyzingStreams.asStateFlow()

    private val _streamProcessingRate = MutableStateFlow("1,850 events/sec")
    val streamProcessingRate: StateFlow<String> = _streamProcessingRate.asStateFlow()

    private var simulationJob: Job? = null

    init {
        seedInitialIncidents()
        startAggregatedStreamIngestion()
    }

    private fun seedInitialIncidents() {
        val initial = listOf(
            PublicSafetyIncident(
                id = "INC-ALPR-9042",
                category = AnomalyCategory.ALPR_WATCHLIST,
                severity = AnomalySeverity.HIGH,
                headline = "ALPR Stolen Vehicle Watchlist Match",
                details = "Plate #7XYZ892 flagged in national stolen vehicle registry detected crossing arterial node #14 at 52 mph.",
                locationDescription = "Arterial Highway Junction 14 - Northbound",
                coordinates = "34.0538° N, 118.2450° W",
                confidenceScore = 0.98f,
                telemetryMetadata = mapOf(
                    "Plate_Hash" to "SHA256:7a9f...e2b1",
                    "Vehicle_Class" to "Dark Sedan",
                    "Speed" to "52 mph",
                    "Sensor_ID" to "ALPR-HWY-14B"
                )
            ),
            PublicSafetyIncident(
                id = "INC-AGDS-4109",
                category = AnomalyCategory.ACOUSTIC_GUNSHOT,
                severity = AnomalySeverity.CRITICAL,
                headline = "Acoustic Gunshot Impulse Triangulated",
                details = "3-node acoustic triangulation confirmed supersonic shockwave followed by 124 dB muzzle blast signature. 3 rounds detected.",
                locationDescription = "Sector Gamma Industrial Complex - Loading Bay 4",
                coordinates = "34.0489° N, 118.2392° W",
                confidenceScore = 0.96f,
                telemetryMetadata = mapOf(
                    "Peak_Decibels" to "124.2 dB",
                    "Rounds_Fired" to "3",
                    "Triangulating_Nodes" to "Node-12, Node-15, Node-19",
                    "Acoustic_Profile" to "Caliber 9x19mm Impulse Envelope"
                )
            ),
            PublicSafetyIncident(
                id = "INC-PER-8812",
                category = AnomalyCategory.PERIMETER_ANOMALY,
                severity = AnomalySeverity.MEDIUM,
                headline = "Perimeter Boundary Beam Interruption",
                details = "Infrared laser tripwire interrupted for 3.4 seconds outside normal operational access window.",
                locationDescription = "Subterranean Perimeter Gate 3",
                coordinates = "34.0510° N, 118.2415° W",
                confidenceScore = 0.91f,
                telemetryMetadata = mapOf(
                    "Beam_ID" to "IR-GATE-03",
                    "Interruption_Duration" to "3.4s",
                    "Tamper_Status" to "Normal"
                )
            )
        )
        _incidents.value = initial
    }

    private fun startAggregatedStreamIngestion() {
        simulationJob?.cancel()
        simulationJob = scope.launch(Dispatchers.Default) {
            val samplePlates = listOf("8KLM412", "5ABC991", "2XYZ604", "9TRK108", "4PLT883")
            val locations = listOf(
                Pair("Expressway Westbound Mile 4", "34.0560° N, 118.2510° W"),
                Pair("Southbound River Overpass", "34.0470° N, 118.2350° W"),
                Pair("East Cargo Intermodal Gate", "34.0515° N, 118.2480° W"),
                Pair("Downtown Financial Plaza Outer Ring", "34.0545° N, 118.2420° W")
            )

            while (isActive) {
                delay(7500) // Periodic non-sensitive event analysis
                if (!_isAnalyzingStreams.value) continue

                val isAlpr = Random.nextBoolean()
                val loc = locations[Random.nextInt(locations.size)]
                val incident = if (isAlpr) {
                    val plate = samplePlates[Random.nextInt(samplePlates.size)]
                    PublicSafetyIncident(
                        id = "INC-ALPR-${Random.nextInt(1000, 9999)}",
                        category = AnomalyCategory.ALPR_WATCHLIST,
                        severity = if (Random.nextBoolean()) AnomalySeverity.HIGH else AnomalySeverity.MEDIUM,
                        headline = "ALPR Transponder Alert: $plate",
                        details = "Aggregated automated license plate reader detected non-registered vehicle transponder #$plate.",
                        locationDescription = loc.first,
                        coordinates = loc.second,
                        confidenceScore = (0.92f + (Random.nextFloat() * 0.07f)).coerceIn(0.90f, 0.99f),
                        telemetryMetadata = mapOf(
                            "Plate_Hash" to "SHA256:hash_${plate.lowercase()}",
                            "Speed" to "${Random.nextInt(38, 68)} mph",
                            "Sensor_ID" to "ALPR-NODE-${Random.nextInt(10, 99)}"
                        )
                    )
                } else {
                    val db = Random.nextInt(118, 128)
                    val rounds = Random.nextInt(1, 5)
                    PublicSafetyIncident(
                        id = "INC-AGDS-${Random.nextInt(1000, 9999)}",
                        category = AnomalyCategory.ACOUSTIC_GUNSHOT,
                        severity = AnomalySeverity.CRITICAL,
                        headline = "Acoustic Impulse Anomaly ($rounds bursts)",
                        details = "Micro-acoustic sensor network detected $rounds sharp impulse signatures with peak amplitude $db dB.",
                        locationDescription = loc.first,
                        coordinates = loc.second,
                        confidenceScore = (0.94f + (Random.nextFloat() * 0.05f)).coerceIn(0.92f, 0.99f),
                        telemetryMetadata = mapOf(
                            "Peak_Decibels" to "$db dB",
                            "Rounds_Detected" to "$rounds",
                            "Spectral_Match" to "Bimodal Muzzle Impulse",
                            "Sensor_Cluster" to "AGDS-Sector-Grid"
                        )
                    )
                }

                val current = _incidents.value.toMutableList()
                if (current.size > 25) current.removeAt(current.size - 1)
                current.add(0, incident)
                _incidents.value = current

                // Publish incident notification to PubSub broker topic
                pubSubBroker?.publish(
                    topic = "public_safety/anomalies/events",
                    payload = "{\"incidentId\":\"${incident.id}\",\"category\":\"${incident.category.name}\",\"severity\":\"${incident.severity.name}\",\"loc\":\"${incident.locationDescription}\"}",
                    senderId = "ANOMALY_ENGINE"
                )
            }
        }
    }

    fun toggleStreamAnalysis(enabled: Boolean) {
        _isAnalyzingStreams.value = enabled
    }

    fun acknowledgeIncident(id: String) {
        val updated = _incidents.value.map {
            if (it.id == id) it.copy(isAcknowledged = true) else it
        }
        _incidents.value = updated
    }

    fun clearAllIncidents() {
        _incidents.value = emptyList()
    }
}
