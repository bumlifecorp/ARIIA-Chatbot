package com.example.ui.screens.earth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.MiniFinderTrackingService
import com.example.util.VoiceActionExecutor
import kotlin.math.*

@Composable
fun MiniFinderSuiteView(
    onSpeak: (String) -> Unit,
    initialMode: MiniFinderAppMode = MiniFinderAppMode.MINIFINDER_GO,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var activeAppMode by remember { mutableStateOf(initialMode) }

    // Collect real-time live coordinate data & telemetry logs from tracking service
    val allDevices by MiniFinderTrackingService.devices.collectAsState()
    val liveTelemetryLog by MiniFinderTrackingService.telemetryLogs.collectAsState()
    val isTrackingActive by MiniFinderTrackingService.isLiveTrackingActive.collectAsState()
    val speedMultiplier by MiniFinderTrackingService.simulationSpeedMultiplier.collectAsState()

    val goDevices = remember(allDevices) { allDevices.filter { it.category != "Hunting Dog" } }
    val hunterDogs = remember(allDevices) { allDevices.filter { it.category == "Hunting Dog" } }

    var selectedGoDeviceId by remember { mutableStateOf("pico-1") }
    var selectedDogId by remember { mutableStateOf("rex-1") }

    val selectedGoDevice = remember(goDevices, selectedGoDeviceId) {
        goDevices.find { it.id == selectedGoDeviceId } ?: goDevices.firstOrNull() ?: allDevices[0]
    }

    val selectedHunterDog = remember(hunterDogs, selectedDogId) {
        hunterDogs.find { it.id == selectedDogId } ?: hunterDogs.firstOrNull() ?: allDevices[0]
    }

    val hunterStands = remember {
        listOf(
            MiniFinderHunterStand("stand-1", "Pass 01 - North Crest", "Johan Lindqvist", 62.3880f, 17.2990f, true),
            MiniFinderHunterStand("stand-2", "Pass 02 - Pine Valley", "Erik Nilsson", 62.3920f, 17.3200f, true),
            MiniFinderHunterStand("stand-3", "Pass 03 - Birch Stream", "Sven Andersson", 62.3970f, 17.2900f, true),
            MiniFinderHunterStand("stand-4", "Pass 04 - Ridge Lookout", "Unassigned Stand", 62.4010f, 17.3100f, false)
        )
    }

    var geofenceRadius by remember { mutableFloatStateOf(selectedGoDevice.geofenceRadiusM.toFloat()) }
    var barkThresholdBpm by remember { mutableIntStateOf(60) }
    var selectedUpdateInterval by remember { mutableStateOf("1.5 sec") }

    val infiniteTransition = rememberInfiniteTransition(label = "MiniFinderAnim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "Pulse"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF030A14))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // MiniFinder Top Header & Live Tracking Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A1628), RoundedCornerShape(10.dp))
                .border(1.dp, Color(0xFF00AAFF), RoundedCornerShape(10.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.GpsFixed,
                    contentDescription = null,
                    tint = if (isTrackingActive) Color(0xFF39FF14) else Color(0xFFFF3366),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("MINIFINDER REAL-TIME GPS SERVICE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF00AAFF), fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = CircleShape,
                            color = if (isTrackingActive) Color(0xFF39FF14) else Color(0xFFFF3366)
                        ) {
                            Box(modifier = Modifier.size(6.dp))
                        }
                    }
                    Text(
                        if (isTrackingActive) "Streaming 1.5s Coordinates • Speed ${speedMultiplier.toInt()}x" else "Tracking Paused",
                        fontSize = 8.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                // Play / Pause Service Button
                IconButton(
                    onClick = {
                        if (isTrackingActive) {
                            MiniFinderTrackingService.pauseLiveTrackingService()
                            onSpeak("MiniFinder real-time GPS tracking service paused.")
                        } else {
                            MiniFinderTrackingService.startLiveTrackingService()
                            onSpeak("MiniFinder real-time GPS tracking service activated.")
                        }
                    },
                    modifier = Modifier.size(26.dp)
                ) {
                    Icon(
                        imageVector = if (isTrackingActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color(0xFF39FF14)
                    )
                }

                // Speed multiplier chips
                listOf(1f, 2f, 5f).forEach { spd ->
                    val isSel = spd == speedMultiplier
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (isSel) Color(0xFF00AAFF) else Color(0xFF0F172A),
                        border = BorderStroke(1.dp, Color(0xFF00AAFF)),
                        modifier = Modifier.clickable {
                            MiniFinderTrackingService.setSpeedMultiplier(spd)
                            onSpeak("Simulation speed set to ${spd.toInt()}x.")
                        }
                    ) {
                        Text(
                            text = "${spd.toInt()}x",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSel) Color.Black else Color.White,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }

                Button(
                    onClick = {
                        val speech = "Initiating two-way voice call to MiniFinder device ${selectedGoDevice.name} at coordinates ${selectedGoDevice.lat}, ${selectedGoDevice.lon}."
                        onSpeak(speech)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00AAFF)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("2-Way Call", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // App Mode Switcher (Go, Live, Hunter)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MiniFinderAppMode.values().forEach { mode ->
                val isSelected = mode == activeAppMode
                val color = when (mode) {
                    MiniFinderAppMode.MINIFINDER_GO -> Color(0xFF00AAFF)
                    MiniFinderAppMode.MINIFINDER_LIVE -> Color(0xFF34A853)
                    MiniFinderAppMode.MINIFINDER_HUNTER -> Color(0xFFFF9900)
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) color.copy(alpha = 0.2f) else Color(0xFF0B1424),
                    border = BorderStroke(1.dp, if (isSelected) color else Color(0xFF1E293B)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            activeAppMode = mode
                            onSpeak("Switched to ${mode.title} - ${mode.subtitle}.")
                        }
                ) {
                    Column(
                        modifier = Modifier.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(mode.title, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (isSelected) color else Color.White)
                        Text(mode.subtitle, fontSize = 7.sp, color = Color(0xFF94A3B8), maxLines = 1)
                    }
                }
            }
        }

        // Main App Mode Content View
        when (activeAppMode) {
            MiniFinderAppMode.MINIFINDER_GO -> {
                MiniFinderGoContent(
                    devices = goDevices,
                    selectedDevice = selectedGoDevice,
                    onSelectDevice = { selectedGoDeviceId = it.id },
                    geofenceRadius = geofenceRadius,
                    onGeofenceChange = { geofenceRadius = it },
                    isSosActive = selectedGoDevice.sosTriggered,
                    onToggleSos = {
                        if (selectedGoDevice.sosTriggered) {
                            MiniFinderTrackingService.resetSosAlarm(selectedGoDevice.id)
                            onSpeak("SOS panic alarm cleared for ${selectedGoDevice.name}.")
                        } else {
                            MiniFinderTrackingService.triggerSosAlarm(selectedGoDevice.id)
                            onSpeak("EMERGENCY SOS PANIC ALARM ACTIVATED for ${selectedGoDevice.name}! Live coordinates ${selectedGoDevice.lat}, ${selectedGoDevice.lon}.")
                        }
                    },
                    pulseScale = pulseScale,
                    onSpeak = onSpeak
                )
            }

            MiniFinderAppMode.MINIFINDER_LIVE -> {
                MiniFinderLiveContent(
                    devices = allDevices,
                    telemetryLog = liveTelemetryLog,
                    updateInterval = selectedUpdateInterval,
                    onIntervalChange = { selectedUpdateInterval = it },
                    onSpeak = onSpeak
                )
            }

            MiniFinderAppMode.MINIFINDER_HUNTER -> {
                MiniFinderHunterContent(
                    dogs = hunterDogs,
                    selectedDog = selectedHunterDog,
                    onSelectDog = { selectedDogId = it.id },
                    stands = hunterStands,
                    barkThresholdBpm = barkThresholdBpm,
                    onThresholdChange = { barkThresholdBpm = it },
                    pulseScale = pulseScale,
                    onSpeak = onSpeak
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 1. MINIFINDER GO APP CONTENT WITH REAL-TIME MAP OVERLAYS
// -----------------------------------------------------------------------------
@Composable
fun ColumnScope.MiniFinderGoContent(
    devices: List<MiniFinderDevice>,
    selectedDevice: MiniFinderDevice,
    onSelectDevice: (MiniFinderDevice) -> Unit,
    geofenceRadius: Float,
    onGeofenceChange: (Float) -> Unit,
    isSosActive: Boolean,
    onToggleSos: () -> Unit,
    pulseScale: Float,
    onSpeak: (String) -> Unit
) {
    // Device Selector Row
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(devices) { dev ->
            val isSel = dev.id == selectedDevice.id
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSel) Color(0xFF003355) else Color(0xFF0D1B2A),
                border = BorderStroke(1.dp, if (isSel) Color(0xFF00AAFF) else Color(0xFF1E293B)),
                modifier = Modifier.clickable {
                    onSelectDevice(dev)
                    onSpeak("MiniFinder Go selected device ${dev.name}. Status: ${dev.status}. Battery ${dev.batteryPercent} percent.")
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = when (dev.model) {
                            "MiniFinder Pico 4G" -> Icons.Default.Person
                            "MiniFinder Nano" -> Icons.Default.ChildCare
                            "MiniFinder Atto Pro" -> Icons.Default.DirectionsCar
                            else -> Icons.Default.Inventory
                        },
                        contentDescription = null,
                        tint = if (isSel) Color(0xFF00AAFF) else Color(0xFF64748B),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(dev.name, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${dev.model} • ${dev.speedKmh} km/h • ${dev.batteryPercent}%", fontSize = 7.sp, color = Color(0xFF94A3B8))
                    }
                }
            }
        }
    }

    // Interactive Tracker Map Canvas visualizing real-time coordinates
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .background(Color(0xFF020712), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF00AAFF).copy(alpha = 0.4f), RoundedCornerShape(12.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val center = Offset(w / 2f, h / 2f)

            // Grid Lines
            val gridCount = 10
            val dx = w / gridCount
            val dy = h / gridCount
            for (i in 0..gridCount) {
                drawLine(Color(0xFF004466).copy(alpha = 0.2f), Offset(i * dx, 0f), Offset(i * dx, h))
                drawLine(Color(0xFF004466).copy(alpha = 0.2f), Offset(0f, i * dy), Offset(w, i * dy))
            }

            // Geofence Safe Zone Circle
            drawCircle(
                color = Color(0xFF34A853).copy(alpha = 0.15f),
                radius = geofenceRadius * 0.25f,
                center = center
            )
            drawCircle(
                color = Color(0xFF34A853),
                radius = geofenceRadius * 0.25f,
                center = center,
                style = Stroke(width = 2f)
            )

            // Historical Trail Line overlay from actual real-time history coordinates
            if (selectedDevice.historyTrail.size > 1) {
                val trailPath = Path()
                val originLat = selectedDevice.historyTrail.first().first
                val originLon = selectedDevice.historyTrail.first().second

                selectedDevice.historyTrail.forEachIndexed { idx, pt ->
                    val px = center.x + (pt.second - originLon) * 250000f
                    val py = center.y - (pt.first - originLat) * 250000f
                    if (idx == 0) trailPath.moveTo(px, py)
                    else trailPath.lineTo(px, py)
                }

                drawPath(trailPath, color = Color(0xFF00AAFF), style = Stroke(width = 3f))
            }

            // Draw all active devices on the map overlay
            devices.forEach { dev ->
                val isSelected = dev.id == selectedDevice.id
                val devX = center.x + (dev.lon - selectedDevice.lon) * 250000f
                val devY = center.y - (dev.lat - selectedDevice.lat) * 250000f

                if (isSelected) {
                    // Selected Primary Pin Drop & Pulsing Ring
                    drawCircle(
                        color = if (isSosActive) Color(0xFFFF0055).copy(alpha = 0.4f) else Color(0xFF00AAFF).copy(alpha = 0.3f),
                        radius = 24f * pulseScale,
                        center = Offset(devX, devY)
                    )
                    drawCircle(
                        color = if (isSosActive) Color(0xFFFF0055) else Color(0xFF00AAFF),
                        radius = 8f,
                        center = Offset(devX, devY)
                    )
                } else {
                    // Secondary Device Pin
                    drawCircle(
                        color = Color(0xFF34A853).copy(alpha = 0.8f),
                        radius = 5f,
                        center = Offset(devX, devY)
                    )
                }
            }
        }

        // HUD Overlay info
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, Color(0xFF00AAFF))
            ) {
                Column(modifier = Modifier.padding(6.dp)) {
                    Text("MINIFINDER GO REAL-TIME POSITION", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00AAFF))
                    Text("DEVICE: ${selectedDevice.name} (${selectedDevice.model})", fontSize = 8.sp, color = Color.White)
                    Text("LAT: ${selectedDevice.lat}° | LON: ${selectedDevice.lon}°", fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("SPEED: ${selectedDevice.speedKmh} km/h | BATT: ${selectedDevice.batteryPercent}% | SATS: ${selectedDevice.satellites}", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Text("STATUS: ${selectedDevice.status}", fontSize = 8.sp, color = if (selectedDevice.sosTriggered) Color(0xFFFF0055) else Color(0xFFCBD5E1))
                }
            }
        }

        // SOS Button Overlay
        Button(
            onClick = onToggleSos,
            colors = ButtonDefaults.buttonColors(containerColor = if (isSosActive) Color(0xFFFF0055) else Color(0xFF00AAFF)),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
        ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (isSosActive) "CLEAR SOS ALARM" else "TRIGGER SOS", fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }

    // Geofence Radius Slider Card
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF0A1628),
        border = BorderStroke(1.dp, Color(0xFF00AAFF).copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Geofence Safe Zone Radius: ${geofenceRadius.toInt()} meters", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34A853))
                Text("Auto Breach Alarm Enabled", fontSize = 8.sp, color = Color(0xFF94A3B8))
            }

            Slider(
                value = geofenceRadius,
                onValueChange = onGeofenceChange,
                valueRange = 100f..2500f,
                colors = SliderDefaults.colors(thumbColor = Color(0xFF34A853), activeTrackColor = Color(0xFF34A853))
            )
        }
    }
}

// -----------------------------------------------------------------------------
// 2. MINIFINDER LIVE APP CONTENT
// -----------------------------------------------------------------------------
@Composable
fun ColumnScope.MiniFinderLiveContent(
    devices: List<MiniFinderDevice>,
    telemetryLog: List<String>,
    updateInterval: String,
    onIntervalChange: (String) -> Unit,
    onSpeak: (String) -> Unit
) {
    // Multi-Device Telemetry Matrix
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(devices) { dev ->
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0B1424),
                border = BorderStroke(1.dp, if (dev.sosTriggered) Color(0xFFFF0055) else Color(0xFF34A853).copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(dev.name, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("${dev.model}", fontSize = 7.sp, color = Color(0xFF34A853))
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("LAT: ${String.format("%.4f", dev.lat)} | LON: ${String.format("%.4f", dev.lon)}", fontSize = 7.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    Text("Batt: ${dev.batteryPercent}% | GSM: ${dev.signalDbm} dBm", fontSize = 7.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                    Text("Speed: ${dev.speedKmh} km/h | Sats: ${dev.satellites}", fontSize = 7.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                }
            }
        }
    }

    // Live Socket Log Terminal
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF02070D),
        border = BorderStroke(1.dp, Color(0xFF34A853).copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("REAL-TIME LIVE TELEMETRY LOG STREAM", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34A853), fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = { MiniFinderTrackingService.clearLogs() },
                        modifier = Modifier.size(18.dp)
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Logs", tint = Color(0xFF94A3B8), modifier = Modifier.size(12.dp))
                    }
                }
                Text("Interval: $updateInterval", fontSize = 8.sp, color = Color(0xFF94A3B8))
            }

            Spacer(modifier = Modifier.height(4.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(telemetryLog.reversed()) { logEntry ->
                    Text(
                        logEntry,
                        fontSize = 8.sp,
                        color = if (logEntry.contains("ALERT") || logEntry.contains("SOS")) Color(0xFFFF0055) else Color(0xFF39FF14),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("1.5 sec", "5 sec", "30 sec", "60 sec").forEach { interval ->
                    val isSel = interval == updateInterval
                    FilterChip(
                        selected = isSel,
                        onClick = {
                            onIntervalChange(interval)
                            onSpeak("MiniFinder Live update interval set to $interval.")
                        },
                        label = { Text(interval, fontSize = 8.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF34A853), selectedLabelColor = Color.White)
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 3. MINIFINDER HUNTER APP CONTENT
// -----------------------------------------------------------------------------
@Composable
fun ColumnScope.MiniFinderHunterContent(
    dogs: List<MiniFinderDevice>,
    selectedDog: MiniFinderDevice,
    onSelectDog: (MiniFinderDevice) -> Unit,
    stands: List<MiniFinderHunterStand>,
    barkThresholdBpm: Int,
    onThresholdChange: (Int) -> Unit,
    pulseScale: Float,
    onSpeak: (String) -> Unit
) {
    // Dog Collar Selector
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(dogs) { dog ->
            val isSel = dog.id == selectedDog.id
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSel) Color(0xFF442200) else Color(0xFF0F172A),
                border = BorderStroke(1.dp, if (isSel) Color(0xFFFF9900) else Color(0xFF1E293B)),
                modifier = Modifier.clickable {
                    onSelectDog(dog)
                    onSpeak("MiniFinder Hunter dog collar locked on ${dog.name}. Coordinates ${dog.lat}, ${dog.lon}. Distance ${dog.distanceToUserMeters} meters. Bark rate ${dog.barksPerMinute} B P M.")
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Pets, contentDescription = null, tint = if (isSel) Color(0xFFFF9900) else Color(0xFF64748B), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(dog.name, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${dog.dogBreed} • ${dog.barksPerMinute ?: 0} BPM", fontSize = 7.sp, color = Color(0xFFFF9900))
                    }
                }
            }
        }
    }

    // Bark Detection & Directional Compass Canvas
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .background(Color(0xFF070B02), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFFF9900).copy(alpha = 0.4f), RoundedCornerShape(12.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val center = Offset(w / 2f, h / 2f)

            // Radar Concentric Circles for Distance
            for (r in listOf(60f, 120f, 180f)) {
                drawCircle(Color(0xFF39FF14).copy(alpha = 0.2f), radius = r, center = center, style = Stroke(width = 1f))
            }

            // Direction Arrow to Dog
            val angleRad = Math.toRadians((selectedDog.headingDegrees ?: 45f).toDouble())
            val dogDistRadius = 130f
            val dogX = center.x + (sin(angleRad) * dogDistRadius).toFloat()
            val dogY = center.y - (cos(angleRad) * dogDistRadius).toFloat()

            // Line from Hunter to Dog
            drawLine(
                color = Color(0xFFFF9900),
                start = center,
                end = Offset(dogX, dogY),
                strokeWidth = 2f
            )

            // Dog Pin
            drawCircle(
                color = Color(0xFFFF9900).copy(alpha = 0.4f),
                radius = 16f * pulseScale,
                center = Offset(dogX, dogY)
            )
            drawCircle(
                color = Color(0xFFFF9900),
                radius = 6f,
                center = Offset(dogX, dogY)
            )

            // Hunter User Center Pin
            drawCircle(Color(0xFF39FF14), radius = 6f, center = center)
        }

        // Bark Counter Gauge Card
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, Color(0xFFFF9900))
            ) {
                Column(modifier = Modifier.padding(6.dp)) {
                    Text("MINIFINDER REX BARK SENSOR & COORDS", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9900))
                    Text("DOG: ${selectedDog.name} (${selectedDog.dogBreed})", fontSize = 8.sp, color = Color.White)
                    Text("LAT: ${selectedDog.lat}° | LON: ${selectedDog.lon}°", fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    Text("BARK FREQUENCY: ${selectedDog.barksPerMinute} BPM (${selectedDog.status})", fontSize = 8.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text("DISTANCE: ${selectedDog.distanceToUserMeters}m | HEADING: ${selectedDog.headingDegrees?.toInt()}° NE", fontSize = 8.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Hunter Stands Overview Card
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, Color(0xFF39FF14))
            ) {
                Column(modifier = Modifier.padding(6.dp)) {
                    Text("HUNTING SECTOR PASS ASSIGNMENTS", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14))
                    stands.forEach { st ->
                        Text("${st.standCode}: ${st.hunterName}", fontSize = 7.sp, color = Color.White)
                    }
                }
            }
        }
    }

    // Hunter Brief & Vocal Audio Button
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF140D04),
        border = BorderStroke(1.dp, Color(0xFFFF9900).copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("MiniFinder Hunter Live Position Alert", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9900))
                Text("Dog ${selectedDog.name} is at ${selectedDog.lat}, ${selectedDog.lon}, ${selectedDog.distanceToUserMeters}m away. Bark rate: ${selectedDog.barksPerMinute} BPM.", fontSize = 8.sp, color = Color(0xFFCBD5E1))
            }

            Button(
                onClick = {
                    val speech = "MiniFinder Hunter report: ${selectedDog.name} is located at latitude ${selectedDog.lat}, longitude ${selectedDog.lon}, ${selectedDog.distanceToUserMeters} meters away at bearing ${selectedDog.headingDegrees?.toInt()} degrees. Bark rate ${selectedDog.barksPerMinute} barks per minute. Status: ${selectedDog.status}."
                    onSpeak(speech)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9900)),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(26.dp)
            ) {
                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Vocal Brief", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
