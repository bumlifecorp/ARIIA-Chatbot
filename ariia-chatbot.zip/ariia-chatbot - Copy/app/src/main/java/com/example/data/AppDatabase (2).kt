package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Dao
import androidx.room.Query
import androidx.room.Insert
import androidx.room.Delete
import kotlinx.coroutines.flow.Flow

@androidx.room.Entity(tableName = "custom_actions")
data class CustomAction(
    @androidx.room.PrimaryKey(autoGenerate = true) val id: Int = 0,
    val phrase: String,
    val target: String
)

@Dao
interface CustomActionDao {
    @Query("SELECT * FROM custom_actions")
    fun getAll(): Flow<List<CustomAction>>
    
    @Insert
    suspend fun insert(action: CustomAction)
    
    @Delete
    suspend fun delete(action: CustomAction)
}

@Database(entities = [CustomAction::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customActionDao(): CustomActionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "riaos_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
