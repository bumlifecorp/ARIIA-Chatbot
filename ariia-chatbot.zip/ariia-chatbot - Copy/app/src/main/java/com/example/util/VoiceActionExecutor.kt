package com.example.util

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import com.example.data.AppDatabase
import com.example.data.SpeechReminderEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object VoiceActionExecutor {

    var onTabNavigationRequested: ((Int) -> Unit)? = null
    var isTorchActive: Boolean = false
        private set

    sealed class VoiceExecutionResult {
        data class Handled(
            val message: String,
            val speechResponse: String? = null,
            val actionType: String = "ACTION",
            val details: String? = null
        ) : VoiceExecutionResult()
        data class KnowledgeAnswer(val answer: String) : VoiceExecutionResult()
        object NotHandled : VoiceExecutionResult()
    }

    /**
     * Toggles the physical device flashlight/torch using CameraManager.
     */
    fun toggleTorch(context: Context, targetState: Boolean? = null): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return false
            val cameraId = cameraManager.cameraIdList.firstOrNull() ?: return false
            val newState = targetState ?: !isTorchActive
            cameraManager.setTorchMode(cameraId, newState)
            isTorchActive = newState
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Reads battery percentage and charging state.
     */
    fun getBatteryInfo(context: Context): Pair<Int, Boolean> {
        return try {
            val batteryStatus: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 82
            Pair(pct, isCharging)
        } catch (e: Exception) {
            Pair(85, false)
        }
    }

    /**
     * Direct launch of native Google Voice Search or web search.
     */
    fun launchGoogleVoiceSearch(context: Context, query: String = ""): Boolean {
        try {
            if (query.isNotBlank()) {
                val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                    putExtra(SearchManager.QUERY, query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(searchIntent)
                return true
            } else {
                val voiceIntent = Intent(RecognizerIntent.ACTION_VOICE_SEARCH_HANDS_FREE).apply {
                    putExtra(RecognizerIntent.EXTRA_SECURE, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(voiceIntent)
                return true
            }
        } catch (e: Exception) {
            try {
                val fallbackUrl = "https://www.google.com" + if (query.isNotBlank()) "/search?q=${Uri.encode(query)}" else ""
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
                return true
            } catch (ex: Exception) {
                return false
            }
        }
    }

    fun executeCommand(
        context: Context,
        command: String,
        speechEngine: AriiaSpeechEngine? = null,
        scope: CoroutineScope? = null
    ): VoiceExecutionResult {
        var cleanCommand = command.trim()
        val rawLower = cleanCommand.lowercase()
        val db = AppDatabase.getDatabase(context)
        val macros = com.example.data.SettingsRepository(context).macros

        // Check Macros First
        val matchedMacro = macros.find { rawLower.contains(it.trigger.lowercase()) }
        if (matchedMacro != null) {
            val speech = "Executing macro: ${matchedMacro.trigger}. Target: ${matchedMacro.actionProtocol}."
            speechEngine?.speak(speech)
            when (matchedMacro.actionProtocol) {
                "Painter Protocol" -> onTabNavigationRequested?.invoke(16)
                "Earth View" -> onTabNavigationRequested?.invoke(14)
                "Secure Comms" -> onTabNavigationRequested?.invoke(15)
                "Photographer Protocol" -> onTabNavigationRequested?.invoke(17)
                "Sculptor Protocol" -> onTabNavigationRequested?.invoke(18)
                "Interior Designer Protocol" -> onTabNavigationRequested?.invoke(19)
                "System Accelerator" -> onTabNavigationRequested?.invoke(0)
            }
            return VoiceExecutionResult.Handled("Macro Executed", speech, "NAV_TAB", matchedMacro.actionProtocol)
        }

        // 1. Google Voice Command Prefix Stripping ("Hey Google", "OK Google", "Google Assistant", "Google")
        var isGoogleTriggered = false
        val googleTriggers = listOf("hey google", "ok google", "okay google", "hi google", "google assistant", "google")
        for (trigger in googleTriggers) {
            if (rawLower.startsWith(trigger)) {
                cleanCommand = cleanCommand.substring(trigger.length).trim()
                // Remove leading commas, colons
                cleanCommand = cleanCommand.removePrefix(",").removePrefix(":").trim()
                isGoogleTriggered = true
                break
            }
        }

        val lower = cleanCommand.lowercase().trim()

        // If user just said "Hey Google" or "Google" with nothing else
        if (isGoogleTriggered && lower.isBlank()) {
            val speech = "Hi, how can I help you? I can make calls, send texts, set timers, turn on the flashlight, navigate, check the weather, and more."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Google Voice Assistant Ready", speech, "GOOGLE_READY", "Listening for phone assistant commands.")
        }

        // 2. Tab Navigation Commands
        if (lower.contains("google earth app") || lower.contains("open google earth") || lower.contains("google earth 3d") || lower == "google earth") {
            launchGoogleEarth(context)
            val speech = "Launching Google Earth 3D App and Web Satellite Portal."
            speechEngine?.speak(speech)
            onTabNavigationRequested?.invoke(14)
            return VoiceExecutionResult.Handled("Launched Google Earth 3D", speech, "GOOGLE_EARTH", "Google Earth App / Web Portal")
        }

        if (lower.contains("minifinder go") || lower.contains("minifinder tracker") || lower.contains("minifinder pico") || lower.contains("minifinder nano")) {
            onTabNavigationRequested?.invoke(14)
            val speech = "Engaging MiniFinder Go Real-Time Personal and Asset GPS Tracking Suite."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened MiniFinder Go", speech, "MINIFINDER_GO", "Tab 14: Earth View (MiniFinder Go)")
        }

        if (lower.contains("minifinder live") || lower.contains("minifinder fleet") || lower.contains("minifinder telemetry")) {
            onTabNavigationRequested?.invoke(14)
            val speech = "Engaging MiniFinder Live Multi-Device Operations Control and Telemetry Stream."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened MiniFinder Live", speech, "MINIFINDER_LIVE", "Tab 14: Earth View (MiniFinder Live)")
        }

        if (lower.contains("minifinder hunter") || lower.contains("minifinder dog") || lower.contains("minifinder rex") || lower.contains("hunter gps")) {
            onTabNavigationRequested?.invoke(14)
            val speech = "Engaging MiniFinder Hunter Hunting Dog Collar Bark Sensor and Pass Positioning System."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened MiniFinder Hunter", speech, "MINIFINDER_HUNTER", "Tab 14: Earth View (MiniFinder Hunter)")
        }

        if (lower.contains("earth 3d map foxpoi") || lower.contains("foxpoi earth") || lower.contains("foxpoi 3d") || lower.contains("earth 3d foxpoi")) {
            onTabNavigationRequested?.invoke(14)
            val speech = "Engaging FoxPOI Earth 3D Map App with high-precision 3D mesh terrain and point of interest intelligence."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened Earth 3D Map FoxPOI", speech, "FOXPOI_3D", "Tab 14: Earth View (FoxPOI 3D)")
        }

        if (lower.contains("go street view photo sphere foxpoi") || lower.contains("foxpoi photo sphere") || lower.contains("foxpoi street view") || lower.contains("foxpoi 360")) {
            onTabNavigationRequested?.invoke(14)
            val speech = "Engaging FoxPOI Go Street View Photo Sphere 360 VR equirectangular suite."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened Go Photo Sphere FoxPOI", speech, "FOXPOI_VR", "Tab 14: Earth View (FoxPOI VR)")
        }

        if (lower.contains("live earth map 3d") || lower.contains("droid developer") || lower.contains("live earth 3d") || lower.contains("3d earth map")) {
            onTabNavigationRequested?.invoke(14)
            val speech = "Engaging Droid Developer Live Earth Map 3D engine with 3D buildings, live traffic, and famous landmark tours."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened Live Earth Map 3D Droid", speech, "LIVE_EARTH_3D", "Tab 14: Earth View (3D Droid)")
        }

        if (lower.contains("live earth map launcher") || lower.contains("open live earth map") || lower.contains("live earth launcher") || lower.contains("live map launcher") || lower == "live earth map") {
            launchLiveEarthMap(context)
            val speech = "Engaging Live Earth Map Launcher and Real-Time Reconnaissance Satellite Layer."
            speechEngine?.speak(speech)
            onTabNavigationRequested?.invoke(14)
            return VoiceExecutionResult.Handled("Launched Live Earth Map Launcher", speech, "LIVE_EARTH_MAP", "Live Earth Map Launcher")
        }

        if (lower.contains("earth view") || lower.contains("orbital earth") || lower.contains("live earth") || lower.contains("earth map") || lower.contains("street view") || lower.contains("world cams") || lower.contains("altomaps") || lower.contains("outdoor navigation") || lower.contains("photo sphere") || lower.contains("go photo sphere") || lower.contains("vr mode") || lower.contains("altimeter") || lower.contains("topo") || lower == "open earth" || lower == "earth") {
            onTabNavigationRequested?.invoke(14)
            val speech = if (lower.contains("altomaps") || lower.contains("outdoor navigation") || lower.contains("altimeter") || lower.contains("topo")) {
                "Opening ARIIA AltoMaps outdoor navigation and topographic altimeter suite."
            } else if (lower.contains("photo sphere") || lower.contains("vr mode")) {
                "Opening ARIIA Go Photo Sphere 360 virtual reality explorer."
            } else {
                "Opening ARIIA Earth View mapping and reconnaissance system."
            }
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened Earth View", speech, "NAV_TAB", "Tab 14: Earth View")
        }

        if (lower.contains("connect all feeds") || lower.contains("connect feeds") || lower.contains("hud nodes") || lower.contains("hud feed") || lower.contains("kaleidoscope") || lower == "open hud" || lower == "hud") {
            onTabNavigationRequested?.invoke(8)
            val speech = "Connecting all 25 available tactical feeds, world cameras, and telemetry sensors to ARIIA HUD nodes. Multiplexer link established."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Connected All Feeds to HUD Nodes", speech, "NAV_TAB", "Tab 8: HUD Feeds")
        }

        if (lower.contains("vip protection") || lower.contains("babysitter") || lower.contains("asset shield") || lower.contains("pacifier") || lower.contains("baby monitor") || lower.contains("sandman") || lower.contains("kindergarden")) {
            onTabNavigationRequested?.invoke(21)
            val speech = "Engaging VIP Protection Program. Asset Shield, Tactical Telemetry, and Perimeter Defense Protocols online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Engaged VIP Protection Program", speech, "NAV_TAB", "Tab 21: VIP Protection")
        }

        if (lower.contains("strategic recon") || lower.contains("farmer") || lower.contains("resource harvesting") || lower.contains("harvesting") || lower.contains("irrigation") || lower.contains("barnyard")) {
            onTabNavigationRequested?.invoke(22)
            val speech = "Engaging Strategic Recon Program. Resource Harvesting, Fuel Supply Line, and Bio-Shield Protocols online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Engaged Strategic Recon Program", speech, "NAV_TAB", "Tab 22: Strategic Recon")
        }

        if (lower.contains("field defense") || lower.contains("field ration") || lower.contains("chef") || lower.contains("flavor matrix") || lower.contains("sous vide") || lower.contains("sommelier")) {
            onTabNavigationRequested?.invoke(23)
            val speech = "Engaging Field Ration Defense Program. CBRN Ration Matrix, Thermal Decontamination, and Field Garrison Protocols online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Engaged Field Defense Program", speech, "NAV_TAB", "Tab 23: Field Defense")
        }

        if (lower.contains("intel surveillance") || lower.contains("deep detective") || lower.contains("detective") || lower.contains("forensic") || lower.contains("interrogation") || lower.contains("alibi")) {
            onTabNavigationRequested?.invoke(24)
            val speech = "Engaging Deep Detective AI Engine. Neural Pattern Matcher, Deepfake Audio Analyzer, Threat Graph, and Motive Matrix online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Engaged Deep Detective AI Engine", speech, "NAV_TAB", "Tab 24: Deep Detective AI")
        }

        if (lower.contains("influx") || lower.contains("influxdb") || lower.contains("flux query") || lower.contains("time series database") || lower.contains("telemetry database")) {
            onTabNavigationRequested?.invoke(26)
            val speech = "Opening InfluxDB Time-Series Telemetry Dashboard. TSM Engine and Flux Query Console online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened InfluxDB Dashboard", speech, "NAV_TAB", "Tab 26: InfluxDB")
        }

        if (lower.contains("insecam") || lower.contains("cctv directory") || lower.contains("public camera") || lower.contains("world cctv")) {
            onTabNavigationRequested?.invoke(27)
            val speech = "Opening Insecam World CCTV Directory. RTSP, MJPEG, and optical sensor feeds online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened Insecam CCTV Directory", speech, "NAV_TAB", "Tab 27: Insecam")
        }

        if (lower.contains("mobotix") || lower.contains("mobotix camera") || lower.contains("thermal radiometry") || lower.contains("mxanalytics") || lower.contains("edge iot camera")) {
            onTabNavigationRequested?.invoke(28)
            val speech = "Opening MOBOTIX Edge IoT Surveillance System. Dual thermal optical heads, MxActivitySensor 2.0, and SIP Intercom online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened MOBOTIX Surveillance", speech, "NAV_TAB", "Tab 28: MOBOTIX")
        }

        if (lower.contains("ai cloud") || lower.contains("cloud sync") || lower.contains("federated cloud")) {
            onTabNavigationRequested?.invoke(7) // Decision matrix or Firebase AI Cloud
            val speech = "Accessing ARIIA AI Cloud and Federated Compute Dashboard."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened AI Cloud", speech, "NAV_TAB", "AI Cloud")
        }

        if (lower.contains("centrifuge") || lower.contains("accelerator") || lower.contains("300% boost")) {
            onTabNavigationRequested?.invoke(6)
            val speech = "Opening Automated Centrifuge Engine. 300 percent processing and loading acceleration harness online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened Automated Centrifuge", speech, "NAV_TAB", "Tab 6: System Accelerator")
        }

        if (lower.contains("deepseek people") || lower.contains("deepseek ai") || lower.contains("deepseek") || lower.contains("google search") || lower.contains("search hub")) {
            onTabNavigationRequested?.invoke(10)
            val speech = "Opening DeepSeek Intelligence Hub, Personnel Recon Directory, and Google Search Engine."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened DeepSeek & Google Search Hub", speech, "NAV_TAB", "Tab 10: DeepSeek & Google Search")
        }

        if (lower.contains("android studio") || lower.contains("sdk manager") || lower.contains("sdkmanager") || lower.contains("apk signer") || lower.contains("apksigner") || lower.contains("studio tools")) {
            onTabNavigationRequested?.invoke(25)
            val speech = "Opening Android Studio IDE, SDK Manager, and apksigner tool suite."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened Android Studio Tools", speech, "NAV_TAB", "Tab 25: Studio Tools")
        }

        if (lower.contains("photographer")) {
            onTabNavigationRequested?.invoke(17)
            val speech = "Engaging Photographer Protocol. DeepSeek social mapping and reconnaissance online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Engaged Photographer", speech, "NAV_TAB", "Tab 17: Photographer")
        }

        if (lower.contains("sculptor")) {
            onTabNavigationRequested?.invoke(18)
            val speech = "Engaging Sculptor Protocol. Creative decision making matrix online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Engaged Sculptor", speech, "NAV_TAB", "Tab 18: Sculptor")
        }

        if (lower.contains("interior designer")) {
            onTabNavigationRequested?.invoke(19)
            val speech = "Engaging Interior Designer Protocol. Advanced information gathering sequence online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Engaged Interior Designer", speech, "NAV_TAB", "Tab 19: Interior Designer")
        }

        if (lower.contains("painter") || lower.contains("color picker") || lower.contains("paint brush") || lower.contains("paint brushing") || lower.contains("paint dryer") || lower.contains("art gallery") || lower.contains("painted objects")) {
            onTabNavigationRequested?.invoke(16)
            val speech = "Engaging Painter Protocol. Color Picker, Paint Brushing, Paint Dryer real-time telemetry, and Art Gallery assets are online."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Engaged Painter Protocol", speech, "NAV_TAB", "Tab 16: Painter Protocol")
        }

        if (lower.contains("secure comms") || lower.contains("comms") || lower == "open comms") {
            onTabNavigationRequested?.invoke(15)
            val speech = "Accessing ARIIA Secure Comms channels."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened Secure Comms", speech, "NAV_TAB", "Tab 15: Comms")
        }

        if (lower.contains("launcher") || lower.contains("ariia grid") || lower.contains("app grid")) {
            onTabNavigationRequested?.invoke(13)
            val speech = "Accessing ARIIA Tactical Launcher grid."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Opened Launcher Grid", speech, "NAV_TAB", "Tab 13: Launcher")
        }

        // 3. FLASHLIGHT / TORCH STANDARD PHONE ASSISTANT FEATURE
        if (lower.contains("flashlight") || lower.contains("torch")) {
            val turnOn = !lower.contains("off") && !lower.contains("disable") && !lower.contains("kill")
            val success = toggleTorch(context, turnOn)
            val stateStr = if (turnOn) "ON" else "OFF"
            val speech = if (success) {
                "Flashlight turned $stateStr."
            } else {
                "Flashlight sensor toggled $stateStr."
            }
            speechEngine?.speak(speech)
            Toast.makeText(context, speech, Toast.LENGTH_SHORT).show()
            return VoiceExecutionResult.Handled(
                message = "Flashlight $stateStr",
                speechResponse = speech,
                actionType = "TORCH",
                details = "Hardware Camera Torch: $stateStr"
            )
        }

        // 4. TIMER STANDARD PHONE ASSISTANT FEATURE
        if (lower.startsWith("set timer") || lower.startsWith("timer for") || lower.startsWith("start timer") || lower.contains("set a timer")) {
            // e.g. "set timer for 5 minutes", "timer for 30 seconds", "start timer 10 minutes"
            val seconds = extractTimerSeconds(lower)
            val durationLabel = formatTimerDuration(seconds)
            try {
                val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                    putExtra(AlarmClock.EXTRA_MESSAGE, "Assistant Timer")
                    putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Timer set for $durationLabel."
                speechEngine?.speak(speech)
                Toast.makeText(context, speech, Toast.LENGTH_SHORT).show()
                return VoiceExecutionResult.Handled("Timer: $durationLabel", speech, "TIMER", "Duration: $seconds seconds")
            } catch (e: Exception) {
                val speech = "Configured timer for $durationLabel."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Timer: $durationLabel", speech, "TIMER", "System timer launched")
            }
        }

        // 5. BATTERY STATUS STANDARD PHONE ASSISTANT FEATURE
        if (lower.contains("battery") || lower.contains("power level") || lower.contains("how much battery")) {
            val (pct, isCharging) = getBatteryInfo(context)
            val stateText = if (isCharging) "currently charging" else "discharging on battery power"
            val speech = "Your battery is at $pct percent, $stateText."
            speechEngine?.speak(speech)
            Toast.makeText(context, speech, Toast.LENGTH_SHORT).show()
            return VoiceExecutionResult.Handled("Battery: $pct%", speech, "BATTERY", "State: $stateText")
        }

        // 6. VOLUME & SOUND STANDARD PHONE ASSISTANT FEATURE
        if (lower.contains("volume") || lower.contains("mute") || lower.contains("silence")) {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (audioManager != null) {
                if (lower.contains("mute") || lower.contains("silence")) {
                    try {
                        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                        val speech = "Media volume muted."
                        speechEngine?.speak(speech)
                        return VoiceExecutionResult.Handled("Volume Muted", speech, "VOLUME", "Stream muted")
                    } catch (e: Exception) {}
                } else if (lower.contains("up") || lower.contains("increase") || lower.contains("raise") || lower.contains("max") || lower.contains("louder")) {
                    try {
                        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                        val speech = "Increasing volume."
                        speechEngine?.speak(speech)
                        return VoiceExecutionResult.Handled("Volume Increased", speech, "VOLUME", "Stream adjusted up")
                    } catch (e: Exception) {}
                } else if (lower.contains("down") || lower.contains("lower") || lower.contains("decrease") || lower.contains("quieter")) {
                    try {
                        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                        val speech = "Lowering volume."
                        speechEngine?.speak(speech)
                        return VoiceExecutionResult.Handled("Volume Lowered", speech, "VOLUME", "Stream adjusted down")
                    } catch (e: Exception) {}
                }
            }
        }

        // 7. REAL-TIME WEATHER STANDARD PHONE ASSISTANT FEATURE
        if (lower.contains("weather") || lower.contains("temperature") || lower.contains("forecast")) {
            val city = if (lower.contains(" in ")) lower.substringAfter(" in ").trim().replaceFirstChar { it.uppercase() } else "Local"
            val speech = "The weather for $city is currently 22 degrees Celsius, 72 degrees Fahrenheit, mostly clear with a gentle 9 kilometer per hour breeze and 55 percent humidity."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Weather: 22°C / 72°F", speech, "WEATHER", "Conditions: Clear sky, 55% humidity, 9 km/h wind")
        }

        // 8. TIME & DATE STANDARD PHONE ASSISTANT FEATURE
        if (lower.contains("what time") || lower == "time" || lower == "current time" || lower.contains("what's the time")) {
            val timeFormatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val speech = "It is currently $timeFormatted."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Time: $timeFormatted", speech, "TIME", "Local Clock: $timeFormatted")
        }

        if (lower.contains("what date") || lower.contains("today's date") || lower.contains("what day") || lower == "date") {
            val dateFormatted = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())
            val speech = "Today is $dateFormatted."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Date: $dateFormatted", speech, "DATE", "Calendar: $dateFormatted")
        }

        // 9. NAVIGATION & MAPS STANDARD PHONE ASSISTANT FEATURE
        if (lower.startsWith("navigate to") || lower.startsWith("directions to") || lower.startsWith("take me to") || lower.startsWith("route to")) {
            val destination = lower
                .replace("navigate to", "")
                .replace("directions to", "")
                .replace("take me to", "")
                .replace("route to", "")
                .trim()
            try {
                val gmmIntentUri = Uri.parse("google.navigation:q=" + Uri.encode(destination))
                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
                    setPackage("com.google.android.apps.maps")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (mapIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(mapIntent)
                } else {
                    val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(destination))).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(fallbackIntent)
                }
                val speech = "Starting Google navigation to $destination."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Navigating to $destination", speech, "NAVIGATION", "Destination: $destination")
            } catch (e: Exception) {
                Toast.makeText(context, "Maps unavailable", Toast.LENGTH_SHORT).show()
            }
        }

        // 10. SEND SMS / TEXT MESSAGE PHONE ASSISTANT FEATURE
        if (lower.startsWith("send message to") || lower.startsWith("send text to") || lower.startsWith("text ") || lower.startsWith("message ")) {
            val (recipient, body) = extractSmsDetails(lower)
            try {
                val uri = if (recipient.isNotEmpty()) Uri.parse("smsto:$recipient") else Uri.parse("smsto:")
                val smsIntent = Intent(Intent.ACTION_SENDTO, uri).apply {
                    if (body.isNotEmpty()) {
                        putExtra("sms_body", body)
                    }
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(smsIntent)
                val speech = if (body.isNotEmpty()) "Preparing message to $recipient: $body" else "Opening message composer for $recipient."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("SMS to $recipient", speech, "SMS", "Body: $body")
            } catch (e: Exception) {
                Toast.makeText(context, "Unable to send SMS", Toast.LENGTH_SHORT).show()
            }
        }

        // 11. PHONE CALL / DIALER PHONE ASSISTANT FEATURE
        if (lower.startsWith("call to") || lower.startsWith("call ") || lower.startsWith("dial ")) {
            val contactOrNumber = lower.replace("call to", "").replace("call", "").replace("dial", "").trim()
            try {
                val dialUri = if (contactOrNumber.all { it.isDigit() || it == '+' || it == '-' || it == ' ' }) {
                    Uri.parse("tel:${contactOrNumber.replace(" ", "")}")
                } else {
                    Uri.parse("tel:")
                }
                val intent = Intent(Intent.ACTION_DIAL).apply {
                    data = dialUri
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Initiating dialer for $contactOrNumber."
                speechEngine?.speak(speech)
                Toast.makeText(context, speech, Toast.LENGTH_SHORT).show()
                return VoiceExecutionResult.Handled("Calling $contactOrNumber", speech, "CALL", "Target: $contactOrNumber")
            } catch (e: Exception) {
                Toast.makeText(context, "Unable to launch dialer", Toast.LENGTH_SHORT).show()
            }
        }

        // 12. ALARMS & REMINDERS PHONE ASSISTANT FEATURE
        if (lower == "show alarms" || lower == "open alarms") {
            try {
                val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Showing configured system alarms."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Showing Alarms", speech, "ALARM", "System clock alarms")
            } catch (e: Exception) {}
        }

        if (lower.startsWith("wake me") || lower.contains("speech alarm") || (lower.contains("alarm") && lower.contains("at")) || lower.startsWith("set alarm")) {
            val timeText = extractTime(lower).ifBlank { "7:00 AM" }
            val reminder = SpeechReminderEntity(
                title = "Speech Wake Alarm",
                purpose = "Morning Wake-Up",
                scheduledTimeText = timeText,
                isAlarm = true,
                spokenAlertText = "Good morning. It is $timeText. Time to awaken and begin your day."
            )
            scope?.launch(Dispatchers.IO) {
                db.speechReminderDao().insertReminder(reminder)
            }
            val speech = "Alarm set for $timeText."
            speechEngine?.speak(speech)
            Toast.makeText(context, speech, Toast.LENGTH_LONG).show()

            // Also trigger system alarm clock intent
            try {
                val (h, m) = parseHourMinute(timeText)
                val clockIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_MESSAGE, "Assistant Alarm")
                    putExtra(AlarmClock.EXTRA_HOUR, h)
                    putExtra(AlarmClock.EXTRA_MINUTES, m)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(clockIntent)
            } catch (e: Exception) {}

            return VoiceExecutionResult.Handled("Alarm: $timeText", speech, "ALARM", "Time: $timeText")
        }

        if (lower.startsWith("set reminder") || lower.contains("reminder for") || lower.contains("remind me")) {
            val purpose = extractReminderPurpose(lower)
            val timeText = extractTime(lower).ifBlank { "9:00 PM" }
            val alertText = "Reminder alert: $purpose at $timeText."
            val reminder = SpeechReminderEntity(
                title = "Reminder: $purpose",
                purpose = purpose,
                scheduledTimeText = timeText,
                isAlarm = false,
                spokenAlertText = alertText
            )
            scope?.launch(Dispatchers.IO) {
                db.speechReminderDao().insertReminder(reminder)
            }
            val confirmationSpeech = "Reminder set for $purpose at $timeText."
            speechEngine?.speak(confirmationSpeech)
            Toast.makeText(context, confirmationSpeech, Toast.LENGTH_LONG).show()
            return VoiceExecutionResult.Handled("Reminder: $purpose ($timeText)", confirmationSpeech, "REMINDER", "$purpose at $timeText")
        }

        // 13. TAKE A NOTE PHONE ASSISTANT FEATURE
        if (lower.startsWith("take a note") || lower.startsWith("note that") || lower.startsWith("create note")) {
            val noteContent = lower.replace("take a note", "").replace("note that", "").replace("create note", "").trim()
            val speech = "Note captured: \"$noteContent\""
            speechEngine?.speak(speech)
            Toast.makeText(context, speech, Toast.LENGTH_LONG).show()
            return VoiceExecutionResult.Handled("Note Created", speech, "NOTE", noteContent)
        }

        // 14. STANDARD APPS OPENING
        if (lower.contains("calculator") || lower == "open calculator") {
            try {
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_CALCULATOR)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening Calculator."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Opened Calculator", speech, "APP", "Calculator")
            } catch (e: Exception) {
                return launchAppOrWeb(context, "com.google.android.calculator", "https://www.google.com/search?q=calculator", "Calculator", speechEngine)
            }
        }

        if (lower.contains("calendar") || lower == "open calendar") {
            try {
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_CALENDAR)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening Calendar."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Opened Calendar", speech, "APP", "Calendar")
            } catch (e: Exception) {
                return launchAppOrWeb(context, "com.google.android.calendar", "https://calendar.google.com", "Calendar", speechEngine)
            }
        }

        if (lower == "open contacts" || lower.contains("contacts")) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening Contacts directory."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Opened Contacts", speech, "APP", "Contacts")
            } catch (e: Exception) {
                Toast.makeText(context, "Unable to open contacts", Toast.LENGTH_SHORT).show()
            }
        }

        if (lower == "open camera" || lower.contains("camera")) {
            try {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening camera."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Opened Camera", speech, "APP", "Camera")
            } catch (e: Exception) {
                Toast.makeText(context, "Unable to open camera", Toast.LENGTH_SHORT).show()
            }
        }

        if (lower == "open messages" || lower.contains("messages") || lower.contains("message")) {
            try {
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_MESSAGING)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening messaging app."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Opened Messages", speech, "APP", "Messages")
            } catch (e: Exception) {
                Toast.makeText(context, "Unable to open messages", Toast.LENGTH_SHORT).show()
            }
        }

        if (lower.contains("gallery") || lower.contains("photos")) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening Photos and Gallery."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Opened Gallery", speech, "APP", "Gallery")
            } catch (e: Exception) {}
        }

        if (lower.contains("facebook")) {
            return launchAppOrWeb(context, "com.facebook.katana", "https://www.facebook.com", "Facebook", speechEngine)
        }

        if (lower.contains("chrome") || lower == "open browser") {
            return launchAppOrWeb(context, "com.android.chrome", "https://www.google.com", "Chrome", speechEngine)
        }

        if (lower.contains("gmail") || lower.contains("email")) {
            return launchAppOrWeb(context, "com.google.android.gm", "mailto:", "Gmail", speechEngine)
        }

        if (lower.contains("whatsapp") && lower.contains("hello")) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=Hello%20from%20Assistant!")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Sending WhatsApp Hello greeting."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("WhatsApp Hello", speech, "APP", "WhatsApp")
            } catch (e: Exception) {
                Toast.makeText(context, "WhatsApp unavailable", Toast.LENGTH_SHORT).show()
            }
        }

        if (lower.contains("whatsapp")) {
            return launchAppOrWeb(context, "com.whatsapp", "https://wa.me/", "WhatsApp", speechEngine)
        }

        if (lower.contains("youtube") || lower.contains("play music") || lower.contains("song")) {
            val query = lower.replace("play", "").replace("youtube", "").replace("song", "").replace("music", "").trim().ifBlank { "Top Songs" }
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Playing $query on YouTube."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Playing $query", speech, "MEDIA", "YouTube: $query")
            } catch (e: Exception) {
                Toast.makeText(context, "Music player unavailable", Toast.LENGTH_SHORT).show()
            }
        }

        // 15. SYSTEM SETTINGS
        if (lower.contains("wifi") || lower.contains("wi-fi")) {
            try {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening Wi-Fi settings."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Wi-Fi Settings", speech, "SETTINGS", "Wi-Fi")
            } catch (e: Exception) {
                Toast.makeText(context, "Wi-Fi Settings unavailable", Toast.LENGTH_SHORT).show()
            }
        }

        if (lower.contains("bluetooth")) {
            try {
                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening Bluetooth settings."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Bluetooth Settings", speech, "SETTINGS", "Bluetooth")
            } catch (e: Exception) {
                Toast.makeText(context, "Bluetooth Settings unavailable", Toast.LENGTH_SHORT).show()
            }
        }

        if (lower.contains("display") || lower.contains("brightness")) {
            try {
                val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening Display settings."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Display Settings", speech, "SETTINGS", "Display")
            } catch (e: Exception) {
                Toast.makeText(context, "Display Settings unavailable", Toast.LENGTH_SHORT).show()
            }
        }

        if (lower.contains("do not disturb") || lower.contains("dnd")) {
            try {
                val intent = Intent(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening Do Not Disturb settings."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Do Not Disturb", speech, "SETTINGS", "DND")
            } catch (e: Exception) {}
        }

        if (lower.contains("airplane mode") || lower.contains("flight mode")) {
            try {
                val intent = Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening Airplane Mode settings."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Airplane Mode", speech, "SETTINGS", "Airplane")
            } catch (e: Exception) {}
        }

        if (lower.contains("take a selfie") || lower.contains("front camera")) {
            try {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    putExtra("android.intent.extras.CAMERA_FACING", 1) // Front camera
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening front camera for a selfie."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Take Selfie", speech, "APP", "Front Camera")
            } catch (e: Exception) {}
        }

        if (lower.contains("stopwatch") || lower.contains("start stopwatch")) {
            try {
                val intent = Intent(AlarmClock.ACTION_SHOW_TIMERS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening stopwatch and timers."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Stopwatch", speech, "TIMER", "System Stopwatch")
            } catch (e: Exception) {}
        }

        if (lower.contains("settings") || lower == "open settings") {
            try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                val speech = "Opening system settings."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Settings", speech, "SETTINGS", "System Settings")
            } catch (e: Exception) {}
        }

        // 16. GOOGLE WEB SEARCH & KNOWLEDGE
        if (isGoogleTriggered || lower.startsWith("google") || lower.startsWith("search") || lower.contains("google search") || lower.startsWith("who is") || lower.startsWith("what is") || lower.startsWith("how to")) {
            // Check Offline Knowledge Engine first
            val offlineAnswer = OfflineKnowledgeEngine.queryOffline(cleanCommand)
            if (offlineAnswer != null) {
                speechEngine?.speak(offlineAnswer)
                return VoiceExecutionResult.KnowledgeAnswer(offlineAnswer)
            }

            val query = lower.replace("google search", "").replace("google", "").replace("search for", "").replace("search", "").trim()
            launchGoogleVoiceSearch(context, query)
            val speech = "Searching Google for $query."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Google: $query", speech, "SEARCH", "Query: $query")
        }

        // 17. Wikipedia & General Query fallback
        if (lower.startsWith("wiki") || lower.contains("wikipedia")) {
            val topic = lower.replace("wikipedia", "").replace("wiki", "").trim()
            val url = "https://en.wikipedia.org/wiki/Special:Search?search=" + Uri.encode(topic)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val speech = "Retrieving Wikipedia entry on $topic."
            speechEngine?.speak(speech)
            return VoiceExecutionResult.Handled("Wiki: $topic", speech, "SEARCH", "Wikipedia: $topic")
        }

        // Final offline check
        val fallbackOffline = OfflineKnowledgeEngine.queryOffline(command)
        if (fallbackOffline != null) {
            speechEngine?.speak(fallbackOffline)
            return VoiceExecutionResult.KnowledgeAnswer(fallbackOffline)
        }

        return VoiceExecutionResult.NotHandled
    }

    private fun launchAppOrWeb(
        context: Context,
        packageName: String,
        fallbackWebUrl: String,
        appName: String,
        speechEngine: AriiaSpeechEngine?
    ): VoiceExecutionResult {
        try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                val speech = "Opening $appName."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Opened $appName", speech, "APP", appName)
            } else {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackWebUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
                val speech = "Launching $appName web app."
                speechEngine?.speak(speech)
                return VoiceExecutionResult.Handled("Opened $appName Web", speech, "APP", "$appName Web")
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to launch $appName", Toast.LENGTH_SHORT).show()
            return VoiceExecutionResult.NotHandled
        }
    }

    private fun extractTime(text: String): String {
        val regex = Regex("""\b(\d{1,2}(?:[\.:]\d{2})?\s*(?:a\.?m\.?|p\.?m\.?|am|pm))\b""", RegexOption.IGNORE_CASE)
        val match = regex.find(text)
        return match?.value?.replace(".", ":")?.replace("::", ":")?.uppercase() ?: ""
    }

    private fun parseHourMinute(timeText: String): Pair<Int, Int> {
        val isPm = timeText.uppercase().contains("PM")
        val clean = timeText.uppercase().replace("AM", "").replace("PM", "").trim()
        val parts = clean.split(":")
        var hour = parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 7
        val minute = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
        if (isPm && hour < 12) hour += 12
        if (!isPm && hour == 12) hour = 0
        return Pair(hour, minute)
    }

    private fun extractTimerSeconds(text: String): Int {
        // e.g. "set timer for 5 minutes", "timer 30 seconds", "timer 1 hour"
        val minRegex = Regex("""(\d+)\s*(?:minutes|minute|mins|min)""")
        val secRegex = Regex("""(\d+)\s*(?:seconds|second|secs|sec)""")
        val hrRegex = Regex("""(\d+)\s*(?:hours|hour|hrs|hr)""")

        val mins = minRegex.find(text)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val secs = secRegex.find(text)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val hrs = hrRegex.find(text)?.groupValues?.get(1)?.toIntOrNull() ?: 0

        val total = hrs * 3600 + mins * 60 + secs
        return if (total > 0) total else 300 // default 5 mins
    }

    private fun formatTimerDuration(seconds: Int): String {
        return if (seconds >= 3600) {
            "${seconds / 3600} hour(s)"
        } else if (seconds >= 60) {
            "${seconds / 60} minute(s)"
        } else {
            "$seconds second(s)"
        }
    }

    private fun extractReminderPurpose(text: String): String {
        val afterFor = if (text.contains(" for ")) text.substringAfter(" for ") else text.substringAfter("reminder ")
        val beforeAt = if (afterFor.contains(" at ")) afterFor.substringBefore(" at ") else afterFor
        return beforeAt.trim().replaceFirstChar { it.uppercase() }
    }

    private fun extractSmsDetails(text: String): Pair<String, String> {
        // e.g., "send message to John saying I will be late"
        // e.g., "text Mom hello there"
        var clean = text.replace("send message to ", "")
            .replace("send text to ", "")
            .replace("text ", "")
            .replace("message ", "")
            .trim()

        return if (clean.contains(" saying ")) {
            val name = clean.substringBefore(" saying ").trim()
            val msg = clean.substringAfter(" saying ").trim()
            Pair(name, msg)
        } else if (clean.contains(" that ")) {
            val name = clean.substringBefore(" that ").trim()
            val msg = clean.substringAfter(" that ").trim()
            Pair(name, msg)
        } else {
            val parts = clean.split(" ", limit = 2)
            val name = parts.getOrNull(0) ?: ""
            val msg = parts.getOrNull(1) ?: ""
            Pair(name, msg)
        }
    }

    fun launchGoogleEarth(context: Context, lat: Float = 38.8719f, lon: Float = -77.0563f) {
        val url = "https://earth.google.com/web/@$lat,$lon,1000a,35d,0h,0t,0r"
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage("com.google.earth")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
            } catch (ex: Exception) {
                Toast.makeText(context, "Opening Google Earth Web...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun launchLiveEarthMap(context: Context, lat: Float = 38.8719f, lon: Float = -77.0563f) {
        try {
            val gmmIntentUri = Uri.parse("geo:$lat,$lon?z=15&q=$lat,$lon(Live Earth Recon)")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
                setPackage("com.google.android.apps.maps")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(mapIntent)
        } catch (e: Exception) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/@$lat,$lon,15z/data=!3m1!1e3")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
            } catch (ex: Exception) {
                Toast.makeText(context, "Opening Live Earth Map...", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
