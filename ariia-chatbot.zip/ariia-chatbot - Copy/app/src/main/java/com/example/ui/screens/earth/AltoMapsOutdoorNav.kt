package com.example.ui.screens.earth
import com.example.ui.screens.earth.CoordinateSystem
import com.example.ui.screens.earth.AltoWaypoint
import com.example.ui.screens.earth.WaypointCategory
import com.example.ui.screens.earth.AltoTrailTrack
import com.example.ui.screens.earth.AltoElevationPoint
import kotlinx.coroutines.launch

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.*

import com.example.ui.MainViewModel

@Composable
fun AltoMapsOutdoorNav(
    viewModel: MainViewModel,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    // Curated iconic outdoor trails incorporating Foxpoi Altomaps features
    val cachedLocations by viewModel.earthRepository.allLocations.collectAsState(initial = emptyList())

    val curatedTrails = remember(cachedLocations) {
        val cachedWaypoints = cachedLocations.filter { it.type == "TRAIL" || it.type == "POI" }.map {
            AltoWaypoint(
                id = it.id,
                name = it.name,
                category = WaypointCategory.CACHE,
                lat = it.latitude.toFloat(),
                lon = it.longitude.toFloat(),
                elevationMeters = 0,
                notes = "Offline Cached Location"
            )
        }
        val baseTrails = listOf(
            AltoTrailTrack(
                id = "trail-mont-blanc",
                name = "Mont Blanc Alpine Ridge Traverse",
                region = "Chamonix Haute-Savoie, France / Italy",
                difficulty = "Alpine Technical",
                totalDistanceKm = 18.4f,
                elevationGainMeters = 1680,
                elevationLossMeters = 1520,
                maxElevMeters = 4807,
                minElevMeters = 1035,
                estimatedHours = 8.5f,
                description = "High-altitude glacial col traverse with steep couloirs, seracs, and ridge moraine navigation.",
                profilePoints = listOf(
                    AltoElevationPoint(0.0f, 1035f),
                    AltoElevationPoint(2.1f, 1420f),
                    AltoElevationPoint(4.5f, 2100f),
                    AltoElevationPoint(7.0f, 3050f),
                    AltoElevationPoint(10.2f, 3817f),
                    AltoElevationPoint(13.8f, 4807f),
                    AltoElevationPoint(16.1f, 3835f),
                    AltoElevationPoint(18.4f, 3167f)
                ),
                waypoints = listOf(
                    AltoWaypoint("w1", "Les Houches Trailhead", WaypointCategory.TRAILHEAD, 45.8901f, 6.7981f, 1035, "Official start, gear check & altimeter calibration"),
                    AltoWaypoint("w2", "Glacier de Bionnassay Spring", WaypointCategory.WATER_SOURCE, 45.8612f, 6.8120f, 2140, "Perennial meltwater spring, sterilize before drink"),
                    AltoWaypoint("w3", "Refuge du Goûter", WaypointCategory.SHELTER, 45.8510f, 6.8300f, 3835, "Alpine hut perched on cliffside, emergency radio"),
                    AltoWaypoint("w4", "Mont Blanc Summit", WaypointCategory.SUMMIT, 45.8326f, 6.8652f, 4807, "Highest alpine summit in Western Europe. Altimeter lock 4807m"),
                    AltoWaypoint("w5", "Grand Couloir Rockfall Hazard", WaypointCategory.HAZARD, 45.8550f, 6.8220f, 3340, "Active rockfall chute, cross before 10:00 AM sun hits")
                ) + cachedWaypoints
            ),
            AltoTrailTrack(
                id = "trail-grand-canyon",
                name = "Grand Canyon Rim-to-River-to-Rim",
                region = "Coconino County, Arizona, USA",
                difficulty = "Strenuous Desert",
                totalDistanceKm = 27.2f,
                elevationGainMeters = 1450,
                elevationLossMeters = 1450,
                maxElevMeters = 2195,
                minElevMeters = 730,
                estimatedHours = 10.0f,
                description = "Deep canyon descent through geological strata down to the Colorado River and inner gorge.",
                profilePoints = listOf(
                    AltoElevationPoint(0.0f, 2195f),
                    AltoElevationPoint(3.0f, 1820f),
                    AltoElevationPoint(6.5f, 1370f),
                    AltoElevationPoint(11.0f, 750f),
                    AltoElevationPoint(14.0f, 730f),
                    AltoElevationPoint(19.0f, 1150f),
                    AltoElevationPoint(23.5f, 1720f),
                    AltoElevationPoint(27.2f, 2195f)
                ),
                waypoints = listOf(
                    AltoWaypoint("w6", "South Kaibab Trailhead", WaypointCategory.TRAILHEAD, 36.0532f, -112.0837f, 2195, "Shuttle drop, no water at trailhead"),
                    AltoWaypoint("w7", "Skeleton Point", WaypointCategory.CACHE, 36.0712f, -112.0811f, 1580, "Emergency cache point, 360 canyon vista"),
                    AltoWaypoint("w8", "Phantom Ranch Spring", WaypointCategory.WATER_SOURCE, 36.1051f, -112.0945f, 750, "Potable spring water spigot and ranger station"),
                    AltoWaypoint("w9", "Bright Angel Camp", WaypointCategory.CAMPSITE, 36.0990f, -112.0970f, 760, "Permitted backcountry camp alongside stream")
                ) + cachedWaypoints
            ),
            AltoTrailTrack(
                id = "trail-rainier",
                name = "Mount Rainier Disappointment Cleaver",
                region = "Pierce County, Washington, USA",
                difficulty = "Alpine Technical",
                totalDistanceKm = 14.8f,
                elevationGainMeters = 2740,
                elevationLossMeters = 2740,
                maxElevMeters = 4392,
                minElevMeters = 1650,
                estimatedHours = 12.0f,
                description = "Glaciated stratovolcano summit route traversing Ingraham Glacier and crevassed snow slopes.",
                profilePoints = listOf(
                    AltoElevationPoint(0.0f, 1650f),
                    AltoElevationPoint(3.2f, 2300f),
                    AltoElevationPoint(6.8f, 3070f),
                    AltoElevationPoint(9.4f, 3450f),
                    AltoElevationPoint(12.1f, 4020f),
                    AltoElevationPoint(14.8f, 4392f)
                ),
                waypoints = listOf(
                    AltoWaypoint("w10", "Paradise Guide Service", WaypointCategory.TRAILHEAD, 46.7865f, -121.7350f, 1650, "Ranger sign-in and avalanche beacon check"),
                    AltoWaypoint("w11", "Camp Muir High Camp", WaypointCategory.SHELTER, 46.8350f, -121.7310f, 3070, "Stone shelter, high camp for summit push"),
                    AltoWaypoint("w12", "Columbia Crest Crater", WaypointCategory.SUMMIT, 46.8529f, -121.7604f, 4392, "Volcanic summit rim, steam fumaroles and crater ice cave")
                ) + cachedWaypoints
            )
        )
        baseTrails
    }

    var selectedTrail by remember { mutableStateOf(curatedTrails[0]) }
    var selectedCoordFormat by remember { mutableStateOf(CoordinateSystem.MGRS) }
    var contourInterval by remember { mutableStateOf(25) } // 10m, 25m, 50m, 100m
    var isRecordingTrack by remember { mutableStateOf(false) }
    var recordedTimeSeconds by remember { mutableStateOf(3742) } // Simulated recorded time
    var recordedDistanceKm by remember { mutableStateOf(6.84f) }
    var isBacktracking by remember { mutableStateOf(false) }
    var isSosStrobeActive by remember { mutableStateOf(false) }
    var scrubDistanceKm by remember { mutableStateOf(10.2f) }
    var currentSubView by remember { mutableStateOf("TOPO_MAP") } // TOPO_MAP, PROFILE_ELEV, WAYPOINTS, SURVIVAL_COMPASS

    // Real-time simulated telemetry (Altomaps sensor fusion)
    var currentAltitudeMeters by remember { mutableStateOf(3835f) }
    var barometricPressureHpa by remember { mutableStateOf(628.4f) }
    var pressureTrendHpaHr by remember { mutableStateOf(-2.8f) } // Negative indicates dropping barometer (storm warning)
    var verticalSpeedMps by remember { mutableStateOf(1.4f) } // +1.4 m/s ascent
    var magneticDeclinationDeg by remember { mutableStateOf(2.4f) } // +2.4° East

    // Dynamic timer for track recording
    LaunchedEffect(isRecordingTrack) {
        if (isRecordingTrack) {
            while (true) {
                delay(1000)
                recordedTimeSeconds += 1
                recordedDistanceKm += 0.0012f
                currentAltitudeMeters += (verticalSpeedMps * 0.2f)
            }
        }
    }

    // SOS Morse Code Flasher
    var sosFlashOn by remember { mutableStateOf(false) }
    LaunchedEffect(isSosStrobeActive) {
        if (isSosStrobeActive) {
            while (true) {
                // S (...)
                repeat(3) { sosFlashOn = true; delay(200); sosFlashOn = false; delay(200) }
                delay(300)
                // O (---)
                repeat(3) { sosFlashOn = true; delay(500); sosFlashOn = false; delay(200) }
                delay(300)
                // S (...)
                repeat(3) { sosFlashOn = true; delay(200); sosFlashOn = false; delay(200) }
                delay(1000)
            }
        } else {
            sosFlashOn = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF02060E)),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // FOXPOI ALTOMAPS TOPOGRAPHIC BANNER
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF0A1322),
            border = BorderStroke(1.dp, Color(0xFF39FF14).copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(Color(0xFF162B17), CircleShape)
                            .border(1.dp, Color(0xFF39FF14), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Terrain, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("ALTOMAPS", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("OUTDOOR TOPO GPS", fontSize = 8.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                        }
                        Text("FOXPOI TACTICAL EXPEDITION & ALTIMETER SUITE", fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Storm Warning alert chip
                    if (pressureTrendHpaHr < -2.0f) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF3B0000),
                            border = BorderStroke(1.dp, Color(0xFFFF0055))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFF0055), modifier = Modifier.size(10.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("STORM WARNING: -${abs(pressureTrendHpaHr)} hPa/h", fontSize = 7.sp, color = Color(0xFFFF0055), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    IconButton(
                        onClick = {
                            val speech = "ARIIA AltoMaps telemetry: Current altitude is ${currentAltitudeMeters.toInt()} meters, or ${(currentAltitudeMeters * 3.28084f).toInt()} feet. Barometer is reading $barometricPressureHpa hectopascals with rapid pressure drop of ${abs(pressureTrendHpaHr)} hectopascals per hour. Active trail: ${selectedTrail.name}, difficulty ${selectedTrail.difficulty}. Total elevation gain is ${selectedTrail.elevationGainMeters} meters."
                            onSpeak(speech)
                        },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Audio Telemetry", tint = Color(0xFF39FF14), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // ALTIMETER & BAROMETER MULTI-SENSOR HUD (Foxpoi Core)
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF060D18),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Altimeter
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("GPS ALTITUDE", fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text("${currentAltitudeMeters.toInt()} m", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    Text("${(currentAltitudeMeters * 3.28084f).toInt()} FT MSL", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                }

                // Barometer
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("BAROMETER", fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text("$barometricPressureHpa", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFCC00), fontFamily = FontFamily.Monospace)
                    Text("hPa (${(barometricPressureHpa * 0.02953f).format(2)} inHg)", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                }

                // Vertical Speed (VSI)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("VSI RATE", fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (verticalSpeedMps >= 0) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = null,
                            tint = if (verticalSpeedMps >= 0) Color(0xFF39FF14) else Color(0xFFFF0055),
                            modifier = Modifier.size(12.dp)
                        )
                        Text("+${(verticalSpeedMps * 60).toInt()} m/m", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    }
                    Text("${(verticalSpeedMps * 196.85f).toInt()} ft/min", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                }

                // Ascent / Descent Total
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("TOTAL GAIN", fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text("+${selectedTrail.elevationGainMeters}m", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    Text("-${selectedTrail.elevationLossMeters}m loss", fontSize = 7.sp, color = Color(0xFFFF3366), fontFamily = FontFamily.Monospace)
                }
            }
        }

        // TRAIL SELECTION & COORDINATE SYSTEM BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Trail Selector dropdown/chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(curatedTrails) { trail ->
                    val isSel = trail.id == selectedTrail.id
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) Color(0xFF133219) else Color(0xFF070E1A),
                        border = BorderStroke(1.dp, if (isSel) Color(0xFF39FF14) else Color(0xFF1E293B)),
                        modifier = Modifier.clickable {
                            selectedTrail = trail
                            currentAltitudeMeters = trail.waypoints.firstOrNull()?.elevationMeters?.toFloat() ?: 1000f
                            onSpeak("Loaded outdoor trail: ${trail.name}. Total distance: ${trail.totalDistanceKm} kilometers. Max elevation ${trail.maxElevMeters} meters.")
                        }
                    ) {
                        Text(
                            text = trail.name.take(18) + "..",
                            fontSize = 8.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSel) Color(0xFF39FF14) else Color(0xFFCBD5E1),
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Coordinate System Pill
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0D1B2A),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.5f)),
                modifier = Modifier.clickable {
                    val next = when (selectedCoordFormat) {
                        CoordinateSystem.LAT_LON_DD -> CoordinateSystem.LAT_LON_DMS
                        CoordinateSystem.LAT_LON_DMS -> CoordinateSystem.MGRS
                        CoordinateSystem.MGRS -> CoordinateSystem.UTM
                        CoordinateSystem.UTM -> CoordinateSystem.GEOHASH
                        CoordinateSystem.GEOHASH -> CoordinateSystem.MAIDENHEAD
                        CoordinateSystem.MAIDENHEAD -> CoordinateSystem.LAT_LON_DD
                    }
                    selectedCoordFormat = next
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Grid4x4, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(10.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(selectedCoordFormat.label, fontSize = 7.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }

        // ACTIVE COORDINATE READOUT STRIP
        val centerWp = selectedTrail.waypoints.firstOrNull() ?: AltoWaypoint("w0", "Origin", WaypointCategory.TRAILHEAD, 45.8326f, 6.8652f, 4807, "")
        val formattedCoord = remember(selectedCoordFormat, centerWp) {
            when (selectedCoordFormat) {
                CoordinateSystem.LAT_LON_DD -> "${centerWp.lat.format(5)}° N, ${centerWp.lon.format(5)}° E"
                CoordinateSystem.LAT_LON_DMS -> "45°50'01\" N  006°51'54\" E"
                CoordinateSystem.MGRS -> "32TLR 32418 78912"
                CoordinateSystem.UTM -> "32T 333420m E 5078120m N"
                CoordinateSystem.GEOHASH -> "u0hjq29b (1.2m precision)"
                CoordinateSystem.MAIDENHEAD -> "JN35ro (Grid Locator)"
            }
        }
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFF030A14),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("FIX: $formattedCoord", fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text("WGS-84 / EGM96 GEOID", fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
            }
        }

        // TOOLBAR TABS (TOPO MAP, PROFILE, WAYPOINTS, SURVIVAL COMPASS)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf(
                Triple("TOPO_MAP", "Topo Contours", Icons.Default.Map),
                Triple("PROFILE_ELEV", "Elev Profile", Icons.Default.ShowChart),
                Triple("WAYPOINTS", "Waypoints (${selectedTrail.waypoints.size})", Icons.Default.Place),
                Triple("SURVIVAL_COMPASS", "Survival Compass", Icons.Default.Explore)
            ).forEach { (key, label, icon) ->
                val isAct = currentSubView == key
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isAct) Color(0xFF003845) else Color(0xFF080F1D),
                    border = BorderStroke(1.dp, if (isAct) Color(0xFF00F0FF) else Color(0xFF1E293B)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { currentSubView = key }
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 5.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(icon, contentDescription = null, tint = if (isAct) Color(0xFF00F0FF) else Color(0xFF64748B), modifier = Modifier.size(11.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(label, fontSize = 7.sp, fontWeight = if (isAct) FontWeight.Bold else FontWeight.Normal, color = if (isAct) Color.White else Color(0xFF94A3B8))
                    }
                }
            }
        }

        // SUB-VIEW CONTENT CONTAINER
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (currentSubView) {
                "TOPO_MAP" -> {
                    AltoTopoContourCanvas(
                        trail = selectedTrail,
                        contourIntervalMeters = contourInterval,
                        onContourIntervalChange = { contourInterval = it },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                "PROFILE_ELEV" -> {
                    AltoElevationProfileView(
                        trail = selectedTrail,
                        scrubKm = scrubDistanceKm,
                        onScrubChange = { scrubDistanceKm = it },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                "WAYPOINTS" -> {
                    AltoWaypointsListView(
                        waypoints = selectedTrail.waypoints,
                        onSpeak = onSpeak,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                "SURVIVAL_COMPASS" -> {
                    AltoSurvivalCompassView(
                        magneticDeclination = magneticDeclinationDeg,
                        isSosActive = isSosStrobeActive,
                        sosLightOn = sosFlashOn,
                        onToggleSos = { isSosStrobeActive = !isSosStrobeActive },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        // GPX TRACK RECORDER & EXPEDITION FOOTER BAR
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF070D18),
            border = BorderStroke(1.dp, if (isRecordingTrack) Color(0xFFFF3366) else Color(0xFF00F0FF).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Recording stats
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(if (isRecordingTrack) Color(0xFFFF0055) else Color(0xFF64748B), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        val hours = recordedTimeSeconds / 3600
                        val mins = (recordedTimeSeconds % 3600) / 60
                        val secs = recordedTimeSeconds % 60
                        val timeStr = "%02d:%02d:%02d".format(hours, mins, secs)
                        Text(
                            text = if (isRecordingTrack) "REC: $timeStr" else "GPX LOG: $timeStr",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isRecordingTrack) Color(0xFFFF0055) else Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${recordedDistanceKm.format(2)} km  |  Avg Pace 14'20\"/km",
                            fontSize = 7.sp,
                            color = Color(0xFF64748B),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Controls
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            isRecordingTrack = !isRecordingTrack
                            if (isRecordingTrack) {
                                onSpeak("Altomaps GPX track recording initiated. Logging GPS breadcrumbs, elevation, and barometric variance.")
                            } else {
                                onSpeak("GPX track logging paused. Total distance recorded: ${recordedDistanceKm.format(2)} kilometers.")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isRecordingTrack) Color(0xFFFF0055) else Color(0xFF39FF14)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Icon(
                            if (isRecordingTrack) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(if (isRecordingTrack) "PAUSE" else "RECORD GPX", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    // Backtrack / Retrace course
                    Button(
                        onClick = {
                            isBacktracking = !isBacktracking
                            onSpeak(if (isBacktracking) "Backtrack navigation engaged. Follow reverse breadcrumbs to origin trailhead." else "Backtrack guidance deactivated.")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isBacktracking) Color(0xFFBD00FF) else Color(0xFF003845)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = null, tint = if (isBacktracking) Color.White else Color(0xFF00F0FF), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("BACKTRACK", fontSize = 8.sp, color = if (isBacktracking) Color.White else Color(0xFF00F0FF), fontWeight = FontWeight.Bold)
                    }

                    // Prefetch Offline Tiles
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val scope = rememberCoroutineScope()
                    val db = remember { androidx.room.Room.databaseBuilder(context, com.example.data.local.AppDatabase::class.java, "ariia_earth_cache.db").fallbackToDestructiveMigration().build() }
                    val altoRepo = remember { com.example.data.repository.AltoMapsRepository(db.altoMapsTileDao()) }
                    var prefetchLoading by remember { mutableStateOf(false) }
                    
                    Button(
                        onClick = {
                            prefetchLoading = true
                            scope.launch {
                                // Simulate prefetching tiles around the trail's first waypoint
                                val startWaypoint = selectedTrail.waypoints.firstOrNull()
                                val lat = startWaypoint?.lat?.toDouble() ?: 0.0
                                val lon = startWaypoint?.lon?.toDouble() ?: 0.0
                                altoRepo.preFetchRegion(
                                    listOf(
                                        com.example.data.local.AltoMapsTileEntity(
                                            tileId = "${selectedTrail.name}-tile-1",
                                            
                                            zoomLevel = 14,
                                            tileX = 0,
                                            tileY = 0,
                                            tileData = ByteArray(0)
                                            
                                        )
                                    )
                                )
                                onSpeak("Downloaded topographic map tiles for ${selectedTrail.name} region for offline usage.")
                                prefetchLoading = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        if (prefetchLoading) {
                            androidx.compose.material3.CircularProgressIndicator(modifier = Modifier.size(12.dp), color = Color(0xFF00F0FF), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(12.dp))
                        }
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("PREFETCH", fontSize = 8.sp, color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TOPOGRAPHIC CONTOUR CANVAS WITH HYPSOMETRIC TINTS
// -------------------------------------------------------------
@Composable
private fun AltoTopoContourCanvas(
    trail: AltoTrailTrack,
    contourIntervalMeters: Int,
    onContourIntervalChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var panX by remember { mutableStateOf(0f) }
    var panY by remember { mutableStateOf(0f) }
    var zoomScale by remember { mutableStateOf(1f) }

    Box(
        modifier = modifier
            .background(Color(0xFF08121E))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    panX += dragAmount.x
                    panY += dragAmount.y
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f + panX
            val cy = size.height / 2f + panY

            // 1. Topographic relief background rings (Simulated 3D contours)
            val baseRadius = min(size.width, size.height) * 0.45f * zoomScale
            val contourCount = 12
            for (i in 0 until contourCount) {
                val r = baseRadius * (1f - (i.toFloat() / contourCount.toFloat()) * 0.85f)
                val elevM = 1000 + i * (contourIntervalMeters * 3)

                // Hypsometric tint color based on elevation
                val ringColor = when {
                    elevM > 4000 -> Color(0xFFF1F5F9).copy(alpha = 0.8f) // Snow
                    elevM > 3000 -> Color(0xFF94A3B8).copy(alpha = 0.6f) // Rock
                    elevM > 2000 -> Color(0xFF475569).copy(alpha = 0.5f) // Alpine grass
                    else -> Color(0xFF1E3A2F).copy(alpha = 0.5f) // Valley forest
                }

                // Draw organic contour loops with sin wave displacement
                val path = Path()
                val steps = 36
                for (s in 0..steps) {
                    val angle = (s.toFloat() / steps) * (2 * Math.PI).toFloat()
                    val wobble = sin(angle * 4f + i) * (r * 0.08f) + cos(angle * 2f) * (r * 0.04f)
                    val px = cx + (r + wobble) * cos(angle)
                    val py = cy + (r + wobble) * sin(angle) * 0.75f // Tilt
                    if (s == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                drawPath(path, ringColor, style = Stroke(width = if (i % 3 == 0) 2f else 1f))
            }

            // 2. Trail Track Line (GPX Polyline)
            val trailPath = Path()
            val trailPoints = listOf(
                Offset(cx - baseRadius * 0.65f, cy + baseRadius * 0.35f),
                Offset(cx - baseRadius * 0.45f, cy + baseRadius * 0.15f),
                Offset(cx - baseRadius * 0.15f, cy + baseRadius * 0.25f),
                Offset(cx + baseRadius * 0.10f, cy - baseRadius * 0.05f),
                Offset(cx + baseRadius * 0.35f, cy - baseRadius * 0.35f),
                Offset(cx + baseRadius * 0.55f, cy - baseRadius * 0.20f)
            )

            trailPoints.forEachIndexed { idx, pt ->
                if (idx == 0) trailPath.moveTo(pt.x, pt.y) else trailPath.lineTo(pt.x, pt.y)
            }
            // Glow and line
            drawPath(trailPath, Color(0xFF39FF14).copy(alpha = 0.4f), style = Stroke(width = 7f))
            drawPath(trailPath, Color(0xFF39FF14), style = Stroke(width = 2.5f))

            // 3. Draw Waypoint Pins along the track
            trailPoints.forEachIndexed { index, pt ->
                val wp = trail.waypoints.getOrNull(index)
                val pinColor = if (wp != null) Color(wp.category.badgeColor) else Color(0xFF00F0FF)

                // Outer circle
                drawCircle(Color.Black, radius = 7f, center = pt)
                drawCircle(pinColor, radius = 5f, center = pt)
                drawCircle(Color.White, radius = 2f, center = pt)
            }

            // 4. Current User Position marker with compass pointer
            val userPos = trailPoints[3]
            drawCircle(Color(0xFF00F0FF).copy(alpha = 0.3f), radius = 14f, center = userPos)
            drawCircle(Color(0xFF00F0FF), radius = 5f, center = userPos)
        }

        // Top-left Overlay: Contour Interval Switcher
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf(10, 25, 50, 100).forEach { interval ->
                val isSel = contourIntervalMeters == interval
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (isSel) Color(0xFF39FF14) else Color(0xFF0B1422).copy(alpha = 0.85f),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFF39FF14) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable { onContourIntervalChange(interval) }
                ) {
                    Text(
                        "${interval}m",
                        fontSize = 7.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.Black else Color(0xFF94A3B8),
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }
        }

        // Top-right Overlay: Zoom controls
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = Color(0xFF0B1422).copy(alpha = 0.85f),
                border = BorderStroke(1.dp, Color(0xFF00F0FF)),
                modifier = Modifier
                    .size(24.dp)
                    .clickable { zoomScale = (zoomScale * 1.25f).coerceAtMost(3.0f) }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom In", tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                }
            }
            Surface(
                shape = CircleShape,
                color = Color(0xFF0B1422).copy(alpha = 0.85f),
                border = BorderStroke(1.dp, Color(0xFF00F0FF)),
                modifier = Modifier
                    .size(24.dp)
                    .clickable { zoomScale = (zoomScale / 1.25f).coerceAtLeast(0.5f) }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom Out", tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                }
            }
        }

        // Bottom Map Legend
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFF050B16).copy(alpha = 0.9f),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).background(Color(0xFF39FF14), CircleShape))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("GPX Track", fontSize = 7.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).background(Color(0xFFFF3366), CircleShape))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Summit Pin", fontSize = 7.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).background(Color(0xFF00AAFF), CircleShape))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Water Source", fontSize = 7.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// ELEVATION PROFILE WITH INTERACTIVE SCRUB CURSOR
// -------------------------------------------------------------
@Composable
private fun AltoElevationProfileView(
    trail: AltoTrailTrack,
    scrubKm: Float,
    onScrubChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val points = trail.profilePoints
    val maxDist = trail.totalDistanceKm
    val maxElev = trail.maxElevMeters.toFloat()
    val minElev = trail.minElevMeters.toFloat()
    val elevSpan = max(maxElev - minElev, 100f)

    // Current scrub altitude estimation by linear interpolation
    val scrubAltitude = remember(scrubKm, points) {
        val nextIdx = points.indexOfFirst { it.distanceKm >= scrubKm }.takeIf { it != -1 } ?: (points.size - 1)
        val prevIdx = max(0, nextIdx - 1)
        val p1 = points[prevIdx]
        val p2 = points[nextIdx]
        if (p2.distanceKm == p1.distanceKm) p1.elevationMeters
        else {
            val frac = (scrubKm - p1.distanceKm) / (p2.distanceKm - p1.distanceKm)
            p1.elevationMeters + frac * (p2.elevationMeters - p1.elevationMeters)
        }
    }

    Column(
        modifier = modifier
            .background(Color(0xFF050B14))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Scrub cursor telemetry header
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF0A1322),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("TRAIL POSITION: ${scrubKm.format(1)} / ${maxDist.format(1)} KM", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                    Text("${scrubAltitude.toInt()} M (${(scrubAltitude * 3.28084f).toInt()} FT)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                }
                Column(horizontalAlignment = Alignment.End) {
                    val slopePct = ((scrubAltitude - minElev) / max(scrubKm * 1000f, 1f) * 100f).coerceIn(-35f, 35f)
                    Text("EST. GRADE: ${slopePct.format(1)}%", fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    Text("ETA: ${(scrubKm / maxDist * trail.estimatedHours).format(1)} hrs", fontSize = 8.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Canvas Elevation Chart
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF03070F), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val padL = 35f
                val padR = 20f
                val padT = 20f
                val padB = 30f
                val chartW = size.width - padL - padR
                val chartH = size.height - padT - padB

                // Grid lines (horizontal elevations)
                val gridSteps = 4
                for (g in 0..gridSteps) {
                    val gy = padT + (chartH / gridSteps) * g
                    val elevVal = (maxElev - (g.toFloat() / gridSteps) * elevSpan).toInt()
                    drawLine(Color(0xFF1E293B), Offset(padL, gy), Offset(size.width - padR, gy), strokeWidth = 1f)
                }

                // Elevation Area & Line
                val areaPath = Path()
                val linePath = Path()

                points.forEachIndexed { i, p ->
                    val x = padL + (p.distanceKm / maxDist) * chartW
                    val y = padT + (1f - (p.elevationMeters - minElev) / elevSpan) * chartH

                    if (i == 0) {
                        areaPath.moveTo(x, padT + chartH)
                        areaPath.lineTo(x, y)
                        linePath.moveTo(x, y)
                    } else {
                        areaPath.lineTo(x, y)
                        linePath.lineTo(x, y)
                    }

                    if (i == points.size - 1) {
                        areaPath.lineTo(x, padT + chartH)
                        areaPath.close()
                    }
                }

                // Gradient Fill
                drawPath(
                    areaPath,
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF39FF14).copy(alpha = 0.4f), Color(0xFF00F0FF).copy(alpha = 0.05f))
                    )
                )
                // Profile stroke
                drawPath(linePath, Color(0xFF39FF14), style = Stroke(width = 2.5f))

                // Draw Waypoint vertical tags
                trail.waypoints.forEach { wp ->
                    // Approximate distance on trail
                    val approxKm = (wp.elevationMeters - minElev) / elevSpan * maxDist
                    val wx = padL + (approxKm.coerceIn(0f, maxDist) / maxDist) * chartW
                    val wy = padT + (1f - (wp.elevationMeters.toFloat() - minElev) / elevSpan) * chartH

                    drawLine(Color(wp.category.badgeColor).copy(alpha = 0.5f), Offset(wx, padT), Offset(wx, padT + chartH), strokeWidth = 1f)
                    drawCircle(Color(wp.category.badgeColor), radius = 3.5f, center = Offset(wx, wy))
                }

                // Scrub Cursor vertical line
                val scrubX = padL + (scrubKm.coerceIn(0f, maxDist) / maxDist) * chartW
                val scrubY = padT + (1f - (scrubAltitude - minElev) / elevSpan) * chartH
                drawLine(Color(0xFF00F0FF), Offset(scrubX, padT), Offset(scrubX, padT + chartH), strokeWidth = 2f)
                drawCircle(Color(0xFF00F0FF), radius = 6f, center = Offset(scrubX, scrubY))
                drawCircle(Color.White, radius = 3f, center = Offset(scrubX, scrubY))
            }
        }

        // Scrub Slider
        Slider(
            value = scrubKm,
            onValueChange = onScrubChange,
            valueRange = 0f..maxDist,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF00F0FF),
                activeTrackColor = Color(0xFF39FF14),
                inactiveTrackColor = Color(0xFF1E293B)
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// -------------------------------------------------------------
// WAYPOINTS LIST WITH ALTITUDE & GPS FIXES
// -------------------------------------------------------------
@Composable
private fun AltoWaypointsListView(
    waypoints: List<AltoWaypoint>,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .background(Color(0xFF050B14))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(waypoints) { wp ->
            val badgeColor = Color(wp.category.badgeColor)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF09111F),
                border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(badgeColor.copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, badgeColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Place, contentDescription = null, tint = badgeColor, modifier = Modifier.size(16.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(wp.name, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                Badge(containerColor = badgeColor.copy(alpha = 0.2f), contentColor = badgeColor) {
                                    Text(wp.category.title, fontSize = 7.sp)
                                }
                            }
                            Text(wp.notes, fontSize = 8.sp, color = Color(0xFF94A3B8))
                            Text(
                                "Lat: ${wp.lat.format(4)}° Lon: ${wp.lon.format(4)}° | Elev: ${wp.elevationMeters}m MSL",
                                fontSize = 7.sp,
                                color = Color(0xFF64748B),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            onSpeak("Waypoint: ${wp.name}. Category: ${wp.category.title}. Elevation: ${wp.elevationMeters} meters. Coordinates: Latitude ${wp.lat}, Longitude ${wp.lon}. ${wp.notes}")
                        },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SURVIVAL COMPASS & SOLAR EPHEMERIS (Foxpoi Wilderness Mode)
// -------------------------------------------------------------
@Composable
private fun AltoSurvivalCompassView(
    magneticDeclination: Float,
    isSosActive: Boolean,
    sosLightOn: Boolean,
    onToggleSos: () -> Unit,
    modifier: Modifier = Modifier
) {
    var headingDeg by remember { mutableStateOf(48f) } // Simulated heading Northeast
    var bearingLockDeg by remember { mutableStateOf<Float?>(null) }

    Column(
        modifier = modifier
            .background(Color(0xFF030712))
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Solar / Moon Ephemeris row
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF07101E),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WbSunny, contentDescription = null, tint = Color(0xFFFFCC00), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("SUNRISE: 05:42 | SUNSET: 20:18", fontSize = 7.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NightsStay, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("MOON: WAXING 74%", fontSize = 7.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Compass Rose Canvas
        Box(
            modifier = Modifier
                .size(180.dp)
                .background(Color(0xFF070E1A), CircleShape)
                .border(2.dp, Color(0xFF00F0FF).copy(alpha = 0.5f), CircleShape)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f - 12f

                // Dial ticks
                for (d in 0 until 360 step 15) {
                    val angleRad = Math.toRadians((d - headingDeg - 90).toDouble()).toFloat()
                    val tickLen = if (d % 90 == 0) 12f else if (d % 45 == 0) 8f else 4f
                    val strokeW = if (d % 90 == 0) 2.5f else 1f
                    val tickColor = if (d == 0) Color(0xFFFF0055) else Color(0xFF64748B)

                    val start = Offset(center.x + (radius - tickLen) * cos(angleRad), center.y + (radius - tickLen) * sin(angleRad))
                    val end = Offset(center.x + radius * cos(angleRad), center.y + radius * sin(angleRad))
                    drawLine(tickColor, start, end, strokeWidth = strokeW)
                }

                // Bearing Lock pointer (if locked)
                if (bearingLockDeg != null) {
                    val lockRad = Math.toRadians((bearingLockDeg!! - headingDeg - 90).toDouble()).toFloat()
                    val lockPt = Offset(center.x + radius * cos(lockRad), center.y + radius * sin(lockRad))
                    drawCircle(Color(0xFFFFCC00), radius = 5f, center = lockPt)
                }

                // Needle pointing True North
                val northRad = Math.toRadians((-headingDeg - 90).toDouble()).toFloat()
                val needleLen = radius * 0.75f
                val northPt = Offset(center.x + needleLen * cos(northRad), center.y + needleLen * sin(northRad))
                val southPt = Offset(center.x - needleLen * 0.6f * cos(northRad), center.y - needleLen * 0.6f * sin(northRad))

                drawLine(Color(0xFFFF0055), center, northPt, strokeWidth = 3f)
                drawLine(Color(0xFF94A3B8), center, southPt, strokeWidth = 2.5f)
                drawCircle(Color(0xFF00F0FF), radius = 4f, center = center)
            }

            // Central Heading Text
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("${headingDeg.toInt()}°", fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color.White, fontFamily = FontFamily.Monospace)
                val cardinal = when (headingDeg.toInt()) {
                    in 338..360, in 0..22 -> "N"
                    in 23..67 -> "NE"
                    in 68..112 -> "E"
                    in 113..157 -> "SE"
                    in 158..202 -> "S"
                    in 203..247 -> "SW"
                    in 248..292 -> "W"
                    else -> "NW"
                }
                Text(cardinal, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
            }
        }

        // Magnetic Declination & Course Lock controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("MAG DECLINATION: +${magneticDeclination}° E", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                Text(if (bearingLockDeg != null) "COURSE LOCKED: ${bearingLockDeg!!.toInt()}°" else "COURSE: UNLOCKED", fontSize = 8.sp, color = if (bearingLockDeg != null) Color(0xFFFFCC00) else Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        bearingLockDeg = if (bearingLockDeg == null) headingDeg else null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (bearingLockDeg != null) Color(0xFFFFCC00) else Color(0xFF0B1B2C)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = if (bearingLockDeg != null) Color.Black else Color(0xFF00F0FF), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(if (bearingLockDeg != null) "LOCKED" else "LOCK BEARING", fontSize = 8.sp, color = if (bearingLockDeg != null) Color.Black else Color(0xFF00F0FF), fontWeight = FontWeight.Bold)
                }

                // SOS Strobe Button
                Button(
                    onClick = onToggleSos,
                    colors = ButtonDefaults.buttonColors(containerColor = if (isSosActive) Color(0xFFFF0055) else Color(0xFF3B0000)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, tint = if (sosLightOn) Color.Yellow else Color.White, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(if (isSosActive) "SOS ACTIVE" else "SOS STROBE", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun Float.format(decimals: Int): String = "%.${decimals}f".format(this)
