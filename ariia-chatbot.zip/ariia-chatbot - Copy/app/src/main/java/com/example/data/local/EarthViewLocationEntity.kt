package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "earth_view_locations")
data class EarthViewLocationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val type: String, // e.g., "TRAIL", "CAMERA", "POI"
    val timestamp: Long = System.currentTimeMillis()
)
