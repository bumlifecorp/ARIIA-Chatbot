package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "speech_reminders")
data class SpeechReminderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val purpose: String,
    val scheduledTimeText: String, // e.g., "7:00 AM", "9:00 PM", "8:00 AM", "2:00 PM"
    val isAlarm: Boolean = false, // true for wake-up alarm, false for reminder
    val spokenAlertText: String, // e.g. "Wake up Operator! It is 7:00 AM.", "Reminder: Time to take your medicine."
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "teachable_voice_commands")
data class TeachableVoiceCommandEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val triggerPhrase: String, // e.g. "shields up", "call to mom", "scan area"
    val actionType: String, // "OPEN_APP", "DIAL", "WEB_SEARCH", "SPEAK", "TRIGGER_ALARM"
    val actionTarget: String, // e.g. "package:com.whatsapp", "tel:mom", "query:news"
    val spokenResponse: String, // e.g. "Opening WhatsApp now.", "Dialing Mom."
    val isBuiltIn: Boolean = false
)

@Entity(tableName = "trained_vision_objects")
data class TrainedVisionObjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val label: String, // e.g. "Coffee Mug", "ID Badge", "Book", "Medicine Bottle"
    val redMean: Float,
    val greenMean: Float,
    val blueMean: Float,
    val luminanceMean: Float,
    val variance: Float,
    val assignedAction: String, // e.g. "SPEAK:Water bottle detected. Hydration recommended.", "ALARM:Medicine time"
    val confidenceThreshold: Float = 0.85f,
    val createdAt: Long = System.currentTimeMillis()
)
