package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PaintedObjectDao {
    @Query("SELECT * FROM painted_objects ORDER BY timestamp DESC")
    fun getAllPaintedObjects(): Flow<List<PaintedObjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(obj: PaintedObjectEntity)

    @Delete
    suspend fun delete(obj: PaintedObjectEntity)

    @Query("DELETE FROM painted_objects WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM painted_objects")
    suspend fun clearAll()
}
