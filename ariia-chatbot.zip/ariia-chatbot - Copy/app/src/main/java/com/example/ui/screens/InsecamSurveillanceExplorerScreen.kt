package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import kotlin.math.cos
import kotlin.math.sin

data class InsecamCameraFeed(
    val id: String,
    val title: String,
    val country: String,
    val city: String,
    val latitude: Float,
    val longitude: Float,
    val manufacturer: String, // Axis, Hikvision, Dahua, Panasonic, Foscam, Mobotix
    val protocol: String,     // RTSP, MJPEG, H.264
    val port: Int,            // 80, 8080, 554
    val category: String,     // Traffic, Harbor, Airport, Hotel, Street, Park, Office
    val resolution: String,   // 1080p, 720p, 4K
    val fps: Int,
    val isOnline: Boolean = true,
    val viewCount: Int = 1250,
    val ipAddressMasked: String = "192.168.1.xxx"
)

@Composable
fun InsecamSurveillanceExplorerScreen(
    onSpeak: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    // Directory of Public Insecam World Security Cameras
    val insecamFeeds = remember {
        listOf(
            InsecamCameraFeed("insecam-01", "Shibuya Crossing Main Cam", "Japan", "Tokyo", 35.6595f, 139.7004f, "Axis Communications", "MJPEG", 8080, "Street", "1080p", 30, true, 4210, "122.215.101.xxx"),
            InsecamCameraFeed("insecam-02", "Times Square North View", "United States", "New York", 40.7580f, -73.9855f, "Hikvision HD", "H.264", 554, "Street", "4K", 60, true, 8920, "108.162.212.xxx"),
            InsecamCameraFeed("insecam-03", "Port of Rotterdam Harbor Locks", "Netherlands", "Rotterdam", 51.9244f, 4.4777f, "Dahua Tech", "RTSP", 554, "Harbor", "1080p", 25, true, 1840, "82.170.219.xxx"),
            InsecamCameraFeed("insecam-04", "Venice Grand Canal Bridge", "Italy", "Venice", 45.4371f, 12.3326f, "Mobotix DualFlex", "MJPEG", 80, "Waterway", "1080p", 20, true, 2150, "151.28.188.xxx"),
            InsecamCameraFeed("insecam-05", "Schiphol Airport Runway 18R", "Netherlands", "Amsterdam", 52.3105f, 4.7683f, "Panasonic i-PRO", "H.264", 8080, "Airport", "4K", 60, true, 3400, "145.53.112.xxx"),
            InsecamCameraFeed("insecam-06", "Gothenburg Harbor Line", "Sweden", "Gothenburg", 57.7089f, 11.9746f, "Axis Dome 4K", "RTSP", 554, "Harbor", "4K", 30, true, 1920, "192.121.201.xxx"),
            InsecamCameraFeed("insecam-07", "Zurich Central Station Concourse", "Switzerland", "Zurich", 47.3769f, 8.5417f, "Bosch Security", "MJPEG", 80, "Transit", "1080p", 30, true, 1480, "194.209.130.xxx"),
            InsecamCameraFeed("insecam-08", "Sydney Harbour Bridge Lookout", "Australia", "Sydney", -33.8523f, 151.2108f, "Foscam Outdoor", "H.264", 88, "Harbor", "1080p", 25, true, 2810, "203.221.190.xxx"),
            InsecamCameraFeed("insecam-09", "Reykjavik Harbor Square", "Iceland", "Reykjavik", 64.1466f, -21.9426f, "Axis Thermal Dome", "MJPEG", 80, "Street", "720p", 15, true, 920, "82.221.45.xxx"),
            InsecamCameraFeed("insecam-10", "Singapore Marina Bay Sands Cam", "Singapore", "Singapore", 1.2838f, 103.8591f, "Hikvision PTZ", "RTSP", 554, "Urban", "4K", 60, true, 5100, "118.200.104.xxx")
        )
    }

    var selectedCategory by remember { mutableStateOf("ALL") }
    var selectedCountry by remember { mutableStateOf("ALL") }

    val categories = remember(insecamFeeds) { listOf("ALL") + insecamFeeds.map { it.category }.distinct() }
    val countries = remember(insecamFeeds) { listOf("ALL") + insecamFeeds.map { it.country }.distinct() }

    val filteredFeeds = remember(insecamFeeds, selectedCategory, selectedCountry) {
        insecamFeeds.filter { feed ->
            (selectedCategory == "ALL" || feed.category == selectedCategory) &&
            (selectedCountry == "ALL" || feed.country == selectedCountry)
        }
    }

    var activeFeed by remember { mutableStateOf(filteredFeeds.first()) }

    var isThermalOverlay by remember { mutableStateOf(false) }
    var isNvgMode by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "InsecamAnim")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Reverse),
        label = "Pulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030A14))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Insecam Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A192F), RoundedCornerShape(10.dp))
                .border(1.dp, Color(0xFF00F0FF), RoundedCornerShape(10.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Videocam, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("INSECAM WORLD CCTV EXPLORER", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(shape = CircleShape, color = Color(0xFF39FF14)) { Box(modifier = Modifier.size(6.dp)) }
                    }
                    Text("${filteredFeeds.size} Live Feeds Online • RTSP/MJPEG Directory • Axis/Hikvision/Dahua", fontSize = 8.sp, color = Color(0xFF94A3B8))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                // Thermal Toggle
                IconButton(
                    onClick = {
                        isThermalOverlay = !isThermalOverlay
                        if (isThermalOverlay) isNvgMode = false
                        onSpeak(if (isThermalOverlay) "Thermal IR mode active." else "Thermal IR mode disabled.")
                    },
                    modifier = Modifier.size(26.dp)
                ) {
                    Icon(Icons.Default.Whatshot, contentDescription = null, tint = if (isThermalOverlay) Color(0xFFFF9900) else Color(0xFF64748B))
                }

                // NVG Green Mode Toggle
                IconButton(
                    onClick = {
                        isNvgMode = !isNvgMode
                        if (isNvgMode) isThermalOverlay = false
                        onSpeak(if (isNvgMode) "Night vision mode active." else "Night vision mode disabled.")
                    },
                    modifier = Modifier.size(26.dp)
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = null, tint = if (isNvgMode) Color(0xFF39FF14) else Color(0xFF64748B))
                }

                // Voice Audio Brief Button
                Button(
                    onClick = {
                        val speech = "Insecam feed locked on ${activeFeed.title} in ${activeFeed.city}, ${activeFeed.country}. Camera protocol ${activeFeed.protocol} on port ${activeFeed.port}. Resolution ${activeFeed.resolution} at ${activeFeed.fps} frames per second."
                        onSpeak(speech)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Audio Brief", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Category & Country Filter Row
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(categories) { cat ->
                val isSel = cat == selectedCategory
                FilterChip(
                    selected = isSel,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat, fontSize = 8.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF00F0FF), selectedLabelColor = Color.Black)
                )
            }
        }

        // Main Insecam Video Canvas View
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(
                    when {
                        isNvgMode -> Color(0xFF001200)
                        isThermalOverlay -> Color(0xFF1F0010)
                        else -> Color(0xFF020712)
                    },
                    RoundedCornerShape(12.dp)
                )
                .border(
                    1.dp,
                    when {
                        isNvgMode -> Color(0xFF39FF14)
                        isThermalOverlay -> Color(0xFFFF9900)
                        else -> Color(0xFF00F0FF).copy(alpha = 0.5f)
                    },
                    RoundedCornerShape(12.dp)
                )
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val center = Offset(w / 2f, h / 2f)

                // Render Simulated Live Video Mesh
                val scanLines = 30
                val dy = h / scanLines
                for (i in 0..scanLines) {
                    val lineColor = when {
                        isNvgMode -> Color(0xFF39FF14).copy(alpha = 0.15f)
                        isThermalOverlay -> Color(0xFFFF0055).copy(alpha = 0.15f)
                        else -> Color(0xFF00F0FF).copy(alpha = 0.08f)
                    }
                    drawLine(lineColor, Offset(0f, i * dy), Offset(w, i * dy))
                }

                // Crosshair Reticle Overlay
                val crosshairColor = when {
                    isNvgMode -> Color(0xFF39FF14)
                    isThermalOverlay -> Color(0xFFFF9900)
                    else -> Color(0xFF00F0FF)
                }
                drawLine(crosshairColor.copy(alpha = 0.4f), Offset(center.x, 0f), Offset(center.x, h))
                drawLine(crosshairColor.copy(alpha = 0.4f), Offset(0f, center.y), Offset(w, center.y))
                drawCircle(crosshairColor, radius = 24f, center = center, style = Stroke(width = 1.5f))

                // Simulated Optical Camera Motion
                drawCircle(
                    color = crosshairColor.copy(alpha = 0.3f),
                    radius = 45f * pulseAlpha,
                    center = center
                )
            }

            // Top HUD Banner
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.85f),
                    border = BorderStroke(1.dp, if (isNvgMode) Color(0xFF39FF14) else Color(0xFF00F0FF))
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text("INSECAM FEED: ${activeFeed.title.uppercase()}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (isNvgMode) Color(0xFF39FF14) else Color(0xFF00F0FF))
                        Text("LOCATION: ${activeFeed.city}, ${activeFeed.country} (${activeFeed.latitude}°, ${activeFeed.longitude}°)", fontSize = 8.sp, color = Color.White)
                        Text("HARDWARE: ${activeFeed.manufacturer} | PORT: ${activeFeed.port} | IP: ${activeFeed.ipAddressMasked}", fontSize = 8.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                        Text("STREAM: ${activeFeed.protocol} • ${activeFeed.resolution} • ${activeFeed.fps} FPS", fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Bottom Right Live Indicator
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color(0xFFFF0055),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(Color.White, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("LIVE INSECAM STREAM", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Camera Feed Selection Carousel
        Text("INSECAM WORLD CCTV DIRECTORY", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)

        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(filteredFeeds) { feed ->
                val isSel = feed.id == activeFeed.id
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) Color(0xFF003355) else Color(0xFF0D1B2A),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFF00F0FF) else Color(0xFF1E293B)),
                    modifier = Modifier.clickable {
                        activeFeed = feed
                        onSpeak("Switched to Insecam feed ${feed.title} in ${feed.city}, ${feed.country}.")
                    }
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(feed.title, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                        Text("${feed.city}, ${feed.country}", fontSize = 7.sp, color = Color(0xFF00F0FF))
                        Text("${feed.manufacturer} • ${feed.resolution}", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}
