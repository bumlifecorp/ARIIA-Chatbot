package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import com.example.utils.HapticManager
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SystemAcceleratorScreen(
    onRunDiagnostics: () -> Unit,
    isDiagnosing: Boolean,
    diagnosticLog: String
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    DisposableEffect(Unit) {
        onDispose { speechEngine.shutdown() }
    }

    // Automated Centrifuge Accelerator States
    var isCentrifugeActive by remember { mutableStateOf(false) }
    var centrifugeRpm by remember { mutableFloatStateOf(0f) }
    var targetRpm by remember { mutableFloatStateOf(15000f) }
    var speedMultiplier by remember { mutableFloatStateOf(1.0f) } // 1.0x to 3.0x (300%)
    var memoryLatencyMs by remember { mutableFloatStateOf(45.0f) }
    var centrifugeMode by remember { mutableStateOf("Parallel Tensor Fluid Centrifuge") }

    // Centrifuge Spin Animation
    val infiniteTransition = rememberInfiniteTransition(label = "CentrifugeSpin")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isCentrifugeActive) 400 else 4000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "CentrifugeRotation"
    )

    // Smooth Centrifuge Acceleration Loop
    LaunchedEffect(isCentrifugeActive) {
        while (true) {
            delay(50)
            if (isCentrifugeActive) {
                if (centrifugeRpm < targetRpm) {
                    centrifugeRpm = (centrifugeRpm + 400f).coerceAtMost(targetRpm)
                }
                speedMultiplier = (1.0f + (centrifugeRpm / targetRpm) * 2.0f).coerceAtMost(3.0f) // 1.0x to 3.0x (300% boost)
                memoryLatencyMs = (45.0f - (centrifugeRpm / targetRpm) * 33.0f).coerceAtLeast(12.0f)
            } else {
                if (centrifugeRpm > 0f) {
                    centrifugeRpm = (centrifugeRpm - 300f).coerceAtLeast(0f)
                }
                speedMultiplier = (1.0f + (centrifugeRpm / targetRpm) * 2.0f).coerceAtLeast(1.0f)
                memoryLatencyMs = (45.0f - (centrifugeRpm / targetRpm) * 33.0f).coerceAtMost(45.0f)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF04070D))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1422)),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.6f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(Color(0xFF11253E), CircleShape)
                                    .border(1.dp, Color(0xFF00F0FF), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Speed,
                                    contentDescription = null,
                                    tint = Color(0xFF00F0FF),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "SYSTEM ACCELERATOR & AUTOMATED CENTRIFUGE",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00F0FF),
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "300% Speed & Processing Acceleration Harness",
                                    fontSize = 10.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                        Surface(
                            color = Color(0xFF39FF14).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "300% BOOST READY",
                                fontSize = 8.sp,
                                color = Color(0xFF39FF14),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Automated Centrifuge 300% Boost Gauge Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF08121E)),
                border = BorderStroke(
                    1.dp,
                    if (isCentrifugeActive) Color(0xFF39FF14) else Color(0xFF1D3452)
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "[AUTOMATED_CENTRIFUGE_ENGINE] - 300% SPEED ACCELERATOR",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCentrifugeActive) Color(0xFF39FF14) else Color(0xFF00F0FF),
                        fontFamily = FontFamily.Monospace
                    )

                    // Centrifuge Visual Canvas Gauge
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .background(Color(0xFF040A12), CircleShape)
                            .border(
                                2.dp,
                                if (isCentrifugeActive) Color(0xFF39FF14) else Color(0xFF1B365D),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val center = Offset(size.width / 2f, size.height / 2f)
                            val radius = size.width / 2f - 12.dp.toPx()

                            // Outer static ring
                            drawCircle(
                                color = Color(0xFF1B365D),
                                radius = radius,
                                style = Stroke(width = 3.dp.toPx())
                            )

                            // Spinning centrifuge rotor arcs
                            val arcColor = if (isCentrifugeActive) Color(0xFF39FF14) else Color(0xFF00F0FF)
                            for (i in 0..3) {
                                val startAngle = rotationAngle + (i * 90f)
                                drawArc(
                                    color = arcColor,
                                    startAngle = startAngle,
                                    sweepAngle = 50f,
                                    useCenter = false,
                                    topLeft = Offset(center.x - radius, center.y - radius),
                                    size = Size(radius * 2f, radius * 2f),
                                    style = Stroke(width = 6.dp.toPx())
                                )
                            }

                            // Inner pulse core
                            drawCircle(
                                color = if (isCentrifugeActive) Color(0xFF39FF14).copy(alpha = 0.2f) else Color(0xFF00F0FF).copy(alpha = 0.1f),
                                radius = radius * 0.5f
                            )
                        }

                        // Centrifuge Metrics Text
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "%.0f%%".format(speedMultiplier * 100f),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCentrifugeActive) Color(0xFF39FF14) else Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "PROCESSING",
                                fontSize = 8.sp,
                                color = Color(0xFF94A3B8),
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "${centrifugeRpm.toInt()} RPM",
                                fontSize = 10.sp,
                                color = Color(0xFF00F0FF),
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Speed & Latency Comparison Meters
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2A))
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("BOOST SPEED", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                                Text("%.1fx (300%%)".format(speedMultiplier), fontSize = 13.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold)
                                Text("300% Accelerated", fontSize = 8.sp, color = Color(0xFF86EFAC))
                            }
                        }
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2A))
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("MEMORY LATENCY", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                                Text("%.1f ms".format(memoryLatencyMs), fontSize = 13.sp, color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold)
                                Text(if (isCentrifugeActive) "73% Latency Cut" else "Baseline 45ms", fontSize = 8.sp, color = Color(0xFF38BDF8))
                            }
                        }
                    }

                    // Automated Centrifuge Launch Button
                    Button(
                        onClick = {
                            isCentrifugeActive = !isCentrifugeActive
                            HapticManager.triggerVoiceCommandSuccess(context)
                            if (isCentrifugeActive) {
                                speechEngine.speak("Automated centrifuge active. Acceleration spin engaged at 15,000 RPM. Loading and model processing accelerated by 300 percent.")
                            } else {
                                speechEngine.speak("Automated centrifuge decelerated to standby mode.")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCentrifugeActive) Color(0xFFFF0055) else Color(0xFF39FF14)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            if (isCentrifugeActive) Icons.Default.PauseCircle else Icons.Default.Bolt,
                            contentDescription = null,
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isCentrifugeActive) "DISENGAGE AUTOMATED CENTRIFUGE" else "ENGAGE AUTOMATED CENTRIFUGE (300% BOOST)",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Model Validation Specs Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF08121E)),
                border = BorderStroke(1.dp, Color(0xFF1D3452)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "LiteRT-LM Model & Memory Centrifuge Registry",
                        fontSize = 12.sp,
                        color = Color(0xFF39FF14),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )

                    ModelSpecRow(label = "Model Engine", value = "LiteRT-LM v0.16.0-stable")
                    ModelSpecRow(label = "Target Revision", value = "rev-2026.09-g2")
                    ModelSpecRow(label = "Centrifuge Fluid Pipeline", value = centrifugeMode)
                    ModelSpecRow(label = "Centrifuge Boost Multiplier", value = "%.1fx (300%% Accelerated)".format(speedMultiplier))
                    ModelSpecRow(label = "SHA-256 Checksum", value = "a4f889c21e7309bf881a29f88c3041ea29b88f117a2")
                    ModelSpecRow(label = "Hardware Acceleration", value = "NNAPI / GPU Centrifuge Delegate Active")
                }
            }
        }

        // Run Diagnostics Action Button
        item {
            Button(
                onClick = {
                    onRunDiagnostics()
                    speechEngine.speak("Executing LiteRT-LM memory and centrifuge accelerator diagnostics.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Speed, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    if (isDiagnosing) "Running Centrifuge Diagnostics..." else "Execute LiteRT-LM & Centrifuge Diagnostics",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Diagnostic Output Console
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF060C14)),
                border = BorderStroke(1.dp, Color(0xFF1D3452)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Diagnostics & Automated Centrifuge Console",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        fontFamily = FontFamily.Monospace
                    )
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        item {
                            Text(
                                text = diagnosticLog + if (isCentrifugeActive) "\n[CENTRIFUGE] 300% Speed Acceleration active at ${centrifugeRpm.toInt()} RPM." else "",
                                color = Color(0xFF39FF14),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ModelSpecRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = Color(0xFF94A3B8))
        Text(text = value, fontSize = 11.sp, color = Color.White, fontFamily = FontFamily.Monospace)
    }
}
