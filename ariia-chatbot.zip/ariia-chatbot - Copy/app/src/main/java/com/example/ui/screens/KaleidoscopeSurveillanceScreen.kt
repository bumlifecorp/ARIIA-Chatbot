package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SurveillanceNode
import com.example.service.InfluxDbServiceWrapper
import com.example.service.InfluxNodeTelemetry
import com.example.util.AriiaSpeechEngine
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun KaleidoscopeSurveillanceScreen(
    nodes: List<SurveillanceNode>,
    onSelectNode: (SurveillanceNode) -> Unit,
    activeNode: SurveillanceNode?,
    allFeedsConnected: Boolean = true,
    onConnectAllFeeds: () -> Unit = {},
    onDisconnectAllFeeds: () -> Unit = {},
    onToggleFeedConnection: (String) -> Unit = {},
    onNavigateTab: (Int) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    var symmetryFolds by remember { mutableIntStateOf(8) } // 6, 8, 12, 16, 24
    var rotationSpeed by remember { mutableFloatStateOf(1.0f) }
    var userRotation by remember { mutableFloatStateOf(0f) }
    var scaleFactor by remember { mutableFloatStateOf(1f) }
    var selectedCategory by remember { mutableStateOf("ALL") }

    // Pulsing animation for active feeds & connection links
    val infiniteTransition = rememberInfiniteTransition(label = "hudPulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweepAngle"
    )

    val batteryLevel by com.example.utils.BatteryObserver.rememberBatteryLevel()
    val isBatteryLow = batteryLevel < 20f
    
    // Dynamic UI Update Strategy for Feed Data
    var dynamicNodes by remember { mutableStateOf(nodes) }
    LaunchedEffect(nodes, isBatteryLow) {
        dynamicNodes = nodes
        while (true) {
            val refreshDelay = if (isBatteryLow) 2000L else 500L
            kotlinx.coroutines.delay(refreshDelay)
            dynamicNodes = dynamicNodes.map { node ->
                if (!node.isConnected) return@map node
                val isCritical = node.threatLevel == "High" || node.feedType == "TACTICAL_COMMS" || node.id == activeNode?.id
                if (isBatteryLow && !isCritical) {
                    // Reduce refresh frequency for non-critical nodes by skipping updates randomly
                    if (Math.random() > 0.3) return@map node 
                }
                node.copy(
                    latencyMs = (node.latencyMs + (-5..5).random()).coerceIn(10, 999),
                    bitrateMbps = (node.bitrateMbps + kotlin.random.Random.nextDouble(-0.5, 0.5).toFloat()).coerceIn(0.5f, 50f)
                )
            }
        }
    }

    // Auto-increment rotation based on speed
    var autoRotation by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(rotationSpeed, isBatteryLow) {
        while (true) {
            val refreshDelay = if (isBatteryLow) 64L else 16L
            val effectiveRotationSpeed = if (isBatteryLow) rotationSpeed * 0.5f else rotationSpeed
            kotlinx.coroutines.delay(refreshDelay)
            autoRotation = (autoRotation + (0.5f * effectiveRotationSpeed)) % 360f
        }
    }

    val totalRotation = (autoRotation + userRotation) % 360f
    val angleStep = 360f / symmetryFolds
    val refractionIndex = String.format(java.util.Locale.US, "%.2f", 1.0f + (scaleFactor * 0.4f) + (symmetryFolds * 0.02f))

    val connectedCount = dynamicNodes.count { it.isConnected }
    val aggregateThroughput = String.format(java.util.Locale.US, "%.1f", dynamicNodes.filter { it.isConnected }.sumOf { it.bitrateMbps.toDouble() })
    val avgLatency = if (connectedCount > 0) dynamicNodes.filter { it.isConnected }.map { it.latencyMs }.average().toInt() else 0

    val filteredNodes = remember(dynamicNodes, selectedCategory) {
        if (selectedCategory == "ALL") {
            dynamicNodes
        } else {
            dynamicNodes.filter { it.category == selectedCategory }
        }
    }

    val currentNode = activeNode ?: dynamicNodes.firstOrNull { it.isConnected } ?: dynamicNodes.firstOrNull()

    // InfluxDB Real-Time Telemetry Streaming Service Wrapper Integration
    LaunchedEffect(nodes) {
        InfluxDbServiceWrapper.registerNodes(nodes)
    }

    val isInfluxStreaming by InfluxDbServiceWrapper.isStreamingActive.collectAsState()
    val influxWriteRate by InfluxDbServiceWrapper.writeRatePps.collectAsState()
    val influxTotalPoints by InfluxDbServiceWrapper.totalPointsIngested.collectAsState()
    val influxTelemetryMap by InfluxDbServiceWrapper.nodeTelemetryMap.collectAsState()
    val latencyHistoryMap by InfluxDbServiceWrapper.latencyHistoryMap.collectAsState()
    val thermalHistoryMap by InfluxDbServiceWrapper.thermalHistoryMap.collectAsState()
    val latestLineProtocol by InfluxDbServiceWrapper.latestLineProtocol.collectAsState()
    val activeInfluxAlerts by InfluxDbServiceWrapper.activeAlerts.collectAsState()
    val anomalyActiveNode by InfluxDbServiceWrapper.anomalyActiveNode.collectAsState()

    var showInfluxPanel by remember { mutableStateOf(false) }
    var showLineProtocolDetails by remember { mutableStateOf(false) }

    val currentInflux = currentNode?.let { influxTelemetryMap[it.id] }
    val currentLatHistory = currentNode?.let { latencyHistoryMap[it.id] } ?: emptyList()
    val currentThermalHistory = currentNode?.let { thermalHistoryMap[it.id] } ?: emptyList()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header & Global Feeds Multiplexer Link Bar
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0A0A10),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (connectedCount > 0) Color(0xFF39FF14) else Color(0xFFFF9900))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ARIIA SPHERICAL HUD MATRIX",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00F0FF),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 15.sp
                            )
                        }

                        Badge(
                            containerColor = if (connectedCount == nodes.size) Color(0xFF003D1A) else Color(0xFF3B2500),
                            contentColor = if (connectedCount == nodes.size) Color(0xFF39FF14) else Color(0xFFFFB300)
                        ) {
                            Text(
                                text = "$connectedCount/${nodes.size} FEEDS LINKED",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Feed Connection Global Actions & Real-time Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "MUX: ${aggregateThroughput} Mbps | LAT: ${avgLatency}ms | AES-256-GCM",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Tactical Cameras, World Cams, Streams, Radar & Sensors",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF64748B),
                                fontSize = 9.sp
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilledTonalButton(
                                onClick = {
                                    onConnectAllFeeds()
                                    speechEngine.speak("Connecting all ${nodes.size} available feeds to ARIIA HUD nodes. Multiplexer synchronised.")
                                },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF004D25),
                                    contentColor = Color(0xFF39FF14)
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Link, contentDescription = "Connect All", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("CONNECT ALL", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    onDisconnectAllFeeds()
                                    speechEngine.speak("All HUD feeds disconnected to standby mode.")
                                },
                                border = BorderStroke(1.dp, Color(0xFF475569)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.LinkOff, contentDescription = "Disconnect All", modifier = Modifier.size(14.dp), tint = Color(0xFF94A3B8))
                            }
                        }
                    }
                }
            }

            // InfluxDB Surveillance Nodes Telemetry HUD Stream Bar & Dynamic Waveform Overlay
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF070B12),
                border = BorderStroke(1.dp, if (anomalyActiveNode != null) Color(0xFFFF3366) else Color(0xFF00F0FF).copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (isInfluxStreaming) Color(0xFF39FF14) else Color(0xFFFF9900))
                            )
                            Text(
                                text = "INFLUXDB TSM STREAM",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00F0FF),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                            Badge(
                                containerColor = if (isInfluxStreaming) Color(0xFF003816) else Color(0xFF381400),
                                contentColor = if (isInfluxStreaming) Color(0xFF39FF14) else Color(0xFFFF9900)
                            ) {
                                Text(
                                    text = if (isInfluxStreaming) "${String.format(java.util.Locale.US, "%.0f", influxWriteRate)} PPS" else "PAUSED",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Badge(
                                containerColor = Color(0xFF0F1A24),
                                contentColor = Color(0xFF00F0FF)
                            ) {
                                Text(
                                    text = "${influxTotalPoints} PTS",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    InfluxDbServiceWrapper.toggleStreaming()
                                    speechEngine.speak(if (isInfluxStreaming) "InfluxDB surveillance telemetry stream paused." else "InfluxDB stream resumed at ${String.format(java.util.Locale.US, "%.0f", influxWriteRate)} points per second.")
                                },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    imageVector = if (isInfluxStreaming) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                    contentDescription = "Toggle Influx Stream",
                                    tint = if (isInfluxStreaming) Color(0xFF39FF14) else Color(0xFFFF9900),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            FilledTonalButton(
                                onClick = { showInfluxPanel = !showInfluxPanel },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = if (showInfluxPanel) Color(0xFF005566) else Color(0xFF131D2E),
                                    contentColor = Color(0xFF00F0FF)
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(26.dp)
                            ) {
                                Icon(
                                    imageVector = if (showInfluxPanel) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = "Toggle Telemetry Panel",
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(if (showInfluxPanel) "HIDE" else "HUD SENSORS", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Expandable Influx Real-Time Telemetry Details
                    AnimatedVisibility(visible = showInfluxPanel) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Active Anomaly Alert Banner if present
                            if (anomalyActiveNode != null) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF3B000E),
                                    border = BorderStroke(1.dp, Color(0xFFFF3366)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Warning, contentDescription = "Anomaly", tint = Color(0xFFFF3366), modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "ANOMALY INJECTED: Node $anomalyActiveNode Latency & Thermal Spike!",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFFFF99AA),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.sp
                                            )
                                        }
                                        TextButton(
                                            onClick = { InfluxDbServiceWrapper.clearAnomaly() },
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                            modifier = Modifier.height(22.dp)
                                        ) {
                                            Text("RESET", color = Color(0xFFFF3366), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // Real-Time Sensor Metrics Cards for focused node
                            currentNode?.let { node ->
                                val telem = currentInflux
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // 1. Latency Metric Card
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFF0E1624),
                                        border = BorderStroke(0.8.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(modifier = Modifier.padding(6.dp)) {
                                            Text("TSM LATENCY", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                                            Text(
                                                text = "${telem?.latencyMs ?: node.latencyMs} ms",
                                                fontSize = 13.sp,
                                                color = if ((telem?.latencyMs ?: node.latencyMs) > 100) Color(0xFFFF3366) else Color(0xFF00F0FF),
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }

                                    // 2. FLIR Thermal Sensor Card
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFF0E1624),
                                        border = BorderStroke(0.8.dp, Color(0xFFFF9900).copy(alpha = 0.4f)),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(modifier = Modifier.padding(6.dp)) {
                                            Text("FLIR THERMAL", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                                            Text(
                                                text = "${String.format(java.util.Locale.US, "%.1f", telem?.thermalTempC ?: 34.0f)}°C",
                                                fontSize = 13.sp,
                                                color = if ((telem?.thermalTempC ?: 34.0f) > 50f) Color(0xFFFF3366) else Color(0xFFFF9900),
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }

                                    // 3. Bitrate Throughput Card
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFF0E1624),
                                        border = BorderStroke(0.8.dp, Color(0xFF39FF14).copy(alpha = 0.4f)),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(modifier = Modifier.padding(6.dp)) {
                                            Text("THROUGHPUT", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                                            Text(
                                                text = "${String.format(java.util.Locale.US, "%.1f", telem?.bitrateMbps ?: node.bitrateMbps)}M",
                                                fontSize = 13.sp,
                                                color = Color(0xFF39FF14),
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }

                                    // 4. AI Confidence / Packet Loss Card
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFF0E1624),
                                        border = BorderStroke(0.8.dp, Color(0xFFBD00FF).copy(alpha = 0.4f)),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(modifier = Modifier.padding(6.dp)) {
                                            Text("AI CONF / LOSS", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                                            Text(
                                                text = "${String.format(java.util.Locale.US, "%.0f", telem?.aiConfidencePct ?: 95f)}% / ${String.format(java.util.Locale.US, "%.1f", telem?.packetLossPct ?: 0f)}%",
                                                fontSize = 10.sp,
                                                color = Color(0xFFBD00FF),
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }

                                // Real-Time Sparkline Waveform Canvas
                                if (currentLatHistory.isNotEmpty() || currentThermalHistory.isNotEmpty()) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFF04060A),
                                        border = BorderStroke(0.8.dp, Color(0xFF1E293B)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(55.dp)
                                    ) {
                                        Row(modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 4.dp)) {
                                            Column(
                                                modifier = Modifier.width(60.dp).fillMaxHeight(),
                                                verticalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("WAVEFORM", fontSize = 7.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Box(modifier = Modifier.size(5.dp).background(Color(0xFF00F0FF)))
                                                    Spacer(modifier = Modifier.width(3.dp))
                                                    Text("Lat", fontSize = 8.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                                                }
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Box(modifier = Modifier.size(5.dp).background(Color(0xFFFF9900)))
                                                    Spacer(modifier = Modifier.width(3.dp))
                                                    Text("Temp", fontSize = 8.sp, color = Color(0xFFFF9900), fontFamily = FontFamily.Monospace)
                                                }
                                            }

                                            Canvas(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                                // Draw zero line
                                                drawLine(
                                                    color = Color(0xFF1E293B),
                                                    start = Offset(0f, size.height - 1f),
                                                    end = Offset(size.width, size.height - 1f),
                                                    strokeWidth = 1f
                                                )

                                                // Draw Latency Waveform
                                                if (currentLatHistory.size > 1) {
                                                    val maxLat = (currentLatHistory.maxOrNull() ?: 100f).coerceAtLeast(60f)
                                                    val stepX = size.width / (currentLatHistory.size - 1).coerceAtLeast(1)
                                                    val path = Path()
                                                    currentLatHistory.forEachIndexed { i, v ->
                                                        val x = i * stepX
                                                        val norm = (v / maxLat).coerceIn(0f, 1f)
                                                        val y = size.height - (norm * (size.height - 4f)) - 2f
                                                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                                                    }
                                                    drawPath(path, color = Color(0xFF00F0FF), style = Stroke(width = 1.8f))
                                                }

                                                // Draw Thermal Waveform
                                                if (currentThermalHistory.size > 1) {
                                                    val maxTemp = (currentThermalHistory.maxOrNull() ?: 70f).coerceAtLeast(60f)
                                                    val stepX = size.width / (currentThermalHistory.size - 1).coerceAtLeast(1)
                                                    val path = Path()
                                                    currentThermalHistory.forEachIndexed { i, v ->
                                                        val x = i * stepX
                                                        val norm = (v / maxTemp).coerceIn(0f, 1f)
                                                        val y = size.height - (norm * (size.height - 4f)) - 2f
                                                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                                                    }
                                                    drawPath(path, color = Color(0xFFFF9900), style = Stroke(width = 1.4f))
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Live Line Protocol Feed Snippet
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF020408),
                                border = BorderStroke(0.6.dp, Color(0xFF1E293B)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "INFLUXDB LINE PROTOCOL (STREAMING):",
                                            fontSize = 8.sp,
                                            color = Color(0xFF64748B),
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "bucket: ${InfluxDbServiceWrapper.INFLUX_BUCKET}",
                                            fontSize = 8.sp,
                                            color = Color(0xFF39FF14),
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = latestLineProtocol.ifBlank { "surveillance_telemetry,category=TACTICAL,node_id=CAM-01 latency_ms=18i,bitrate_mbps=4.50,fps=60i,thermal_temp_c=36.50 1726620000000000000" },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF39FF14),
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        maxLines = 2
                                    )
                                }
                            }

                            // Action Bar: Simulate Anomaly & Open Full Influx Dashboard
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            val targetId = currentNode?.id ?: "CAM-01"
                                            InfluxDbServiceWrapper.triggerAnomaly(targetId)
                                            speechEngine.speak("Simulating network latency and thermal anomaly on node $targetId. InfluxDB alert triggered.")
                                        },
                                        border = BorderStroke(1.dp, Color(0xFFFF3366).copy(alpha = 0.8f)),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF3366)),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(24.dp)
                                    ) {
                                        Icon(Icons.Default.Bolt, contentDescription = "Anomaly", modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("INJECT ANOMALY", fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }

                                Button(
                                    onClick = { onNavigateTab(26) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003844)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(24.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "InfluxDB Dashboard", modifier = Modifier.size(12.dp), tint = Color(0xFF00F0FF))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("INFLUX DASHBOARD (TAB 26)", fontSize = 8.sp, color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }

            // Category Filter Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val categories = listOf(
                    "ALL" to "ALL (${nodes.size})",
                    "TACTICAL" to "TACTICAL (${nodes.count { it.category == "TACTICAL" }})",
                    "WORLD_CAMS" to "WORLD CAMS (${nodes.count { it.category == "WORLD_CAMS" }})",
                    "STREAMS" to "STREAMS PUBSUB (${nodes.count { it.category == "STREAMS" }})",
                    "RADAR_TOPO" to "RADAR & TOPO (${nodes.count { it.category == "RADAR_TOPO" }})",
                    "PHOTO_SPHERE" to "360 PHOTO (${nodes.count { it.category == "PHOTO_SPHERE" }})",
                    "HARDWARE_AI" to "HARDWARE & AI (${nodes.count { it.category == "HARDWARE_AI" }})"
                )

                items(categories) { (catKey, label) ->
                    FilterChip(
                        selected = selectedCategory == catKey,
                        onClick = { selectedCategory = catKey },
                        label = { Text(label, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF005566),
                            selectedLabelColor = Color(0xFF00F0FF),
                            containerColor = Color(0xFF0D111A),
                            labelColor = Color(0xFF94A3B8)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedCategory == catKey,
                            borderColor = Color(0xFF1E293B),
                            selectedBorderColor = Color(0xFF00F0FF)
                        )
                    )
                }
            }

            // Controls Bar: Symmetry Folds & Speed
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0E121B),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("Wedges:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF00F0FF), fontSize = 11.sp)
                        listOf(6, 8, 12, 16, 24).forEach { folds ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (symmetryFolds == folds) Color(0xFFBD00FF) else Color(0xFF1A2234))
                                    .clickable { symmetryFolds = folds }
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${folds}f",
                                    fontSize = 10.sp,
                                    color = if (symmetryFolds == folds) Color.White else Color(0xFF94A3B8),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "${String.format(java.util.Locale.US, "%.1f", rotationSpeed)}x",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF39FF14),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF1A2234))
                                .clickable { rotationSpeed = maxOf(0.0f, rotationSpeed - 0.5f) },
                            contentAlignment = Alignment.Center
                        ) { Text("-", color = Color.White, fontSize = 12.sp) }

                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF1A2234))
                                .clickable { rotationSpeed = minOf(5.0f, rotationSpeed + 0.5f) },
                            contentAlignment = Alignment.Center
                        ) { Text("+", color = Color.White, fontSize = 12.sp) }
                    }
                }
            }

            // Polygonal Wedge Reflection Stage with Live Feed Projection & Touch Gestures
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF05070B),
                border = BorderStroke(1.5.dp, if (currentNode?.isConnected == true) Color(0xFF00F0FF).copy(alpha = 0.8f) else Color(0xFF334155)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, _, zoom, rotation ->
                                scaleFactor = (scaleFactor * zoom).coerceIn(0.5f, 3.0f)
                                userRotation += rotation
                            }
                        }
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                    ) {
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val radius = minOf(size.width, size.height) * 0.44f * scaleFactor

                        // 1. Draw Feed-specific simulated visual projection in background
                        drawFeedVisualSimulation(
                            node = currentNode,
                            pulseAlpha = pulseAlpha,
                            sweepAngle = sweepAngle,
                            center = center,
                            radius = radius
                        )

                        // 2. Draw real-time N-fold symmetry wedges
                        for (i in 0 until symmetryFolds) {
                            val angleRad = Math.toRadians((totalRotation + i * angleStep).toDouble())
                            val nextAngleRad = Math.toRadians((totalRotation + (i + 1) * angleStep).toDouble())

                            val x1 = center.x + (radius * cos(angleRad)).toFloat()
                            val y1 = center.y + (radius * sin(angleRad)).toFloat()
                            val x2 = center.x + (radius * cos(nextAngleRad)).toFloat()
                            val y2 = center.y + (radius * sin(nextAngleRad)).toFloat()

                            val wedgePath = Path().apply {
                                moveTo(center.x, center.y)
                                lineTo(x1, y1)
                                lineTo(x2, y2)
                                close()
                            }

                            val colorBase = if (i % 2 == 0) Color(0xFFBD00FF) else Color(0xFF00F0FF)
                            drawPath(
                                path = wedgePath,
                                color = colorBase.copy(alpha = 0.12f)
                            )
                            drawPath(
                                path = wedgePath,
                                color = colorBase.copy(alpha = 0.55f),
                                style = Stroke(width = 1.2f)
                            )
                        }

                        // Center core pulsing reticle & feed status ring
                        drawCircle(
                            color = if (currentNode?.isConnected == true) Color(0xFF39FF14).copy(alpha = pulseAlpha) else Color(0xFFFF9900).copy(alpha = 0.5f),
                            radius = radius * 0.22f,
                            center = center,
                            style = Stroke(width = 2.5f)
                        )

                        drawCircle(
                            color = Color(0xFF00F0FF).copy(alpha = 0.4f),
                            radius = radius * 0.08f,
                            center = center
                        )
                    }

                    // Feed Status & Control Overlays
                    currentNode?.let { node ->
                        // Top-left node badge
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Badge(
                                containerColor = if (node.isConnected) Color(0xFF003816) else Color(0xFF381400),
                                contentColor = if (node.isConnected) Color(0xFF39FF14) else Color(0xFFFF9900)
                            ) {
                                Text(
                                    text = if (node.isConnected) "LIVE FEED: ${node.id}" else "OFFLINE: ${node.id}",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                            Badge(containerColor = Color(0xFF0E1A29), contentColor = Color(0xFF00F0FF)) {
                                Text(node.resolution, fontSize = 8.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                            }
                            Badge(containerColor = Color(0xFF0E1A29), contentColor = Color(0xFF39FF14)) {
                                Text("${node.fps} FPS", fontSize = 8.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                            }
                        }

                        // Top-right direct module jump
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    val speech = "Feed ${node.id}: ${node.sector}. ${node.description}"
                                    speechEngine.speak(speech)
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.VolumeUp, contentDescription = "Listen", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                            }

                            if (node.targetTab != 8) {
                                Button(
                                    onClick = { onNavigateTab(node.targetTab) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003344)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Open", modifier = Modifier.size(12.dp), tint = Color(0xFF00F0FF))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("OPEN", fontSize = 9.sp, color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Bottom-left telemetry info
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = node.sector,
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            val telem = currentInflux
                            val influxSuffix = if (telem != null) {
                                " | FLIR: ${String.format(java.util.Locale.US, "%.1f", telem.thermalTempC)}°C | Loss: ${String.format(java.util.Locale.US, "%.1f", telem.packetLossPct)}% [INFLUX]"
                            } else ""
                            Text(
                                text = "${node.protocol} | ${node.coordinates} | Lat: ${telem?.latencyMs ?: node.latencyMs}ms | ${String.format(java.util.Locale.US, "%.1f", telem?.bitrateMbps ?: node.bitrateMbps)} Mbps$influxSuffix",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Bottom-right link toggle
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(10.dp)
                        ) {
                            IconButton(
                                onClick = { onToggleFeedConnection(node.id) },
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(if (node.isConnected) Color(0xFF004D25) else Color(0xFF262626))
                            ) {
                                Icon(
                                    imageVector = if (node.isConnected) Icons.Default.Link else Icons.Default.LinkOff,
                                    contentDescription = "Toggle Link",
                                    tint = if (node.isConnected) Color(0xFF39FF14) else Color(0xFF94A3B8),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Feeds Grid Header with count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CONNECTED HUD FEEDS (${filteredNodes.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color(0xFF00F0FF),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Tap node to inspect on kaleidoscope stage",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B),
                    fontSize = 10.sp
                )
            }

            // Connected External Nodes Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredNodes, key = { it.id }) { node ->
                    SurveillanceNodeCard(
                        node = node,
                        isSelected = activeNode?.id == node.id,
                        influxTelemetry = influxTelemetryMap[node.id],
                        onClick = { onSelectNode(node) },
                        onToggleConnect = { onToggleFeedConnection(node.id) },
                        onDirectOpen = { onNavigateTab(node.targetTab) }
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawFeedVisualSimulation(
    node: SurveillanceNode?,
    pulseAlpha: Float,
    sweepAngle: Float,
    center: Offset,
    radius: Float
) {
    if (node == null || !node.isConnected) {
        // Offline crosshatch
        drawLine(
            color = Color(0xFF334155).copy(alpha = 0.3f),
            start = Offset(center.x - radius, center.y - radius),
            end = Offset(center.x + radius, center.y + radius),
            strokeWidth = 1f
        )
        drawLine(
            color = Color(0xFF334155).copy(alpha = 0.3f),
            start = Offset(center.x - radius, center.y + radius),
            end = Offset(center.x + radius, center.y - radius),
            strokeWidth = 1f
        )
        return
    }

    when (node.feedType) {
        "WEATHER_RADAR" -> {
            // Concentric radar range rings
            drawCircle(color = Color(0xFF00F0FF).copy(alpha = 0.2f), radius = radius * 0.8f, center = center, style = Stroke(1f))
            drawCircle(color = Color(0xFF00F0FF).copy(alpha = 0.2f), radius = radius * 0.5f, center = center, style = Stroke(1f))
            drawCircle(color = Color(0xFF00F0FF).copy(alpha = 0.2f), radius = radius * 0.25f, center = center, style = Stroke(1f))

            // Radar sweep line
            val rad = Math.toRadians(sweepAngle.toDouble())
            val endX = center.x + (radius * cos(rad)).toFloat()
            val endY = center.y + (radius * sin(rad)).toFloat()
            drawLine(
                color = Color(0xFF39FF14).copy(alpha = 0.8f),
                start = center,
                end = Offset(endX, endY),
                strokeWidth = 2f
            )

            // Simulated storm cell blips
            drawCircle(color = Color(0xFFFF3366).copy(alpha = pulseAlpha), radius = 10f, center = Offset(center.x + radius * 0.4f, center.y - radius * 0.3f))
            drawCircle(color = Color(0xFFFFCC00).copy(alpha = pulseAlpha * 0.8f), radius = 14f, center = Offset(center.x - radius * 0.5f, center.y + radius * 0.2f))
        }

        "ALTO_MAPS" -> {
            // Topographic contour lines
            for (r in 1..4) {
                drawCircle(
                    color = Color(0xFFFF9900).copy(alpha = 0.25f),
                    radius = radius * (r * 0.2f),
                    center = Offset(center.x + (r * 8f), center.y - (r * 5f)),
                    style = Stroke(width = 1.2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f)))
                )
            }
            // Altimeter elevation crosshair
            drawLine(
                color = Color(0xFFFF9900).copy(alpha = 0.6f),
                start = Offset(center.x - radius * 0.6f, center.y),
                end = Offset(center.x + radius * 0.6f, center.y),
                strokeWidth = 1f
            )
        }

        "PHOTO_SPHERE" -> {
            // Equirectangular 360 spherical grid lines
            for (deg in listOf(-45, 0, 45)) {
                val yOffset = center.y + (radius * (deg / 90f) * 0.6f)
                drawLine(
                    color = Color(0xFF00F0FF).copy(alpha = 0.35f),
                    start = Offset(center.x - radius * 0.8f, yOffset),
                    end = Offset(center.x + radius * 0.8f, yOffset),
                    strokeWidth = 1f
                )
            }
            // VR 360 compass reticle
            drawCircle(
                color = Color(0xFFBD00FF).copy(alpha = 0.5f),
                radius = radius * 0.35f,
                center = center,
                style = Stroke(width = 1.5f)
            )
        }

        "ROBOTICS_LIDAR" -> {
            // Rotating LIDAR point cloud particles
            for (p in 0..16) {
                val pAngle = Math.toRadians((sweepAngle * 1.5f + p * 22.5f).toDouble())
                val dist = radius * (0.3f + ((p % 5) * 0.12f))
                val px = center.x + (dist * cos(pAngle)).toFloat()
                val py = center.y + (dist * sin(pAngle)).toFloat()
                drawCircle(color = Color(0xFF39FF14).copy(alpha = 0.8f), radius = 3.5f, center = Offset(px, py))
            }
        }

        "FACE_VISION" -> {
            // Biometric face tracking mesh box
            val boxSize = radius * 0.6f
            drawRect(
                color = Color(0xFF00F0FF).copy(alpha = pulseAlpha),
                topLeft = Offset(center.x - boxSize / 2f, center.y - boxSize / 2f),
                size = Size(boxSize, boxSize),
                style = Stroke(1.5f)
            )
            // Facial landmarks
            drawCircle(color = Color(0xFF39FF14), radius = 3f, center = Offset(center.x - boxSize * 0.2f, center.y - boxSize * 0.15f))
            drawCircle(color = Color(0xFF39FF14), radius = 3f, center = Offset(center.x + boxSize * 0.2f, center.y - boxSize * 0.15f))
            drawCircle(color = Color(0xFF39FF14), radius = 2.5f, center = Offset(center.x, center.y + boxSize * 0.05f))
            drawCircle(color = Color(0xFF39FF14), radius = 3f, center = Offset(center.x, center.y + boxSize * 0.2f))
        }

        else -> {
            // Tactical Cam / World Cam / Stream PubSub Video simulation
            // Horizontal scanlines
            for (y in (center.y - radius).toInt()..(center.y + radius).toInt() step 12) {
                drawLine(
                    color = Color(0xFF00F0FF).copy(alpha = 0.07f),
                    start = Offset(center.x - radius, y.toFloat()),
                    end = Offset(center.x + radius, y.toFloat()),
                    strokeWidth = 1f
                )
            }

            // Target bracket reticle
            val bracketSize = radius * 0.35f
            // Corners
            val tl = Offset(center.x - bracketSize, center.y - bracketSize)
            val tr = Offset(center.x + bracketSize, center.y - bracketSize)
            val bl = Offset(center.x - bracketSize, center.y + bracketSize)
            val br = Offset(center.x + bracketSize, center.y + bracketSize)
            val cColor = if (node.threatLevel == "High") Color(0xFFFF3366) else Color(0xFF00F0FF)

            drawLine(color = cColor, start = tl, end = Offset(tl.x + 16f, tl.y), strokeWidth = 2f)
            drawLine(color = cColor, start = tl, end = Offset(tl.x, tl.y + 16f), strokeWidth = 2f)

            drawLine(color = cColor, start = tr, end = Offset(tr.x - 16f, tr.y), strokeWidth = 2f)
            drawLine(color = cColor, start = tr, end = Offset(tr.x, tr.y + 16f), strokeWidth = 2f)

            drawLine(color = cColor, start = bl, end = Offset(bl.x + 16f, bl.y), strokeWidth = 2f)
            drawLine(color = cColor, start = bl, end = Offset(bl.x, bl.y - 16f), strokeWidth = 2f)

            drawLine(color = cColor, start = br, end = Offset(br.x - 16f, br.y), strokeWidth = 2f)
            drawLine(color = cColor, start = br, end = Offset(br.x, br.y - 16f), strokeWidth = 2f)
        }
    }
}

@Composable
fun SurveillanceNodeCard(
    node: SurveillanceNode,
    isSelected: Boolean,
    influxTelemetry: InfluxNodeTelemetry? = null,
    onClick: () -> Unit,
    onToggleConnect: () -> Unit,
    onDirectOpen: () -> Unit
) {
    val borderColor = if (isSelected) Color(0xFF39FF14) else if (influxTelemetry?.isAnomaly == true) Color(0xFFFF3366) else if (node.isConnected) Color(0xFF1E293B) else Color(0xFF331E1E)
    val backgroundColor = if (isSelected) Color(0xFF05240A).copy(alpha = 0.5f) else Color(0xFF0A0C13)

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = backgroundColor,
        border = BorderStroke(1.5.dp, borderColor),
        modifier = Modifier
            .fillMaxWidth()
            .height(138.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (node.isConnected) Color(0xFF39FF14) else Color(0xFF64748B))
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = node.id,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (node.isConnected) Color(0xFF00F0FF) else Color(0xFF64748B),
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (influxTelemetry?.isAnomaly == true) {
                        Badge(containerColor = Color(0xFF6B0014), contentColor = Color(0xFFFF3366)) {
                            Text("SPIKE", fontSize = 8.sp, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                        }
                    } else if (influxTelemetry != null) {
                        Badge(
                            containerColor = if (influxTelemetry.thermalTempC > 45f) Color(0xFF6B3A00) else Color(0xFF0A2E12),
                            contentColor = if (influxTelemetry.thermalTempC > 45f) Color(0xFFFF9900) else Color(0xFF39FF14)
                        ) {
                            Text("${String.format(java.util.Locale.US, "%.0f", influxTelemetry.thermalTempC)}°C", fontSize = 8.sp, modifier = Modifier.padding(horizontal = 2.dp, vertical = 1.dp))
                        }
                    }

                    Badge(
                        containerColor = when (node.threatLevel) {
                            "High" -> Color(0xFF6B0000)
                            "Elevated" -> Color(0xFF6B4200)
                            else -> Color(0xFF0A3800)
                        },
                        contentColor = Color.White
                    ) {
                        Text(node.threatLevel, fontSize = 8.sp, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(if (node.isConnected) Color(0xFF003D1A) else Color(0xFF262626))
                            .clickable { onToggleConnect() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (node.isConnected) Icons.Default.Link else Icons.Default.LinkOff,
                            contentDescription = "Link",
                            tint = if (node.isConnected) Color(0xFF39FF14) else Color(0xFF94A3B8),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }

            Column {
                Text(
                    text = node.sector,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    maxLines = 2
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${node.protocol} • ${node.resolution}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B),
                    fontSize = 9.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val liveLat = influxTelemetry?.latencyMs ?: node.latencyMs
                val liveBitrate = influxTelemetry?.bitrateMbps ?: node.bitrateMbps
                Text(
                    text = "${liveLat}ms | ${node.fps}FPS | ${String.format(java.util.Locale.US, "%.1f", liveBitrate)}M",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (liveLat > 100) Color(0xFFFF9900) else Color(0xFF39FF14),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )

                if (node.targetTab != 8) {
                    Text(
                        text = "OPEN →",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF00F0FF),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onDirectOpen() }
                    )
                }
            }
        }
    }
}
