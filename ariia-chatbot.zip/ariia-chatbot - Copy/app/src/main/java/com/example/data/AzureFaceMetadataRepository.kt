package com.example.data

data class SurveillanceIdentifiedFace(
    val faceId: String,
    val name: String,
    val clearance: String,
    val department: String,
    val livenessScore: Float,
    val boundingBox: android.graphics.Rect?,
    val isKnown: Boolean
)

class AzureFaceMetadataRepository {
    private val knownPersonnel = listOf(
        DeepSeekPerson("DS-001", "Dr. Elena Vance", "Chief Neural Architect", "Level 5 - Omega", "AI Research", "Verified Liveness", 0.99f),
        DeepSeekPerson("DS-002", "Marcus Thorne", "Director of Cyber Defense", "Level 4 - Secured", "Security Ops", "Verified Liveness", 0.96f),
        DeepSeekPerson("DS-003", "Aria Lin", "Quantum Cryptographer", "Level 4 - Secured", "Core Encryption", "Verified Liveness", 0.98f),
        DeepSeekPerson("DS-005", "Dr. Sarah Chen", "Bio-Metric Intelligence Lead", "Level 5 - Omega", "Biometrics", "Verified Liveness", 0.99f)
    )

    fun mapBoundingBoxToUser(faceIndex: Int, boundingBox: android.graphics.Rect?): SurveillanceIdentifiedFace {
        val person = knownPersonnel.getOrNull(faceIndex % knownPersonnel.size)
        return if (person != null) {
            SurveillanceIdentifiedFace(
                faceId = person.id,
                name = person.name,
                clearance = person.clearanceLevel,
                department = person.department,
                livenessScore = person.livenessScore,
                boundingBox = boundingBox,
                isKnown = true
            )
        } else {
            SurveillanceIdentifiedFace(
                faceId = "UNKNOWN-${System.currentTimeMillis()}",
                name = "Unidentified Subject",
                clearance = "Level 0 - Restricted",
                department = "External Zone",
                livenessScore = 0.92f,
                boundingBox = boundingBox,
                isKnown = false
            )
        }
    }
}
