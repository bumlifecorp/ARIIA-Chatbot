package com.example.ui.screens.earth

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

@Composable
fun Globe3DView(
    activeTarget: TacticalTarget,
    presetTargets: List<TacticalTarget>,
    satellites: List<OrbitalSatellite>,
    selectedSatellite: OrbitalSatellite,
    selectedLayer: EarthLayer,
    is3dElevationMode: Boolean,
    showWeatherRadar: Boolean,
    showDayNightTerminator: Boolean,
    yawDeg: Float,
    pitchDeg: Float,
    zoomLevel: Float,
    onYawPitchChange: (Float, Float) -> Unit,
    onZoomChange: (Float) -> Unit,
    onTargetSelected: (TacticalTarget) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "GlobeTransitions")
    val orbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Restart),
        label = "OrbitMotion"
    )
    val beaconPulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 2.4f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "BeaconPulse"
    )
    val radarSweep by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "RadarSweep"
    )

    Box(
        modifier = modifier
            .background(Color(0xFF020408), RoundedCornerShape(14.dp))
            .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.3f), RoundedCornerShape(14.dp))
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    val newYaw = yawDeg - dragAmount.x * 0.45f
                    val newPitch = (pitchDeg + dragAmount.y * 0.45f).coerceIn(-85f, 85f)
                    onYawPitchChange(newYaw, newPitch)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val center = Offset(w / 2f, h / 2f)
            val baseRadius = (minOf(w, h) * 0.38f) * zoomLevel
            val globeRadius = baseRadius.coerceAtLeast(30f)

            // 1. Atmospheric Glow
            val atmosphereColor = when (selectedLayer) {
                EarthLayer.OPTICAL -> Color(0xFF0099FF)
                EarthLayer.SAR_RADAR -> Color(0xFF00FF88)
                EarthLayer.THERMAL_IR -> Color(0xFFFF2200)
                EarthLayer.NIGHT_OPS -> Color(0xFF220044)
                EarthLayer.TOPOGRAPHICAL -> Color(0xFF8800FF)
            }

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(atmosphereColor.copy(alpha = 0.35f), atmosphereColor.copy(alpha = 0.05f), Color.Transparent),
                    center = center,
                    radius = globeRadius * 1.35f
                ),
                radius = globeRadius * 1.35f,
                center = center
            )

            // 2. Base Sphere Fill
            val sphereBase = when (selectedLayer) {
                EarthLayer.OPTICAL -> Color(0xFF051D3B)
                EarthLayer.SAR_RADAR -> Color(0xFF011412)
                EarthLayer.THERMAL_IR -> Color(0xFF1F0404)
                EarthLayer.NIGHT_OPS -> Color(0xFF020308)
                EarthLayer.TOPOGRAPHICAL -> Color(0xFF10051C)
            }
            drawCircle(color = sphereBase, radius = globeRadius, center = center)

            // 3. Parallels (Latitude lines)
            val latSteps = listOf(-60f, -30f, 0f, 30f, 60f)
            latSteps.forEach { lat ->
                val isEquator = lat == 0f
                val latRad = Math.toRadians(lat.toDouble())
                val pitchRad = Math.toRadians(pitchDeg.toDouble())

                val rLat = (globeRadius * cos(latRad)).toFloat()
                val yCenter = center.y - (globeRadius * sin(latRad) * cos(pitchRad)).toFloat()
                val hLat = (rLat * sin(pitchRad)).toFloat().absoluteValue

                val lineColor = if (isEquator) Color(0xFF00F0FF).copy(alpha = 0.5f) else Color(0xFF00F0FF).copy(alpha = 0.15f)
                drawOval(
                    color = lineColor,
                    topLeft = Offset(center.x - rLat, yCenter - hLat),
                    size = Size(rLat * 2f, maxOf(hLat * 2f, 1f)),
                    style = Stroke(if (isEquator) 1.5f else 0.8f)
                )
            }

            // 4. Meridians (Longitude lines)
            for (lon in 0 until 360 step 30) {
                val relLon = (lon - yawDeg) % 360f
                val relLonRad = Math.toRadians(relLon.toDouble())

                if (cos(relLonRad) > -0.2) {
                    val alpha = (cos(relLonRad).toFloat() + 0.2f).coerceIn(0.05f, 0.4f)
                    val xOffset = (globeRadius * sin(relLonRad)).toFloat()

                    drawOval(
                        color = Color(0xFF00F0FF).copy(alpha = alpha * 0.4f),
                        topLeft = Offset(center.x + xOffset - (globeRadius * 0.1f), center.y - globeRadius),
                        size = Size(globeRadius * 0.2f, globeRadius * 2f),
                        style = Stroke(0.8f)
                    )
                }
            }

            // 5. Continents and Landmass Patches
            val continentSeeds = listOf(
                Triple(40f, -100f, "North America"),
                Triple(-15f, -60f, "South America"),
                Triple(50f, 15f, "Europe"),
                Triple(10f, 25f, "Africa"),
                Triple(45f, 90f, "Asia"),
                Triple(-25f, 135f, "Australia")
            )

            val landColor = when (selectedLayer) {
                EarthLayer.OPTICAL -> Color(0xFF1E5B2E).copy(alpha = 0.7f)
                EarthLayer.SAR_RADAR -> Color(0xFF39FF14).copy(alpha = 0.45f)
                EarthLayer.THERMAL_IR -> Color(0xFFFF5500).copy(alpha = 0.5f)
                EarthLayer.NIGHT_OPS -> Color(0xFFFFEE88).copy(alpha = 0.35f)
                EarthLayer.TOPOGRAPHICAL -> Color(0xFFBD00FF).copy(alpha = 0.5f)
            }

            continentSeeds.forEach { (cLat, cLon, _) ->
                val phi = Math.toRadians(cLat.toDouble())
                val theta = Math.toRadians((cLon - yawDeg).toDouble())
                val pitchR = Math.toRadians(pitchDeg.toDouble())

                val x3 = cos(phi) * sin(theta)
                val y3 = sin(phi)
                val z3 = cos(phi) * cos(theta)

                val yRot = y3 * cos(pitchR) - z3 * sin(pitchR)
                val zRot = y3 * sin(pitchR) + z3 * cos(pitchR)

                if (zRot > 0) {
                    val px = center.x + (globeRadius * x3).toFloat()
                    val py = center.y - (globeRadius * yRot).toFloat()
                    val patchRadius = (globeRadius * 0.28f * (zRot.toFloat())).coerceAtLeast(8f)

                    drawCircle(color = landColor, radius = patchRadius, center = Offset(px, py))
                }
            }

            // 6. Day/Night Solar Terminator Shadow & City Lights
            if (showDayNightTerminator) {
                // Approximate solar longitude based on current UTC time (~16:08 UTC => Sun near -62 deg Lon)
                val solarLon = -62f
                val relSolarLon = (solarLon - yawDeg)
                val sunPhi = Math.toRadians(0.0) // Near Equinox
                val sunTheta = Math.toRadians(relSolarLon.toDouble())
                val sunZ = (cos(sunPhi) * cos(sunTheta)).toFloat()

                // Semi-transparent night shadow overlay
                val nightCenterOffset = if (sunZ > 0) -globeRadius * 0.35f else globeRadius * 0.35f
                drawCircle(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color(0xCC00030B)),
                        start = Offset(center.x - globeRadius, center.y),
                        end = Offset(center.x + globeRadius, center.y)
                    ),
                    radius = globeRadius,
                    center = center
                )

                // Shimmering nocturnal city light clusters on night hemisphere
                val cityLights = listOf(
                    Pair(40.71f, -74.00f), // NYC
                    Pair(51.50f, -0.12f),  // London
                    Pair(48.85f, 2.35f),   // Paris
                    Pair(35.67f, 139.65f), // Tokyo
                    Pair(31.23f, 121.47f), // Shanghai
                    Pair(25.20f, 55.27f)   // Dubai
                )
                cityLights.forEach { (cLat, cLon) ->
                    val phi = Math.toRadians(cLat.toDouble())
                    val theta = Math.toRadians((cLon - yawDeg).toDouble())
                    val pitchR = Math.toRadians(pitchDeg.toDouble())

                    val x3 = cos(phi) * sin(theta)
                    val y3 = sin(phi)
                    val z3 = cos(phi) * cos(theta)

                    val yRot = y3 * cos(pitchR) - z3 * sin(pitchR)
                    val zRot = y3 * sin(pitchR) + z3 * cos(pitchR)

                    if (zRot > 0.1) {
                        val cx = center.x + (globeRadius * x3).toFloat()
                        val cy = center.y - (globeRadius * yRot).toFloat()
                        drawCircle(
                            color = Color(0xFFFFCC33).copy(alpha = 0.75f),
                            radius = 2.5.dp.toPx(),
                            center = Offset(cx, cy)
                        )
                    }
                }
            }

            // 7. Live Weather Radar & Storm Vortexes
            if (showWeatherRadar) {
                val stormCells = listOf(
                    Triple(24f, -70f, 32f), // Atlantic Hurricane
                    Triple(16f, 130f, 36f), // Pacific Typhoon
                    Triple(48f, -15f, 24f)  // North Atlantic Low
                )

                stormCells.forEach { (sLat, sLon, sRadiusKm) ->
                    val phi = Math.toRadians(sLat.toDouble())
                    val theta = Math.toRadians((sLon - yawDeg).toDouble())
                    val pitchR = Math.toRadians(pitchDeg.toDouble())

                    val x3 = cos(phi) * sin(theta)
                    val y3 = sin(phi)
                    val z3 = cos(phi) * cos(theta)

                    val yRot = y3 * cos(pitchR) - z3 * sin(pitchR)
                    val zRot = y3 * sin(pitchR) + z3 * cos(pitchR)

                    if (zRot > 0) {
                        val sx = center.x + (globeRadius * x3).toFloat()
                        val sy = center.y - (globeRadius * yRot).toFloat()

                        // Rotating radar spiral
                        drawCircle(
                            brush = Brush.sweepGradient(
                                colors = listOf(Color(0xFF39FF14).copy(alpha = 0.5f), Color(0xFFFF0055).copy(alpha = 0.4f), Color.Transparent),
                                center = Offset(sx, sy)
                            ),
                            radius = (globeRadius * 0.18f * zRot.toFloat()).coerceAtLeast(10f),
                            center = Offset(sx, sy)
                        )
                    }
                }
            }

            // 8. Satellite Orbits and Moving Constellations
            satellites.forEachIndexed { idx, sat ->
                val isSelected = sat.noradId == selectedSatellite.noradId
                val orbitRadius = globeRadius * (1.18f + idx * 0.12f)

                drawOval(
                    color = sat.orbitColor.copy(alpha = if (isSelected) 0.5f else 0.2f),
                    topLeft = Offset(center.x - orbitRadius, center.y - orbitRadius * 0.45f),
                    size = Size(orbitRadius * 2f, orbitRadius * 0.9f),
                    style = Stroke(if (isSelected) 1.5f else 0.8f)
                )

                val movingRad = Math.toRadians((orbitAngle + idx * 90.0) % 360.0)
                val satX = center.x + (orbitRadius * cos(movingRad)).toFloat()
                val satY = center.y + (orbitRadius * 0.45f * sin(movingRad)).toFloat()

                drawCircle(color = sat.orbitColor, radius = if (isSelected) 5f else 3.5f, center = Offset(satX, satY))
                if (isSelected) {
                    drawCircle(color = sat.orbitColor.copy(alpha = 0.4f), radius = 10f * beaconPulse, center = Offset(satX, satY), style = Stroke(1.2f))
                }
            }

            // 9. Tactical Targets & 3D Extruded Building Models
            presetTargets.forEach { target ->
                val isTargetActive = target.id == activeTarget.id
                val phi = Math.toRadians(target.latitude.toDouble())
                val theta = Math.toRadians((target.longitude - yawDeg).toDouble())
                val pitchR = Math.toRadians(pitchDeg.toDouble())

                val x3 = cos(phi) * sin(theta)
                val y3 = sin(phi)
                val z3 = cos(phi) * cos(theta)

                val yRot = y3 * cos(pitchR) - z3 * sin(pitchR)
                val zRot = y3 * sin(pitchR) + z3 * cos(pitchR)

                if (zRot > 0.05) {
                    val tx = center.x + (globeRadius * x3).toFloat()
                    val ty = center.y - (globeRadius * yRot).toFloat()

                    val pinColor = if (isTargetActive) Color(0xFFFF3366) else Color(0xFF00F0FF)

                    // 3D Isometric Extrusion (Live Earth Map 3D feature)
                    if (is3dElevationMode) {
                        val towerHeight = 16.dp.toPx() * (if (isTargetActive) 1.4f else 1.0f)
                        val topX = tx
                        val topY = ty - towerHeight

                        // Extrusion pillar
                        drawLine(
                            color = pinColor.copy(alpha = 0.7f),
                            start = Offset(tx, ty),
                            end = Offset(topX, topY),
                            strokeWidth = 2.5f
                        )

                        // 3D Building Rooftop diamond
                        val dSize = 5.dp.toPx()
                        val roofPath = Path().apply {
                            moveTo(topX, topY - dSize)
                            lineTo(topX + dSize, topY)
                            lineTo(topX, topY + dSize)
                            lineTo(topX - dSize, topY)
                            close()
                        }
                        drawPath(roofPath, color = pinColor)
                    }

                    // Pulsing beacon ring
                    if (isTargetActive) {
                        drawCircle(
                            color = pinColor.copy(alpha = 0.5f),
                            radius = 8.dp.toPx() * beaconPulse,
                            center = Offset(tx, ty),
                            style = Stroke(1.5f)
                        )
                    }

                    // Core Pin
                    drawCircle(color = pinColor, radius = if (isTargetActive) 5.dp.toPx() else 3.5.dp.toPx(), center = Offset(tx, ty))

                    if (isTargetActive) {
                        val crossLen = 12.dp.toPx()
                        drawLine(pinColor, Offset(tx - crossLen, ty), Offset(tx + crossLen, ty), strokeWidth = 1f)
                        drawLine(pinColor, Offset(tx, ty - crossLen), Offset(tx, ty + crossLen), strokeWidth = 1f)
                    }
                }
            }

            // 10. Globe Outer Rim
            drawCircle(
                color = Color(0xFF00F0FF).copy(alpha = 0.6f),
                radius = globeRadius,
                center = center,
                style = Stroke(1.2f)
            )

            // Central Reticle
            val reticleLen = 14.dp.toPx()
            drawLine(Color(0xFF39FF14).copy(alpha = 0.4f), Offset(center.x - reticleLen, center.y), Offset(center.x + reticleLen, center.y), strokeWidth = 1f)
            drawLine(Color(0xFF39FF14).copy(alpha = 0.4f), Offset(center.x, center.y - reticleLen), Offset(center.x, center.y + reticleLen), strokeWidth = 1f)
        }

        // HUD Overlay Stats (Top-Left)
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
        ) {
            Badge(containerColor = Color(0xFF00222B), contentColor = Color(0xFF00F0FF)) {
                Text("LAT: ${"%.3f".format(pitchDeg)}° | LON: ${"%.3f".format(yawDeg)}°", fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
            Spacer(modifier = Modifier.height(3.dp))
            Badge(containerColor = Color(0xFF0D1C28), contentColor = Color(0xFF39FF14)) {
                Text("ALT: ${(zoomLevel * 1420).toInt()} km (LEO)", fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
            if (is3dElevationMode) {
                Spacer(modifier = Modifier.height(3.dp))
                Badge(containerColor = Color(0xFF331A00), contentColor = Color(0xFFFF9900)) {
                    Text("3D ISOMETRIC ELEVATION ACTIVE", fontSize = 7.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Zoom & Re-Center Controls (Top-Right)
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(
                onClick = { onZoomChange((zoomLevel + 0.2f).coerceAtMost(2.2f)) },
                modifier = Modifier
                    .size(28.dp)
                    .background(Color(0xFF0A1220), CircleShape)
                    .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f), CircleShape)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
            }
            IconButton(
                onClick = { onZoomChange((zoomLevel - 0.2f).coerceAtLeast(0.6f)) },
                modifier = Modifier
                    .size(28.dp)
                    .background(Color(0xFF0A1220), CircleShape)
                    .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f), CircleShape)
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
            }
            IconButton(
                onClick = {
                    onZoomChange(1.0f)
                    onYawPitchChange(activeTarget.longitude, activeTarget.latitude)
                },
                modifier = Modifier
                    .size(28.dp)
                    .background(Color(0xFF0A1220), CircleShape)
                    .border(1.dp, Color(0xFF39FF14).copy(alpha = 0.4f), CircleShape)
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = "Center on Target", tint = Color(0xFF39FF14), modifier = Modifier.size(16.dp))
            }
        }
    }
}
