package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun VoiceCommandsHelpDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = ImmersiveSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RÖSTKOMMANDON",
                        style = MaterialTheme.typography.titleMedium,
                        color = ImmersiveLavender,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Stäng",
                            tint = ImmersiveTextSecondary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Här är några exempel på vad du kan säga:",
                    color = ImmersiveTextPrimary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                val commands = listOf(
                    "Öppna [Appnamn]" to "Exempel: 'Öppna Kalkylator', 'Starta Inställningar'",
                    "Tänd/Släck ficklampan" to "Slår på eller av enhetens ficklampa.",
                    "Starta HUD / Kamera" to "Byter till Vision HUD-läget.",
                    "Visa appar" to "Öppnar appmenyn (App Drawer)."
                )
                
                commands.forEach { (title, desc) ->
                    Column(modifier = Modifier.padding(bottom = 12.dp)) {
                        Text(
                            text = "• $title",
                            color = ImmersiveTextPrimary,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = desc,
                            color = ImmersiveTextMuted,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 12.dp, top = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
