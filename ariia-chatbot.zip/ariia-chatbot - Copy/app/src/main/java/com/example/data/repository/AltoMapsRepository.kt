package com.example.data.repository

import com.example.data.local.AltoMapsTileDao
import com.example.data.local.AltoMapsTileEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class AltoMapsRepository(private val tileDao: AltoMapsTileDao) {
    val tileCountFlow: Flow<Int> = tileDao.getTileCount()

    suspend fun getTile(tileId: String): AltoMapsTileEntity? {
        return withContext(Dispatchers.IO) {
            tileDao.getTileById(tileId)
        }
    }

    suspend fun saveTile(tile: AltoMapsTileEntity) {
        withContext(Dispatchers.IO) {
            tileDao.insertTile(tile)
        }
    }
    
    suspend fun preFetchRegion(tiles: List<AltoMapsTileEntity>) {
        withContext(Dispatchers.IO) {
            tiles.forEach { tileDao.insertTile(it) }
        }
    }

    suspend fun deleteTile(tileId: String) {
        withContext(Dispatchers.IO) {
            tileDao.deleteTile(tileId)
        }
    }

    suspend fun clearCache() {
        withContext(Dispatchers.IO) {
            tileDao.clearAllTiles()
        }
    }

    suspend fun getCacheStats(): Pair<Int, Long> {
        return withContext(Dispatchers.IO) {
            val count = tileDao.getTileCountSync()
            val tiles = tileDao.getAllTiles()
            val totalBytes = tiles.sumOf { it.tileData.size.toLong() }
            Pair(count, totalBytes)
        }
    }
}
