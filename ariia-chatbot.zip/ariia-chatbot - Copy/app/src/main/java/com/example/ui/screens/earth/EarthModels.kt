package com.example.ui.screens.earth

import androidx.compose.ui.graphics.Color

enum class EarthViewMode(val label: String, val badge: String) {
    GLOBE_3D("3D Globe Recon", "ORBIT"),
    ALTO_MAPS("AltoMaps Outdoors", "TOPO GPS"),
    LIVE_EARTH_3D_DROID("Live Earth Map 3D", "DROID 3D"),
    EARTH_3D_FOXPOI("Earth 3D Map FoxPOI", "FOXPOI 3D"),
    MINIFINDER_SUITE("MiniFinder GPS", "TRACKER"),
    PHOTO_SPHERE("Go Photo Sphere", "360° VR"),
    STREET_VIEW("360° Street View", "PANORAMA"),
    WORLD_CAMS("Live Earth Cams", "LIVE FEED"),
    GPS_ROUTE("Tactical Routing", "ROUTE"),
    SPEEDO_COMPASS("Speedo & Compass", "SENSORS"),
    MEASURE_TOOL("Geodesic Measure", "CALC")
}

enum class EarthLayer(val label: String, val description: String) {
    OPTICAL("Optical Satellite", "True-color high-resolution optical imagery with cloud cover layers"),
    SAR_RADAR("SAR Radar Recon", "Synthetic Aperture Radar penetrating clouds, fog, and night terrain"),
    THERMAL_IR("Thermal Infrared", "Heat signatures, active propulsion exhaust, and facility power grids"),
    NIGHT_OPS("Night Operations", "Electromagnetic radiation, nocturnal city illumination, and fiber backbones"),
    TOPOGRAPHICAL("Topographical DEM", "Digital elevation model with 3D terrain contours and fault lines")
}

data class TacticalTarget(
    val id: String,
    val name: String,
    val callsign: String,
    val country: String,
    val timezone: String,
    val latitude: Float,
    val longitude: Float,
    val altitudeMeters: Int,
    val classification: String,
    val summary: String,
    val weatherTempC: Int = 21,
    val weatherCondition: String = "Clear Sky"
)

data class OrbitalSatellite(
    val name: String,
    val noradId: String,
    val orbitAltitudeKm: Int,
    val velocityKmS: Float,
    val inclinationDeg: Float,
    val sensorResolution: String,
    val orbitColor: Color
)

data class WorldCamera(
    val id: String,
    val title: String,
    val location: String,
    val country: String,
    val latitude: Float,
    val longitude: Float,
    val category: String, // Space, Urban, Defense, Harbor
    val resolution: String,
    val fps: Int,
    val bitrateKbps: Int,
    val status: String = "LIVE STREAM ACTIVE",
    val description: String
)

data class PanoramaHotspot(
    val id: String,
    val title: String,
    val yawOffset: Float, // -180 to 180 deg
    val pitchOffset: Float,
    val info: String
)

data class PanoramaLocation(
    val id: String,
    val title: String,
    val sector: String,
    val latitude: Float,
    val longitude: Float,
    val environmentType: String,
    val description: String,
    val hotspots: List<PanoramaHotspot> = emptyList()
)

data class GpsRouteWaypoint(
    val id: String,
    val name: String,
    val lat: Float,
    val lon: Float
)

data class GpsRouteStep(
    val index: Int,
    val instruction: String,
    val distanceKm: Float,
    val bearing: String,
    val etaMinutes: Int
)

data class GeodesicPoint(
    val id: String,
    val label: String,
    val latitude: Float,
    val longitude: Float
)

// AltoMaps Outdoor Expedition & Topo Navigation Models (Foxpoi AltoMaps Suite)
enum class CoordinateSystem(val label: String) {
    LAT_LON_DD("Decimal (DD)"),
    LAT_LON_DMS("Degrees Min Sec (DMS)"),
    MGRS("MGRS Grid"),
    UTM("UTM WGS84"),
    GEOHASH("Geohash"),
    MAIDENHEAD("Maidenhead (QTH)")
}

enum class WaypointCategory(val title: String, val badgeColor: Long) {
    SUMMIT("Peak / Summit", 0xFFFF3366),
    CAMPSITE("Camp Site", 0xFF00F0FF),
    WATER_SOURCE("Water Spring", 0xFF00AAFF),
    TRAILHEAD("Trailhead Origin", 0xFF39FF14),
    CACHE("Supplies Cache", 0xFFFFCC00),
    HAZARD("Crevasse / Hazard", 0xFFFF0055),
    SHELTER("Refuge Shelter", 0xFFBD00FF)
}

data class AltoWaypoint(
    val id: String,
    val name: String,
    val category: WaypointCategory,
    val lat: Float,
    val lon: Float,
    val elevationMeters: Int,
    val notes: String,
    val distanceKmFromUser: Float = 1.2f
)

data class AltoElevationPoint(
    val distanceKm: Float,
    val elevationMeters: Float
)

data class AltoTrailTrack(
    val id: String,
    val name: String,
    val region: String,
    val difficulty: String, // Easy, Moderate, Strenuous, Alpine Technical
    val totalDistanceKm: Float,
    val elevationGainMeters: Int,
    val elevationLossMeters: Int,
    val maxElevMeters: Int,
    val minElevMeters: Int,
    val estimatedHours: Float,
    val profilePoints: List<AltoElevationPoint>,
    val waypoints: List<AltoWaypoint>,
    val description: String
)

// Go Photo Sphere 360 Models (Foxpoi Photo Sphere Suite)
data class SphericalHotspot(
    val id: String,
    val title: String,
    val yawDeg: Float, // -180 to 180 deg
    val pitchDeg: Float, // -90 to 90 deg
    val targetSphereId: String? = null,
    val info: String,
    val isPortal: Boolean = false
)

data class PhotoSphereLocation(
    val id: String,
    val title: String,
    val category: String, // Summits, Wilderness, Monument, Space/Sci
    val locationName: String,
    val country: String,
    val latitude: Float,
    val longitude: Float,
    val elevationMeters: Int,
    val captureDate: String,
    val cameraSensor: String = "Foxpoi 360 Spherical HDR",
    val defaultFovDegrees: Float = 75f,
    val description: String,
    val visualTheme: String = "ALPINE_GLACIER", // ALPINE_GLACIER, DESERT_CANYON, VOLCANO_CRATER, HISTORIC_TEMPLE, CYBER_OBSERVATORY
    val hotspots: List<SphericalHotspot> = emptyList(),
    val localImagePath: String? = null
)

data class SphereCaptureTarget(
    val id: Int,
    val yawDeg: Float,
    val pitchDeg: Float,
    var isCaptured: Boolean = false
)

// MiniFinder Go, Live, & Hunter Tracking Models
enum class MiniFinderAppMode(val title: String, val subtitle: String) {
    MINIFINDER_GO("MiniFinder Go", "Personal & Asset Real-Time Tracking"),
    MINIFINDER_LIVE("MiniFinder Live", "Multi-Device Telemetry & Fleet Operations"),
    MINIFINDER_HUNTER("MiniFinder Hunter", "Hunting Dog & Team Tactical GPS")
}

data class MiniFinderDevice(
    val id: String,
    val name: String,
    val model: String, // MiniFinder Pico, Nano, Atto Pro, Zeon, Rex
    val category: String, // Personal, Vehicle, Asset, Elder, Dog, Team
    val lat: Float,
    val lon: Float,
    val batteryPercent: Int,
    val speedKmh: Int,
    val status: String, // Online, Moving, Idle, SOS Alarm, Geofence Alert
    val signalDbm: Int,
    val satellites: Int,
    val sosTriggered: Boolean = false,
    val fallDetected: Boolean = false,
    val geofenceActive: Boolean = true,
    val geofenceRadiusM: Int = 300,
    val temperatureC: Int = 22,
    val historyTrail: List<Pair<Float, Float>> = emptyList(),
    // Hunter-specific fields
    val dogBreed: String? = null,
    val barksPerMinute: Int? = null,
    val isBarking: Boolean = false,
    val distanceToUserMeters: Int? = null,
    val headingDegrees: Float? = null,
    val hunterStand: String? = null
)

data class MiniFinderGeofenceZone(
    val id: String,
    val name: String,
    val lat: Float,
    val lon: Float,
    val radiusMeters: Int,
    val isAlarmOnEntry: Boolean = true,
    val isAlarmOnExit: Boolean = true,
    val colorHex: Long = 0xFF34A853
)

data class MiniFinderHunterStand(
    val id: String,
    val standCode: String,
    val hunterName: String,
    val lat: Float,
    val lon: Float,
    val isOccupied: Boolean = true
)


