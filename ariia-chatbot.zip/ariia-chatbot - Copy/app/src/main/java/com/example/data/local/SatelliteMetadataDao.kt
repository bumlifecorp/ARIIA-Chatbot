package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SatelliteMetadataDao {
    @Query("SELECT * FROM satellite_metadata ORDER BY timestamp DESC")
    fun getAllMetadata(): Flow<List<SatelliteMetadataEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMetadata(metadata: SatelliteMetadataEntity)

    @Query("DELETE FROM satellite_metadata WHERE metadataId = :id")
    suspend fun deleteMetadataById(id: String)
}
