package com.example.service

import com.example.ui.screens.earth.MiniFinderDevice
import com.example.ui.screens.earth.MiniFinderGeofenceZone
import com.example.ui.screens.earth.MiniFinderHunterStand
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

object MiniFinderTrackingService {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var trackingJob: Job? = null

    private val _isLiveTrackingActive = MutableStateFlow(true)
    val isLiveTrackingActive: StateFlow<Boolean> = _isLiveTrackingActive.asStateFlow()

    private val _simulationSpeedMultiplier = MutableStateFlow(1f) // 1x, 2x, 5x
    val simulationSpeedMultiplier: StateFlow<Float> = _simulationSpeedMultiplier.asStateFlow()

    private val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    // Initial Fleet Devices
    private val initialDevices = listOf(
        MiniFinderDevice(
            id = "pico-1",
            name = "Pico Elder Tracker",
            model = "MiniFinder Pico 4G",
            category = "Personal / Elder Care",
            lat = 57.7089f,
            lon = 11.9746f,
            batteryPercent = 94,
            speedKmh = 2,
            status = "Online - Safe Zone",
            signalDbm = -65,
            satellites = 16,
            sosTriggered = false,
            fallDetected = false,
            geofenceActive = true,
            geofenceRadiusM = 400,
            temperatureC = 21,
            historyTrail = listOf(
                Pair(57.7070f, 11.9720f),
                Pair(57.7080f, 11.9730f),
                Pair(57.7085f, 11.9740f),
                Pair(57.7089f, 11.9746f)
            )
        ),
        MiniFinderDevice(
            id = "nano-1",
            name = "Nano Child Safety",
            model = "MiniFinder Nano",
            category = "Personal / Child",
            lat = 57.7125f,
            lon = 11.9810f,
            batteryPercent = 82,
            speedKmh = 4,
            status = "Moving - School Zone",
            signalDbm = -72,
            satellites = 14,
            sosTriggered = false,
            fallDetected = false,
            geofenceActive = true,
            geofenceRadiusM = 500,
            temperatureC = 19,
            historyTrail = listOf(
                Pair(57.7100f, 11.9780f),
                Pair(57.7115f, 11.9795f),
                Pair(57.7125f, 11.9810f)
            )
        ),
        MiniFinderDevice(
            id = "atto-1",
            name = "Volvo XC90 Fleet",
            model = "MiniFinder Atto Pro",
            category = "Vehicle Fleet",
            lat = 57.7200f,
            lon = 11.9900f,
            batteryPercent = 100,
            speedKmh = 68,
            status = "Moving - Highway E6",
            signalDbm = -58,
            satellites = 18,
            sosTriggered = false,
            geofenceActive = true,
            geofenceRadiusM = 1500,
            temperatureC = 23,
            historyTrail = listOf(
                Pair(57.7150f, 11.9850f),
                Pair(57.7180f, 11.9880f),
                Pair(57.7200f, 11.9900f)
            )
        ),
        MiniFinderDevice(
            id = "zeon-1",
            name = "Cargo Container #4",
            model = "MiniFinder Zeon",
            category = "Asset / Logistics",
            lat = 57.6950f,
            lon = 11.9500f,
            batteryPercent = 65,
            speedKmh = 0,
            status = "Stationary Port",
            signalDbm = -80,
            satellites = 12,
            historyTrail = listOf(
                Pair(57.6950f, 11.9500f)
            )
        ),
        MiniFinderDevice(
            id = "rex-1",
            name = "Rex (Jämthund)",
            model = "MiniFinder Rex Dog Collar",
            category = "Hunting Dog",
            lat = 62.3908f,
            lon = 17.3069f,
            batteryPercent = 88,
            speedKmh = 14,
            status = "Barking at Bay",
            signalDbm = -60,
            satellites = 17,
            dogBreed = "Jämthund (Swedish Elkhound)",
            barksPerMinute = 78,
            isBarking = true,
            distanceToUserMeters = 340,
            headingDegrees = 45f,
            historyTrail = listOf(
                Pair(62.3890f, 17.3040f),
                Pair(62.3900f, 17.3055f),
                Pair(62.3908f, 17.3069f)
            )
        ),
        MiniFinderDevice(
            id = "freja-1",
            name = "Freja (Norrbottenspets)",
            model = "MiniFinder Rex Dog Collar",
            category = "Hunting Dog",
            lat = 62.3950f,
            lon = 17.3150f,
            batteryPercent = 91,
            speedKmh = 8,
            status = "Tracking Trail Scent",
            signalDbm = -68,
            satellites = 15,
            dogBreed = "Norrbottenspets",
            barksPerMinute = 16,
            isBarking = false,
            distanceToUserMeters = 820,
            headingDegrees = 110f,
            historyTrail = listOf(
                Pair(62.3930f, 17.3110f),
                Pair(62.3940f, 17.3130f),
                Pair(62.3950f, 17.3150f)
            )
        )
    )

    private val _devices = MutableStateFlow(initialDevices)
    val devices: StateFlow<List<MiniFinderDevice>> = _devices.asStateFlow()

    private val _telemetryLogs = MutableStateFlow(
        listOf(
            "[${dateFormat.format(Date())}] SYSTEM: MiniFinder Real-Time GPS Tracking Service Initialized.",
            "[${dateFormat.format(Date())}] MQTT: Connected to Swedish IoT Gateway tls://iot.minifinder.se:8883",
            "[${dateFormat.format(Date())}] FLEET: 6 MiniFinder Devices Online (Pico, Nano, Atto, Zeon, Rex)."
        )
    )
    val telemetryLogs: StateFlow<List<String>> = _telemetryLogs.asStateFlow()

    private var stepCount = 0

    init {
        startLiveTrackingService()
    }

    fun startLiveTrackingService() {
        if (trackingJob?.isActive == true) return
        _isLiveTrackingActive.value = true

        trackingJob = scope.launch {
            while (isActive) {
                val delayMs = (1500 / _simulationSpeedMultiplier.value).toLong().coerceAtLeast(200L)
                delay(delayMs)
                updateDeviceCoordinatesAndTelemetry()
            }
        }
    }

    fun pauseLiveTrackingService() {
        _isLiveTrackingActive.value = false
        trackingJob?.cancel()
    }

    fun setSpeedMultiplier(multiplier: Float) {
        _simulationSpeedMultiplier.value = multiplier
    }

    fun triggerSosAlarm(deviceId: String) {
        val timeStr = dateFormat.format(Date())
        _devices.value = _devices.value.map { dev ->
            if (dev.id == deviceId) {
                dev.copy(
                    sosTriggered = true,
                    status = "EMERGENCY SOS PANIC ALARM ACTIVE!"
                )
            } else dev
        }
        addLog("[ $timeStr ] ALERT: SOS PANIC BUTTON PRESSED on device $deviceId!")
    }

    fun resetSosAlarm(deviceId: String) {
        val timeStr = dateFormat.format(Date())
        _devices.value = _devices.value.map { dev ->
            if (dev.id == deviceId) {
                dev.copy(
                    sosTriggered = false,
                    status = "Online - Normal"
                )
            } else dev
        }
        addLog("[ $timeStr ] INFO: SOS Panic alarm cleared for device $deviceId.")
    }

    fun clearLogs() {
        _telemetryLogs.value = listOf("[${dateFormat.format(Date())}] Logs cleared.")
    }

    private fun updateDeviceCoordinatesAndTelemetry() {
        stepCount++
        val timeStr = dateFormat.format(Date())

        val currentList = _devices.value
        val updatedList = currentList.map { dev ->
            val angle = (stepCount * 0.15f) + dev.id.hashCode() % 10
            val dLat: Float
            val dLon: Float
            var newSpeed = dev.speedKmh
            var newStatus = dev.status
            var newBpm = dev.barksPerMinute

            when (dev.id) {
                "atto-1" -> {
                    // Vehicle fast movement
                    dLat = sin(angle) * 0.0008f
                    dLon = cos(angle) * 0.0012f
                    newSpeed = (60 + (sin(angle * 2) * 15)).toInt().coerceIn(40, 110)
                    newStatus = "Moving - Highway E6 ($newSpeed km/h)"
                }
                "rex-1" -> {
                    // Hunting dog running & barking
                    dLat = cos(angle * 1.5f) * 0.0004f
                    dLon = sin(angle * 1.5f) * 0.0005f
                    newSpeed = (10 + (sin(angle * 3) * 6)).toInt().coerceIn(2, 22)
                    newBpm = (70 + (sin(angle * 4) * 20)).toInt().coerceIn(40, 110)
                    newStatus = if (newBpm > 75) "BAY ALARM - DOG TREED GAME ($newBpm BPM)" else "Barking at Bay ($newBpm BPM)"
                }
                "pico-1" -> {
                    // Elder gentle walking in park
                    dLat = sin(angle * 0.5f) * 0.00015f
                    dLon = cos(angle * 0.5f) * 0.00015f
                    newSpeed = (2 + (sin(angle) * 1.5)).toInt().coerceIn(0, 5)
                    newStatus = "Walking - Safe Zone ($newSpeed km/h)"
                }
                "nano-1" -> {
                    // Child walking near school
                    dLat = cos(angle * 0.8f) * 0.0002f
                    dLon = sin(angle * 0.8f) * 0.00025f
                    newSpeed = (3 + (sin(angle) * 2)).toInt().coerceIn(0, 7)
                    newStatus = "Moving - School Safe Zone"
                }
                "freja-1" -> {
                    // Hunting dog tracking scent
                    dLat = sin(angle * 1.1f) * 0.0003f
                    dLon = cos(angle * 1.1f) * 0.00035f
                    newSpeed = (8 + (cos(angle) * 4)).toInt().coerceIn(2, 16)
                    newBpm = (12 + (sin(angle * 2) * 8)).toInt().coerceIn(5, 30)
                }
                else -> {
                    // Stationary or slight GPS jitter
                    dLat = (sin(angle) * 0.00003f)
                    dLon = (cos(angle) * 0.00003f)
                }
            }

            val newLat = dev.lat + dLat
            val newLon = dev.lon + dLon

            // Update trail history (keep last 15 points)
            val updatedTrail = (dev.historyTrail + Pair(newLat, newLon)).takeLast(15)

            // Calculate distance to origin for geofence breach test
            val distM = calculateDistanceMeters(dev.lat, dev.lon, newLat, newLon)

            dev.copy(
                lat = newLat,
                lon = newLon,
                speedKmh = newSpeed,
                status = newStatus,
                barksPerMinute = newBpm,
                isBarking = (newBpm ?: 0) > 20,
                signalDbm = (-60 - (stepCount % 15)).coerceIn(-95, -50),
                satellites = (14 + (stepCount % 5)).coerceIn(10, 20),
                distanceToUserMeters = if (dev.distanceToUserMeters != null) (dev.distanceToUserMeters + (sin(angle) * 12).toInt()).coerceAtLeast(10) else null,
                headingDegrees = (dev.headingDegrees?.let { (it + 5f) % 360f } ?: 0f),
                historyTrail = updatedTrail
            )
        }

        _devices.value = updatedList

        // Periodically append log line
        if (stepCount % 2 == 0) {
            val randomDev = updatedList[stepCount % updatedList.size]
            val logLine = "[ $timeStr ] ${randomDev.id.uppercase()}: GPS (${String.format("%.4f", randomDev.lat)}, ${String.format("%.4f", randomDev.lon)}), Spd ${randomDev.speedKmh} km/h, RSSI ${randomDev.signalDbm}dBm, Sats ${randomDev.satellites}"
            addLog(logLine)
        }
    }

    private fun addLog(line: String) {
        val currentLogs = _telemetryLogs.value.toMutableList()
        currentLogs.add(line)
        if (currentLogs.size > 50) {
            _telemetryLogs.value = currentLogs.takeLast(50)
        } else {
            _telemetryLogs.value = currentLogs
        }
    }

    private fun calculateDistanceMeters(lat1: Float, lon1: Float, lat2: Float, lon2: Float): Float {
        val r = 6371000f // Earth radius meters
        val dLat = Math.toRadians((lat2 - lat1).toDouble())
        val dLon = Math.toRadians((lon2 - lon1).toDouble())
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1.toDouble())) * cos(Math.toRadians(lat2.toDouble())) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return (r * c).toFloat()
    }
}
