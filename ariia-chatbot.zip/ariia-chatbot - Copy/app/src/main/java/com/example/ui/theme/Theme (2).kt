package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ImmersiveColorScheme = darkColorScheme(
    primary = ImmersiveLavender,
    onPrimary = ImmersiveOnLavender,
    primaryContainer = ImmersiveLavenderContainer,
    onPrimaryContainer = ImmersiveOnLavenderContainer,
    secondary = ImmersiveLavender,
    onSecondary = ImmersiveOnLavender,
    secondaryContainer = ImmersiveLavenderContainer,
    onSecondaryContainer = ImmersiveOnLavenderContainer,
    tertiary = ImmersiveEmerald,
    onTertiary = ImmersiveBg,
    background = ImmersiveBg,
    onBackground = ImmersiveTextPrimary,
    surface = ImmersiveSurface,
    onSurface = ImmersiveTextPrimary,
    surfaceVariant = ImmersiveCardBg,
    onSurfaceVariant = ImmersiveTextSecondary,
    outline = ImmersiveBorder,
    error = ImmersiveRose,
    onError = ImmersiveBg
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ImmersiveColorScheme,
        typography = Typography,
        content = content
    )
}
