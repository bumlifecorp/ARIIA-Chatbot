package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        IdentifiedFaceLogEntity::class,
        SpeechReminderEntity::class,
        TeachableVoiceCommandEntity::class,
        TrainedVisionObjectEntity::class,
        PaintedObjectEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun identifiedFaceLogDao(): IdentifiedFaceLogDao
    abstract fun speechReminderDao(): SpeechReminderDao
    abstract fun teachableVoiceCommandDao(): TeachableVoiceCommandDao
    abstract fun trainedVisionObjectDao(): TrainedVisionObjectDao
    abstract fun paintedObjectDao(): PaintedObjectDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "surveillance_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
