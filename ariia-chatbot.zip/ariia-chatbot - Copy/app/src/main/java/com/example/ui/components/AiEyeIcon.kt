package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AiEyeIcon(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ai_eye_transition")
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .size(120.dp)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(120.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            val radius = size.width / 2
            
            // Outer glowing triangle (Pyramid/Prism)
            val triangleRadius = radius * 0.9f
            val trianglePath = Path().apply {
                for (i in 0..2) {
                    val angle = (i * 120 - 90) * (Math.PI / 180f)
                    val x = center.x + triangleRadius * cos(angle).toFloat()
                    val y = center.y + triangleRadius * sin(angle).toFloat()
                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                }
                close()
            }
            
            // Neon colors
            val cyan = Color(0xFF00FFFF)
            val magenta = Color(0xFFFF00FF)
            val amber = Color(0xFFFFB300)
            

            drawPath(
                path = trianglePath,
                color = magenta.copy(alpha = 0.2f),
                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawPath(
                path = trianglePath,
                color = magenta.copy(alpha = 0.6f),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            
            // Inner rotating Hexagon
            rotate(rotation, center) {
                val hexRadius = radius * 0.55f
                val hexPath = Path().apply {
                    for (i in 0..5) {
                        val angle = (i * 60) * (Math.PI / 180f)
                        val x = center.x + hexRadius * cos(angle).toFloat()
                        val y = center.y + hexRadius * sin(angle).toFloat()
                        if (i == 0) moveTo(x, y) else lineTo(x, y)
                    }
                    close()
                }
                drawPath(
                    path = hexPath,
                    brush = Brush.sweepGradient(
                        colors = listOf(cyan, magenta, amber, cyan),
                        center = center
                    ),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
                
                // Tech nodes on hexagon vertices
                for (i in 0..5) {
                    val angle = (i * 60) * (Math.PI / 180f)
                    val x = center.x + hexRadius * cos(angle).toFloat()
                    val y = center.y + hexRadius * sin(angle).toFloat()
                    drawCircle(
                        color = cyan,
                        radius = 4.dp.toPx(),
                        center = Offset(x, y)
                    )
                }
            }
            
            // Center All-Seeing Eye (Orb/Pupil)
            val pupilRadius = radius * 0.2f * pulse
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(cyan, Color.Blue, Color.Transparent),
                    center = center,
                    radius = radius * 0.4f * pulse
                ),
                center = center,
                radius = radius * 0.4f * pulse,
                blendMode = BlendMode.Screen
            )
            
            drawCircle(
                color = Color.White,
                radius = pupilRadius * 0.3f,
                center = center
            )
            
            drawCircle(
                color = amber,
                radius = pupilRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}
