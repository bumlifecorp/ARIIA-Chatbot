package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(
    onNavigate: (Int) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Hero Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.tertiaryContainer
                            )
                        )
                    )
                    .padding(24.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Badge(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ) {
                            Text("EAGLE EYE DEFENSE AI PROTOCOL", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                        Icon(
                            imageVector = Icons.Default.RemoveRedEye,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Text(
                        text = "KaleidoPhone - ARIIA AI Assistant",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Eagle Eye Defense Supercomputer Platform • ARIIA Autonomous Reconnaissance & Intelligence Integration Assistant with Live Streaming, Quantum Core, Satellite Recon, and Influx/MOBOTIX Surveillance.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        item {
            Text(
                text = "AI Capabilities & Tools",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        item {
            FeatureCard(
                title = "Google Voice Command & Phone Assistant",
                description = "Hands-free voice assistant with 'Hey Google' triggers, phone calls, SMS, alarms, timers, flashlight, battery metrics, navigation, and speech synthesis.",
                icon = Icons.Default.Mic,
                onClick = { onNavigate(4) }
            )
        }

        item {
            FeatureCard(
                title = "Gemini Live Streaming Chat",
                description = "Stream token-by-token conversational AI responses in real-time.",
                icon = Icons.AutoMirrored.Filled.Chat,
                onClick = { onNavigate(1) }
            )
        }

        item {
            FeatureCard(
                title = "AI Text Analyzer & Summarizer",
                description = "Summarize articles, analyze sentiment, and enhance professional writing.",
                icon = Icons.Default.EditNote,
                onClick = { onNavigate(2) }
            )
        }

        item {
            FeatureCard(
                title = "AI Content & Code Generator",
                description = "Generate creative stories, code snippets, structured responses, and marketing copy.",
                icon = Icons.Default.AutoAwesome,
                onClick = { onNavigate(3) }
            )
        }

        item {
            FeatureCard(
                title = "A.R.I.I.A. Tactical Assistant (Eagle Eye OS)",
                description = "Interact with the omnipotent AI assistant featuring tactical assessment and command overrides.",
                icon = Icons.Default.Cloud,
                onClick = { onNavigate(4) }
            )
        }

        item {
            FeatureCard(
                title = "Cognitive Learning Semantic Engine",
                description = "Cross-session persistent memory that refines rules and adapts to your workflow.",
                icon = Icons.Default.Psychology,
                onClick = { onNavigate(5) }
            )
        }

        item {
            FeatureCard(
                title = "System Accelerator & LiteRT-LM 0.16.0",
                description = "Memory accelerator diagnostics and exact model file SHA-256 validation.",
                icon = Icons.Default.Speed,
                onClick = { onNavigate(6) }
            )
        }

        item {
            FeatureCard(
                title = "Spherical Multimonitor Kaleidoscope HUD",
                description = "Simultaneous worldview kaleidoscope city surveillance grid with 3D polygonal wedge reflection stage.",
                icon = Icons.Default.AutoAwesome,
                onClick = { onNavigate(8) }
            )
        }

        item {
            FeatureCard(
                title = "CameraX 1.3.1 & Azure Vision Liveness v1.4",
                description = "Real-time ML Kit background frame analysis, face tracking, Azure Face API liveness, & voice control.",
                icon = Icons.Default.Videocam,
                onClick = { onNavigate(9) }
            )
        }

        item {
            FeatureCard(
                title = "DeepSeek People & AI Core",
                description = "Manage personnel directory, biometrics verification, and query DeepSeek Neural AI in real-time.",
                icon = Icons.Default.AutoAwesome,
                onClick = { onNavigate(10) }
            )
        }

        item {
            FeatureCard(
                title = "Teachable Voice, Vision & Speech Reminders",
                description = "Train mobile for object recognition, set verbal speech alarms/reminders with purpose, direct app/contacts launch, and 100% offline Q&A.",
                icon = Icons.Default.RecordVoiceOver,
                onClick = { onNavigate(11) }
            )
        }

        item {
            FeatureCard(
                title = "Stream Ingestion, Pub/Sub & Anomaly Radar",
                description = "RTSP/WebRTC sub-second latency feeds, MQTT/Kafka telemetry brokerage, and aggregated ALPR & acoustic gunshot anomaly detection.",
                icon = Icons.Default.Hub,
                onClick = { onNavigate(12) }
            )
        }

        item {
            FeatureCard(
                title = "ARIIA Tactical Launcher & HUD Grid",
                description = "Customizable app grid with holographic HUD overlay, direct app intent interactions, 360° LIDAR radar, and 6-DOF robotics actuation.",
                icon = Icons.Default.PrecisionManufacturing,
                onClick = { onNavigate(13) }
            )
        }

        item {
            FeatureCard(
                title = "ARIIA Earth View & AltoMaps 3D",
                description = "Planetary cartography & Foxpoi outdoors: AltoMaps topographic GPS & altimeter/barometer HUD, Go Photo Sphere 360° VR panoramas & studio, 3D globe with weather radar, street view, live world cams, and route guidance.",
                icon = Icons.Default.Public,
                onClick = { onNavigate(14) }
            )
        }

        item {
            FeatureCard(
                title = "ARIIA Secure Comms & Tactical Spaces",
                description = "Encrypted multi-channel communication spaces (#orbital-recon, #field-operatives, #ai-command), geolocation attachments, and voice audio dispatches.",
                icon = Icons.Default.Forum,
                onClick = { onNavigate(15) }
            )
        }

        item {
            FeatureCard(
                title = "Protocol: [Painter]",
                description = "Color_Picker automated search with facial recognition, Paint_Brushing continuous object selection, Paint_Dryer real-time satellite & camera telemetry, and Art_Gallery catalog.",
                icon = Icons.Default.Palette,
                onClick = { onNavigate(16) }
            )
        }
    }
}

@Composable
fun FeatureCard(
    title: String,
    description: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        )
    ) {
        Row(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
