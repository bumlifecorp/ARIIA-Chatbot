package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "altomaps_tiles")
data class AltoMapsTileEntity(
    @PrimaryKey val tileId: String,
    val zoomLevel: Int,
    val tileX: Int,
    val tileY: Int,
    val tileData: ByteArray,
    val timestamp: Long = System.currentTimeMillis()
)
