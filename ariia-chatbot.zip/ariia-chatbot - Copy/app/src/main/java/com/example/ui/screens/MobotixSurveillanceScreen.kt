package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import kotlin.math.cos
import kotlin.math.sin

data class MobotixCameraNode(
    val id: String,
    val model: String,              // M73 Thermal TR, S74 Modular, p71 Hemispheric, T26 Intercom
    val name: String,
    val location: String,
    val ipAddress: String,
    val opticalResolution: String,  // 4K UltraHD, 6MP, Hemispheric 360
    val thermalSensorPresent: Boolean,
    val thermalSpotTempC: Float,     // Current spot radiometric temp
    val maxAlarmThresholdC: Float,  // High temp alarm trigger threshold
    val mxActivitySensorActive: Boolean,
    val sipDoorControl: Boolean,
    val isOnline: Boolean = true,
    val edgeSdStorageGb: Int,
    val activeEventCount: Int
)

data class MxAnalyticsEvent(
    val timestamp: String,
    val cameraId: String,
    val cameraName: String,
    val eventType: String,          // Thermal Overheat, Human Intrusion, Vehicle Vector, SIP Call
    val severity: String,           // CRITICAL, WARNING, INFO
    val detail: String
)

@Composable
fun MobotixSurveillanceScreen(
    onSpeak: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    val mobotixNodes = remember {
        listOf(
            MobotixCameraNode("mobotix-01", "MOBOTIX M73 Thermal TR", "Perimeter North Dual Head", "Gate 1 North", "192.168.10.101", "4K UltraHD", true, 34.2f, 48.0f, true, false, true, 256, 3),
            MobotixCameraNode("mobotix-02", "MOBOTIX S74 Flex Quad", "Tactical Vault Modular", "Vault Concourse", "192.168.10.102", "6MP Quad Sensor", false, 24.5f, 40.0f, true, false, true, 512, 1),
            MobotixCameraNode("mobotix-03", "MOBOTIX p71 Hemispheric", "360 Dome Command Hall", "HQ Lobby", "192.168.10.103", "Hemispheric 360", false, 22.8f, 38.0f, true, false, true, 128, 0),
            MobotixCameraNode("mobotix-04", "MOBOTIX T26 Intercom", "Gate 1 SIP Door Access", "Main Entrance", "192.168.10.104", "6MP Hemispheric", false, 23.1f, 42.0f, true, true, true, 128, 5)
        )
    }

    var activeNode by remember { mutableStateOf(mobotixNodes.first()) }
    var viewMode by remember { mutableStateOf("OPTICAL_THERMAL") } // OPTICAL_THERMAL, RADIOMETRY_MAP, MX_ANALYTICS, SIP_INTERCOM
    var doorUnlocked by remember { mutableStateOf(false) }
    var sirenActive by remember { mutableStateOf(false) }

    val recentEvents = remember {
        mutableStateListOf(
            MxAnalyticsEvent("11:04:12", "mobotix-01", "Perimeter North Dual Head", "Thermal Overheat", "WARNING", "Spot TR reading 49.8°C exceeds threshold 48.0°C"),
            MxAnalyticsEvent("11:02:45", "mobotix-01", "Perimeter North Dual Head", "Human Intrusion", "CRITICAL", "MxActivitySensor 2.0 vector detected speed 14 km/h"),
            MxAnalyticsEvent("10:58:19", "mobotix-04", "Gate 1 SIP Door Access", "SIP Call", "INFO", "Ringswitch trigger activated from keycard reader"),
            MxAnalyticsEvent("10:45:02", "mobotix-02", "Tactical Vault Modular", "Vehicle Vector", "INFO", "Vehicle trajectory tracked across Quad 2 sensor")
        )
    }

    val infiniteTransition = rememberInfiniteTransition(label = "MobotixAnim")
    val pulseRatio by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Reverse),
        label = "Pulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030B18))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // MOBOTIX Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A1B30), RoundedCornerShape(10.dp))
                .border(1.dp, Color(0xFFFF9900), RoundedCornerShape(10.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CameraIndoor, contentDescription = null, tint = Color(0xFFFF9900), modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("MOBOTIX EDGE IoT SURVEILLANCE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFFFF9900), fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(shape = CircleShape, color = Color(0xFF39FF14)) { Box(modifier = Modifier.size(6.dp)) }
                    }
                    Text("Decentralized Edge Architecture • MxAnalytics 2.0 • Thermal Radiometry (TR) • SIP Intercom", fontSize = 8.sp, color = Color(0xFF94A3B8))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                // Siren Relay Trigger
                Button(
                    onClick = {
                        sirenActive = !sirenActive
                        val status = if (sirenActive) "MOBOTIX emergency strobe and alarm siren relay engaged!" else "MOBOTIX siren relay disengaged."
                        onSpeak(status)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (sirenActive) Color(0xFFFF0055) else Color(0xFF1E293B)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = if (sirenActive) Color.White else Color(0xFFFF9900), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (sirenActive) "SIREN ON" else "SIREN", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }

                // Voice Brief Button
                Button(
                    onClick = {
                        val speech = "MOBOTIX node locked on ${activeNode.name}. Model ${activeNode.model}. Thermal spot temperature is ${activeNode.thermalSpotTempC} degrees Celsius. MxActivitySensor AI filter is online."
                        onSpeak(speech)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9900)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Voice Brief", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Camera Node Selector Row
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(mobotixNodes) { node ->
                val isSel = node.id == activeNode.id
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) Color(0xFF332200) else Color(0xFF0F172A),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFFFF9900) else Color(0xFF334155)),
                    modifier = Modifier.clickable { activeNode = node }
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (node.thermalSensorPresent) Icons.Default.Whatshot else Icons.Default.Videocam,
                            contentDescription = null,
                            tint = if (isSel) Color(0xFFFF9900) else Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(node.name, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("${node.model} • ${node.ipAddress}", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // View Mode Selector Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            val modes = listOf(
                "OPTICAL_THERMAL" to "Dual Optical/Thermal",
                "RADIOMETRY_MAP" to "Radiometry TR Map",
                "MX_ANALYTICS" to "MxActivitySensor 2.0",
                "SIP_INTERCOM" to "SIP Intercom"
            )

            modes.forEach { (key, label) ->
                val isSel = viewMode == key
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isSel) Color(0xFFFF9900) else Color.Transparent,
                    modifier = Modifier.clickable { viewMode = key }
                ) {
                    Text(
                        label,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.Black else Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Main MOBOTIX Visualizer Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF020914), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFFFF9900).copy(alpha = 0.6f), RoundedCornerShape(12.dp))
        ) {
            when (viewMode) {
                "OPTICAL_THERMAL", "RADIOMETRY_MAP" -> {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // Render Thermal Heat Gradient Grid
                        val cols = 16
                        val rows = 12
                        val cellW = w / cols
                        val cellH = h / rows

                        for (r in 0 until rows) {
                            for (c in 0 until cols) {
                                val distFromHotspot = kotlin.math.hypot(c - 8f, r - 5f)
                                val tempVal = (50f - distFromHotspot * 4f).coerceIn(18f, 52f)

                                val cellColor = when {
                                    tempVal > 45f -> Color(0xFFFF0055).copy(alpha = 0.8f)
                                    tempVal > 35f -> Color(0xFFFF9900).copy(alpha = 0.6f)
                                    tempVal > 28f -> Color(0xFFFFEE00).copy(alpha = 0.4f)
                                    else -> Color(0xFF00F0FF).copy(alpha = 0.15f)
                                }

                                drawRect(
                                    color = cellColor,
                                    topLeft = Offset(c * cellW, r * cellH),
                                    size = Size(cellW - 1f, cellH - 1f)
                                )
                            }
                        }

                        // Hotspot Radiometric Target Marker
                        val hotspot = Offset(8 * cellW + cellW / 2f, 5 * cellH + cellH / 2f)
                        drawCircle(Color(0xFFFF0055), radius = 30f * pulseRatio, center = hotspot, style = Stroke(width = 2f))
                        drawLine(Color.White, Offset(hotspot.x - 15, hotspot.y), Offset(hotspot.x + 15, hotspot.y))
                        drawLine(Color.White, Offset(hotspot.x, hotspot.y - 15), Offset(hotspot.x, hotspot.y + 15))
                    }

                    // Radiometry HUD Overlay
                    Column(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.Black.copy(alpha = 0.85f),
                            border = BorderStroke(1.dp, Color(0xFFFF9900))
                        ) {
                            Column(modifier = Modifier.padding(6.dp)) {
                                Text("MOBOTIX THERMAL RADIOMETRY (TR)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9900))
                                Text("SPOT TEMP: ${activeNode.thermalSpotTempC}°C (MAX HOTSPOT: 49.8°C)", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                Text("ALARM THRESHOLD: ${activeNode.maxAlarmThresholdC}°C • EMISSIVITY: 0.95", fontSize = 8.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                                Text("SENSOR HEAD: DUAL THERMAL + 4K OPTICAL", fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }

                "MX_ANALYTICS" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                    ) {
                        Text("MxActivitySensor 2.0 AI MOVEMENT VECTORS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9900), fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.height(6.dp))

                        // Vector Grid Simulation
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .background(Color(0xFF071224), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF00F0FF))
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawCircle(Color(0xFF00F0FF), radius = 60f, center = Offset(size.width * 0.4f, size.height * 0.5f), style = Stroke(width = 2f))
                                drawLine(Color(0xFF39FF14), Offset(size.width * 0.2f, size.height * 0.7f), Offset(size.width * 0.6f, size.height * 0.3f), strokeWidth = 3f)
                            }
                            Text("HUMAN VECTOR: 14 km/h • DIRECTION 45°", modifier = Modifier.padding(8.dp), fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("RECENT MxAnalytics EDGE EVENTS", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(recentEvents) { ev ->
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFF0F172A),
                                    border = BorderStroke(1.dp, if (ev.severity == "CRITICAL") Color(0xFFFF0055) else Color(0xFFFF9900))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("[${ev.timestamp}] ${ev.eventType} - ${ev.cameraName}", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            Text(ev.detail, fontSize = 7.sp, color = Color(0xFF94A3B8))
                                        }
                                        Surface(shape = RoundedCornerShape(3.dp), color = if (ev.severity == "CRITICAL") Color(0xFFFF0055) else Color(0xFFFF9900)) {
                                            Text(ev.severity, fontSize = 6.sp, color = Color.Black, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "SIP_INTERCOM" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = Color(0xFFFF9900), modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("MOBOTIX T26 SIP VIDEO INTERCOM", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                        Text("IP: 192.168.10.104 • RFID KEYCARD READER • 2-WAY AUDIO", fontSize = 8.sp, color = Color(0xFF94A3B8))

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = {
                                    doorUnlocked = !doorUnlocked
                                    val status = if (doorUnlocked) "Gate 1 SIP Electric Door Lock RELEASED." else "Gate 1 SIP Electric Door Lock ENGAGED."
                                    onSpeak(status)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = if (doorUnlocked) Color(0xFF39FF14) else Color(0xFFFF9900))
                            ) {
                                Icon(if (doorUnlocked) Icons.Default.LockOpen else Icons.Default.Lock, contentDescription = null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (doorUnlocked) "DOOR UNLOCKED" else "UNLOCK DOOR", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
