package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.data.*
import com.example.util.AriiaSpeechEngine
import com.example.util.FrameFeatureSignature
import com.example.util.TeachableVisionEngine
import com.example.util.VoiceActionExecutor
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.Executors

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun TeachableVoiceVisionScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    val database = remember { AppDatabase.getDatabase(context) }
    val reminderDao = database.speechReminderDao()
    val commandDao = database.teachableVoiceCommandDao()
    val objectDao = database.trainedVisionObjectDao()

    val speechEngine = remember { AriiaSpeechEngine(context) }
    DisposableEffect(Unit) {
        onDispose {
            speechEngine.shutdown()
        }
    }

    val permissionsState = rememberMultiplePermissionsState(
        permissions = listOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
    )

    // Observe Room data
    val remindersList by reminderDao.getAllReminders().collectAsState(initial = emptyList())
    val commandsList by commandDao.getAllCommands().collectAsState(initial = emptyList())
    val trainedObjectsList by objectDao.getAllTrainedObjects().collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf(0) } // 0: Speech Reminders & Alarms, 1: Teachable Voice, 2: Teachable Vision, 3: Offline QA
    var textInput by remember { mutableStateOf("") }
    var assistantFeedback by remember { mutableStateOf("ARIIA Voice & Vision Assistant standing by. Say a command or choose an action below.") }
    var isListening by remember { mutableStateOf(false) }

    // Teachable Vision live states
    var latestFrameSignature by remember { mutableStateOf<FrameFeatureSignature?>(null) }
    var detectedObjectBanner by remember { mutableStateOf<String?>(null) }
    var lastDetectionTime by remember { mutableStateOf(0L) }
    var showTrainDialog by remember { mutableStateOf(false) }
    var newObjectLabel by remember { mutableStateOf("") }
    var newObjectAction by remember { mutableStateOf("") }

    // Teachable Voice Command dialog
    var showAddCommandDialog by remember { mutableStateOf(false) }
    var newCommandTrigger by remember { mutableStateOf("") }
    var newCommandAction by remember { mutableStateOf("OPEN_APP") }
    var newCommandTarget by remember { mutableStateOf("") }
    var newCommandResponse by remember { mutableStateOf("") }

    // Pre-populate default teachable commands if empty
    LaunchedEffect(commandsList) {
        if (commandsList.isEmpty()) {
            withContext(Dispatchers.IO) {
                commandDao.insertCommand(
                    TeachableVoiceCommandEntity(
                        triggerPhrase = "call to mom",
                        actionType = "DIAL",
                        actionTarget = "tel:",
                        spokenResponse = "Calling Mom now.",
                        isBuiltIn = true
                    )
                )
                commandDao.insertCommand(
                    TeachableVoiceCommandEntity(
                        triggerPhrase = "open whatsapp",
                        actionType = "OPEN_APP",
                        actionTarget = "com.whatsapp",
                        spokenResponse = "Opening WhatsApp terminal.",
                        isBuiltIn = true
                    )
                )
            }
        }
    }

    // Pre-populate default speech reminders if empty
    LaunchedEffect(remindersList) {
        if (remindersList.isEmpty()) {
            withContext(Dispatchers.IO) {
                reminderDao.insertReminder(
                    SpeechReminderEntity(
                        title = "Speech Wake Alarm",
                        purpose = "Morning Wake Up",
                        scheduledTimeText = "7:00 AM",
                        isAlarm = true,
                        spokenAlertText = "Good morning Operator! It is 7:00 AM. Wake up, time for mission briefing."
                    )
                )
                reminderDao.insertReminder(
                    SpeechReminderEntity(
                        title = "Speech Reminder: Medicine",
                        purpose = "Evening Medicine",
                        scheduledTimeText = "9:00 PM",
                        isAlarm = false,
                        spokenAlertText = "Attention Operator: Scheduled Speech Reminder. Time to take your prescribed medicine now."
                    )
                )
                reminderDao.insertReminder(
                    SpeechReminderEntity(
                        title = "Speech Reminder: Yoga",
                        purpose = "Morning Yoga Routine",
                        scheduledTimeText = "8:00 AM",
                        isAlarm = false,
                        spokenAlertText = "Attention Operator: Scheduled Speech Reminder for Yoga session at 8:00 AM."
                    )
                )
                reminderDao.insertReminder(
                    SpeechReminderEntity(
                        title = "Speech Reminder: Meeting",
                        purpose = "Meeting with Raju",
                        scheduledTimeText = "2:00 PM",
                        isAlarm = false,
                        spokenAlertText = "Attention Operator: Tactical Speech Reminder. Meeting with Raju scheduled at 2:00 PM."
                    )
                )
            }
        }
    }

    // Speech Recognizer setup
    val speechRecognizer = remember { SpeechRecognizer.createSpeechRecognizer(context) }
    DisposableEffect(Unit) {
        val listener = object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { isListening = false }
            override fun onError(error: Int) {
                isListening = false
                assistantFeedback = "Voice recognition error code: $error"
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val voiceCmd = matches[0]
                    textInput = voiceCmd
                    handleCommand(voiceCmd, context, speechEngine, coroutineScope) { result ->
                        assistantFeedback = result
                    }
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
        speechRecognizer.setRecognitionListener(listener)
        onDispose {
            speechRecognizer.destroy()
        }
    }

    LaunchedEffect(permissionsState.allPermissionsGranted) {
        if (!permissionsState.allPermissionsGranted) {
            permissionsState.launchMultiplePermissionRequest()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Bar
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0A0A0E),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ARIIA TEACHABLE AI & SPEECH REMINDERS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F0FF),
                            fontFamily = FontFamily.Monospace
                        )
                        Badge(containerColor = Color(0xFF00363D), contentColor = Color(0xFF39FF14)) {
                            Text("100% OFFLINE", fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                    }
                    Text(
                        text = "Voice speech alarms, teachable object recognition, direct app launching & offline answers.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            // Tabs Selector
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF101018),
                contentColor = Color(0xFF00F0FF)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Speech Reminders", fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Teachable Voice", fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Teachable Vision", fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Offline Q&A", fontSize = 11.sp) },
                    icon = { Icon(Icons.Default.Psychology, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }

            // Interactive Voice & Text Input Bar
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF14141E),
                border = BorderStroke(1.dp, if (isListening) Color(0xFF39FF14) else Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (!isListening) {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    val settings = com.example.data.SettingsRepository(context)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Say 'Call to mom', 'Wake me at 7 AM', 'What is passion?', etc.")
                                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, settings.speechTimeout.toLong())
                                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, settings.speechTimeout.toLong())
                                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, (100f - settings.micSensitivity).toLong() * 20)
                                }
                                speechRecognizer.startListening(intent)
                            } else {
                                speechRecognizer.stopListening()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                            contentDescription = "Voice Input",
                            tint = if (isListening) Color(0xFFFF3333) else Color(0xFF00F0FF)
                        )
                    }

                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("Type or speak: 'Wake me at 7 AM', 'Call to mom'...", color = Color(0xFF64748B), fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true
                    )

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                handleCommand(textInput, context, speechEngine, coroutineScope) { result ->
                                    assistantFeedback = result
                                }
                            }
                        }
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color(0xFFBD00FF))
                    }
                }
            }

            // Feedback Banner
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0A121A),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = assistantFeedback,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFE2E8F0)
                    )
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> SpeechRemindersTab(
                    reminders = remindersList,
                    speechEngine = speechEngine,
                    onAddReminder = { title, purpose, time, isAlarm, spoken ->
                        coroutineScope.launch(Dispatchers.IO) {
                            reminderDao.insertReminder(
                                SpeechReminderEntity(
                                    title = title,
                                    purpose = purpose,
                                    scheduledTimeText = time,
                                    isAlarm = isAlarm,
                                    spokenAlertText = spoken
                                )
                            )
                        }
                        speechEngine.speak("Speech Reminder for $purpose configured for $time.")
                    },
                    onDeleteReminder = { rem ->
                        coroutineScope.launch(Dispatchers.IO) {
                            reminderDao.deleteReminder(rem)
                        }
                    }
                )

                1 -> TeachableVoiceTab(
                    commands = commandsList,
                    speechEngine = speechEngine,
                    onAddCommand = { trigger, action, target, spoken ->
                        coroutineScope.launch(Dispatchers.IO) {
                            commandDao.insertCommand(
                                TeachableVoiceCommandEntity(
                                    triggerPhrase = trigger.lowercase().trim(),
                                    actionType = action,
                                    actionTarget = target,
                                    spokenResponse = spoken
                                )
                            )
                        }
                        speechEngine.speak("Learned new voice trigger: $trigger.")
                    },
                    onDeleteCommand = { cmd ->
                        coroutineScope.launch(Dispatchers.IO) {
                            commandDao.deleteCommand(cmd)
                        }
                    }
                )

                2 -> TeachableVisionTab(
                    permissionsGranted = permissionsState.allPermissionsGranted,
                    trainedObjects = trainedObjectsList,
                    onFrameAnalyzed = { sig ->
                        latestFrameSignature = sig
                        val match = TeachableVisionEngine.matchAgainstTrainedObjects(sig, trainedObjectsList)
                        if (match != null) {
                            val now = System.currentTimeMillis()
                            if (now - lastDetectionTime > 4000) { // 4 second cooldown
                                lastDetectionTime = now
                                val obj = match.first
                                val sim = match.second
                                detectedObjectBanner = "Recognized: ${obj.label} (${(sim * 100).toInt()}% match)"
                                val speech = "Teachable Vision recognized ${obj.label}. Executing action."
                                speechEngine.speak(speech)
                                assistantFeedback = speech
                            }
                        }
                    },
                    onRequestPermissions = { permissionsState.launchMultiplePermissionRequest() },
                    onTrainCurrentObject = { label, action ->
                        latestFrameSignature?.let { sig ->
                            coroutineScope.launch(Dispatchers.IO) {
                                objectDao.insertTrainedObject(
                                    TrainedVisionObjectEntity(
                                        label = label,
                                        redMean = sig.redMean,
                                        greenMean = sig.greenMean,
                                        blueMean = sig.blueMean,
                                        luminanceMean = sig.luminanceMean,
                                        variance = sig.variance,
                                        assignedAction = action
                                    )
                                )
                            }
                            speechEngine.speak("Successfully trained mobile for object: $label.")
                            assistantFeedback = "Trained object '$label' stored in offline neural memory."
                        }
                    },
                    onDeleteObject = { obj ->
                        coroutineScope.launch(Dispatchers.IO) {
                            objectDao.deleteTrainedObject(obj)
                        }
                    },
                    detectedBanner = detectedObjectBanner
                )

                3 -> OfflineKnowledgeTab(
                    speechEngine = speechEngine,
                    onQuerySelected = { q ->
                        textInput = q
                        handleCommand(q, context, speechEngine, coroutineScope) { result ->
                            assistantFeedback = result
                        }
                    }
                )
            }
        }
    }
}

private fun handleCommand(
    command: String,
    context: android.content.Context,
    speechEngine: AriiaSpeechEngine,
    scope: kotlinx.coroutines.CoroutineScope,
    onResult: (String) -> Unit
) {
    val result = VoiceActionExecutor.executeCommand(context, command, speechEngine, scope)
    when (result) {
        is VoiceActionExecutor.VoiceExecutionResult.Handled -> {
            onResult("Action Executed: ${result.message}")
            com.example.utils.HapticManager.triggerVoiceCommandSuccess(context)
        }
        is VoiceActionExecutor.VoiceExecutionResult.KnowledgeAnswer -> {
            onResult(result.answer)
        }
        is VoiceActionExecutor.VoiceExecutionResult.NotHandled -> {
            val fallback = "Command recognized: \"$command\". Processed through ARIIA neural router."
            speechEngine.speak(fallback)
            onResult(fallback)
        }
    }
}

@Composable
fun SpeechRemindersTab(
    reminders: List<SpeechReminderEntity>,
    speechEngine: AriiaSpeechEngine,
    onAddReminder: (String, String, String, Boolean, String) -> Unit,
    onDeleteReminder: (SpeechReminderEntity) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var inputPurpose by remember { mutableStateOf("") }
    var inputTime by remember { mutableStateOf("") }
    var isAlarmChoice by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SPEECH REMINDERS & ALARMS (${reminders.size})",
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFF39FF14),
                fontFamily = FontFamily.Monospace
            )
            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Reminder", color = Color.Black, fontSize = 11.sp)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(reminders) { rem ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0E0E16),
                    border = BorderStroke(1.dp, if (rem.isAlarm) Color(0xFFFF9900) else Color(0xFF00F0FF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (rem.isAlarm) Icons.Default.Alarm else Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = if (rem.isAlarm) Color(0xFFFF9900) else Color(0xFF00F0FF),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = rem.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Badge(
                                containerColor = if (rem.isAlarm) Color(0xFF3A2000) else Color(0xFF002930),
                                contentColor = if (rem.isAlarm) Color(0xFFFF9900) else Color(0xFF00F0FF)
                            ) {
                                Text(rem.scheduledTimeText, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp))
                            }
                        }

                        Text(
                            text = "\"${rem.spokenAlertText}\"",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8),
                            fontFamily = FontFamily.Monospace
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { speechEngine.speak(rem.spokenAlertText) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF39FF14)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Speak Now (Test)", fontSize = 10.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = { onDeleteReminder(rem) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF4444), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("New Speech Reminder / Alarm", color = Color.White) },
            containerColor = Color(0xFF14141E),
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = inputPurpose,
                        onValueChange = { inputPurpose = it },
                        label = { Text("Purpose (e.g. Medicine, Yoga, Raju Meeting)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = inputTime,
                        onValueChange = { inputTime = it },
                        label = { Text("Time (e.g. 7:00 AM, 9:00 PM)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isAlarmChoice, onCheckedChange = { isAlarmChoice = it })
                        Text("Is Wake-up Speech Alarm", color = Color.White, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputPurpose.isNotBlank()) {
                            val time = inputTime.ifBlank { "7:00 AM" }
                            val spoken = if (isAlarmChoice) {
                                "Good morning Operator! It is $time. Wake up for $inputPurpose."
                            } else {
                                "Attention Operator: Scheduled Speech Reminder for $inputPurpose at $time."
                            }
                            onAddReminder("Speech ${if (isAlarmChoice) "Alarm" else "Reminder"}: $inputPurpose", inputPurpose, time, isAlarmChoice, spoken)
                            showAddDialog = false
                            inputPurpose = ""
                            inputTime = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF))
                ) {
                    Text("Save", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel", color = Color(0xFF94A3B8)) }
            }
        )
    }
}

@Composable
fun TeachableVoiceTab(
    commands: List<TeachableVoiceCommandEntity>,
    speechEngine: AriiaSpeechEngine,
    onAddCommand: (String, String, String, String) -> Unit,
    onDeleteCommand: (TeachableVoiceCommandEntity) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var trigger by remember { mutableStateOf("") }
    var actionType by remember { mutableStateOf("OPEN_APP") }
    var target by remember { mutableStateOf("") }
    var spoken by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TEACHABLE VOICE COMMANDS (${commands.size})",
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFF00F0FF),
                fontFamily = FontFamily.Monospace
            )
            Button(
                onClick = { showDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF)),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Teach Command", color = Color.White, fontSize = 11.sp)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(commands) { cmd ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0E0E16),
                    border = BorderStroke(1.dp, Color(0xFFBD00FF).copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "Say: \"${cmd.triggerPhrase}\"",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Action: ${cmd.actionType} • Target: ${cmd.actionTarget}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF39FF14)
                            )
                            Text(
                                text = "Spoken: \"${cmd.spokenResponse}\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8)
                            )
                        }

                        IconButton(onClick = { onDeleteCommand(cmd) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF4444), modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Teach New Voice Command", color = Color.White) },
            containerColor = Color(0xFF14141E),
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = trigger,
                        onValueChange = { trigger = it },
                        label = { Text("Spoken Trigger (e.g. call to mom, open facebook)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = target,
                        onValueChange = { target = it },
                        label = { Text("Target (e.g. com.whatsapp, tel:mom, news)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = spoken,
                        onValueChange = { spoken = it },
                        label = { Text("ARIIA Spoken Response") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (trigger.isNotBlank()) {
                            onAddCommand(trigger, actionType, target.ifBlank { "default" }, spoken.ifBlank { "Executing $trigger." })
                            showDialog = false
                            trigger = ""
                            target = ""
                            spoken = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF))
                ) {
                    Text("Teach", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancel", color = Color(0xFF94A3B8)) }
            }
        )
    }
}

@Composable
fun TeachableVisionTab(
    permissionsGranted: Boolean,
    trainedObjects: List<TrainedVisionObjectEntity>,
    onFrameAnalyzed: (FrameFeatureSignature) -> Unit,
    onRequestPermissions: () -> Unit,
    onTrainCurrentObject: (String, String) -> Unit,
    onDeleteObject: (TrainedVisionObjectEntity) -> Unit,
    detectedBanner: String?
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var showTrainDialog by remember { mutableStateOf(false) }
    var trainLabel by remember { mutableStateOf("") }
    var trainAction by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!permissionsGranted) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF200A0A),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Camera permission needed for Teachable Vision.", color = Color(0xFFFF6666))
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = onRequestPermissions) { Text("Grant Camera Permission") }
                }
            }
        } else {
            // Live Camera Preview with Viewfinder
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color.Black, RoundedCornerShape(14.dp))
            ) {
                AndroidView(
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            layoutParams = android.view.ViewGroup.LayoutParams(
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                    update = { previewView ->
                        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                        cameraProviderFuture.addListener({
                            val cameraProvider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().also {
                                it.setSurfaceProvider(previewView.surfaceProvider)
                            }

                            val executor = Executors.newSingleThreadExecutor()
                            val imageAnalysis = ImageAnalysis.Builder()
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                .build()
                                .also { analysis ->
                                    analysis.setAnalyzer(executor) { proxy ->
                                        val signature = TeachableVisionEngine.extractFeatures(proxy)
                                        onFrameAnalyzed(signature)
                                        proxy.close()
                                    }
                                }

                            try {
                                cameraProvider.unbindAll()
                                cameraProvider.bindToLifecycle(
                                    lifecycleOwner,
                                    CameraSelector.DEFAULT_BACK_CAMERA,
                                    preview,
                                    imageAnalysis
                                )
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }, ContextCompat.getMainExecutor(context))
                    }
                )

                // Viewfinder Target Overlay
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Transparent,
                    border = BorderStroke(2.dp, Color(0xFF39FF14)),
                    modifier = Modifier
                        .size(120.dp)
                        .align(Alignment.Center)
                ) {}

                // Capture & Train Button
                Button(
                    onClick = { showTrainDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF39FF14)),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp)
                ) {
                    Icon(Icons.Default.Camera, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Train Object In Viewfinder", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        detectedBanner?.let { banner ->
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF00363D),
                border = BorderStroke(1.dp, Color(0xFF39FF14)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = banner,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF39FF14),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }

        // List of Trained Objects
        Text(
            text = "TRAINED OBJECTS IN OFFLINE NEURAL STORE (${trainedObjects.size})",
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF00F0FF),
            fontFamily = FontFamily.Monospace
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(trainedObjects) { obj ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF0E0E16),
                    border = BorderStroke(1.dp, Color(0xFF334155)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(obj.label, style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Action: ${obj.assignedAction}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF39FF14))
                        }
                        IconButton(onClick = { onDeleteObject(obj) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF4444), modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (showTrainDialog) {
        AlertDialog(
            onDismissRequest = { showTrainDialog = false },
            title = { Text("Train Object from Camera", color = Color.White) },
            containerColor = Color(0xFF14141E),
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Point the viewfinder at the object (e.g. coffee mug, ID badge, book).", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    OutlinedTextField(
                        value = trainLabel,
                        onValueChange = { trainLabel = it },
                        label = { Text("Object Name (e.g. Water Bottle, Keys)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = trainAction,
                        onValueChange = { trainAction = it },
                        label = { Text("Action (e.g. Remind Hydration, Open App)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (trainLabel.isNotBlank()) {
                            onTrainCurrentObject(trainLabel, trainAction.ifBlank { "Log detection" })
                            showTrainDialog = false
                            trainLabel = ""
                            trainAction = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF39FF14))
                ) {
                    Text("Save Object", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTrainDialog = false }) { Text("Cancel", color = Color(0xFF94A3B8)) }
            }
        )
    }
}

@Composable
fun OfflineKnowledgeTab(
    speechEngine: AriiaSpeechEngine,
    onQuerySelected: (String) -> Unit
) {
    val sampleQuestions = listOf(
        "What is passion?",
        "What is epithelial cells?",
        "How to play chess?",
        "Who is Galileo?",
        "Call to mom",
        "Open contacts",
        "Open camera",
        "Open messages",
        "Open Facebook",
        "Open chrome",
        "Open WhatsApp",
        "Open Gmail",
        "Google today s news",
        "Wiki Bermuda triangle",
        "YouTube how to cook idli sambar",
        "Wake me at 7.00 a.m.",
        "Set reminder for medicine at 9.00 p.m.",
        "Set reminder for yoga at 8.00 a.m.",
        "Set reminder for meeting with Raju at 2 p.m."
    )

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "OFFLINE INTELLIGENCE & SAMPLE COMMANDS",
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF00F0FF),
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "Tap any question or command below to execute it with offline reasoning and spoken ARIIA voice.",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF94A3B8)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(sampleQuestions) { q ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF0E0E18),
                    border = BorderStroke(1.dp, Color(0xFF1E293B)),
                    onClick = { onQuerySelected(q) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "\"$q\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = "Run",
                            tint = Color(0xFF00F0FF),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
