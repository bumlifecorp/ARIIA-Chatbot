package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.util.AriiaSpeechEngine
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PainterProtocolScreen(
    engine: PainterProtocolEngine = remember { PainterProtocolEngine() },
    onNavigateToEarth: (String, Float, Float) -> Unit = { _, _, _ -> },
    onNavigateTab: (Int) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    // Navigation sub-tabs inside [Painter] Protocol:
    // 0: Color_Picker (Search & Filter + Facial Recognition)
    // 1: Paint_Brushing (Selection & Canvas Paint)
    // 2: Paint_Dryer (Real-time Telemetry & Satellite Sensor Tracking)
    // 3: Art_Gallery (Display All Painted Objects)
    var selectedProtocolTab by remember { mutableIntStateOf(0) }

    var isArtistAutomationActive by remember { mutableStateOf(true) }
    var autoHarmonyStatus by remember { mutableStateOf("Golden Ratio Palette (1.618)") }

    val paintedObjects by engine.paintedObjects.collectAsState()
    val searchResults by engine.searchResults.collectAsState()
    val isSearching by engine.isSearching.collectAsState()
    val telemetryLogs by engine.telemetryHandoffLog.collectAsState()
    val canvasTargets by engine.canvasDetectableObjects.collectAsState()

    var activeFocusTargetId by remember { mutableStateOf<String?>(null) }
    val focusedPaintedObject = paintedObjects.firstOrNull { it.id == activeFocusTargetId } ?: paintedObjects.firstOrNull()

    // Pulsing animations for telemetry radar & sensors
    val infiniteTransition = rememberInfiniteTransition(label = "painterRadarPulse")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweepAngle"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030508))
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // [Painter] Protocol Header Banner
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF090D15),
                border = BorderStroke(1.5.dp, Color(0xFF00F0FF).copy(alpha = 0.7f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00F0FF))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "PROTOCOL: [PAINTER]",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00F0FF),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 15.sp
                            )
                        }

                        Badge(
                            containerColor = Color(0xFF003816),
                            contentColor = Color(0xFF39FF14)
                        ) {
                            Text(
                                text = "${paintedObjects.size} TARGETS IN GALLERY",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Color_Picker • Paint_Brushing • Paint_Dryer • Art_Gallery",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("AUTO HARMONY", fontSize = 8.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                                Switch(
                                    checked = isArtistAutomationActive,
                                    onCheckedChange = {
                                        isArtistAutomationActive = it
                                        speechEngine.speak(if (it) "Artist Program Automation active. Automatic color harmonic balancing engaged." else "Automation paused.")
                                    },
                                    modifier = Modifier.scale(0.7f),
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
                                )
                            }
                            IconButton(
                                onClick = {
                                    val count = paintedObjects.size
                                    val speech = "Painter Protocol online. $count objects painted and monitored across satellite telemetry and camera feeds. Automation state: $autoHarmonyStatus."
                                    speechEngine.speak(speech)
                                },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(Icons.Default.VolumeUp, contentDescription = "Voice Brief", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            // Sub-Navigation Tabs: Color_Picker, Paint_Brushing, Paint_Dryer, Art_Gallery
            TabRow(
                selectedTabIndex = selectedProtocolTab,
                containerColor = Color(0xFF0A0E18),
                contentColor = Color(0xFF00F0FF),
                divider = {}
            ) {
                Tab(
                    selected = selectedProtocolTab == 0,
                    onClick = { selectedProtocolTab = 0 },
                    text = {
                        Text(
                            "Color_Picker",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    icon = { Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedProtocolTab == 1,
                    onClick = { selectedProtocolTab = 1 },
                    text = {
                        Text(
                            "Paint_Brushing",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    icon = { Icon(Icons.Default.Brush, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedProtocolTab == 2,
                    onClick = { selectedProtocolTab = 2 },
                    text = {
                        Text(
                            "Paint_Dryer",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    icon = { Icon(Icons.Default.Sensors, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedProtocolTab == 3,
                    onClick = { selectedProtocolTab = 3 },
                    text = {
                        Text(
                            "Art_Gallery",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    icon = { Icon(Icons.Default.Collections, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }

            // Tab Content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedProtocolTab) {
                    0 -> ColorPickerView(
                        engine = engine,
                        searchResults = searchResults,
                        isSearching = isSearching,
                        onPaintResult = { result, paintColorHex, paintColorName, priority ->
                            val painted = engine.paintObject(
                                targetLabel = result.label,
                                category = result.category,
                                paintColorHex = paintColorHex,
                                paintColorName = paintColorName,
                                priority = priority,
                                feedId = result.matchedFeedId,
                                feedName = result.matchedFeedName,
                                lat = result.latitude,
                                lon = result.longitude,
                                altitude = result.altitudeMeters,
                                velocity = result.estimatedVelocity,
                                heading = result.headingDegrees,
                                faceScore = result.facialMatchScore,
                                faceProfileId = result.facialProfileId,
                                detectionSource = "Color_Picker Search"
                            )
                            activeFocusTargetId = painted.id
                            speechEngine.speak("Target painted with $paintColorName. Transferring to Paint Dryer real-time telemetry.")
                            com.example.utils.HapticManager.triggerPainterProtocolComplete(context)
                            Toast.makeText(context, "Painted ${result.label} [$paintColorName]", Toast.LENGTH_SHORT).show()
                            selectedProtocolTab = 2 // Transition to Paint_Dryer to observe telemetry
                        }
                    )
                    1 -> PaintBrushingView(
                        engine = engine,
                        canvasTargets = canvasTargets,
                        onPaintTarget = { targetLabel, category, hex, name, prio, feedId, feedName ->
                            val painted = engine.paintObject(
                                targetLabel = targetLabel,
                                category = category,
                                paintColorHex = hex,
                                paintColorName = name,
                                priority = prio,
                                feedId = feedId,
                                feedName = feedName,
                                lat = 34.0522 + ((-5..5).random() * 0.005),
                                lon = -118.2437 + ((-5..5).random() * 0.005),
                                altitude = 45.0,
                                velocity = 15.0f,
                                heading = 45.0f,
                                detectionSource = "Paint_Brushing Canvas Tool"
                            )
                            activeFocusTargetId = painted.id
                            speechEngine.speak("Object painted with $name. Continuous monitoring and telemetry dryer engaged.")
                            com.example.utils.HapticManager.triggerPainterProtocolComplete(context)
                            Toast.makeText(context, "Painted $targetLabel", Toast.LENGTH_SHORT).show()
                            selectedProtocolTab = 2 // Move to Paint_Dryer
                        }
                    )
                    2 -> PaintDryerView(
                        focusedTarget = focusedPaintedObject,
                        allPaintedObjects = paintedObjects,
                        telemetryLogs = telemetryLogs,
                        sweepAngle = sweepAngle,
                        pulseAlpha = pulseAlpha,
                        onSelectTarget = { activeFocusTargetId = it.id },
                        onVoiceBriefing = { target ->
                            val text = "Telemetry lock for ${target.name}. Latitude ${String.format(Locale.US, "%.4f", target.latitude)}, longitude ${String.format(Locale.US, "%.4f", target.longitude)}. Speed ${target.velocityKmh} kilometers per hour, heading ${target.headingDegrees.toInt()} degrees. Satellite link stable."
                            speechEngine.speak(text)
                        },
                        onNavigateToEarth = { target ->
                            onNavigateToEarth(target.name, target.latitude.toFloat(), target.longitude.toFloat())
                        }
                    )
                    3 -> ArtGalleryView(
                        paintedObjects = paintedObjects,
                        onSelectTrack = { target ->
                            activeFocusTargetId = target.id
                            selectedProtocolTab = 2 // Switch to Paint_Dryer
                        },
                        onToggleMonitoring = { engine.toggleMonitoring(it) },
                        onRemove = { engine.removePaintedObject(it) },
                        onColorChange = { id, hex, name -> engine.updatePaintColor(id, hex, name) },
                        onVoiceDossier = { target ->
                            val speech = "Dossier for ${target.name}. Category ${target.category}, lock status ${target.lockStatus}. Paint drying is at ${target.dryStatusPercent} percent. Telemetry source: ${target.currentFeedName}."
                            speechEngine.speak(speech)
                        }
                    )
                }
            }
        }
    }
}

/**
 * Feature A: Color_Picker View
 * Combine all search, camera and map features to create a protocol using algorithms
 * to apply search filters and conduct automated searches from user parameter input.
 * Facial recognition can be applied to pictures of people and used as search filter
 * applicable to live maps and camera feeds for fast detection and localization.
 */
@Composable
fun ColorPickerView(
    engine: PainterProtocolEngine,
    searchResults: List<ColorPickerSearchResult>,
    isSearching: Boolean,
    onPaintResult: (ColorPickerSearchResult, String, String, String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") }
    var selectedThreat by remember { mutableStateOf("ALL") }
    var enableFacialRec by remember { mutableStateOf(true) }
    var selectedFaceProfileId by remember { mutableStateOf("DS-001") }
    var minConfidence by remember { mutableFloatStateOf(0.85f) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            // Algorithmic Search Filters Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF0C101A),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "COLOR_PICKER ALGORITHMIC SEARCH MATRIX",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFF00F0FF),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search parameter (Name, Vector ID, Plate, Sector)...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF00F0FF)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00F0FF),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Target Category Filter Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("ALL", "PERSON", "VEHICLE", "DRONE", "VESSEL", "FACILITY").forEach { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 9.sp, fontFamily = FontFamily.Monospace) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF004455),
                                    selectedLabelColor = Color(0xFF00F0FF),
                                    containerColor = Color(0xFF0E1420),
                                    labelColor = Color(0xFF94A3B8)
                                )
                            )
                        }
                    }

                    // Facial Recognition Filter Subsection
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF05131C),
                        border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Face, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Biometric Facial Recognition Filter",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                                Switch(
                                    checked = enableFacialRec,
                                    onCheckedChange = { enableFacialRec = it },
                                    modifier = Modifier.height(24.dp)
                                )
                            }

                            if (enableFacialRec) {
                                Text(
                                    text = "Select Biometric Face Profile to correlate with live maps & camera feeds:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF94A3B8),
                                    fontSize = 10.sp
                                )

                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items(engine.availableFaceProfiles) { profile ->
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (selectedFaceProfileId == profile.id) Color(0xFF003844) else Color(0xFF090E18),
                                            border = BorderStroke(
                                                1.dp,
                                                if (selectedFaceProfileId == profile.id) Color(0xFF00F0FF) else Color(0xFF1E293B)
                                            ),
                                            modifier = Modifier.clickable { selectedFaceProfileId = profile.id }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Person,
                                                    contentDescription = null,
                                                    tint = if (selectedFaceProfileId == profile.id) Color(0xFF39FF14) else Color(0xFF94A3B8),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Column {
                                                    Text(profile.name, fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                    Text("${(profile.knownFaceScore * 100).toInt()}% Match", fontSize = 8.sp, color = Color(0xFF39FF14))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Threat Filter & Confidence Threshold
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Min Confidence: ${(minConfidence * 100).toInt()}%",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8),
                            fontFamily = FontFamily.Monospace
                        )
                        Slider(
                            value = minConfidence,
                            onValueChange = { minConfidence = it },
                            valueRange = 0.70f..0.99f,
                            modifier = Modifier.width(180.dp)
                        )
                    }

                    // Run Search Button
                    Button(
                        onClick = {
                            engine.performColorPickerSearch(
                                ColorPickerSearchFilter(
                                    query = searchQuery,
                                    category = selectedCategory,
                                    threatLevel = selectedThreat,
                                    enableFacialRecognition = enableFacialRec,
                                    selectedFaceProfileId = if (enableFacialRec) selectedFaceProfileId else null,
                                    minConfidenceThreshold = minConfidence
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF005566)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isSearching) {
                            CircularProgressIndicator(color = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SWEEPING 25+ CAMERAS & SATELLITE MAPS...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.Sensors, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("RUN AUTOMATED COLOR_PICKER SWEEP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Search Results Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LOCALIZED SEARCH RESULTS (${searchResults.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color(0xFF00F0FF),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Tap target to Apply Paint & Dry",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B),
                    fontSize = 9.sp
                )
            }
        }

        // Search Results Cards
        if (searchResults.isEmpty() && !isSearching) {
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF0A0D15),
                    border = BorderStroke(1.dp, Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.FilterList, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(32.dp))
                        Text(
                            text = "No active results. Tap 'RUN AUTOMATED COLOR_PICKER SWEEP' to scan all connected feeds and satellite telemetry.",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(searchResults, key = { it.id }) { result ->
                SearchResultItemCard(
                    result = result,
                    onPaint = { hex, name, prio ->
                        onPaintResult(result, hex, name, prio)
                    }
                )
            }
        }
    }
}

@Composable
fun SearchResultItemCard(
    result: ColorPickerSearchResult,
    onPaint: (String, String, String) -> Unit
) {
    val accentColor = remember(result.suggestedPaintColorHex) {
        try {
            Color(android.graphics.Color.parseColor(result.suggestedPaintColorHex))
        } catch (_: Exception) {
            Color(0xFF00F0FF)
        }
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF0A0E17),
        border = BorderStroke(1.2.dp, accentColor.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(accentColor)
                    )
                    Text(
                        text = result.label,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }

                Badge(containerColor = Color(0xFF003816), contentColor = Color(0xFF39FF14)) {
                    Text(
                        "${String.format(Locale.US, "%.1f", result.confidence * 100)}% MATCH",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            // Feed & Coordinates
            Text(
                text = "MATCHED: ${result.matchedFeedName} (${result.matchedFeedId})",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF00F0FF),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Coords: ${result.coordinates}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF94A3B8),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Est Speed: ${result.estimatedVelocity} km/h",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF39FF14),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Paint Quick Trigger Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Badge(containerColor = accentColor.copy(alpha = 0.2f), contentColor = accentColor) {
                    Text("SUGGESTED BRUSH: ${result.suggestedPaintColorName}", fontSize = 8.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                }

                Button(
                    onClick = {
                        onPaint(result.suggestedPaintColorHex, result.suggestedPaintColorName, "CRITICAL_P1")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Icon(Icons.Default.Brush, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Black)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("PAINT & DRY", fontSize = 9.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Feature B: Paint_Brushing View
 * Allowing users to select or "paint" any detectable object for continuous monitoring.
 */
@Composable
fun PaintBrushingView(
    engine: PainterProtocolEngine,
    canvasTargets: List<DetectableCanvasTarget>,
    onPaintTarget: (String, String, String, String, String, String, String) -> Unit
) {
    var selectedBrushColor by remember { mutableStateOf(engine.paintBrushPalette[0]) } // Pair(hex, name)
    var selectedPriority by remember { mutableStateOf("CRITICAL_P1") }
    var selectedFeed by remember { mutableStateOf("CAM-01: Downtown Sector Alpha") }
    var customLabel by remember { mutableStateOf("Subject Vance (Retinal Lock)") }
    var customCategory by remember { mutableStateOf("PERSON") }

    var selectedTargetIdOnCanvas by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            // Live Feed Selection
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0A0E18),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("FEED VIEWPORT:", style = MaterialTheme.typography.labelSmall, color = Color(0xFF64748B), fontSize = 8.sp)
                        Text(selectedFeed, style = MaterialTheme.typography.bodySmall, color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("CAM-01", "SHIBUYA", "DRONE-04", "PORT-FLIR").forEach { fKey ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF162032))
                                    .clickable {
                                        selectedFeed = when (fKey) {
                                            "SHIBUYA" -> "CAM-SHIBUYA: Shibuya Scramble Crossing 4K"
                                            "DRONE-04" -> "CAM-04: Aerial Drone Gimbal"
                                            "PORT-FLIR" -> "CAM-02: Industrial Port FLIR Thermal"
                                            else -> "CAM-01: Downtown Sector Alpha"
                                        }
                                    }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(fKey, fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        item {
            // Interactive Video Feed Canvas with Detectable Objects to Paint
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF05070D),
                border = BorderStroke(1.5.dp, Color(0xFF00F0FF).copy(alpha = 0.8f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures { offset ->
                                val xPct = offset.x / size.width
                                val yPct = offset.y / size.height
                                // Check if tapped on any target
                                val hit = canvasTargets.firstOrNull {
                                    xPct >= it.xPercent && xPct <= (it.xPercent + it.widthPercent) &&
                                            yPct >= it.yPercent && yPct <= (it.yPercent + it.heightPercent)
                                }
                                if (hit != null) {
                                    selectedTargetIdOnCanvas = hit.id
                                    customLabel = hit.label
                                    customCategory = hit.category
                                } else {
                                    selectedTargetIdOnCanvas = null
                                    customLabel = "Custom Painted Reticle #${(100..999).random()}"
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // Simulated scanlines
                        for (y in 0..h.toInt() step 14) {
                            drawLine(
                                color = Color(0xFF00F0FF).copy(alpha = 0.05f),
                                start = Offset(0f, y.toFloat()),
                                end = Offset(w, y.toFloat()),
                                strokeWidth = 1f
                            )
                        }

                        // Crosshairs
                        drawLine(color = Color(0xFF00F0FF).copy(alpha = 0.2f), start = Offset(w / 2f, 0f), end = Offset(w / 2f, h), strokeWidth = 1f)
                        drawLine(color = Color(0xFF00F0FF).copy(alpha = 0.2f), start = Offset(0f, h / 2f), end = Offset(w, h / 2f), strokeWidth = 1f)

                        // Draw detectable targets bounding boxes
                        canvasTargets.forEach { target ->
                            val boxX = target.xPercent * w
                            val boxY = target.yPercent * h
                            val boxW = target.widthPercent * w
                            val boxH = target.heightPercent * h

                            val isSelected = target.id == selectedTargetIdOnCanvas
                            val boxColor = if (isSelected) Color(0xFF39FF14) else if (target.isAlreadyPainted) Color(0xFFBD00FF) else Color(0xFF00F0FF)

                            drawRect(
                                color = boxColor.copy(alpha = 0.7f),
                                topLeft = Offset(boxX, boxY),
                                size = Size(boxW, boxH),
                                style = Stroke(width = if (isSelected) 2.5f else 1.2f)
                            )

                            // Corner brackets
                            val bLen = 8f
                            drawLine(color = boxColor, start = Offset(boxX, boxY), end = Offset(boxX + bLen, boxY), strokeWidth = 2f)
                            drawLine(color = boxColor, start = Offset(boxX, boxY), end = Offset(boxX, boxY + bLen), strokeWidth = 2f)
                        }
                    }

                    // Feed Watermark & Status
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Badge(containerColor = Color(0xFF003816), contentColor = Color(0xFF39FF14)) {
                            Text("OPTICAL LIVE FEED", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                        Badge(containerColor = Color(0xFF101B2B), contentColor = Color(0xFF00F0FF)) {
                            Text("TAP TO SELECT OR PAINT", fontSize = 8.sp)
                        }
                    }

                    // Bottom info bar of selected canvas object
                    selectedTargetIdOnCanvas?.let { selId ->
                        val target = canvasTargets.firstOrNull { it.id == selId }
                        if (target != null) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFF002233).copy(alpha = 0.9f),
                                border = BorderStroke(1.dp, Color(0xFF39FF14)),
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "SELECTED: ${target.label} | Category: ${target.category} | ${(target.confidence * 100).toInt()}% Conf",
                                    color = Color(0xFF39FF14),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            // Paint Brush Palette & Customization Controls
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF0B101C),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "PAINT_BRUSHING TOOL CONTROLS",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFF00F0FF),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    // Target Name field
                    OutlinedTextField(
                        value = customLabel,
                        onValueChange = { customLabel = it },
                        label = { Text("Paint Target Label / Designation", fontSize = 10.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00F0FF),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Paint Color Brush Palette Selection
                    Text(
                        text = "Select Tracking Paint Color / Signature:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF94A3B8),
                        fontSize = 10.sp
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(engine.paintBrushPalette) { (hex, name) ->
                            val cColor = try {
                                Color(android.graphics.Color.parseColor(hex))
                            } catch (_: Exception) {
                                Color(0xFF00F0FF)
                            }
                            val isSelected = selectedBrushColor.first == hex

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) cColor.copy(alpha = 0.25f) else Color(0xFF101624),
                                border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) cColor else Color(0xFF334155)),
                                modifier = Modifier.clickable { selectedBrushColor = Pair(hex, name) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(cColor)
                                    )
                                    Text(
                                        text = name,
                                        fontSize = 10.sp,
                                        color = if (isSelected) Color.White else Color(0xFF94A3B8),
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }

                    // Priority selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Monitoring Priority:", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("CRITICAL_P1" to "P1 Critical", "HIGH_P2" to "P2 High", "CONTINUOUS_P3" to "P3 Continuous").forEach { (key, lbl) ->
                                val isSel = selectedPriority == key
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSel) Color(0xFFBD00FF) else Color(0xFF162032))
                                        .clickable { selectedPriority = key }
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = lbl,
                                        fontSize = 9.sp,
                                        color = if (isSel) Color.White else Color(0xFF94A3B8),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Apply Paint Brush Action Button
                    val activeBrushColor = try {
                        Color(android.graphics.Color.parseColor(selectedBrushColor.first))
                    } catch (_: Exception) {
                        Color(0xFF00F0FF)
                    }

                    Button(
                        onClick = {
                            val feedParts = selectedFeed.split(":")
                            val feedId = feedParts[0].trim()
                            val feedName = feedParts.getOrElse(1) { "Live Optical Feed" }.trim()

                            onPaintTarget(
                                customLabel,
                                customCategory,
                                selectedBrushColor.first,
                                selectedBrushColor.second,
                                selectedPriority,
                                feedId,
                                feedName
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = activeBrushColor),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Brush, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "APPLY PAINT BRUSH [START CONTINUOUS MONITORING]",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }
        }
    }
}

/**
 * Feature C: Paint_Dryer View
 * Combining facial recognition with camera and satellite telemetry using all available assets
 * to create a protocol using algorithms to locate, monitor and track painted objects' movement in real-time.
 */
@Composable
fun PaintDryerView(
    focusedTarget: PaintedObject?,
    allPaintedObjects: List<PaintedObject>,
    telemetryLogs: List<String>,
    sweepAngle: Float,
    pulseAlpha: Float,
    onSelectTarget: (PaintedObject) -> Unit,
    onVoiceBriefing: (PaintedObject) -> Unit,
    onNavigateToEarth: (PaintedObject) -> Unit
) {
    if (focusedTarget == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No active painted target. Use Color_Picker or Paint_Brushing to acquire an object.", color = Color(0xFF64748B), fontSize = 12.sp)
        }
        return
    }

    val targetColor = remember(focusedTarget.paintColorHex) {
        try {
            Color(android.graphics.Color.parseColor(focusedTarget.paintColorHex))
        } catch (_: Exception) {
            Color(0xFF00F0FF)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Target Selector Row
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(allPaintedObjects) { obj ->
                    val isSel = obj.id == focusedTarget.id
                    val c = try {
                        Color(android.graphics.Color.parseColor(obj.paintColorHex))
                    } catch (_: Exception) {
                        Color(0xFF00F0FF)
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isSel) c.copy(alpha = 0.2f) else Color(0xFF0E131E),
                        border = BorderStroke(if (isSel) 1.5.dp else 1.dp, if (isSel) c else Color(0xFF1E293B)),
                        modifier = Modifier.clickable { onSelectTarget(obj) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(c))
                            Text(obj.id, fontSize = 9.sp, color = if (isSel) Color.White else Color(0xFF94A3B8), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Active Target Telemetry & "Paint Drying" Lock State Card
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF090D16),
                border = BorderStroke(1.5.dp, targetColor.copy(alpha = 0.8f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(targetColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = focusedTarget.name,
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Badge(
                            containerColor = if (focusedTarget.dryStatusPercent == 100) Color(0xFF003816) else Color(0xFF382200),
                            contentColor = if (focusedTarget.dryStatusPercent == 100) Color(0xFF39FF14) else Color(0xFFFFB300)
                        ) {
                            Text(
                                text = "${focusedTarget.dryStatusPercent}% DRY - ${focusedTarget.lockStatus}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Progress bar representing "Paint_Dryer" lock hardening
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("PAINT_DRYER SATELLITE & SENSOR LOCK PROGRESS:", fontSize = 9.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                            Text("${focusedTarget.dryStatusPercent}%", fontSize = 9.sp, color = targetColor, fontWeight = FontWeight.Bold)
                        }
                        LinearProgressIndicator(
                            progress = { focusedTarget.dryStatusPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = targetColor,
                            trackColor = Color(0xFF1E293B)
                        )
                    }

                    // Live Telemetry Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("GPS COORDINATES", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                            Text(focusedTarget.coordinates, fontSize = 11.sp, color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("VELOCITY", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                            Text("${String.format(Locale.US, "%.1f", focusedTarget.velocityKmh)} km/h", fontSize = 11.sp, color = Color(0xFF39FF14), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("ALTITUDE", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                            Text("${focusedTarget.altitudeMeters.toInt()} m", fontSize = 11.sp, color = Color(0xFFFFB300), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("HEADING", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                            Text("${focusedTarget.headingDegrees.toInt()}°", fontSize = 11.sp, color = Color(0xFFBD00FF), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    // Connected Multi-Asset Sensor Link
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF060B12),
                        border = BorderStroke(1.dp, Color(0xFF1E293B)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("ACTIVE ASSET CHAIN:", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                                Text("${focusedTarget.currentFeedName} → LEO Satellite Constellation", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(
                                    onClick = { onVoiceBriefing(focusedTarget) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "Speak", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                                }

                                FilledTonalButton(
                                    onClick = { onNavigateToEarth(focusedTarget) },
                                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF003844), contentColor = Color(0xFF00F0FF)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(26.dp)
                                ) {
                                    Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("EARTH 3D", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Real-Time 2D Tactical Radar & Vector Trajectory Canvas
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF05070B),
                border = BorderStroke(1.5.dp, Color(0xFF00F0FF).copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val radius = minOf(size.width, size.height) * 0.42f

                        // Radar Range Rings
                        drawCircle(color = Color(0xFF00F0FF).copy(alpha = 0.15f), radius = radius, center = center, style = Stroke(1f))
                        drawCircle(color = Color(0xFF00F0FF).copy(alpha = 0.15f), radius = radius * 0.66f, center = center, style = Stroke(1f))
                        drawCircle(color = Color(0xFF00F0FF).copy(alpha = 0.15f), radius = radius * 0.33f, center = center, style = Stroke(1f))

                        // Crosshairs
                        drawLine(color = Color(0xFF00F0FF).copy(alpha = 0.2f), start = Offset(center.x - radius, center.y), end = Offset(center.x + radius, center.y), strokeWidth = 1f)
                        drawLine(color = Color(0xFF00F0FF).copy(alpha = 0.2f), start = Offset(center.x, center.y - radius), end = Offset(center.x, center.y + radius), strokeWidth = 1f)

                        // Radar sweep line
                        val rad = Math.toRadians(sweepAngle.toDouble())
                        val endX = center.x + (radius * cos(rad)).toFloat()
                        val endY = center.y + (radius * sin(rad)).toFloat()
                        drawLine(
                            color = Color(0xFF39FF14).copy(alpha = 0.7f),
                            start = center,
                            end = Offset(endX, endY),
                            strokeWidth = 2f
                        )

                        // Draw trajectory breadcrumbs for active target
                        val crumbs = focusedTarget.breadcrumbs
                        if (crumbs.size > 1) {
                            for (i in 0 until crumbs.size - 1) {
                                val c1 = crumbs[i]
                                val c2 = crumbs[i + 1]
                                val offsetFactor = 0.005f
                                val pt1 = Offset(
                                    center.x + ((c1.lon - focusedTarget.longitude) / offsetFactor * radius * 0.8f).toFloat(),
                                    center.y + ((c1.lat - focusedTarget.latitude) / offsetFactor * radius * 0.8f).toFloat()
                                )
                                val pt2 = Offset(
                                    center.x + ((c2.lon - focusedTarget.longitude) / offsetFactor * radius * 0.8f).toFloat(),
                                    center.y + ((c2.lat - focusedTarget.latitude) / offsetFactor * radius * 0.8f).toFloat()
                                )

                                drawLine(
                                    color = targetColor.copy(alpha = 0.5f),
                                    start = pt1,
                                    end = pt2,
                                    strokeWidth = 1.8f
                                )
                            }
                        }

                        // Target Core Reticle at center
                        drawCircle(
                            color = targetColor.copy(alpha = pulseAlpha),
                            radius = 12f,
                            center = center,
                            style = Stroke(2.5f)
                        )
                        drawCircle(
                            color = targetColor,
                            radius = 4f,
                            center = center
                        )

                        // Heading vector arrow
                        val hRad = Math.toRadians(focusedTarget.headingDegrees.toDouble())
                        val vecX = center.x + (40f * cos(hRad)).toFloat()
                        val vecY = center.y + (40f * sin(hRad)).toFloat()
                        drawLine(
                            color = Color(0xFF39FF14),
                            start = center,
                            end = Offset(vecX, vecY),
                            strokeWidth = 2.2f
                        )
                    }

                    // Compass Indicators
                    Text("N", modifier = Modifier.align(Alignment.TopCenter).padding(4.dp), color = Color(0xFF00F0FF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("S", modifier = Modifier.align(Alignment.BottomCenter).padding(4.dp), color = Color(0xFF64748B), fontSize = 9.sp)
                    Text("E", modifier = Modifier.align(Alignment.CenterEnd).padding(4.dp), color = Color(0xFF64748B), fontSize = 9.sp)
                    Text("W", modifier = Modifier.align(Alignment.CenterStart).padding(4.dp), color = Color(0xFF64748B), fontSize = 9.sp)
                }
            }
        }

        // Telemetry Multi-Asset Handoff Stream Log
        item {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF080B12),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "MULTI-ASSET TELEMETRY & SATELLITE HANDOFF LOG",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF00F0FF),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )

                    telemetryLogs.take(5).forEach { log ->
                        Text(
                            text = log,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

/**
 * Feature D: Art_Gallery View
 * Display all painted objects in an interactive catalog with rich telemetry and controls.
 */
@Composable
fun ArtGalleryView(
    paintedObjects: List<PaintedObject>,
    onSelectTrack: (PaintedObject) -> Unit,
    onToggleMonitoring: (String) -> Unit,
    onRemove: (String) -> Unit,
    onColorChange: (String, String, String) -> Unit,
    onVoiceDossier: (PaintedObject) -> Unit
) {
    var filterCategory by remember { mutableStateOf("ALL") }

    val filteredList = remember(paintedObjects, filterCategory) {
        if (filterCategory == "ALL") paintedObjects else paintedObjects.filter { it.category == filterCategory }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Art Gallery Header Stats
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF0B0F1A),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ART_GALLERY PAINTED ASSETS",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color(0xFF00F0FF),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Active multi-sensor objects under continuous telemetry",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF64748B),
                            fontSize = 9.sp
                        )
                    }

                    Badge(containerColor = Color(0xFF003816), contentColor = Color(0xFF39FF14)) {
                        Text(
                            "${paintedObjects.count { it.isMonitoring }} ACTIVE LOCKS",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Category Filter Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(listOf("ALL", "PERSON", "VEHICLE", "DRONE", "VESSEL")) { cat ->
                    FilterChip(
                        selected = filterCategory == cat,
                        onClick = { filterCategory = cat },
                        label = { Text(cat, fontSize = 9.sp, fontFamily = FontFamily.Monospace) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF004455),
                            selectedLabelColor = Color(0xFF00F0FF),
                            containerColor = Color(0xFF0E1420),
                            labelColor = Color(0xFF94A3B8)
                        )
                    )
                }
            }
        }

        // Painted Object Dossier Cards in Art Gallery
        if (filteredList.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF0A0D15),
                    border = BorderStroke(1.dp, Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Collections, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(36.dp))
                        Text(
                            text = "Art Gallery is empty. Use Color_Picker or Paint_Brushing to paint detectable objects for continuous monitoring.",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(filteredList, key = { it.id }) { target ->
                ArtGalleryCard(
                    target = target,
                    onTrack = { onSelectTrack(target) },
                    onToggleMonitoring = { onToggleMonitoring(target.id) },
                    onRemove = { onRemove(target.id) },
                    onVoice = { onVoiceDossier(target) }
                )
            }
        }
    }
}

@Composable
fun ArtGalleryCard(
    target: PaintedObject,
    onTrack: () -> Unit,
    onToggleMonitoring: () -> Unit,
    onRemove: () -> Unit,
    onVoice: () -> Unit
) {
    val brushColor = remember(target.paintColorHex) {
        try {
            Color(android.graphics.Color.parseColor(target.paintColorHex))
        } catch (_: Exception) {
            Color(0xFF00F0FF)
        }
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF080C14),
        border = BorderStroke(1.5.dp, brushColor.copy(alpha = 0.75f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Card Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(brushColor)
                    )
                    Text(
                        text = target.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Badge(containerColor = brushColor.copy(alpha = 0.2f), contentColor = brushColor) {
                    Text(target.paintColorName, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                }
            }

            // Identification Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "ID: ${target.id} | Cat: ${target.category} | ${target.priority}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (target.facialMatchScore > 0.0f) {
                    Badge(containerColor = Color(0xFF003816), contentColor = Color(0xFF39FF14)) {
                        Text("FACE: ${(target.facialMatchScore * 100).toInt()}%", fontSize = 8.sp, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                    }
                }
            }

            // Telemetry & Feed link
            Text(
                text = "COORDS: ${target.coordinates} • ${String.format(Locale.US, "%.1f", target.velocityKmh)} km/h • Heading: ${target.headingDegrees.toInt()}°",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF00F0FF),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )

            Text(
                text = "FEED: ${target.currentFeedName}",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF64748B),
                fontSize = 9.sp
            )

            // Drying progress bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LinearProgressIndicator(
                    progress = { target.dryStatusPercent / 100f },
                    modifier = Modifier
                        .weight(1f)
                        .height(5.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = brushColor,
                    trackColor = Color(0xFF1E293B)
                )
                Text("${target.dryStatusPercent}% DRY", fontSize = 8.sp, color = brushColor, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }

            // Actions: Track in Dryer, Voice Briefing, Pause Monitoring, Release
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = onTrack,
                        colors = ButtonDefaults.buttonColors(containerColor = brushColor),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Icon(Icons.Default.Sensors, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("DRYER TELEMETRY", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = onVoice,
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Dossier Voice", tint = Color(0xFF00F0FF), modifier = Modifier.size(16.dp))
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onToggleMonitoring,
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = if (target.isMonitoring) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle Monitoring",
                            tint = if (target.isMonitoring) Color(0xFF39FF14) else Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onRemove,
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Release", tint = Color(0xFFFF3366), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
