package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ImmersiveBg
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveOnLavender
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.viewmodel.LauncherViewMode

@Composable
fun LauncherDock(
    isTorchOn: Boolean,
    isVisionVisible: Boolean,
    viewMode: LauncherViewMode,
    onToggleTorch: () -> Unit,
    onOpenVoice: () -> Unit,
    onToggleVision: () -> Unit,
    onToggleDrawer: () -> Unit,
    iconShape: String = "Squircle",
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Flashlight / Torch Button (btnTorch)
            RoundDockButton(
                iconShape = iconShape,
                icon = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                isActive = isTorchOn,
                testTag = "btnTorch",
                contentDescription = "Ficklampa",
                onClick = onToggleTorch
            )

            // 2. Vision HUD Toggle Button (btnVision)
            RoundDockButton(
                iconShape = iconShape,
                icon = if (isVisionVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                isActive = isVisionVisible,
                testTag = "btnVision",
                contentDescription = "Vision",
                onClick = onToggleVision
            )

            // 3. App Drawer / Launcher Toggle Button (btnDrawer)
            RoundDockButton(
                iconShape = iconShape,
                icon = Icons.Default.Apps,
                isActive = viewMode == LauncherViewMode.DRAWER,
                testTag = "btnDrawer",
                contentDescription = "Appar",
                onClick = onToggleDrawer
            )

            // 4. Main Voice Assistant Button (btnVoice) - Lavender Pill/Circle with Dark Contrast
            VoiceDockButton(
                iconShape = iconShape,
                onClick = onOpenVoice,
                testTag = "btnVoice"
            )
        }
    }
}

@Composable
private fun RoundDockButton(
    icon: ImageVector,
    isActive: Boolean,
    testTag: String,
    contentDescription: String,
    iconShape: String = "Squircle",
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        targetValue = if (isActive) ImmersiveLavender.copy(alpha = 0.25f) else ImmersiveSurface,
        label = "btn_bg"
    )
    val borderColor by animateColorAsState(
        targetValue = if (isActive) ImmersiveLavender else ImmersiveBorder,
        label = "btn_border"
    )

    val shape = when (iconShape) {
        "Circle" -> CircleShape
        "Squircle" -> RoundedCornerShape(16.dp)
        "Teardrop" -> RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 50, bottomStartPercent = 10)
        else -> RoundedCornerShape(20.dp) // Default
    }

    val tintColor by animateColorAsState(
        targetValue = if (isActive) ImmersiveLavender else ImmersiveTextPrimary,
        label = "btn_tint"
    )


    Box(
        modifier = Modifier
            .size(54.dp)
            .testTag(testTag)
            .clip(shape)
            .background(bgColor, shape)
            .border(1.dp, borderColor, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tintColor,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
private fun VoiceDockButton(
    onClick: () -> Unit,
    testTag: String,
    iconShape: String = "Squircle"
) {

    val shape = when (iconShape) {
        "Circle" -> CircleShape
        "Squircle" -> RoundedCornerShape(16.dp)
        "Teardrop" -> RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 50, bottomStartPercent = 10)
        else -> RoundedCornerShape(20.dp) // Default
    }

    Box(
        modifier = Modifier
            .size(54.dp)
            .testTag(testTag)
            .clip(shape)
            .background(ImmersiveLavender, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Mic,
            contentDescription = "Röststyrning",
            tint = ImmersiveOnLavender,
            modifier = Modifier.size(26.dp)
        )
    }
}

