package com.example.ui.screens.earth

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

@Composable
fun TacticalGpsRouteFinder(
    presetTargets: List<TacticalTarget>,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var originTarget by remember { mutableStateOf(presetTargets[0]) }
    var destinationTarget by remember { mutableStateOf(presetTargets[1]) }

    // Geodesic distance calculation via Haversine formula
    val distanceKm = remember(originTarget, destinationTarget) {
        val r = 6371.0 // Earth radius in km
        val lat1 = Math.toRadians(originTarget.latitude.toDouble())
        val lon1 = Math.toRadians(originTarget.longitude.toDouble())
        val lat2 = Math.toRadians(destinationTarget.latitude.toDouble())
        val lon2 = Math.toRadians(destinationTarget.longitude.toDouble())

        val dLat = lat2 - lat1
        val dLon = lon2 - lon1
        val a = sin(dLat / 2).pow(2) + cos(lat1) * cos(lat2) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        (r * c).toFloat()
    }

    val distanceNm = (distanceKm * 0.539957f)
    val etaMach1Hours = (distanceKm / 1234.8f)
    val etaMinutes = (etaMach1Hours * 60).toInt()

    // Generated Turn-by-Turn Waypoints
    val routeSteps = remember(originTarget, destinationTarget, distanceKm) {
        listOf(
            GpsRouteStep(1, "Depart origin facility [${originTarget.callsign}]. Ascend to FL450 corridor.", distanceKm * 0.15f, "045° NE", maxOf(etaMinutes / 6, 2)),
            GpsRouteStep(2, "Intercept Great-Circle trans-oceanic geodesic waypoint ALPHA-09.", distanceKm * 0.35f, "062° ENE", maxOf(etaMinutes / 3, 5)),
            GpsRouteStep(3, "High-altitude orbital handoff with ARIIA-KH11 relay constellation.", distanceKm * 0.30f, "085° E", maxOf(etaMinutes / 4, 4)),
            GpsRouteStep(4, "Descend into terminal approach corridor for [${destinationTarget.callsign}].", distanceKm * 0.20f, "110° ESE", maxOf(etaMinutes / 5, 3))
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF03060E)),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Origin / Destination Selectors
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF080D18),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TACTICAL GPS ROUTE PLANNER", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    Button(
                        onClick = {
                            val speech = "Tactical flight route calculated from ${originTarget.name} to ${destinationTarget.name}. Total distance: ${distanceKm.toInt()} kilometers or ${distanceNm.toInt()} nautical miles. Estimated transit time: $etaMinutes minutes."
                            onSpeak(speech)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003845)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Audio Route", fontSize = 7.sp, color = Color(0xFF00F0FF))
                    }
                }

                // Origin Row
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TripOrigin, contentDescription = null, tint = Color(0xFF39FF14), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("FROM:", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.width(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(presetTargets) { t ->
                            val isSel = t.id == originTarget.id
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSel) Color(0xFF003A2B) else Color(0xFF0B1320),
                                border = BorderStroke(1.dp, if (isSel) Color(0xFF39FF14) else Color(0xFF1E293B)),
                                modifier = Modifier.clickable { originTarget = t }
                            ) {
                                Text(t.callsign, fontSize = 7.sp, color = if (isSel) Color.White else Color(0xFF94A3B8), modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                            }
                        }
                    }
                }

                // Destination Row
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = Color(0xFFFF0055), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("TO:    ", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.width(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(presetTargets) { t ->
                            val isSel = t.id == destinationTarget.id
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSel) Color(0xFF3A0018) else Color(0xFF0B1320),
                                border = BorderStroke(1.dp, if (isSel) Color(0xFFFF0055) else Color(0xFF1E293B)),
                                modifier = Modifier.clickable { destinationTarget = t }
                            ) {
                                Text(t.callsign, fontSize = 7.sp, color = if (isSel) Color.White else Color(0xFF94A3B8), modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                            }
                        }
                    }
                }
            }
        }

        // Distance & ETA Tactical Metric Badges
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0A1424),
                border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.3f)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("GEODESIC DISTANCE", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Text("${"%,d".format(distanceKm.toInt())} KM", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    Text("${"%,d".format(distanceNm.toInt())} NM", fontSize = 8.sp, color = Color(0xFF64748B))
                }
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF0A1424),
                border = BorderStroke(1.dp, Color(0xFF39FF14).copy(alpha = 0.3f)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ESTIMATED TRANSIT", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Text("$etaMinutes MIN", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    Text("@ MACH 1.0 (Corridor)", fontSize = 8.sp, color = Color(0xFF64748B))
                }
            }
        }

        // Turn-by-Turn Waypoint List
        Text("TURN-BY-TURN TACTICAL WAYPOINTS:", fontSize = 9.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(routeSteps) { step ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF080D1A),
                    border = BorderStroke(1.dp, Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .background(Color(0xFF00222F), CircleShape)
                                .border(1.dp, Color(0xFF00F0FF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("${step.index}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(step.instruction, fontSize = 9.sp, color = Color.White)
                            Text("Bearing: ${step.bearing} • Leg: ${step.distanceKm.toInt()} km", fontSize = 7.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                        }
                        Badge(containerColor = Color(0xFF0A202A), contentColor = Color(0xFF00F0FF)) {
                            Text("+${step.etaMinutes}m", fontSize = 7.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TacticalGpsSpeedoCompass(
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var isSimulatingSpeed by remember { mutableStateOf(true) }
    var currentSpeedKmh by remember { mutableFloatStateOf(118f) }
    var headingAngle by remember { mutableFloatStateOf(42f) }
    var altitudeMeters by remember { mutableIntStateOf(480) }

    val infiniteTransition = rememberInfiniteTransition(label = "SpeedoSim")
    val simulatedSpeedDelta by infiniteTransition.animateFloat(
        initialValue = -8f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(tween(2500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "SpeedDelta"
    )

    val effectiveSpeedKmh = if (isSimulatingSpeed) (currentSpeedKmh + simulatedSpeedDelta).coerceAtLeast(0f) else currentSpeedKmh
    val effectiveSpeedKnots = (effectiveSpeedKmh * 0.539957f)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF03060E)),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Tactical Speedometer & Compass Gauges
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Left: Speedometer Gauge Box
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(Color(0xFF020610), RoundedCornerShape(14.dp))
                    .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                    val w = size.width
                    val h = size.height
                    val center = Offset(w / 2f, h / 2f)
                    val radius = minOf(w, h) * 0.44f

                    // Speedometer Arc (135° to 405°)
                    drawArc(
                        color = Color(0xFF142436),
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        style = Stroke(8.dp.toPx()),
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2f, radius * 2f)
                    )

                    // Active Speed Arc
                    val speedPct = (effectiveSpeedKmh / 240f).coerceIn(0f, 1f)
                    drawArc(
                        brush = Brush.sweepGradient(
                            colors = listOf(Color(0xFF00F0FF), Color(0xFF39FF14), Color(0xFFFF0055)),
                            center = center
                        ),
                        startAngle = 135f,
                        sweepAngle = 270f * speedPct,
                        useCenter = false,
                        style = Stroke(8.dp.toPx()),
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2f, radius * 2f)
                    )
                }

                // Speed Text Center
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SPEED", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Text("${effectiveSpeedKmh.toInt()}", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    Text("KM/H", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    Text("${effectiveSpeedKnots.toInt()} KTS", fontSize = 8.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                }
            }

            // Right: True-North Compass Azimuth Dial
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(Color(0xFF020610), RoundedCornerShape(14.dp))
                    .border(1.dp, Color(0xFF39FF14).copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                    val w = size.width
                    val h = size.height
                    val center = Offset(w / 2f, h / 2f)
                    val radius = minOf(w, h) * 0.44f

                    // Outer dial ring
                    drawCircle(color = Color(0xFF132A1C), radius = radius, center = center, style = Stroke(2f))

                    // Compass Tick marks
                    for (deg in 0 until 360 step 30) {
                        val rad = Math.toRadians((deg - headingAngle).toDouble())
                        val p1 = Offset(center.x + (radius * 0.82f * sin(rad)).toFloat(), center.y - (radius * 0.82f * cos(rad)).toFloat())
                        val p2 = Offset(center.x + (radius * sin(rad)).toFloat(), center.y - (radius * cos(rad)).toFloat())
                        val isCard = deg % 90 == 0
                        drawLine(
                            color = if (deg == 0) Color(0xFFFF0055) else if (isCard) Color(0xFF39FF14) else Color(0xFF64748B),
                            start = p1,
                            end = p2,
                            strokeWidth = if (isCard) 2f else 1f
                        )
                    }

                    // North Needle Point
                    val needleRad = Math.toRadians(-headingAngle.toDouble())
                    val needleLen = radius * 0.75f
                    val needleTip = Offset(center.x + (needleLen * sin(needleRad)).toFloat(), center.y - (needleLen * cos(needleRad)).toFloat())
                    val needleOpp = Offset(center.x - (needleLen * 0.6f * sin(needleRad)).toFloat(), center.y + (needleLen * 0.6f * cos(needleRad)).toFloat())
                    drawLine(Color(0xFFFF0055), center, needleTip, strokeWidth = 3f)
                    drawLine(Color(0xFF64748B), center, needleOpp, strokeWidth = 2f)
                    drawCircle(Color.White, radius = 3.dp.toPx(), center = center)
                }

                // Compass Heading Label
                Column(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("HEADING: ${headingAngle.toInt()}° NE", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Tactical Telemetry Stats Dock
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF080D18),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("GPS TELEMETRY & HARDWARE SENSORS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    Button(
                        onClick = {
                            val speech = "GPS telemetry active. Current speed: ${effectiveSpeedKmh.toInt()} kilometers per hour. Heading: ${headingAngle.toInt()} degrees North East. Altitude: $altitudeMeters meters above sea level. 16 GPS and GLONASS satellite locks verified."
                            onSpeak(speech)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003845)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sensor Audio", fontSize = 7.sp, color = Color(0xFF00F0FF))
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("ELEVATION (MSL)", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("$altitudeMeters M", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("BARO PRESSURE", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("1013.2 hPa", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("SATELLITE LOCKS", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("16 / 24 LOCKED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("ACCURACY", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("±1.4 M", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
fun TacticalGeodesicMeasureTool(
    presetTargets: List<TacticalTarget>,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var pointA by remember { mutableStateOf(presetTargets[0]) }
    var pointB by remember { mutableStateOf(presetTargets[2]) }
    var pointC by remember { mutableStateOf(presetTargets[4]) }

    // Distance calculation A to B
    fun calcDist(t1: TacticalTarget, t2: TacticalTarget): Double {
        val r = 6371.0
        val lat1 = Math.toRadians(t1.latitude.toDouble())
        val lon1 = Math.toRadians(t1.longitude.toDouble())
        val lat2 = Math.toRadians(t2.latitude.toDouble())
        val lon2 = Math.toRadians(t2.longitude.toDouble())
        val dLat = lat2 - lat1
        val dLon = lon2 - lon1
        val a = sin(dLat / 2).pow(2) + cos(lat1) * cos(lat2) * sin(dLon / 2).pow(2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    val distAB = calcDist(pointA, pointB)
    val distBC = calcDist(pointB, pointC)
    val distCA = calcDist(pointC, pointA)

    // Heron's formula for spherical triangle approximate area
    val s = (distAB + distBC + distCA) / 2.0
    val areaSqKm = sqrt(max(0.0, s * (s - distAB) * (s - distBC) * (s - distCA)))

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF03060E)),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF080D18),
            border = BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("GEODESIC DISTANCE & AREA CALCULATOR", fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    Button(
                        onClick = {
                            val speech = "Geodesic calculation complete. Polygon area across vertices: ${areaSqKm.toInt()} square kilometers. Perimeter: ${(distAB + distBC + distCA).toInt()} kilometers."
                            onSpeak(speech)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003845)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(24.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Read Calc", fontSize = 7.sp, color = Color(0xFF00F0FF))
                    }
                }

                Text("Calculate geodesic distance lines and enclosed polygon area between tactical planetary points.", fontSize = 9.sp, color = Color(0xFFCBD5E1))
            }
        }

        // Polygon Vertex Selectors
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0B1422),
                border = BorderStroke(1.dp, Color(0xFF00F0FF)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(6.dp)) {
                    Text("VERTEX A", fontSize = 7.sp, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    Text(pointA.callsign, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0B1422),
                border = BorderStroke(1.dp, Color(0xFF39FF14)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(6.dp)) {
                    Text("VERTEX B", fontSize = 7.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    Text(pointB.callsign, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0B1422),
                border = BorderStroke(1.dp, Color(0xFFFF9900)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(6.dp)) {
                    Text("VERTEX C", fontSize = 7.sp, color = Color(0xFFFF9900), fontFamily = FontFamily.Monospace)
                    Text(pointC.callsign, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        // Results Cards
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFF070F1C),
            border = BorderStroke(1.dp, Color(0xFF39FF14).copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("CALCULATED SPHERICAL METRICS:", fontSize = 8.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("ENCLOSED AREA", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("${"%,d".format(areaSqKm.toInt())} KM²", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("TOTAL PERIMETER", fontSize = 7.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                        Text("${"%,d".format((distAB + distBC + distCA).toInt())} KM", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFF00F0FF), fontFamily = FontFamily.Monospace)
                    }
                }
                Divider(color = Color(0xFF1E293B))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("A ➔ B: ${distAB.toInt()} km", fontSize = 8.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                    Text("B ➔ C: ${distBC.toInt()} km", fontSize = 8.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                    Text("C ➔ A: ${distCA.toInt()} km", fontSize = 8.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
