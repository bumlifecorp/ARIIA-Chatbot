package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.SettingsRepository
import com.example.data.VoiceMacro
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(private val repository: SettingsRepository) : ViewModel() {

    private val _micSensitivity = MutableStateFlow(repository.micSensitivity)
    val micSensitivity: StateFlow<Float> = _micSensitivity.asStateFlow()

    private val _speechTimeout = MutableStateFlow(repository.speechTimeout)
    val speechTimeout: StateFlow<Float> = _speechTimeout.asStateFlow()

    private val _macros = MutableStateFlow(repository.macros)
    val macros: StateFlow<List<VoiceMacro>> = _macros.asStateFlow()

    fun updateMicSensitivity(value: Float) {
        _micSensitivity.value = value
        repository.micSensitivity = value
    }

    fun updateSpeechTimeout(value: Float) {
        _speechTimeout.value = value
        repository.speechTimeout = value
    }

    fun addMacro(trigger: String, actionProtocol: String) {
        val newMacros = _macros.value + VoiceMacro(trigger, actionProtocol)
        _macros.value = newMacros
        repository.macros = newMacros
    }

    fun removeMacro(macro: VoiceMacro) {
        val newMacros = _macros.value.filter { it != macro }
        _macros.value = newMacros
        repository.macros = newMacros
    }
}

class SettingsViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SettingsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SettingsViewModel(SettingsRepository(context)) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
