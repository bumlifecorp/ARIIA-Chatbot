package com.example.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class StreamingProtocol(val label: String, val typicalLatencyMs: Int) {
    WEBRTC("WebRTC (Sub-Second Latency)", 85),
    RTSP("RTSP (Real-Time Streaming Protocol)", 420)
}

enum class IceConnectionState {
    NEW, CHECKING, CONNECTED, COMPLETED, DISCONNECTED, FAILED
}

data class StreamEndpoint(
    val id: String,
    val name: String,
    val uri: String,
    val protocol: StreamingProtocol,
    val resolution: String = "1920x1080",
    val targetFps: Int = 60
)

data class StreamMetrics(
    val latencyMs: Int,
    val currentFps: Int,
    val bitrateKbps: Int,
    val packetLossPercent: Float,
    val jitterMs: Int,
    val iceState: IceConnectionState,
    val bytesReceived: Long,
    val framesDecoded: Long
)

class StreamIngestionManager(private val scope: CoroutineScope) {

    private val _availableStreams = MutableStateFlow<List<StreamEndpoint>>(
        listOf(
            StreamEndpoint("STREAM-01", "Sector Alpha - Main Highway (WebRTC)", "webrtc://live.tactical.net/sector-alpha/feed0", StreamingProtocol.WEBRTC),
            StreamEndpoint("STREAM-02", "Sector Beta - Maritime Port Perimeter (RTSP)", "rtsp://live.tactical.net:554/live/sector-beta", StreamingProtocol.RTSP),
            StreamEndpoint("STREAM-03", "Downtown Aerial Drone Unit (WebRTC)", "webrtc://relay.drone4.tactical.net/h264", StreamingProtocol.WEBRTC),
            StreamEndpoint("STREAM-04", "Central Transit Station Concourse (RTSP)", "rtsp://transit-hub.sec/rtsp/cam12", StreamingProtocol.RTSP)
        )
    )
    val availableStreams: StateFlow<List<StreamEndpoint>> = _availableStreams.asStateFlow()

    private val _activeStream = MutableStateFlow<StreamEndpoint>(_availableStreams.value[0])
    val activeStream: StateFlow<StreamEndpoint> = _activeStream.asStateFlow()

    private val _streamMetrics = MutableStateFlow(
        StreamMetrics(
            latencyMs = 78,
            currentFps = 60,
            bitrateKbps = 4850,
            packetLossPercent = 0.02f,
            jitterMs = 4,
            iceState = IceConnectionState.CONNECTED,
            bytesReceived = 10485760L,
            framesDecoded = 12400L
        )
    )
    val streamMetrics: StateFlow<StreamMetrics> = _streamMetrics.asStateFlow()

    private val _streamStatusLog = MutableStateFlow<List<String>>(
        listOf(
            "[WebRTC] PeerConnection initialized. SDP offer exchanged.",
            "[WebRTC] ICE candidate gathering complete. Local candidate selected.",
            "[WebRTC] DTLS handshake verified. Sub-second SRTP media stream established."
        )
    )
    val streamStatusLog: StateFlow<List<String>> = _streamStatusLog.asStateFlow()

    private var metricsJob: Job? = null

    init {
        startMetricsSimulation()
    }

    fun selectStream(endpoint: StreamEndpoint) {
        _activeStream.value = endpoint
        appendLog("[Switch] Switched ingestion feed to ${endpoint.name} (${endpoint.protocol.name})")
        startMetricsSimulation()
    }

    fun toggleProtocol(newProtocol: StreamingProtocol) {
        val current = _activeStream.value
        if (current.protocol != newProtocol) {
            val updatedUri = if (newProtocol == StreamingProtocol.WEBRTC) {
                current.uri.replace("rtsp://", "webrtc://")
            } else {
                current.uri.replace("webrtc://", "rtsp://")
            }
            val updated = current.copy(protocol = newProtocol, uri = updatedUri)
            _activeStream.value = updated
            appendLog("[Protocol] Ingestion protocol toggled to ${newProtocol.label}")
            startMetricsSimulation()
        }
    }

    private fun startMetricsSimulation() {
        metricsJob?.cancel()
        metricsJob = scope.launch(Dispatchers.Default) {
            val baseLatency = _activeStream.value.protocol.typicalLatencyMs
            var totalBytes = _streamMetrics.value.bytesReceived
            var totalFrames = _streamMetrics.value.framesDecoded

            while (isActive) {
                delay(1000)
                val jitter = Random.nextInt(2, 9)
                val latencyNoise = Random.nextInt(-6, 8)
                val latency = (baseLatency + latencyNoise).coerceAtLeast(35)
                val fps = if (Random.nextFloat() > 0.95f) 59 else 60
                val bitrate = Random.nextInt(4400, 5200)
                val loss = (Random.nextFloat() * 0.05f)
                totalBytes += (bitrate * 1024 / 8)
                totalFrames += fps

                _streamMetrics.value = StreamMetrics(
                    latencyMs = latency,
                    currentFps = fps,
                    bitrateKbps = bitrate,
                    packetLossPercent = loss,
                    jitterMs = jitter,
                    iceState = IceConnectionState.CONNECTED,
                    bytesReceived = totalBytes,
                    framesDecoded = totalFrames
                )
            }
        }
    }

    private fun appendLog(log: String) {
        val current = _streamStatusLog.value.toMutableList()
        if (current.size > 20) current.removeAt(0)
        current.add(log)
        _streamStatusLog.value = current
    }
}
