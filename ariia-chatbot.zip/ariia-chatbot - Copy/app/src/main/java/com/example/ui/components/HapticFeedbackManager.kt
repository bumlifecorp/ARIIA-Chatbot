package com.example.ui.components

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class HapticFeedbackManager(private val context: Context) {

    fun vibrateForSymmetry(symmetryFolds: Int) {
        try {
            val amplitude = when {
                symmetryFolds >= 24 -> 255
                symmetryFolds >= 16 -> 200
                symmetryFolds >= 12 -> 150
                symmetryFolds >= 8 -> 100
                else -> 60
            }
            val duration = (symmetryFolds * 2).toLong().coerceIn(10L, 50L)

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                val vibrator = vibratorManager.defaultVibrator
                vibrator.vibrate(VibrationEffect.createOneShot(duration, amplitude))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vibrator.vibrate(VibrationEffect.createOneShot(duration, amplitude))
            }
        } catch (e: Exception) {
            // Ignore if vibration unavailable
        }
    }

    fun vibrateTouchGesture() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vibrator.vibrate(VibrationEffect.createOneShot(15, 120))
            }
        } catch (e: Exception) {
            // Ignore
        }
    }
}
