package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppItem
import com.example.ui.theme.ImmersiveAmber
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveCardBg
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveOnLavender
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveTextMuted
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.viewmodel.AppCategory

@Composable
fun AppGrid(
    apps: List<AppItem>,
    favoriteApps: List<AppItem>,
    recentApps: List<AppItem> = emptyList(),
    searchQuery: String,
    selectedCategory: AppCategory,
    onSearchChange: (String) -> Unit,
    onCategorySelected: (AppCategory) -> Unit,
    onAppClick: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    iconShape: String = "Squircle",
    iconSize: String = "Medium",
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 60.dp)
            .testTag("appListView"),
        shape = RoundedCornerShape(28.dp),
        color = ImmersiveCardBg,
        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
        shadowElevation = 16.dp
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Card Header Bar (Matching HTML spec .bg-[#2B2930] .border-b .border-[#49454F])
            Surface(
                color = ImmersiveSurface,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INSTALLED APPS",
                        style = MaterialTheme.typography.labelMedium,
                        color = ImmersiveTextSecondary,
                        letterSpacing = 1.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp
                    )
                    Icon(
                        imageVector = Icons.Default.Apps,
                        contentDescription = "Apps",
                        tint = ImmersiveLavender,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(ImmersiveBorder)
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Search Input Field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = {
                        Text(
                            text = "Sök appar...",
                            color = ImmersiveTextMuted,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = ImmersiveLavender
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search",
                                    tint = ImmersiveTextSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder,
                        focusedContainerColor = ImmersiveSurface,
                        unfocusedContainerColor = ImmersiveSurface,
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_apps_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category Chips Row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(AppCategory.values()) { category ->
                        val isSelected = category == selectedCategory
                        FilterChip(
                            selected = isSelected,
                            onClick = { onCategorySelected(category) },
                            label = {
                                Text(
                                    text = category.displayName,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ImmersiveLavender,
                                selectedLabelColor = ImmersiveOnLavender,
                                containerColor = ImmersiveSurface,
                                labelColor = ImmersiveTextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = ImmersiveBorder,
                                selectedBorderColor = ImmersiveLavender
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }


                // Recent Apps Bar
                if (searchQuery.isEmpty() && recentApps.isNotEmpty() && selectedCategory != AppCategory.FAVORITES) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "SENAST ANVÄNDA",
                        style = MaterialTheme.typography.labelSmall,
                        color = ImmersiveTextSecondary,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(recentApps) { app ->
                            FavoriteAppPill(
                                app = app,
                                onClick = { onAppClick(app.packageName) }
                            )
                        }
                    }
                }

                // Favorites Bar (if no search active and favorites exist)
                if (searchQuery.isEmpty() && favoriteApps.isNotEmpty() && selectedCategory != AppCategory.FAVORITES) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "FAVORITER",
                        style = MaterialTheme.typography.labelSmall,
                        color = ImmersiveLavender,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(favoriteApps) { favApp ->
                            FavoriteAppPill(
                                app = favApp,
                                onClick = { onAppClick(favApp.packageName) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Apps Grid
                if (apps.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "No apps",
                                tint = ImmersiveTextMuted,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (searchQuery.isNotEmpty()) "Inga appar matchar \"$searchQuery\"" else "Inga appar hittades",
                                color = ImmersiveTextSecondary,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 74.dp),
                        contentPadding = PaddingValues(bottom = 24.dp, top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                    ) {
                        items(apps, key = { it.packageName }) { app ->
                            AppGridItem(
                                app = app,
                                onClick = { onAppClick(app.packageName) },
                                onToggleFavorite = { onToggleFavorite(app.packageName) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppGridItem(
    app: AppItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    iconShape: String = "Squircle",
    iconSize: String = "Medium",
    modifier: Modifier = Modifier
) {

    val sizeDp = when (iconSize) {
        "Small" -> 40.dp
        "Large" -> 64.dp
        else -> 52.dp
    }
    
    val shape = when (iconShape) {
        "Circle" -> CircleShape
        "Squircle" -> RoundedCornerShape(16.dp)
        "Teardrop" -> RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 50, bottomStartPercent = 10)
        else -> RoundedCornerShape(20.dp) // Default
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp)
            .testTag("app_item_${app.packageName}")
    ) {
        Box(
            modifier = Modifier.size(sizeDp),
            contentAlignment = Alignment.Center
        ) {
            // App Icon rendering
            if (app.icon != null) {
                val bitmap = remember(app.icon) {
                    drawableToBitmap(app.icon)
                }
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = app.label,
                        modifier = Modifier
                            .size(sizeDp * 0.88f)
                            .clip(shape)
                    )
                } else {
                    DefaultAppIcon(app.label, sizeDp * 0.88f, shape)
                }
            } else {
                DefaultAppIcon(app.label)
            }

            // Star indicator for favorites
            if (app.isFavorite) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(16.dp)
                        .background(ImmersiveAmber, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Favorite",
                        tint = ImmersiveCardBg,
                        modifier = Modifier.size(10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = app.label,
            color = ImmersiveTextPrimary,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Normal,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = 11.sp
        )
    }
}

@Composable
fun FavoriteAppPill(
    app: AppItem,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = ImmersiveSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (app.icon != null) {
                val bitmap = remember(app.icon) { drawableToBitmap(app.icon) }
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = app.label,
                        modifier = Modifier
                            .size(22.dp)
                            .clip(RoundedCornerShape(6.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
            }
            Text(
                text = app.label,
                color = ImmersiveTextPrimary,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun DefaultAppIcon(label: String, size: androidx.compose.ui.unit.Dp = 46.dp, shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(12.dp)) {
    val initial = label.firstOrNull()?.uppercase() ?: "A"
    Box(
        modifier = Modifier
            .size(size)
            .background(
                color = ImmersiveSurface,
                shape = shape
            )
            .border(1.dp, ImmersiveBorder, shape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initial,
            color = ImmersiveLavender,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

fun drawableToBitmap(drawable: Drawable): Bitmap? {
    return try {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        bitmap
    } catch (e: Exception) {
        null
    }
}

