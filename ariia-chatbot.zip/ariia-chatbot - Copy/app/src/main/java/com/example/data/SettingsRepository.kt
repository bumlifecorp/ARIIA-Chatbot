package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.squareup.moshi.Types

data class VoiceMacro(val trigger: String, val actionProtocol: String)

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val type = Types.newParameterizedType(List::class.java, VoiceMacro::class.java)
    private val adapter = moshi.adapter<List<VoiceMacro>>(type)

    var micSensitivity: Float
        get() = prefs.getFloat("mic_sensitivity", 50f)
        set(value) = prefs.edit().putFloat("mic_sensitivity", value).apply()

    var speechTimeout: Float
        get() = prefs.getFloat("speech_timeout", 3000f)
        set(value) = prefs.edit().putFloat("speech_timeout", value).apply()

    var macros: List<VoiceMacro>
        get() {
            val json = prefs.getString("voice_macros", "[]") ?: "[]"
            return try {
                adapter.fromJson(json) ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        }
        set(value) {
            val json = adapter.toJson(value)
            prefs.edit().putString("voice_macros", json).apply()
        }
}
