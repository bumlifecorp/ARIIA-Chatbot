package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import com.example.utils.HapticManager
import kotlinx.coroutines.delay
import kotlin.random.Random

enum class DetectiveProtocol(val title: String, val badge: String, val icon: @Composable () -> Unit) {
    DEEP_DETECTIVE_AI("Deep Detective AI Engine", "DEEP_AI", { Icon(Icons.Default.Psychology, contentDescription = null) }),
    FORENSIC_TRACE("Forensic Trace Protocol", "RECON", { Icon(Icons.Default.Fingerprint, contentDescription = null) }),
    DEEPFAKE_AUDIO("Deepfake Audio Analyzer", "SYNTH_VOICE", { Icon(Icons.Default.GraphicEq, contentDescription = null) }),
    INTERROGATION("Interrogation Analysis", "STRESS", { Icon(Icons.Default.RecordVoiceOver, contentDescription = null) }),
    MOTIVE_MATRIX("AI Motive & Intent Matrix", "PSYCHOLOGY", { Icon(Icons.Default.Grid4x4, contentDescription = null) }),
    THREAT_GRAPH("Global Threat Graph", "NETWORK", { Icon(Icons.Default.Hub, contentDescription = null) }),
    CONTAINMENT_PERIMETER("Containment Perimeter", "LOCKDOWN", { Icon(Icons.Default.Security, contentDescription = null) })
}

@Composable
fun DetectiveProgramScreen(
    onNavigateTab: (Int) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    DisposableEffect(Unit) {
        onDispose { speechEngine.shutdown() }
    }

    var activeProtocol by remember { mutableStateOf(DetectiveProtocol.DEEP_DETECTIVE_AI) }
    var isAutomationEngineActive by remember { mutableStateOf(true) }

    var lieProbabilityPct by remember { mutableFloatStateOf(14f) }
    var deepfakeProbabilityPct by remember { mutableFloatStateOf(3.2f) }
    var perimeterIntegrity by remember { mutableFloatStateOf(99.8f) }
    var suspectThreatScore by remember { mutableFloatStateOf(78.5f) }

    LaunchedEffect(isAutomationEngineActive) {
        while (isAutomationEngineActive) {
            delay(3500)
            lieProbabilityPct = 10f + Random.nextFloat() * 15f
            deepfakeProbabilityPct = 1f + Random.nextFloat() * 5f
            suspectThreatScore = (suspectThreatScore + (Random.nextFloat() - 0.5f) * 2f).coerceIn(40f, 95f)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090214))
            .padding(12.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF17042C)),
            border = BorderStroke(1.dp, Color(0xFFA855F7).copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(Color(0xFF280749), CircleShape)
                        .border(1.dp, Color(0xFFA855F7), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Psychology, contentDescription = null, tint = Color(0xFFA855F7), modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("[DEEP_DETECTIVE_AI_PROGRAM]", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, fontFamily = FontFamily.Monospace)
                    Text("Deep AI Biometrics, Deepfake Detection, Threat Graph & Motive Analysis", fontSize = 10.sp, color = Color(0xFFE9D5FF))
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("AUTOMATION", fontSize = 8.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Switch(
                        checked = isAutomationEngineActive,
                        onCheckedChange = {
                            isAutomationEngineActive = it
                            speechEngine.speak(if (it) "Deep Detective AI Automation active" else "Deep Detective Engine paused")
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFA855F7))
                    )
                }
            }
        }

        // Stats Row
        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DetectiveStatChip("DEEPFAKE SCORE", "%.1f%%".format(deepfakeProbabilityPct), Color(0xFF38BDF8), Modifier.weight(1f))
            DetectiveStatChip("LIE DETECT", "${lieProbabilityPct.toInt()}%", Color(0xFF39FF14), Modifier.weight(1f))
            DetectiveStatChip("THREAT MATRIX", "%.1f".format(suspectThreatScore), Color(0xFFA855F7), Modifier.weight(1f))
            DetectiveStatChip("PERIMETER", "%.1f%%".format(perimeterIntegrity), Color(0xFFF43F5E), Modifier.weight(1f))
        }

        // Protocol Tabs
        LazyRow(modifier = Modifier.padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(DetectiveProtocol.values()) { protocol ->
                val isSelected = activeProtocol == protocol
                Card(
                    modifier = Modifier.clickable {
                        activeProtocol = protocol
                        HapticManager.triggerVoiceCommandInitiation(context)
                        speechEngine.speak("Switched to ${protocol.title}")
                    },
                    colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFFA855F7).copy(alpha = 0.25f) else Color(0xFF17042C)),
                    border = BorderStroke(1.dp, if (isSelected) Color(0xFFA855F7) else Color(0xFF3B0D66)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        protocol.icon()
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(protocol.title, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, color = if (isSelected) Color.White else Color(0xFFD8B4FE))
                    }
                }
            }
        }

        // Active View
        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            when (activeProtocol) {
                DetectiveProtocol.DEEP_DETECTIVE_AI -> DeepDetectiveAiContent(speechEngine, context)
                DetectiveProtocol.FORENSIC_TRACE -> ForensicTraceContent(speechEngine)
                DetectiveProtocol.DEEPFAKE_AUDIO -> DeepfakeAudioContent(deepfakeProbabilityPct, speechEngine, context)
                DetectiveProtocol.INTERROGATION -> InterrogationContent(lieProbabilityPct, speechEngine, context)
                DetectiveProtocol.MOTIVE_MATRIX -> MotiveMatrixContent(suspectThreatScore, speechEngine, context)
                DetectiveProtocol.THREAT_GRAPH -> ThreatGraphContent(speechEngine, context)
                DetectiveProtocol.CONTAINMENT_PERIMETER -> ContainmentPerimeterContent(perimeterIntegrity, speechEngine, context)
            }
        }
    }
}

@Composable
fun DetectiveStatChip(label: String, value: String, color: Color, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF17042C)), border = BorderStroke(1.dp, color.copy(alpha = 0.4f)), shape = RoundedCornerShape(8.dp)) {
        Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 7.sp, color = Color(0xFFD8B4FE), fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 11.sp, color = color, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun DeepDetectiveAiContent(speechEngine: AriiaSpeechEngine, context: Context) {
    var aiAnalysisText by remember { mutableStateOf("Deep Detective AI ready. Tap below to run biometrics and suspect footprint cross-synthesis.") }

    Card(modifier = Modifier.fillMaxSize(), colors = CardDefaults.cardColors(containerColor = Color(0xFF120323)), border = BorderStroke(1.dp, Color(0xFF3B0D66))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("[DEEP_DETECTIVE_AI_ENGINE] - Neural Cyber-Forensic Hub", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA855F7), fontFamily = FontFamily.Monospace)
            
            Text("Automated Biometrics, Crypto-Flow Tracking & Neural Intent Reasoning", fontSize = 11.sp, color = Color.White)

            Card(
                modifier = Modifier.fillMaxWidth().weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF090214)),
                border = BorderStroke(1.dp, Color(0xFF2E0A52))
            ) {
                LazyColumn(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Text(aiAnalysisText, fontSize = 12.sp, color = Color(0xFFE9D5FF), fontFamily = FontFamily.Monospace)
                    }
                }
            }

            Button(
                onClick = {
                    HapticManager.triggerVoiceCommandSuccess(context)
                    aiAnalysisText = "[DEEP_DETECTIVE_AI_ANALYSIS]\n" +
                            "• Biometric Face Match: 99.4% confidence (Subject Delta-7)\n" +
                            "• Deepfake Audio Audit: CLEAN (Natural voice pitch micro-fluctuations)\n" +
                            "• Threat Matrix: High intent anomaly flagged in Sector 4\n" +
                            "• Crypto-Wallet Link: 0x8F2A... -> Cold Storage Vault\n" +
                            "• Recommended Action: Deploy non-lethal containment lock."
                    speechEngine.speak("Deep Detective AI analysis complete. Subject Delta-7 biometric match verified at 99.4 percent confidence.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Psychology, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("RUN DEEP DETECTIVE AI SYNTHESIS", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun DeepfakeAudioContent(deepfakePct: Float, speechEngine: AriiaSpeechEngine, context: Context) {
    Card(modifier = Modifier.fillMaxSize(), colors = CardDefaults.cardColors(containerColor = Color(0xFF120323)), border = BorderStroke(1.dp, Color(0xFF3B0D66))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("[DEEPFAKE_AUDIO_ANALYZER] - Neural Voice Tremor & Pitch Jitter", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8), fontFamily = FontFamily.Monospace)
            Text("SYNTHETIC AUDIO PROBABILITY: %.1f%% (AUTHENTIC NATURAL VOICE)".format(deepfakePct), fontSize = 11.sp, color = Color(0xFF39FF14))

            Button(
                onClick = {
                    HapticManager.triggerVoiceCommandSuccess(context)
                    speechEngine.speak("Synthetic audio analysis complete. Pitch jitter and vocal tract acoustics confirm authentic human speech.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("AUDIT SYNTHETIC VOICE JITTER", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun MotiveMatrixContent(threatScore: Float, speechEngine: AriiaSpeechEngine, context: Context) {
    Card(modifier = Modifier.fillMaxSize(), colors = CardDefaults.cardColors(containerColor = Color(0xFF120323)), border = BorderStroke(1.dp, Color(0xFF3B0D66))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("[AI_MOTIVE_INTENT_MATRIX] - Threat Psychology Evaluator", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA855F7), fontFamily = FontFamily.Monospace)
            Text("MOTIVE SCORE: %.1f / 100.0 (ELEVATED RISK)".format(threatScore), fontSize = 11.sp, color = Color(0xFFF43F5E))

            Button(
                onClick = {
                    HapticManager.triggerVoiceCommandSuccess(context)
                    speechEngine.speak("Motive and intent matrix generated. Financial gain and cyber-recon motives primary factors.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Grid4x4, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("EVALUATE SUSPECT MOTIVE VECTOR", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun ThreatGraphContent(speechEngine: AriiaSpeechEngine, context: Context) {
    Card(modifier = Modifier.fillMaxSize(), colors = CardDefaults.cardColors(containerColor = Color(0xFF120323)), border = BorderStroke(1.dp, Color(0xFF3B0D66))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("[GLOBAL_THREAT_GRAPH] - Suspect Network Topology", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
            Text("Network Mapping: 6 Suspect Nodes & 2 Cold Storage Crypto Wallets Connected", fontSize = 11.sp, color = Color.White)

            Box(
                modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF090214)).border(1.dp, Color(0xFF2E0A52)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cX = size.width / 2f
                    val cY = size.height / 2f
                    drawCircle(Color(0xFFA855F7), radius = 18.dp.toPx(), center = Offset(cX, cY))
                    drawCircle(Color(0xFF38BDF8), radius = 12.dp.toPx(), center = Offset(cX - 100f, cY - 80f))
                    drawCircle(Color(0xFF39FF14), radius = 12.dp.toPx(), center = Offset(cX + 100f, cY - 60f))
                    drawCircle(Color(0xFFF43F5E), radius = 12.dp.toPx(), center = Offset(cX - 80f, cY + 90f))

                    drawLine(Color(0xFFA855F7), Offset(cX, cY), Offset(cX - 100f, cY - 80f), strokeWidth = 2.dp.toPx())
                    drawLine(Color(0xFFA855F7), Offset(cX, cY), Offset(cX + 100f, cY - 60f), strokeWidth = 2.dp.toPx())
                    drawLine(Color(0xFFA855F7), Offset(cX, cY), Offset(cX - 80f, cY + 90f), strokeWidth = 2.dp.toPx())
                }
                Text("SUSPECT NETWORK NODES", fontSize = 9.sp, color = Color(0xFFD8B4FE), fontFamily = FontFamily.Monospace, modifier = Modifier.align(Alignment.TopStart).padding(8.dp))
            }

            Button(
                onClick = {
                    HapticManager.triggerVoiceCommandSuccess(context)
                    speechEngine.speak("Threat graph node cluster mapped. All secondary encrypted communication channels identified.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF39FF14)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Hub, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("TRACE ENCRYPTED SUSPECT GRAPH", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun ForensicTraceContent(speechEngine: AriiaSpeechEngine) {
    Card(modifier = Modifier.fillMaxSize(), colors = CardDefaults.cardColors(containerColor = Color(0xFF120323)), border = BorderStroke(1.dp, Color(0xFF3B0D66))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("[FORENSIC_TRACE_PROTOCOL] - Digital Metadata Reconstructor", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA855F7), fontFamily = FontFamily.Monospace)
            Text("Forensic Trace: 4 Metadata Artifacts Recovered", fontSize = 11.sp, color = Color.White)
            Button(onClick = { speechEngine.speak("Digital fingerprint reconstructed. EXIF geotag mapped to Sector 7.") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7)), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Search, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("RUN FORENSIC RECONSTRUCTION", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun InterrogationContent(liePct: Float, speechEngine: AriiaSpeechEngine, context: Context) {
    Card(modifier = Modifier.fillMaxSize(), colors = CardDefaults.cardColors(containerColor = Color(0xFF120323)), border = BorderStroke(1.dp, Color(0xFF3B0D66))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("[INTERROGATION_ANALYSIS_PROTOCOL] - Voice Tremor & Micro-Expression Analyzer", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA855F7), fontFamily = FontFamily.Monospace)
            Text("LIE LIKELIHOOD SCORE: ${liePct.toInt()}% (HIGH TRUTHFULNESS)", fontSize = 11.sp, color = Color(0xFF39FF14))
            Button(onClick = {
                HapticManager.triggerVoiceCommandSuccess(context)
                speechEngine.speak("Voice micro-tremor analysis complete. Zero stress spikes detected during statement.")
            }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("AUDIT VOICE MICRO-TREMOR HERTZ", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun ContainmentPerimeterContent(integrity: Float, speechEngine: AriiaSpeechEngine, context: Context) {
    Card(modifier = Modifier.fillMaxSize(), colors = CardDefaults.cardColors(containerColor = Color(0xFF120323)), border = BorderStroke(1.dp, Color(0xFF3B0D66))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("[CONTAINMENT_PERIMETER_PROTOCOL] - Automated Geo-Fence Anomaly Lock", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA855F7), fontFamily = FontFamily.Monospace)
            Text("PERIMETER INTEGRITY: %.1f%% SECURE".format(integrity), fontSize = 11.sp, color = Color(0xFF39FF14))
            Button(onClick = {
                HapticManager.triggerVoiceCommandSuccess(context)
                speechEngine.speak("Perimeter containment lock engaged. All infrared beam sensors active.")
            }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0055)), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("ENGAGE PERIMETER LOCKDOWN", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
        }
    }
}
