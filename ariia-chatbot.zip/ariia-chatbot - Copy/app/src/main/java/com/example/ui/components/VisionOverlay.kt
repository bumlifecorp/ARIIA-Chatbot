package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import android.speech.tts.TextToSpeech
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DetectedObjectInfo
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveEmerald
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary

@Composable
fun VisionOverlay(
    feedbackVisual: Boolean = true,
    feedbackAuditory: Boolean = false,
    feedbackHaptic: Boolean = false,
    onToggleVisual: () -> Unit = {},
    onToggleAuditory: () -> Unit = {},
    onToggleHaptic: () -> Unit = {},
    detectedObjects: List<DetectedObjectInfo>,
    summaryText: String,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hud_scan")
    val scanLineProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanline"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(context) {
        val textToSpeech = TextToSpeech(context) { status ->
            // init
        }
        tts = textToSpeech
        onDispose {
            textToSpeech.shutdown()
        }
    }

    LaunchedEffect(summaryText) {
        if (summaryText.isNotEmpty() && summaryText != "Skannar miljö..." && summaryText != "Skannar efter objekt...") {
            if (feedbackHaptic) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            if (feedbackAuditory) {
                tts?.speak(summaryText, TextToSpeech.QUEUE_FLUSH, null, null)
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        // Draw HUD scan line, center reticle, and target boxes
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // 1. Draw animated horizontal scan beam
            val scanY = scanLineProgress * canvasHeight
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        ImmersiveLavender.copy(alpha = 0.4f),
                        ImmersiveLavender.copy(alpha = 0.85f),
                        ImmersiveLavender.copy(alpha = 0.4f),
                        Color.Transparent
                    )
                ),
                start = Offset(0f, scanY),
                end = Offset(canvasWidth, scanY),
                strokeWidth = 2.dp.toPx()
            )

            // 2. Draw Center Target Reticle Box (matching HTML .w-48 .h-48 rounded-2xl with lavender corners)
            val boxSize = minOf(canvasWidth * 0.55f, 220.dp.toPx())
            val boxLeft = (canvasWidth - boxSize) / 2f
            val boxTop = (canvasHeight - boxSize) / 2f

            // Faint rounded rectangle
            drawRoundRect(
                color = Color.White.copy(alpha = 0.15f),
                topLeft = Offset(boxLeft, boxTop),
                size = Size(boxSize, boxSize),
                cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
                style = Stroke(width = 1.dp.toPx())
            )

            // Lavender corner brackets
            val cornerSize = 20.dp.toPx()
            val bracketWidth = 2.5.dp.toPx()
            val bracketColor = ImmersiveLavender

            // Top-Left corner
            drawLine(bracketColor, Offset(boxLeft, boxTop), Offset(boxLeft + cornerSize, boxTop), bracketWidth)
            drawLine(bracketColor, Offset(boxLeft, boxTop), Offset(boxLeft, boxTop + cornerSize), bracketWidth)

            // Top-Right corner
            drawLine(bracketColor, Offset(boxLeft + boxSize - cornerSize, boxTop), Offset(boxLeft + boxSize, boxTop), bracketWidth)
            drawLine(bracketColor, Offset(boxLeft + boxSize, boxTop), Offset(boxLeft + boxSize, boxTop + cornerSize), bracketWidth)

            // Bottom-Left corner
            drawLine(bracketColor, Offset(boxLeft, boxTop + boxSize), Offset(boxLeft + cornerSize, boxTop + boxSize), bracketWidth)
            drawLine(bracketColor, Offset(boxLeft, boxTop + boxSize - cornerSize), Offset(boxLeft, boxTop + boxSize), bracketWidth)

            // Bottom-Right corner
            drawLine(bracketColor, Offset(boxLeft + boxSize - cornerSize, boxTop + boxSize), Offset(boxLeft + boxSize, boxTop + boxSize), bracketWidth)
            drawLine(bracketColor, Offset(boxLeft + boxSize, boxTop + boxSize - cornerSize), Offset(boxLeft + boxSize, boxTop + boxSize), bracketWidth)

            // 3. Draw ML Kit detected object bounding boxes
            if (feedbackVisual) {
            detectedObjects.forEach { obj ->
                val normRect = obj.boundingBoxRatio
                if (normRect != null) {
                    val dLeft = normRect.left * canvasWidth
                    val dTop = normRect.top * canvasHeight
                    val dRight = normRect.right * canvasWidth
                    val dBottom = normRect.bottom * canvasHeight
                    val dWidth = (dRight - dLeft).coerceAtLeast(30f)
                    val dHeight = (dBottom - dTop).coerceAtLeast(30f)

                    drawRect(
                        color = ImmersiveLavender.copy(alpha = 0.7f),
                        topLeft = Offset(dLeft, dTop),
                        size = Size(dWidth, dHeight),
                        style = Stroke(
                            width = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                        )
                    )

                    val cl = 14.dp.toPx()
                    drawRect(color = ImmersiveLavender, topLeft = Offset(dLeft, dTop), size = Size(cl, 3.dp.toPx()))
                    drawRect(color = ImmersiveLavender, topLeft = Offset(dLeft, dTop), size = Size(3.dp.toPx(), cl))
                }
            }
            }
        }

        // Bottom/Floating Object Detected Banner (matching Immersive UI spec)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


            // Feedback Options Row
            Row(
                modifier = Modifier
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FeedbackTogglePill(
                    icon = if (feedbackVisual) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    isActive = feedbackVisual,
                    onClick = onToggleVisual
                )
                FeedbackTogglePill(
                    icon = if (feedbackAuditory) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    isActive = feedbackAuditory,
                    onClick = onToggleAuditory
                )
                FeedbackTogglePill(
                    icon = Icons.Default.Vibration,
                    isActive = feedbackHaptic,
                    onClick = onToggleHaptic
                )
            }
            if (feedbackVisual) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ImmersiveBorder.copy(alpha = 0.85f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                shadowElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tvDetectedObject")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Pulsing Lavender indicator dot
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                color = ImmersiveLavender.copy(alpha = pulseAlpha),
                                shape = CircleShape
                            )
                            .border(1.dp, ImmersiveLavender, CircleShape)
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "OBJECT DETECTED",
                            style = MaterialTheme.typography.labelSmall,
                            color = ImmersiveLavender,
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = summaryText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ImmersiveTextPrimary,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            maxLines = 2
                        )
                    }

                    if (detectedObjects.isNotEmpty()) {

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = ImmersiveLavender.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveLavender.copy(alpha = 0.6f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI Match",
                                    tint = ImmersiveLavender,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${detectedObjects.first().confidence}%",
                                    color = ImmersiveLavender,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Quick object pill badges
            if (detectedObjects.size > 1) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    detectedObjects.drop(1).take(3).forEach { obj ->

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ImmersiveSurface.copy(alpha = 0.85f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder)
                        ) {
                            Text(
                                text = "${obj.label} (${obj.confidence}%)",
                                color = ImmersiveTextSecondary,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
            }
        }
    }
}


@Composable
private fun FeedbackTogglePill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = CircleShape,
        color = if (isActive) com.example.ui.theme.ImmersiveLavender else com.example.ui.theme.ImmersiveSurface.copy(alpha = 0.7f),
        border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.ImmersiveBorder),
        modifier = Modifier.clickable { onClick() }
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isActive) com.example.ui.theme.ImmersiveOnLavender else com.example.ui.theme.ImmersiveTextSecondary,
            modifier = Modifier
                .padding(8.dp)
                .size(20.dp)
        )
    }
}
