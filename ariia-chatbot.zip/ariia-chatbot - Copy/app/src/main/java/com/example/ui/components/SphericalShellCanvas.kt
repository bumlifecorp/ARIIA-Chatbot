package com.example.ui.components

import android.content.Context
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SphericalShellCanvas(
    modifier: Modifier = Modifier,
    symmetryFolds: Int = 8,
    rotationSpeed: Float = 1.0f,
    onScaleChanged: (Float) -> Unit = {},
    content: @Composable () -> Unit = {}
) {
    val context = LocalContext.current
    val hapticManager = remember { HapticFeedbackManager(context) }

    var userRotation by remember { mutableStateOf(0f) }
    var scaleFactor by remember { mutableStateOf(1f) }

    // Momentum-based physics controller for HUD rotation velocity decay
    var rotationVelocity by remember { mutableStateOf(0f) }

    LaunchedEffect(rotationVelocity) {
        if (abs(rotationVelocity) > 0.01f) {
            while (abs(rotationVelocity) > 0.01f) {
                userRotation += rotationVelocity
                rotationVelocity *= 0.92f // friction decay factor
                delay(16)
            }
            rotationVelocity = 0f
        }
    }

    // Auto-rotation animation
    val infiniteTransition = rememberInfiniteTransition(label = "spherical_shell")
    val autoRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(15000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shell_rotation"
    )

    val totalRotation = (autoRotation * rotationSpeed + userRotation) % 360f

    Box(
        modifier = modifier
            .pointerInput(Unit) {
                detectTransformGestures { _, _, zoom, rotation ->
                    scaleFactor = (scaleFactor * zoom).coerceIn(0.6f, 3.0f)
                    if (abs(rotation) > 0.001f) {
                        rotationVelocity = rotation * 15f
                        userRotation += rotationVelocity
                    }
                    onScaleChanged(scaleFactor)
                    hapticManager.vibrateTouchGesture()
                }
            }
            .graphicsLayer(
                scaleX = scaleFactor,
                scaleY = scaleFactor
            )
    ) {
        // Unreal Engine Style 3D Spherical Shell Canvas Framing
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = minOf(size.width, size.height) * 0.46f

            // Draw outer Unreal holographic spherical wireframe shell
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF00F0FF).copy(alpha = 0.25f), Color(0xFFBD00FF).copy(alpha = 0.05f), Color.Transparent),
                    center = center,
                    radius = radius * 1.2f
                ),
                radius = radius * 1.2f,
                center = center
            )

            // Latitudinal and longitudinal 3D wireframe rings
            for (i in 0..4) {
                val r = radius * (0.25f * (i + 1))
                drawCircle(
                    color = Color(0xFF00F0FF).copy(alpha = 0.2f),
                    radius = r,
                    center = center,
                    style = Stroke(width = 1f)
                )
            }

            // Polygonal symmetry wedges (Unreal Engine holographic stage framing)
            val angleStep = 360f / symmetryFolds
            for (i in 0 until symmetryFolds) {
                val angleRad = Math.toRadians((totalRotation + i * angleStep).toDouble())
                val nextAngleRad = Math.toRadians((totalRotation + (i + 1) * angleStep).toDouble())

                val x1 = center.x + (radius * cos(angleRad)).toFloat()
                val y1 = center.y + (radius * sin(angleRad)).toFloat()
                val x2 = center.x + (radius * cos(nextAngleRad)).toFloat()
                val y2 = center.y + (radius * sin(nextAngleRad)).toFloat()

                val wedgePath = Path().apply {
                    moveTo(center.x, center.y)
                    lineTo(x1, y1)
                    lineTo(x2, y2)
                    close()
                }

                val strokeColor = if (i % 2 == 0) Color(0xFF00F0FF) else Color(0xFFBD00FF)
                drawPath(
                    path = wedgePath,
                    color = strokeColor.copy(alpha = 0.5f),
                    style = Stroke(width = 1.5f)
                )
            }

            // Pulsing Core Target Ring
            drawCircle(
                color = Color(0xFF39FF14).copy(alpha = 0.7f),
                radius = radius * 0.2f,
                center = center,
                style = Stroke(width = 2.5f)
            )
        }

        // Inner embedded content (camera preview / HUD feed)
        Box(modifier = Modifier.fillMaxSize()) {
            content()
        }
    }
}
