package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Hub
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.screens.AriiaAssistantScreen
import com.example.ui.screens.CognitiveLearningScreen
import com.example.ui.screens.ContentGeneratorScreen
import com.example.ui.screens.DecisionMatrixScreen
import com.example.ui.screens.FirebaseAiDashboardScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.KaleidoscopeSurveillanceScreen
import com.example.ui.screens.LiveStreamingChatScreen
import com.example.ui.screens.SystemAcceleratorScreen
import com.example.ui.screens.TextAnalyzerScreen
import com.example.ui.screens.DeepSeekPeopleScreen
import com.example.ui.screens.VisionVoiceControlScreen
import com.example.ui.screens.TeachableVoiceVisionScreen
import com.example.ui.screens.StreamPubSubSecurityScreen
import com.example.ui.screens.AriiaLauncherScreen
import com.example.ui.screens.AriiaEarthScreen
import com.example.ui.screens.AriiaCommsScreen
import com.example.ui.screens.PainterProtocolScreen
import com.example.ui.screens.PhotographerProtocolScreen
import com.example.ui.screens.SculptorProtocolScreen
import com.example.ui.screens.InteriorDesignerProtocolScreen
import com.example.ui.screens.BabysitterProgramScreen
import com.example.ui.screens.FarmerProgramScreen
import com.example.ui.screens.ChefProgramScreen
import com.example.ui.screens.DetectiveProgramScreen
import com.example.ui.screens.AndroidStudioToolsScreen
import com.example.ui.screens.InfluxTelemetryDashboardScreen
import com.example.ui.screens.InsecamSurveillanceExplorerScreen
import com.example.ui.screens.MobotixSurveillanceScreen
import com.example.ui.SettingsMacrosScreen
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.material.icons.filled.Settings

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: MainViewModel = viewModel()
                val selectedTab by viewModel.selectedTab.collectAsState()
                val chatMessages by viewModel.chatMessages.collectAsState()
                val isStreaming by viewModel.isStreaming.collectAsState()
                val streamingText by viewModel.streamingCurrentText.collectAsState()
                val analysisResult by viewModel.analysisResult.collectAsState()
                val isAnalyzing by viewModel.isAnalyzing.collectAsState()
                val generatedContent by viewModel.generatedContent.collectAsState()
                val isGenerating by viewModel.isGenerating.collectAsState()
                val firebaseStatus by viewModel.firebaseStatus.collectAsState()
                val ariiaMessages by viewModel.ariiaMessages.collectAsState()
                val isAriiaProcessing by viewModel.isAriiaProcessing.collectAsState()
                val memories by viewModel.memories.collectAsState()
                val isLearning by viewModel.isLearning.collectAsState()
                val diagnosticLog by viewModel.diagnosticLog.collectAsState()
                val isDiagnosing by viewModel.isDiagnosing.collectAsState()
                val decisionResult by viewModel.decisionResult.collectAsState()
                val isEvaluating by viewModel.isEvaluating.collectAsState()
                val surveillanceNodes by viewModel.surveillanceNodes.collectAsState()
                val activeNode by viewModel.activeNode.collectAsState()

                var dispatchedTargetPayload by remember { mutableStateOf<String?>(null) }
                var dispatchedTargetLat by remember { mutableStateOf<Float?>(null) }
                var dispatchedTargetLon by remember { mutableStateOf<Float?>(null) }

                LaunchedEffect(Unit) {
                    com.example.util.VoiceActionExecutor.onTabNavigationRequested = { tabIndex ->
                        viewModel.selectTab(tabIndex)
                    }
                }
                
                val context = androidx.compose.ui.platform.LocalContext.current
                LaunchedEffect(viewModel.audioFeedbackEvents) {
                    viewModel.audioFeedbackEvents.collect {
                        com.example.utils.AudioFeedbackManager.playSuccessSound(context)
                        com.example.utils.HapticManager.triggerVoiceCommandSuccess(context)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { viewModel.selectTab(0) },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { viewModel.selectTab(1) },
                                icon = { Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Live Chat") },
                                label = { Text("Live Chat") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 4,
                                onClick = { viewModel.selectTab(4) },
                                icon = { Icon(Icons.Default.Mic, contentDescription = "Google Voice Assistant") },
                                label = { Text("Assistant") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 8,
                                onClick = { viewModel.selectTab(8) },
                                icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Surveillance") },
                                label = { Text("HUD") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 9,
                                onClick = { viewModel.selectTab(9) },
                                icon = { Icon(Icons.Default.Videocam, contentDescription = "Vision & Voice") },
                                label = { Text("Vision") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 10,
                                onClick = { viewModel.selectTab(10) },
                                icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "DeepSeek") },
                                label = { Text("DeepSeek") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 11,
                                onClick = { viewModel.selectTab(11) },
                                icon = { Icon(Icons.Default.RecordVoiceOver, contentDescription = "Teachable AI") },
                                label = { Text("Teachable") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 12,
                                onClick = { viewModel.selectTab(12) },
                                icon = { Icon(Icons.Default.Hub, contentDescription = "Streams & PubSub") },
                                label = { Text("Streams") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 13,
                                onClick = { viewModel.selectTab(13) },
                                icon = { Icon(Icons.Default.PrecisionManufacturing, contentDescription = "ARIIA Launcher") },
                                label = { Text("ARIIA Grid") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 14,
                                onClick = { viewModel.selectTab(14) },
                                icon = { Icon(Icons.Default.Public, contentDescription = "ARIIA Earth View") },
                                label = { Text("Earth View") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 15,
                                onClick = { viewModel.selectTab(15) },
                                icon = { Icon(Icons.Default.Forum, contentDescription = "Secure Comms") },
                                label = { Text("Comms") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 16,
                                onClick = { viewModel.selectTab(16) },
                                icon = { Icon(Icons.Default.Palette, contentDescription = "Painter Protocol") },
                                label = { Text("Painter") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 21,
                                onClick = { viewModel.selectTab(21) },
                                icon = { Icon(Icons.Default.Shield, contentDescription = "VIP Protection Program") },
                                label = { Text("VIP Protect") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 22,
                                onClick = { viewModel.selectTab(22) },
                                icon = { Icon(Icons.Default.PrecisionManufacturing, contentDescription = "Strategic Recon Program") },
                                label = { Text("Strat Recon") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 23,
                                onClick = { viewModel.selectTab(23) },
                                icon = { Icon(Icons.Default.Biotech, contentDescription = "Field Ration Defense Program") },
                                label = { Text("Field Defense") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 24,
                                onClick = { viewModel.selectTab(24) },
                                icon = { Icon(Icons.Default.Security, contentDescription = "Intel Surveillance Program") },
                                label = { Text("Intel Surveillance") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 25,
                                onClick = { viewModel.selectTab(25) },
                                icon = { Icon(Icons.Default.IntegrationInstructions, contentDescription = "Android Studio Tools") },
                                label = { Text("Studio Tools") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 26,
                                onClick = { viewModel.selectTab(26) },
                                icon = { Icon(Icons.Default.Timeline, contentDescription = "InfluxDB Time Series") },
                                label = { Text("Influx DB") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 27,
                                onClick = { viewModel.selectTab(27) },
                                icon = { Icon(Icons.Default.Videocam, contentDescription = "Insecam CCTV Explorer") },
                                label = { Text("Insecam") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 28,
                                onClick = { viewModel.selectTab(28) },
                                icon = { Icon(Icons.Default.CameraIndoor, contentDescription = "MOBOTIX Edge IoT Surveillance") },
                                label = { Text("MOBOTIX") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 20,
                                onClick = { viewModel.selectTab(20) },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings") }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (selectedTab) {
                            0 -> HomeScreen(onNavigate = { viewModel.selectTab(it) })
                            1 -> LiveStreamingChatScreen(
                                messages = chatMessages,
                                isStreaming = isStreaming,
                                streamingText = streamingText,
                                onSendMessage = { viewModel.sendMessageStreaming(it) }
                            )
                            2 -> TextAnalyzerScreen(
                                analysisResult = analysisResult,
                                isAnalyzing = isAnalyzing,
                                onAnalyze = { text, mode -> viewModel.analyzeText(text, mode) }
                            )
                            3 -> ContentGeneratorScreen(
                                generatedContent = generatedContent,
                                isGenerating = isGenerating,
                                onGenerate = { prompt, cat -> viewModel.generateContent(prompt, cat) }
                            )
                            4 -> AriiaAssistantScreen(
                                ariiaMessages = ariiaMessages,
                                isProcessing = isAriiaProcessing,
                                onQueryAriia = { viewModel.queryAriia(it) },
                                onAddMessage = { sender, text -> viewModel.addAssistantMessage(sender, text) },
                                onNavigateTab = { viewModel.selectTab(it) }
                            )
                            5 -> CognitiveLearningScreen(
                                memories = memories,
                                onAddMemory = { cat, content -> viewModel.addMemory(cat, content) },
                                onRefineRules = { viewModel.refineRules() },
                                isLearning = isLearning
                            )
                            6 -> SystemAcceleratorScreen(
                                onRunDiagnostics = { viewModel.runDiagnostics() },
                                isDiagnosing = isDiagnosing,
                                diagnosticLog = diagnosticLog
                            )
                            7 -> DecisionMatrixScreen(
                                decisionResult = decisionResult,
                                isEvaluating = isEvaluating,
                                onEvaluateDecision = { opts, crit -> viewModel.evaluateDecision(opts, crit) }
                            )
                            8 -> KaleidoscopeSurveillanceScreen(
                                nodes = surveillanceNodes,
                                onSelectNode = { viewModel.selectSurveillanceNode(it) },
                                activeNode = activeNode,
                                allFeedsConnected = viewModel.allFeedsConnected.collectAsState().value,
                                onConnectAllFeeds = { viewModel.connectAllFeeds() },
                                onDisconnectAllFeeds = { viewModel.disconnectAllFeeds() },
                                onToggleFeedConnection = { viewModel.toggleFeedConnection(it) },
                                onNavigateTab = { viewModel.selectTab(it) }
                            )
                            9 -> VisionVoiceControlScreen(
                                onCommandRecognized = { command ->
                                    viewModel.queryAriia("Voice command: $command")
                                }
                            )
                            10 -> DeepSeekPeopleScreen(
                                onQueryDeepSeekAi = { prompt ->
                                    viewModel.queryAriia("DeepSeek AI: $prompt")
                                }
                            )
                            11 -> TeachableVoiceVisionScreen()
                            12 -> StreamPubSubSecurityScreen()
                            13 -> AriiaLauncherScreen()
                            14 -> AriiaEarthScreen(
                                viewModel = viewModel,
                                onNavigateToCommsWithTarget = { name: String, lat: Float, lon: Float ->
                                    dispatchedTargetPayload = name
                                    dispatchedTargetLat = lat
                                    dispatchedTargetLon = lon
                                    viewModel.selectTab(15)
                                }
                            )
                            15 -> AriiaCommsScreen(
                                initialTargetPayload = dispatchedTargetPayload,
                                initialTargetLat = dispatchedTargetLat,
                                initialTargetLon = dispatchedTargetLon,
                                onNavigateToEarth = { viewModel.selectTab(14) }
                            )
                            16 -> PainterProtocolScreen(
                                onNavigateToEarth = { name: String, lat: Float, lon: Float ->
                                    dispatchedTargetPayload = name
                                    dispatchedTargetLat = lat
                                    dispatchedTargetLon = lon
                                    viewModel.selectTab(14)
                                },
                                onNavigateTab = { tabIndex: Int -> viewModel.selectTab(tabIndex) }
                            )
                            17 -> PhotographerProtocolScreen(
                                onQueryDeepSeekAi = { prompt -> viewModel.queryAriia("DeepSeek AI: $prompt") }
                            )
                            18 -> SculptorProtocolScreen()
                            19 -> InteriorDesignerProtocolScreen()
                            20 -> SettingsMacrosScreen()
                            21 -> BabysitterProgramScreen(onNavigateTab = { viewModel.selectTab(it) })
                            22 -> FarmerProgramScreen(onNavigateTab = { viewModel.selectTab(it) })
                            23 -> ChefProgramScreen(onNavigateTab = { viewModel.selectTab(it) })
                            24 -> DetectiveProgramScreen(onNavigateTab = { viewModel.selectTab(it) })
                            25 -> AndroidStudioToolsScreen(onNavigateTab = { viewModel.selectTab(it) })
                            26 -> InfluxTelemetryDashboardScreen()
                            27 -> InsecamSurveillanceExplorerScreen()
                            28 -> MobotixSurveillanceScreen()
                        }
                    }
                }
            }
        }
    }
}
