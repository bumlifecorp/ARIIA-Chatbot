package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.widget.Toast


import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.util.Base64
import java.io.ByteArrayOutputStream
import com.example.network.InlineData

import com.example.data.AppDatabase
import com.example.data.CustomAction
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AppItem
import com.example.model.DetectedObjectInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class LauncherViewMode {
    DRAWER,
    VISION_HUD,
    MINIMAL
}

enum class AppCategory(val displayName: String) {
    ALL("All Apps"),
    FAVORITES("Favorites"),
    SOCIAL("Social"),
    CHAT("Chat"),
    PRODUCTIVITY("Productivity"),
    FINANCE("Finance"),
    SHOPPING("Shopping"),
    GAMES("Games"),
    MEDIA("Media"),
    SYSTEM("System"),
    OTHER("Other")
}

data class VoiceDialogState(
    val isOpen: Boolean = false,
    val isListening: Boolean = false,
    val recognizedText: String = "",
    val feedbackMessage: String = ""
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {


    private val db = AppDatabase.getDatabase(application)
    val customActions: kotlinx.coroutines.flow.StateFlow<List<CustomAction>> = db.customActionDao().getAll()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _wallpaperUri = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)
    val wallpaperUri: kotlinx.coroutines.flow.StateFlow<String?> = _wallpaperUri.asStateFlow()

    fun setWallpaperUri(uri: String?) {
        _wallpaperUri.value = uri
        // In a real app we would persist this uri to SharedPreferences or Datastore
    }
    
    fun addCustomAction(phrase: String, target: String) {
        viewModelScope.launch {
            db.customActionDao().insert(CustomAction(phrase = phrase, target = target))
        }
    }
    
    fun deleteCustomAction(action: CustomAction) {
        viewModelScope.launch {
            db.customActionDao().delete(action)
        }
    }

    private val _installedApps = MutableStateFlow<List<AppItem>>(emptyList())
    val installedApps: StateFlow<List<AppItem>> = _installedApps.asStateFlow()


    private val _recentAppPackages = MutableStateFlow<List<String>>(emptyList())
    val recentApps: StateFlow<List<AppItem>> = combine(_recentAppPackages, _installedApps) { recents, apps ->
        recents.mapNotNull { pkg -> apps.find { it.packageName == pkg } }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _recentCommands = MutableStateFlow<List<String>>(emptyList())
    val recentCommands: StateFlow<List<String>> = _recentCommands.asStateFlow()


    private val _iconShape = kotlinx.coroutines.flow.MutableStateFlow("Squircle")
    val iconShape: kotlinx.coroutines.flow.StateFlow<String> = _iconShape.asStateFlow()

    private val _iconSize = kotlinx.coroutines.flow.MutableStateFlow("Medium")
    val iconSize: kotlinx.coroutines.flow.StateFlow<String> = _iconSize.asStateFlow()

    fun setIconShape(shape: String) {
        _iconShape.value = shape
    }

    fun setIconSize(size: String) {
        _iconSize.value = size
    }

    private val _detectionConfidenceThreshold = MutableStateFlow(60)
    val detectionConfidenceThreshold: StateFlow<Int> = _detectionConfidenceThreshold.asStateFlow()

    fun setDetectionConfidenceThreshold(value: Int) {
        _detectionConfidenceThreshold.value = value
    }

    fun addToRecentCommands(command: String) {
        if (command.isBlank()) return
        val current = _recentCommands.value.toMutableList()
        current.remove(command)
        current.add(0, command)
        if (current.size > 5) current.removeLast()
        _recentCommands.value = current
    }

    fun addToRecentApps(packageName: String) {
        val current = _recentAppPackages.value.toMutableList()
        current.remove(packageName)
        current.add(0, packageName)
        if (current.size > 5) current.removeLast()
        _recentAppPackages.value = current
    }

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow(AppCategory.ALL)
    val selectedCategory: StateFlow<AppCategory> = _selectedCategory.asStateFlow()

    private val _favoritePackageNames = MutableStateFlow<Set<String>>(emptySet())
    val favoritePackageNames: StateFlow<Set<String>> = _favoritePackageNames.asStateFlow()

    val filteredApps: StateFlow<List<AppItem>> = combine(
        _installedApps,
        _searchQuery,
        _selectedCategory,
        _favoritePackageNames
    ) { apps, query, category, favorites ->
        var list = apps.map { app ->
            app.copy(isFavorite = favorites.contains(app.packageName))
        }

        if (category == AppCategory.FAVORITES) {
            list = list.filter { it.isFavorite }
        } else if (category != AppCategory.ALL) {
            list = list.filter { it.category.equals(category.displayName, ignoreCase = true) }
        }

        if (query.isNotBlank()) {
            list = list.filter {
                it.label.contains(query, ignoreCase = true) ||
                        it.packageName.contains(query, ignoreCase = true)
            }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteApps: StateFlow<List<AppItem>> = combine(
        _installedApps,
        _favoritePackageNames
    ) { apps, favorites ->
        apps.filter { favorites.contains(it.packageName) }
            .map { it.copy(isFavorite = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Camera & ML Kit vision state
    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    private val _detectedObjects = MutableStateFlow<List<DetectedObjectInfo>>(emptyList())
    val detectedObjects: StateFlow<List<DetectedObjectInfo>> = _detectedObjects.asStateFlow()

    private val _detectedSummaryText = MutableStateFlow("Inget objekt identifierat")
    val detectedSummaryText: StateFlow<String> = _detectedSummaryText.asStateFlow()

    private val _viewMode = MutableStateFlow(LauncherViewMode.VISION_HUD)
    val viewMode: StateFlow<LauncherViewMode> = _viewMode.asStateFlow()

    private val _isVisionOverlayVisible = MutableStateFlow(true)
    val isVisionOverlayVisible: StateFlow<Boolean> = _isVisionOverlayVisible.asStateFlow()

    private val _isCameraActive = MutableStateFlow(true)
    val isCameraActive: StateFlow<Boolean> = _isCameraActive.asStateFlow()

    private val _voiceState = MutableStateFlow(VoiceDialogState())
    val voiceState: StateFlow<VoiceDialogState> = _voiceState.asStateFlow()

    private val _feedbackVisual = MutableStateFlow(true)
    val feedbackVisual: StateFlow<Boolean> = _feedbackVisual.asStateFlow()

    private val _feedbackAuditory = MutableStateFlow(false)
    val feedbackAuditory: StateFlow<Boolean> = _feedbackAuditory.asStateFlow()

    private val _feedbackHaptic = MutableStateFlow(true)
    val feedbackHaptic: StateFlow<Boolean> = _feedbackHaptic.asStateFlow()

    fun toggleFeedbackVisual() { _feedbackVisual.value = !_feedbackVisual.value }
    fun toggleFeedbackAuditory() { _feedbackAuditory.value = !_feedbackAuditory.value }
    fun toggleFeedbackHaptic() { _feedbackHaptic.value = !_feedbackHaptic.value }

    init {
        loadInstalledApps()
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val pm = getApplication<Application>().packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val pkgAppsList: List<ResolveInfo> = pm.queryIntentActivities(mainIntent, 0)

            val appList = pkgAppsList.map { resolveInfo ->
                val label = resolveInfo.loadLabel(pm).toString()
                val pkgName = resolveInfo.activityInfo.packageName
                val icon = try {
                    resolveInfo.loadIcon(pm)
                } catch (e: Exception) {
                    null
                }
                val isSystem = (resolveInfo.activityInfo.applicationInfo.flags and
                        android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0

                val category = categorizeApp(label, pkgName, isSystem)

                AppItem(
                    packageName = pkgName,
                    label = label,
                    icon = icon,
                    isSystemApp = isSystem,
                    category = category
                )
            }.sortedBy { it.label.lowercase() }

            // Pre-seed some default favorites if none set
            if (_favoritePackageNames.value.isEmpty() && appList.isNotEmpty()) {
                val initialFavs = appList.take(5).map { it.packageName }.toSet()
                _favoritePackageNames.value = initialFavs
            }

            withContext(Dispatchers.Main) {
                _installedApps.value = appList
            }
        }
    }

private fun categorizeApp(label: String, pkgName: String, isSystem: Boolean): String {
        val lower = "$label $pkgName".lowercase()
        return when {
            lower.contains("facebook") || lower.contains("twitter") || lower.contains("instagram") ||
            lower.contains("snapchat") || lower.contains("tiktok") || lower.contains("linkedin") ||
            lower.contains("social") || lower.contains("reddit") -> "Social"
            
            lower.contains("whatsapp") || lower.contains("telegram") || lower.contains("messenger") ||
            lower.contains("chat") || lower.contains("message") || lower.contains("slack") ||
            lower.contains("discord") || lower.contains("viber") -> "Chat"
            
            lower.contains("mail") || lower.contains("gmail") || lower.contains("outlook") ||
            lower.contains("docs") || lower.contains("sheet") || lower.contains("drive") ||
            lower.contains("keep") || lower.contains("notes") || lower.contains("task") ||
            lower.contains("todo") || lower.contains("calendar") || lower.contains("calc") -> "Productivity"
            
            lower.contains("bank") || lower.contains("pay") || lower.contains("finance") ||
            lower.contains("wallet") || lower.contains("cash") || lower.contains("money") -> "Finance"
            
            lower.contains("shop") || lower.contains("amazon") || lower.contains("ebay") ||
            lower.contains("store") || lower.contains("buy") -> "Shopping"
            
            lower.contains("game") || lower.contains("play") || lower.contains("puzzle") ||
            lower.contains("arcade") || lower.contains("casino") -> "Games"
            
            lower.contains("camera") || lower.contains("gallery") || lower.contains("photo") ||
            lower.contains("video") || lower.contains("music") || lower.contains("audio") ||
            lower.contains("youtube") || lower.contains("media") || lower.contains("spotify") ||
            lower.contains("netflix") || lower.contains("player") -> "Media"
            
            isSystem || lower.contains("setting") || lower.contains("android") ||
            lower.contains("system") || lower.contains("phone") || lower.contains("dialer") ||
            lower.contains("contact") || lower.contains("clock") || lower.contains("file") ||
            lower.contains("tool") || lower.contains("torch") || lower.contains("scanner") -> "System"
            
            else -> "Other"
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: AppCategory) {
        _selectedCategory.value = category
    }

    fun setViewMode(mode: LauncherViewMode) {
        _viewMode.value = mode
    }

    fun toggleVisionOverlay() {
        _isVisionOverlayVisible.value = !_isVisionOverlayVisible.value
    }

    fun toggleCameraActive() {
        _isCameraActive.value = !_isCameraActive.value
    }

    fun toggleFavorite(packageName: String) {
        val current = _favoritePackageNames.value.toMutableSet()
        if (current.contains(packageName)) {
            current.remove(packageName)
        } else {
            current.add(packageName)
        }
        _favoritePackageNames.value = current
    }

    fun onObjectsDetected(objects: List<DetectedObjectInfo>, summary: String) {
        _detectedObjects.value = objects
        _detectedSummaryText.value = summary
    }

    fun toggleTorch(context: Context) {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        if (cameraManager == null) {
            Toast.makeText(context, "Ficklampa stöds inte", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val cameraIdList = cameraManager.cameraIdList
            if (cameraIdList.isNotEmpty()) {
                val cameraId = cameraIdList[0]
                val newState = !_isTorchOn.value
                cameraManager.setTorchMode(cameraId, newState)
                _isTorchOn.value = newState
            } else {
                Toast.makeText(context, "Ingen kameraficklampa hittades", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            // Emulators or devices without physical flash might throw CameraAccessException
            _isTorchOn.value = !_isTorchOn.value
            Toast.makeText(context, "Ficklampa: ${_isTorchOn.value}", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchApp(context: Context, packageName: String) {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            try {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                addToRecentApps(packageName)
            } catch (e: Exception) {
                Toast.makeText(context, "Kunde inte starta $packageName", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Appen saknar startaktivitet", Toast.LENGTH_SHORT).show()
        }
    }

    fun openVoiceDialog() {
        _voiceState.value = VoiceDialogState(
            isOpen = true,
            isListening = true,
            feedbackMessage = "Tala till RiaOS... Säg t.ex. 'Öppna Chrome' eller 'Tänd ficklampan'"
        )
    }

    fun closeVoiceDialog() {
        _voiceState.value = _voiceState.value.copy(isOpen = false, isListening = false)
    }


    fun submitGesture(composePath: androidx.compose.ui.graphics.Path) {
        viewModelScope.launch {
            try {
                // Convert Path to Bitmap
                val androidPath = composePath.asAndroidPath()
                val bounds = android.graphics.RectF()
                androidPath.computeBounds(bounds, true)
                
                if (bounds.width() < 10 || bounds.height() < 10) return@launch // Too small
                
                // Add padding
                val padding = 40f
                val width = (bounds.width() + padding * 2).toInt()
                val height = (bounds.height() + padding * 2).toInt()
                
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                canvas.drawColor(Color.WHITE) // White background
                
                val paint = Paint().apply {
                    color = Color.BLACK
                    style = Paint.Style.STROKE
                    strokeWidth = 12f
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                    isAntiAlias = true
                }
                
                // Translate path to 0,0
                androidPath.offset(-bounds.left + padding, -bounds.top + padding)
                canvas.drawPath(androidPath, paint)
                
                // Convert to Base64
                val baos = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, baos)
                val base64Data = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                
                // Send to Gemini
                val apiKey = com.example.BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    _voiceState.value = _voiceState.value.copy(
                        isOpen = true,
                        feedbackMessage = "API-nyckel saknas för rit-igenkänning."
                    )
                    return@launch
                }
                
                val response = com.example.network.RetrofitClient.service.generateContent(
                    apiKey,
                    com.example.network.GenerateContentRequest(
                        contents = listOf(com.example.network.Content(
                            parts = listOf(
                                com.example.network.Part(text = "What single letter of the alphabet is drawn in this image? Reply with ONLY the letter, nothing else."),
                                com.example.network.Part(inlineData = InlineData("image/jpeg", base64Data))
                            )
                        )),
                        systemInstruction = com.example.network.Content(
                            parts = listOf(com.example.network.Part(text = "You are an OCR assistant. Reply strictly with one uppercase character."))
                        )
                    )
                )
                
                val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()?.uppercase()
                
                if (!reply.isNullOrEmpty() && reply.length == 1 && reply[0].isLetter()) {
                    // Find app starting with this letter
                    val matches = _installedApps.value.filter { it.label.uppercase().startsWith(reply) }
                    if (matches.isNotEmpty()) {
                        val target = matches.find { it.isFavorite } ?: matches.first()
                        _voiceState.value = _voiceState.value.copy(
                            isOpen = true,
                            feedbackMessage = "Ritade '$reply'. Öppnar ${target.label}..."
                        )
                        setSearchQuery(reply)
                        setViewMode(LauncherViewMode.DRAWER)
                    } else {
                        _voiceState.value = _voiceState.value.copy(
                            isOpen = true,
                            feedbackMessage = "Ritade '$reply'. Hittade inga appar."
                        )
                        setSearchQuery(reply)
                        setViewMode(LauncherViewMode.DRAWER)
                    }
                }
                
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun handleVoiceResult(context: Context, recognizedSpeech: String) {
        val lower = recognizedSpeech.lowercase().trim()
        _voiceState.value = _voiceState.value.copy(
            recognizedText = recognizedSpeech,
            isListening = false
        )


        viewModelScope.launch {
            // First check custom actions
            val customAction = customActions.value.find { lower.contains(it.phrase.lowercase()) }
            if (customAction != null) {
                _voiceState.value = _voiceState.value.copy(feedbackMessage = "Kör anpassad åtgärd...")
                
                // If it's a URL, launch intent. If it's a package, launch app.
                if (customAction.target.startsWith("http")) {
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(customAction.target))
                    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        _voiceState.value = _voiceState.value.copy(feedbackMessage = "Kunde inte öppna länken")
                    }
                } else {
                    launchApp(context, customAction.target)
                }
                return@launch
            }
            
            when {

                lower.contains("ficklampa") || lower.contains("torch") || lower.contains("blixt") || lower.contains("light") -> {
                    toggleTorch(context)
                    _voiceState.value = _voiceState.value.copy(
                        feedbackMessage = if (_isTorchOn.value) "Ficklampan är tänd 🔦" else "Ficklampan är släckt"
                    )
                }
                lower.contains("kamera") || lower.contains("vision") || lower.contains("hud") -> {
                    setViewMode(LauncherViewMode.VISION_HUD)
                    _voiceState.value = _voiceState.value.copy(feedbackMessage = "Byter till Vision HUD-läge 📷")
                }
                lower.startsWith("öppna") || lower.startsWith("starta") || lower.startsWith("open") || lower.startsWith("launch") -> {
                    val appQuery = lower.replace("öppna", "").replace("starta", "").replace("open", "").replace("launch", "").trim()
                    val matches = _installedApps.value.filter { it.label.contains(appQuery, ignoreCase = true) }
                    if (matches.size == 1) {
                        _voiceState.value = _voiceState.value.copy(feedbackMessage = "Startar ${matches.first().label}...")
                        launchApp(context, matches.first().packageName)
                    } else if (matches.size > 1) {
                        val exactMatch = matches.find { it.label.equals(appQuery, ignoreCase = true) }
                        if (exactMatch != null) {
                            _voiceState.value = _voiceState.value.copy(feedbackMessage = "Startar ${exactMatch.label}...")
                            launchApp(context, exactMatch.packageName)
                        } else {
                            val names = matches.take(3).joinToString { it.label }
                            _voiceState.value = _voiceState.value.copy(feedbackMessage = "Flera träffar: $names")
                        }
                    } else {
                        _voiceState.value = _voiceState.value.copy(feedbackMessage = "Hittade ingen app med namnet '$appQuery'")
                    }
                }
                lower.contains("appar") || lower.contains("apps") || lower.contains("meny") || lower.contains("drawer") -> {
                    setViewMode(LauncherViewMode.DRAWER)
                    _voiceState.value = _voiceState.value.copy(feedbackMessage = "Öppnar appmenyn 📱")
                }
                else -> {
                    _voiceState.value = _voiceState.value.copy(
                        feedbackMessage = "Tänker..."
                    )
                    
                    try {
                        val apiKey = com.example.BuildConfig.GEMINI_API_KEY
                        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                             _voiceState.value = _voiceState.value.copy(
                                feedbackMessage = "API-nyckel saknas. Konfigurera den i Secrets panel."
                            )
                        } else {
                            val response = com.example.network.RetrofitClient.service.generateContent(
                                apiKey,
                                com.example.network.GenerateContentRequest(
                                    contents = listOf(com.example.network.Content(
                                        parts = listOf(com.example.network.Part(text = recognizedSpeech))
                                    )),
                                    systemInstruction = com.example.network.Content(
                                        parts = listOf(com.example.network.Part(text = "You are RiaOS AI Assistant. You answer concisely and directly in Swedish, matching the user's inquiry."))
                                    )
                                )
                            )
                            val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Inget svar från AI."
                            _voiceState.value = _voiceState.value.copy(feedbackMessage = reply)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        _voiceState.value = _voiceState.value.copy(feedbackMessage = "Kan inte nå AI just nu.")
                    }
                }
            }
        }
    }
}
