package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DecisionMatrixScreen(
    decisionResult: String,
    isEvaluating: Boolean,
    onEvaluateDecision: (String, String) -> Unit
) {
    var optionInput by remember { mutableStateOf("Option A vs Option B") }
    var criteriaInput by remember { mutableStateOf("Cost, Speed, Maintainability, Scalability") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0A0A0E),
                border = BorderStroke(1.dp, Color(0xFF39FF14).copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STRUCTURED DECISION MATRIX",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF39FF14),
                            fontFamily = FontFamily.Monospace
                        )
                        Badge(
                            containerColor = Color(0xFF0A3800),
                            contentColor = Color(0xFFF1F8E9)
                        ) {
                            Text("AUTO EVALUATE", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp)
                        }
                    }
                    Text(
                        text = "Weighs options against criteria automatically. Builds an options × criteria comparison matrix with trade-offs and reasoned recommendations.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            // Inputs
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF14141C),
                border = BorderStroke(1.dp, Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = optionInput,
                        onValueChange = { optionInput = it },
                        label = { Text("Options to Compare (e.g. Jetpack Compose vs Flutter)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF39FF14),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    OutlinedTextField(
                        value = criteriaInput,
                        onValueChange = { criteriaInput = it },
                        label = { Text("Evaluation Criteria (comma separated)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF39FF14),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Button(
                        onClick = {
                            if (optionInput.isNotBlank() && criteriaInput.isNotBlank()) {
                                onEvaluateDecision(optionInput, criteriaInput)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF39FF14)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Balance, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isEvaluating) "Generating Comparison Matrix..." else "Evaluate Options & Build Matrix", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Results Output
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0A0A0E),
                border = BorderStroke(1.dp, Color(0xFF334155)),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Decision Matrix & Trade-off Analysis",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFF39FF14),
                        fontFamily = FontFamily.Monospace
                    )
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text(
                                text = decisionResult.ifEmpty { "Enter options and criteria above to generate the structured comparison matrix and recommendation." },
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
