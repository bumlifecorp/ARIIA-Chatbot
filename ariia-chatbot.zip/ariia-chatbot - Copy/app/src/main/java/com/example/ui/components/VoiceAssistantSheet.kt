package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.ImmersiveBg
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveCardBg
import com.example.ui.theme.ImmersiveLavender
import com.example.ui.theme.ImmersiveOnLavender
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveTextMuted
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.viewmodel.VoiceDialogState

@Composable
fun VoiceAssistantDialog(
    voiceState: VoiceDialogState,
    recentCommands: List<String> = emptyList(),
    onReissueCommand: (String) -> Unit = {},
    onClose: () -> Unit,
    onTriggerSpeechIntent: () -> Unit,
    onExecuteCommand: (String) -> Unit
) {
    if (!voiceState.isOpen) return

    var manualCommandText by remember { mutableStateOf("") }
    var showHelp by remember { mutableStateOf(false) }
    
    if (showHelp) {
        VoiceCommandsHelpDialog { showHelp = false }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "voice_wave")
    val waveScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave"
    )

    Dialog(onDismissRequest = onClose) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = ImmersiveSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
            shadowElevation = 24.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .testTag("voice_assistant_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(ImmersiveLavender, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "RÖSTASSISTENT",
                            style = MaterialTheme.typography.labelMedium,
                            color = ImmersiveLavender,
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row {
                        IconButton(
                            onClick = { showHelp = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = androidx.compose.material.icons.Icons.Default.HelpOutline,
                                contentDescription = "Hjälp",
                                tint = ImmersiveTextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = onClose,
                            modifier = Modifier.size(32.dp)
                        ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Stäng",
                            tint = ImmersiveTextSecondary
                        )
                    }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Lavender Microphone Avatar
                Box(
                    modifier = Modifier.size(96.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (voiceState.isListening) {
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .scale(waveScale)
                                .background(ImmersiveLavender.copy(alpha = 0.2f), CircleShape)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(ImmersiveLavender, CircleShape)
                            .clickable { onTriggerSpeechIntent() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (voiceState.isListening) Icons.Default.Mic else Icons.Default.MicOff,
                            contentDescription = "Tala",
                            tint = ImmersiveOnLavender,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Feedback / Status message
                Text(
                    text = voiceState.feedbackMessage.ifEmpty { "Tala till RiaOS..." },
                    style = MaterialTheme.typography.bodyMedium,
                    color = ImmersiveTextPrimary,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )

                if (voiceState.recognizedText.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = ImmersiveCardBg,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder)
                    ) {
                        Text(
                            text = "\"${voiceState.recognizedText}\"",
                            color = ImmersiveLavender,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Command Suggestions

                if (recentCommands.isNotEmpty()) {
                    Text(
                        text = "TIDIGARE KOMMANDON",
                        style = MaterialTheme.typography.labelSmall,
                        color = ImmersiveTextMuted,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(recentCommands) { cmd ->
                            CommandPill(label = cmd, onClick = { onReissueCommand(cmd) })
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
                Text(
                    text = "SNABB-KOMMANDON",
                    style = MaterialTheme.typography.labelSmall,
                    color = ImmersiveTextMuted,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    QuickCommandButton("🔦 Ficklampa", Modifier.weight(1f)) {
                        onExecuteCommand("tänd ficklampan")
                    }
                    QuickCommandButton("📷 Vision HUD", Modifier.weight(1f)) {
                        onExecuteCommand("vision hud")
                    }
                    QuickCommandButton("📱 Appar", Modifier.weight(1f)) {
                        onExecuteCommand("öppna appar")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Manual text command input
                OutlinedTextField(
                    value = manualCommandText,
                    onValueChange = { manualCommandText = it },
                    placeholder = {
                        Text("Eller skriv ett kommando...", color = ImmersiveTextMuted, fontSize = 13.sp)
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ImmersiveLavender,
                        unfocusedBorderColor = ImmersiveBorder,
                        focusedContainerColor = ImmersiveCardBg,
                        unfocusedContainerColor = ImmersiveCardBg,
                        focusedTextColor = ImmersiveTextPrimary,
                        unfocusedTextColor = ImmersiveTextPrimary
                    ),
                    trailingIcon = {
                        if (manualCommandText.isNotBlank()) {
                            Button(
                                onClick = {
                                    onExecuteCommand(manualCommandText)
                                    manualCommandText = ""
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ImmersiveLavender,
                                    contentColor = ImmersiveOnLavender
                                ),
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Text("Kör", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Voice Trigger Button
                Button(
                    onClick = onTriggerSpeechIntent,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ImmersiveLavender,
                        contentColor = ImmersiveOnLavender
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Start Voice",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Starta Röstinmatning", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun QuickCommandButton(
    text: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = ImmersiveCardBg,
        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
        modifier = modifier.clickable { onClick() }
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = ImmersiveTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}


@Composable
private fun CommandPill(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = ImmersiveCardBg,
        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = ImmersiveTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp),
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}
