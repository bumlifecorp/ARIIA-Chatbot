package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AltoMapsTileDao {
    @Query("SELECT * FROM altomaps_tiles WHERE tileId = :tileId")
    suspend fun getTileById(tileId: String): AltoMapsTileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTile(tile: AltoMapsTileEntity)

    @Query("DELETE FROM altomaps_tiles WHERE tileId = :tileId")
    suspend fun deleteTile(tileId: String)

    @Query("SELECT COUNT(*) FROM altomaps_tiles")
    fun getTileCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM altomaps_tiles")
    suspend fun getTileCountSync(): Int

    @Query("DELETE FROM altomaps_tiles")
    suspend fun clearAllTiles()

    @Query("SELECT * FROM altomaps_tiles")
    suspend fun getAllTiles(): List<AltoMapsTileEntity>
}
