package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.ui.MemoryItem

@Composable
fun CognitiveLearningScreen(
    memories: List<MemoryItem>,
    onAddMemory: (String, String) -> Unit,
    onRefineRules: () -> Unit,
    isLearning: Boolean
) {
    var newCategory by remember { mutableStateOf("Preference") }
    var newContent by remember { mutableStateOf("") }
    var expandedAdd by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0A0A0E),
                border = BorderStroke(1.dp, Color(0xFFBD00FF).copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "COGNITIVE LEARNING ENGINE",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFBD00FF),
                            fontFamily = FontFamily.Monospace
                        )
                        Badge(
                            containerColor = Color(0xFF38006B),
                            contentColor = Color(0xFFF3E5F5)
                        ) {
                            Text("ACTIVE SYNC", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp)
                        }
                    }
                    Text(
                        text = "Cross-session semantic memory engine. Automatically refines rules, stores preferences, and adapts to your workflow across interactions.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            // Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { expandedAdd = !expandedAdd },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF)),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Inject Memory", color = Color.White)
                }

                OutlinedButton(
                    onClick = { onRefineRules() },
                    border = BorderStroke(1.dp, Color(0xFF00F0FF)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF00F0FF)),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Psychology, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isLearning) "Refining..." else "Refine Rules")
                }
            }

            if (expandedAdd) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF14141C),
                    border = BorderStroke(1.dp, Color(0xFF334155)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Add New Semantic Knowledge", style = MaterialTheme.typography.labelLarge, color = Color(0xFF00F0FF))
                        OutlinedTextField(
                            value = newCategory,
                            onValueChange = { newCategory = it },
                            label = { Text("Category (Preference / Rule / Goal)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFBD00FF),
                                unfocusedBorderColor = Color(0xFF334155),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        OutlinedTextField(
                            value = newContent,
                            onValueChange = { newContent = it },
                            label = { Text("Semantic Fact / Instruction") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFBD00FF),
                                unfocusedBorderColor = Color(0xFF334155),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        Button(
                            onClick = {
                                if (newContent.isNotBlank()) {
                                    onAddMemory(newCategory, newContent)
                                    newContent = ""
                                    expandedAdd = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Save to Core", color = Color.Black)
                        }
                    }
                }
            }

            // Memory Feed
            Text(
                text = "Persistent Knowledge Graph (${memories.size} nodes)",
                style = MaterialTheme.typography.titleSmall,
                color = Color(0xFF00F0FF),
                fontFamily = FontFamily.Monospace
            )

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(memories) { mem ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF0A0A0E),
                        border = BorderStroke(1.dp, Color(0xFF334155)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Badge(
                                    containerColor = when (mem.category) {
                                        "Preference" -> Color(0xFF38006B)
                                        "Learned Rule" -> Color(0xFF00363D)
                                        else -> Color(0xFF0A3800)
                                    },
                                    contentColor = Color.White
                                ) {
                                    Text(mem.category, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp)
                                }
                                Text(
                                    text = "Confidence: ${(mem.confidence * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF39FF14),
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = mem.content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
