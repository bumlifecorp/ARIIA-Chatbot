package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "satellite_metadata")
data class SatelliteMetadataEntity(
    @PrimaryKey val metadataId: String,
    val regionName: String,
    val resolution: Float,
    val cloudCover: Float,
    val acquisitionDate: Long,
    val sensorType: String,
    val timestamp: Long = System.currentTimeMillis()
)
