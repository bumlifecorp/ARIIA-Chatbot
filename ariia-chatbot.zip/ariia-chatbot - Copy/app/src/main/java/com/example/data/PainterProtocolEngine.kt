package com.example.data

import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

class PainterProtocolEngine(
    private val context: Context? = null
) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Preset biometric face profiles for Color_Picker search
    val availableFaceProfiles = listOf(
        PresetFaceProfile(
            id = "DS-001",
            name = "Dr. Elena Vance",
            title = "Chief Neural Architect",
            clearance = "Level 5 - Omega",
            department = "AI Research",
            knownFaceScore = 0.99f,
            description = "High-priority subject. Verified facial liveness vector. Optical recognition signature 0x9F41."
        ),
        PresetFaceProfile(
            id = "DS-002",
            name = "Marcus Thorne",
            title = "Director of Cyber Defense",
            clearance = "Level 4 - Secured",
            department = "Security Ops",
            knownFaceScore = 0.96f,
            description = "Field operations supervisor. Tactical telemetry profile verified."
        ),
        PresetFaceProfile(
            id = "DS-003",
            name = "Aria Lin",
            title = "Quantum Cryptographer",
            clearance = "Level 4 - Secured",
            department = "Core Encryption",
            knownFaceScore = 0.98f,
            description = "Subterranean comms specialist. Real-time retinal and facial landmarks registered."
        ),
        PresetFaceProfile(
            id = "DS-005",
            name = "Dr. Sarah Chen",
            title = "Bio-Metric Intelligence Lead",
            clearance = "Level 5 - Omega",
            department = "Biometrics",
            knownFaceScore = 0.99f,
            description = "Biometric classification researcher with continuous tracking authorization."
        ),
        PresetFaceProfile(
            id = "OP-ECHO",
            name = "Operative Echo (Covert)",
            title = "Tactical Recon Agent",
            clearance = "Level 3 - Tactical",
            department = "Field Recon",
            knownFaceScore = 0.94f,
            description = "Active asset moving through metropolitan transit corridors under surveillance."
        ),
        PresetFaceProfile(
            id = "SUS-99",
            name = "Suspect Phantom-9",
            title = "Perimeter Intruder Flag",
            clearance = "Unauthorized",
            department = "External Alert",
            knownFaceScore = 0.91f,
            description = "Anomaly detected near cyber perimeter. Flagged for immediate paint & dry continuous lock."
        )
    )

    // Palette of tactical paint colors
    val paintBrushPalette = listOf(
        Pair("#00F0FF", "Cyan Hunter"),
        Pair("#39FF14", "Emerald Sentinel"),
        Pair("#FFB300", "Amber Warning"),
        Pair("#FF0055", "Crimson Strike"),
        Pair("#BD00FF", "Ultraviolet Shadow"),
        Pair("#00E5FF", "Ice Blue Vector")
    )

    // Simulated Detectable Canvas Objects on Camera/Satellite view
    private val _canvasDetectableObjects = MutableStateFlow<List<DetectableCanvasTarget>>(
        listOf(
            DetectableCanvasTarget(
                id = "OBJ-01",
                label = "Subject Elena Vance",
                category = "PERSON",
                xPercent = 0.28f,
                yPercent = 0.35f,
                widthPercent = 0.16f,
                heightPercent = 0.28f,
                confidence = 0.98f,
                faceScore = 0.99f,
                threatLevel = "Low"
            ),
            DetectableCanvasTarget(
                id = "OBJ-02",
                label = "Armored Convoy SV-4",
                category = "VEHICLE",
                xPercent = 0.62f,
                yPercent = 0.52f,
                widthPercent = 0.24f,
                heightPercent = 0.20f,
                confidence = 0.95f,
                threatLevel = "Elevated"
            ),
            DetectableCanvasTarget(
                id = "OBJ-03",
                label = "Autonomous Drone TU-4",
                category = "DRONE",
                xPercent = 0.44f,
                yPercent = 0.15f,
                widthPercent = 0.14f,
                heightPercent = 0.12f,
                confidence = 0.97f,
                threatLevel = "Low"
            ),
            DetectableCanvasTarget(
                id = "OBJ-04",
                label = "Subject Marcus Thorne",
                category = "PERSON",
                xPercent = 0.76f,
                yPercent = 0.30f,
                widthPercent = 0.15f,
                heightPercent = 0.26f,
                confidence = 0.96f,
                faceScore = 0.96f,
                threatLevel = "Low"
            ),
            DetectableCanvasTarget(
                id = "OBJ-05",
                label = "Unmarked Transit Van",
                category = "VEHICLE",
                xPercent = 0.12f,
                yPercent = 0.68f,
                widthPercent = 0.22f,
                heightPercent = 0.18f,
                confidence = 0.92f,
                threatLevel = "High"
            )
        )
    )
    val canvasDetectableObjects: StateFlow<List<DetectableCanvasTarget>> = _canvasDetectableObjects.asStateFlow()

    // Color_Picker Search Results
    private val _searchResults = MutableStateFlow<List<ColorPickerSearchResult>>(emptyList())
    val searchResults: StateFlow<List<ColorPickerSearchResult>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    // Real-time telemetry log for Paint_Dryer
    private val _telemetryHandoffLog = MutableStateFlow<List<String>>(
        listOf(
            "INITIALIZED: Painter Protocol Multi-Asset Telemetry Engine.",
            "LINKED: 4 LEO Orbital Constellations (Sentinel-3, NRO-KH11, Starlink-07, GeoSat-2).",
            "SYNC: Optical FLIR + Doppler Radar + AltoMaps Baro layers operational."
        )
    )
    val telemetryHandoffLog: StateFlow<List<String>> = _telemetryHandoffLog.asStateFlow()

    // Art_Gallery Painted Objects list
    private val _paintedObjects = MutableStateFlow<List<PaintedObject>>(
        listOf(
            PaintedObject(
                id = "PAINT-001",
                name = "Dr. Elena Vance (Neural Lead)",
                category = "PERSON",
                paintColorHex = "#00F0FF",
                paintColorName = "Cyan Hunter",
                priority = "CRITICAL_P1",
                facialMatchScore = 0.99f,
                facialProfileId = "DS-001",
                coordinates = "35.6595° N, 139.7004° E",
                latitude = 35.6595,
                longitude = 139.7004,
                altitudeMeters = 38.0,
                velocityKmh = 4.8f,
                headingDegrees = 112.0f,
                currentFeedId = "CAM-SHIBUYA",
                currentFeedName = "Shibuya Scramble Crossing 4K",
                sensorType = "Optical 4K + LEO Satellite Relay",
                lockStatus = "STABLE_TRACK",
                dryStatusPercent = 100,
                isMonitoring = true,
                detectionSource = "Color_Picker Facial Recognition",
                notes = "Primary asset painted in Tokyo metro sector. Real-time orbital telemetry lock confirmed.",
                breadcrumbs = listOf(
                    TelemetryPoint(35.6590, 139.7000, 38.0, 4.5f, 110f, System.currentTimeMillis() - 40000, "CAM-SHIBUYA"),
                    TelemetryPoint(35.6593, 139.7002, 38.0, 4.7f, 112f, System.currentTimeMillis() - 20000, "CAM-SHIBUYA"),
                    TelemetryPoint(35.6595, 139.7004, 38.0, 4.8f, 112f, System.currentTimeMillis(), "CAM-SHIBUYA")
                )
            ),
            PaintedObject(
                id = "PAINT-002",
                name = "Armored Escort Convoy SV-04",
                category = "VEHICLE",
                paintColorHex = "#39FF14",
                paintColorName = "Emerald Sentinel",
                priority = "HIGH_P2",
                facialMatchScore = 0.0f,
                facialProfileId = "",
                coordinates = "34.0537° N, 118.2427° W",
                latitude = 34.0537,
                longitude = -118.2427,
                altitudeMeters = 72.0,
                velocityKmh = 68.4f,
                headingDegrees = 278.0f,
                currentFeedId = "STREAM-HIGHWAY",
                currentFeedName = "Sector Alpha - Main Highway Stream",
                sensorType = "WebRTC Video Analytics + Drone CAM-04",
                lockStatus = "LOCKED_DRYING",
                dryStatusPercent = 92,
                isMonitoring = true,
                detectionSource = "Paint_Brushing Manual Bounding Box",
                notes = "Vehicle painted during corridor transit. Handoff to aerial drone active.",
                breadcrumbs = listOf(
                    TelemetryPoint(34.0510, -118.2390, 72.0, 65.0f, 275f, System.currentTimeMillis() - 30000, "STREAM-HIGHWAY"),
                    TelemetryPoint(34.0525, -118.2410, 72.0, 67.5f, 276f, System.currentTimeMillis() - 15000, "STREAM-HIGHWAY"),
                    TelemetryPoint(34.0537, -118.2427, 72.0, 68.4f, 278f, System.currentTimeMillis(), "STREAM-HIGHWAY")
                )
            ),
            PaintedObject(
                id = "PAINT-003",
                name = "Tactical Recon Drone Alpha",
                category = "DRONE",
                paintColorHex = "#FFB300",
                paintColorName = "Amber Warning",
                priority = "CONTINUOUS_P3",
                facialMatchScore = 0.0f,
                facialProfileId = "",
                coordinates = "40.7128° N, 74.0060° W",
                latitude = 40.7128,
                longitude = -74.0060,
                altitudeMeters = 240.0,
                velocityKmh = 115.0f,
                headingDegrees = 15.0f,
                currentFeedId = "CAM-04",
                currentFeedName = "Tactical Unit 4 - Aerial Drone",
                sensorType = "Aerial Gimbal + Satellite KH-11",
                lockStatus = "STABLE_TRACK",
                dryStatusPercent = 100,
                isMonitoring = true,
                detectionSource = "Color_Picker Automated Sweep",
                notes = "UAV flight path monitored across airspace corridor.",
                breadcrumbs = listOf(
                    TelemetryPoint(40.7100, -74.0070, 235.0, 112f, 14f, System.currentTimeMillis() - 25000, "CAM-04"),
                    TelemetryPoint(40.7115, -74.0065, 238.0, 114f, 15f, System.currentTimeMillis() - 12000, "CAM-04"),
                    TelemetryPoint(40.7128, -74.0060, 240.0, 115f, 15f, System.currentTimeMillis(), "CAM-04")
                )
            ),
            PaintedObject(
                id = "PAINT-004",
                name = "Unidentified Vessel (Perimeter)",
                category = "VESSEL",
                paintColorHex = "#FF0055",
                paintColorName = "Crimson Strike",
                priority = "CRITICAL_P1",
                facialMatchScore = 0.0f,
                facialProfileId = "",
                coordinates = "33.7490° N, 118.2655° W",
                latitude = 33.7490,
                longitude = -118.2655,
                altitudeMeters = 0.5,
                velocityKmh = 22.0f,
                headingDegrees = 195.0f,
                currentFeedId = "CAM-02",
                currentFeedName = "Sector Beta - Industrial Port (FLIR)",
                sensorType = "Thermal Infrared FLIR + Maritime Radar",
                lockStatus = "SATELLITE_HANDOFF",
                dryStatusPercent = 78,
                isMonitoring = true,
                detectionSource = "Paint_Brushing FLIR Canvas",
                notes = "High-threat maritime craft crossing boundary channel. Satellite tracking engaged.",
                breadcrumbs = listOf(
                    TelemetryPoint(33.7510, -118.2640, 0.5, 21f, 192f, System.currentTimeMillis() - 20000, "CAM-02"),
                    TelemetryPoint(33.7490, -118.2655, 0.5, 22f, 195f, System.currentTimeMillis(), "CAM-02")
                )
            )
        )
    )
    val paintedObjects: StateFlow<List<PaintedObject>> = _paintedObjects.asStateFlow()

    private var roomDao: PaintedObjectDao? = null

    init {
        // Initialize Room Database if context is available
        if (context != null) {
            scope.launch {
                try {
                    val db = AppDatabase.getDatabase(context)
                    roomDao = db.paintedObjectDao()
                    // Sync initial entities if database is empty
                    roomDao?.getAllPaintedObjects()?.collect { entities ->
                        if (entities.isNotEmpty()) {
                            val mapped = entities.map { entity ->
                                val existing = _paintedObjects.value.firstOrNull { it.id == entity.id }
                                PaintedObject.fromEntity(entity, existing?.breadcrumbs ?: emptyList())
                            }
                            _paintedObjects.value = mapped
                        } else {
                            // Seed initial objects
                            _paintedObjects.value.forEach { obj ->
                                roomDao?.insertOrUpdate(obj.toEntity())
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Fallback to in-memory state if room init encounters issues
                }
            }
        }

        // Start real-time telemetry simulation for Paint_Dryer
        startRealtimeTelemetrySimulation()
    }

    /**
     * Feature A: Color_Picker
     * Automated search and multi-asset filtering applying algorithms,
     * including facial recognition matching across live maps and camera feeds.
     */
    fun performColorPickerSearch(filter: ColorPickerSearchFilter) {
        scope.launch {
            _isSearching.value = true
            kotlinx.coroutines.delay(650) // Simulation of algorithmic search across 25+ nodes

            val matchedResults = mutableListOf<ColorPickerSearchResult>()
            val selectedProfile = availableFaceProfiles.firstOrNull { it.id == filter.selectedFaceProfileId }

            // 1. Facial Recognition Multi-Feed Sweep if enabled
            if (filter.enableFacialRecognition && selectedProfile != null) {
                // Biometric Vector extraction & matching against live feeds
                matchedResults.add(
                    ColorPickerSearchResult(
                        id = "SEARCH-${selectedProfile.id}-SHIBUYA",
                        label = "${selectedProfile.name} [Face Match: ${String.format(Locale.US, "%.1f", selectedProfile.knownFaceScore * 100)}%]",
                        category = "PERSON",
                        matchedFeedId = "CAM-SHIBUYA",
                        matchedFeedName = "Shibuya Scramble Crossing 4K",
                        coordinates = "35.6595° N, 139.7004° E",
                        latitude = 35.6595,
                        longitude = 139.7004,
                        altitudeMeters = 38.0,
                        confidence = selectedProfile.knownFaceScore,
                        facialMatch = true,
                        facialProfileId = selectedProfile.id,
                        facialMatchScore = selectedProfile.knownFaceScore,
                        threatLevel = if (selectedProfile.id == "SUS-99") "High" else "Low",
                        estimatedVelocity = 4.2f,
                        headingDegrees = 110.0f,
                        suggestedPaintColorHex = if (selectedProfile.id == "SUS-99") "#FF0055" else "#00F0FF",
                        suggestedPaintColorName = if (selectedProfile.id == "SUS-99") "Crimson Strike" else "Cyan Hunter"
                    )
                )

                // Secondary detection in Sector Alpha Downtown
                matchedResults.add(
                    ColorPickerSearchResult(
                        id = "SEARCH-${selectedProfile.id}-DOWNTOWN",
                        label = "${selectedProfile.name} (Associative Vector) [Confidence: 94.6%]",
                        category = "PERSON",
                        matchedFeedId = "CAM-01",
                        matchedFeedName = "Sector Alpha - Downtown Core",
                        coordinates = "34.0522° N, 118.2437° W",
                        latitude = 34.0522,
                        longitude = -118.2437,
                        altitudeMeters = 42.0,
                        confidence = 0.946f,
                        facialMatch = true,
                        facialProfileId = selectedProfile.id,
                        facialMatchScore = 0.946f,
                        threatLevel = "Low",
                        estimatedVelocity = 3.6f,
                        headingDegrees = 45.0f,
                        suggestedPaintColorHex = "#39FF14",
                        suggestedPaintColorName = "Emerald Sentinel"
                    )
                )
            }

            // 2. Automated Object/Vehicle/Drone/Vessel search from user parameter input
            val candidates = listOf(
                ColorPickerSearchResult(
                    id = "SEARCH-VEH-01",
                    label = "Tactical Black SUV (Plate: 9XYZ21)",
                    category = "VEHICLE",
                    matchedFeedId = "STREAM-HIGHWAY",
                    matchedFeedName = "Sector Alpha - Main Highway Stream",
                    coordinates = "34.0537° N, 118.2427° W",
                    latitude = 34.0537,
                    longitude = -118.2427,
                    altitudeMeters = 70.0,
                    confidence = 0.97f,
                    facialMatch = false,
                    threatLevel = "Elevated",
                    estimatedVelocity = 64.0f,
                    headingDegrees = 275.0f,
                    suggestedPaintColorHex = "#39FF14",
                    suggestedPaintColorName = "Emerald Sentinel"
                ),
                ColorPickerSearchResult(
                    id = "SEARCH-DRONE-01",
                    label = "Airborne Perimeter Drone TU-4",
                    category = "DRONE",
                    matchedFeedId = "CAM-04",
                    matchedFeedName = "Tactical Unit 4 - Aerial Drone",
                    coordinates = "40.7128° N, 74.0060° W",
                    latitude = 40.7128,
                    longitude = -74.0060,
                    altitudeMeters = 240.0,
                    confidence = 0.98f,
                    facialMatch = false,
                    threatLevel = "Low",
                    estimatedVelocity = 110.0f,
                    headingDegrees = 18.0f,
                    suggestedPaintColorHex = "#FFB300",
                    suggestedPaintColorName = "Amber Warning"
                ),
                ColorPickerSearchResult(
                    id = "SEARCH-VESSEL-01",
                    label = "Unregistered Speedboat Bravo-9",
                    category = "VESSEL",
                    matchedFeedId = "CAM-02",
                    matchedFeedName = "Sector Beta - Industrial Port (FLIR)",
                    coordinates = "33.7490° N, 118.2655° W",
                    latitude = 33.7490,
                    longitude = -118.2655,
                    altitudeMeters = 0.5,
                    confidence = 0.93f,
                    facialMatch = false,
                    threatLevel = "High",
                    estimatedVelocity = 24.5f,
                    headingDegrees = 192.0f,
                    suggestedPaintColorHex = "#FF0055",
                    suggestedPaintColorName = "Crimson Strike"
                ),
                ColorPickerSearchResult(
                    id = "SEARCH-FAC-01",
                    label = "Underground Server Vault Ingress",
                    category = "FACILITY",
                    matchedFeedId = "CAM-03",
                    matchedFeedName = "Omega Grid - Cyber Perimeter",
                    coordinates = "37.7749° N, 122.4194° W",
                    latitude = 37.7749,
                    longitude = -122.4194,
                    altitudeMeters = -15.0,
                    confidence = 0.99f,
                    facialMatch = false,
                    threatLevel = "Elevated",
                    estimatedVelocity = 0.0f,
                    headingDegrees = 0.0f,
                    suggestedPaintColorHex = "#BD00FF",
                    suggestedPaintColorName = "Ultraviolet Shadow"
                ),
                ColorPickerSearchResult(
                    id = "SEARCH-PERSON-NYC",
                    label = "Unidentified Pedestrian Cluster Subject",
                    category = "PERSON",
                    matchedFeedId = "CAM-TIMES-SQ",
                    matchedFeedName = "Times Square Real-Time Pan",
                    coordinates = "40.7580° N, 73.9855° W",
                    latitude = 40.7580,
                    longitude = -73.9855,
                    altitudeMeters = 15.0,
                    confidence = 0.89f,
                    facialMatch = true,
                    facialProfileId = "SUS-99",
                    facialMatchScore = 0.89f,
                    threatLevel = "Low",
                    estimatedVelocity = 5.1f,
                    headingDegrees = 180.0f,
                    suggestedPaintColorHex = "#00E5FF",
                    suggestedPaintColorName = "Ice Blue Vector"
                )
            )

            // Filter candidates based on user inputs
            val filtered = candidates.filter { candidate ->
                val categoryMatch = filter.category == "ALL" || candidate.category == filter.category
                val threatMatch = filter.threatLevel == "ALL" || candidate.threatLevel.equals(filter.threatLevel, ignoreCase = true)
                val confidenceMatch = candidate.confidence >= filter.minConfidenceThreshold
                val queryMatch = filter.query.isBlank() ||
                        candidate.label.contains(filter.query, ignoreCase = true) ||
                        candidate.matchedFeedName.contains(filter.query, ignoreCase = true)

                categoryMatch && threatMatch && confidenceMatch && queryMatch
            }

            matchedResults.addAll(filtered)
            _searchResults.value = matchedResults
            _isSearching.value = false

            addTelemetryLog("COLOR_PICKER: Algorithmic search completed. Found ${matchedResults.size} matches across connected matrix.")
        }
    }

    /**
     * Feature B: Paint_Brushing
     * Allows user to select or "paint" any detectable object for continuous monitoring.
     */
    fun paintObject(
        targetLabel: String,
        category: String,
        paintColorHex: String,
        paintColorName: String,
        priority: String = "CRITICAL_P1",
        feedId: String,
        feedName: String,
        lat: Double,
        lon: Double,
        altitude: Double = 40.0,
        velocity: Float = 5.0f,
        heading: Float = 0.0f,
        faceScore: Float = 0.0f,
        faceProfileId: String = "",
        detectionSource: String = "Paint_Brushing Tool"
    ): PaintedObject {
        val newId = "PAINT-${String.format(Locale.US, "%03d", _paintedObjects.value.size + 1)}"
        val newObj = PaintedObject(
            id = newId,
            name = targetLabel,
            category = category,
            paintColorHex = paintColorHex,
            paintColorName = paintColorName,
            priority = priority,
            facialMatchScore = faceScore,
            facialProfileId = faceProfileId,
            coordinates = "${String.format(Locale.US, "%.4f", lat)}° N, ${String.format(Locale.US, "%.4f", lon)}° W",
            latitude = lat,
            longitude = lon,
            altitudeMeters = altitude,
            velocityKmh = velocity,
            headingDegrees = heading,
            currentFeedId = feedId,
            currentFeedName = feedName,
            sensorType = "Optical FLIR + Satellite Telemetry",
            lockStatus = "LOCKED_DRYING",
            dryStatusPercent = 25, // Initial wet paint, drying engine hardens it
            isMonitoring = true,
            detectionSource = detectionSource,
            notes = "Target painted for continuous monitoring. Satellite telemetry link initiated.",
            breadcrumbs = listOf(
                TelemetryPoint(lat, lon, altitude, velocity, heading, System.currentTimeMillis(), feedId)
            )
        )

        // Add to state flow
        _paintedObjects.value = listOf(newObj) + _paintedObjects.value

        // Persist to Room
        scope.launch {
            try {
                roomDao?.insertOrUpdate(newObj.toEntity())
            } catch (_: Exception) {}
        }

        // Update canvas detectable objects to reflect painted status
        _canvasDetectableObjects.value = _canvasDetectableObjects.value.map {
            if (it.label.contains(targetLabel, ignoreCase = true) || targetLabel.contains(it.label, ignoreCase = true)) {
                it.copy(isAlreadyPainted = true)
            } else it
        }

        addTelemetryLog("PAINT_BRUSHING: Painted '$targetLabel' [$newId] with $paintColorName. Locking sensors.")
        return newObj
    }

    /**
     * Feature C: Paint_Dryer real-time telemetry engine
     * Combines facial recognition with camera and satellite telemetry using all available assets
     * to locate, monitor and track painted objects' movement in real-time.
     */
    private fun startRealtimeTelemetrySimulation() {
        scope.launch {
            var step = 0
            while (isActive) {
                kotlinx.coroutines.delay(2000) // Update telemetry every 2 seconds
                step++

                val updatedList = _paintedObjects.value.map { obj ->
                    if (!obj.isMonitoring) return@map obj

                    // Simulate slight trajectory movement based on speed and heading
                    val headingRad = Math.toRadians(obj.headingDegrees.toDouble())
                    val deltaDistance = (obj.velocityKmh / 3600.0) * 2.0 // km in 2 sec
                    val deltaLat = (deltaDistance / 111.0) * cos(headingRad)
                    val deltaLon = (deltaDistance / (111.0 * cos(Math.toRadians(obj.latitude)))) * sin(headingRad)

                    val newLat = obj.latitude + deltaLat
                    val newLon = obj.longitude + deltaLon

                    // Slight speed & altitude variations
                    val newSpeed = (obj.velocityKmh + ((-1..1).random() * 0.4f)).coerceAtLeast(0.0f)
                    val newAlt = (obj.altitudeMeters + ((-1..1).random() * 0.5)).coerceAtLeast(0.0)
                    val newHeading = (obj.headingDegrees + ((-2..2).random())).coerceIn(0f, 360f)

                    // Paint_Dryer: Hardening process from wet paint to fully dried and locked
                    val newDryPercent = minOf(100, obj.dryStatusPercent + 5)
                    val newLockStatus = when {
                        newDryPercent < 60 -> "LOCKED_DRYING"
                        newDryPercent < 95 -> "STABLE_TRACK"
                        step % 12 == 0 -> "SATELLITE_HANDOFF"
                        else -> "STABLE_TRACK"
                    }

                    // Satellite / Camera handoff simulation
                    var activeFeedId = obj.currentFeedId
                    var activeFeedName = obj.currentFeedName
                    if (newLockStatus == "SATELLITE_HANDOFF") {
                        activeFeedId = "CAM-06"
                        activeFeedName = "Global Recon - Orbital Relay (LEO KH-11)"
                        addTelemetryLog("PAINT_DRYER: Satellite handoff executed for ${obj.id}. Switched to LEO Orbital Relay.")
                    }

                    val newPoint = TelemetryPoint(
                        lat = newLat,
                        lon = newLon,
                        alt = newAlt,
                        speedKmh = newSpeed,
                        heading = newHeading,
                        timestamp = System.currentTimeMillis(),
                        sourceFeed = activeFeedId
                    )
                    val updatedBreadcrumbs = (obj.breadcrumbs + newPoint).takeLast(20)

                    obj.copy(
                        latitude = newLat,
                        longitude = newLon,
                        coordinates = "${String.format(Locale.US, "%.4f", newLat)}° N, ${String.format(Locale.US, "%.4f", newLon)}° W",
                        velocityKmh = newSpeed,
                        altitudeMeters = newAlt,
                        headingDegrees = newHeading,
                        dryStatusPercent = newDryPercent,
                        lockStatus = newLockStatus,
                        currentFeedId = activeFeedId,
                        currentFeedName = activeFeedName,
                        breadcrumbs = updatedBreadcrumbs
                    )
                }

                _paintedObjects.value = updatedList
            }
        }
    }

    /**
     * Feature D: Art_Gallery management operations
     */
    fun toggleMonitoring(id: String) {
        _paintedObjects.value = _paintedObjects.value.map {
            if (it.id == id) {
                val updated = it.copy(isMonitoring = !it.isMonitoring)
                scope.launch {
                    try { roomDao?.insertOrUpdate(updated.toEntity()) } catch (_: Exception) {}
                }
                addTelemetryLog("ART_GALLERY: ${it.id} monitoring toggled to ${updated.isMonitoring}.")
                updated
            } else it
        }
    }

    fun updatePaintColor(id: String, newHex: String, newName: String) {
        _paintedObjects.value = _paintedObjects.value.map {
            if (it.id == id) {
                val updated = it.copy(paintColorHex = newHex, paintColorName = newName)
                scope.launch {
                    try { roomDao?.insertOrUpdate(updated.toEntity()) } catch (_: Exception) {}
                }
                addTelemetryLog("ART_GALLERY: ${it.id} paint color updated to $newName ($newHex).")
                updated
            } else it
        }
    }

    fun removePaintedObject(id: String) {
        _paintedObjects.value = _paintedObjects.value.filter { it.id != id }
        scope.launch {
            try { roomDao?.deleteById(id) } catch (_: Exception) {}
        }
        addTelemetryLog("ART_GALLERY: Removed target $id from active painted registry.")
    }

    fun clearAllPaintedObjects() {
        _paintedObjects.value = emptyList()
        scope.launch {
            try { roomDao?.clearAll() } catch (_: Exception) {}
        }
        addTelemetryLog("ART_GALLERY: All painted objects cleared.")
    }

    private fun addTelemetryLog(message: String) {
        val timestamp = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
        _telemetryHandoffLog.value = (listOf("[$timestamp] $message") + _telemetryHandoffLog.value).take(40)
    }
}
