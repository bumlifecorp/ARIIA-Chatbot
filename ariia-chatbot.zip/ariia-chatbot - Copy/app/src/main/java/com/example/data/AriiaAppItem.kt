package com.example.data

data class AriiaAppItem(
    val id: String,
    val label: String,
    val packageName: String? = null,
    val command: String,
    val category: String, // "Tactical", "Comms", "System", "Sensors"
    val iconType: String, // "phone", "whatsapp", "camera", "contacts", "settings", "alarm", "radar", "ai", "terminal"
    val isFavorite: Boolean = false,
    val orderIndex: Int = 0
)

enum class HudOverlayMode {
    SCANNING,
    LOCK_ON,
    CALIBRATION,
    MINIMAL
}
