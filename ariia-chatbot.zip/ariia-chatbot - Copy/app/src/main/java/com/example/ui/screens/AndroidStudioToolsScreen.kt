package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AriiaSpeechEngine
import com.example.utils.HapticManager
import kotlinx.coroutines.delay

enum class StudioToolTab(val title: String, val icon: @Composable () -> Unit) {
    STUDIO_IDE("Android Studio IDE", { Icon(Icons.Default.Code, contentDescription = null) }),
    SDK_MANAGER("SDK Manager", { Icon(Icons.Default.Build, contentDescription = null) }),
    APK_SIGNER("APK Signer", { Icon(Icons.Default.VerifiedUser, contentDescription = null) })
}

@Composable
fun AndroidStudioToolsScreen(
    onNavigateTab: (Int) -> Unit = {}
) {
    val context = LocalContext.current
    val speechEngine = remember { AriiaSpeechEngine(context) }

    DisposableEffect(Unit) {
        onDispose { speechEngine.shutdown() }
    }

    var activeTab by remember { mutableStateOf(StudioToolTab.STUDIO_IDE) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030712))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(Color(0xFF1E293B), CircleShape)
                        .border(1.dp, Color(0xFF38BDF8), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.IntegrationInstructions,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "ANDROID STUDIO & APK BUILD SUITE",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8),
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "IDE Tools, SDK Manager v35 & apksigner Cryptographic Suite",
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
                Surface(
                    color = Color(0xFF39FF14).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "AGP 8.8 READY",
                        fontSize = 8.sp,
                        color = Color(0xFF39FF14),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Tab Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StudioToolTab.values().forEach { tab ->
                val isSelected = activeTab == tab
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            activeTab = tab
                            HapticManager.triggerVoiceCommandInitiation(context)
                            speechEngine.speak("Switched to ${tab.title}")
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF0284C7).copy(alpha = 0.25f) else Color(0xFF0F172A)
                    ),
                    border = BorderStroke(1.dp, if (isSelected) Color(0xFF38BDF8) else Color(0xFF1E293B)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        tab.icon()
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tab.title,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        // Content Area
        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            when (activeTab) {
                StudioToolTab.STUDIO_IDE -> AndroidStudioIdeContent(speechEngine, context)
                StudioToolTab.SDK_MANAGER -> SdkManagerContent(speechEngine, context)
                StudioToolTab.APK_SIGNER -> ApkSignerContent(speechEngine, context)
            }
        }
    }
}

@Composable
fun AndroidStudioIdeContent(speechEngine: AriiaSpeechEngine, context: Context) {
    var isBuildingProject by remember { mutableStateOf(false) }
    var buildLog by remember {
        mutableStateOf(
            "[INFO] Android Studio Ladybug 2024.2.1 Patch 2 initialized.\n" +
                    "[INFO] Gradle Daemon running (JVM 21.0.2).\n" +
                    "[INFO] AGP: 8.8.0-rc01 | Kotlin: 2.0.21 | KSP: 2.0.21-1.0.25\n" +
                    "[READY] Layout Inspector & Logcat monitor standing by."
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0B132B)),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "[STUDIO_IDE_PROJECT_INSPECTOR]",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8),
                        fontFamily = FontFamily.Monospace
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Root Project Name", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("Kaleidophone ARIIA AI Assistant", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Compile / Target SDK", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("API 35 (Android 15)", fontSize = 10.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Min SDK Version", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("API 26 (Android 8.0 Oreo)", fontSize = 10.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("UI Framework", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("Jetpack Compose Material 3", fontSize = 10.sp, color = Color(0xFF38BDF8))
                    }
                }
            }
        }

        item {
            Button(
                onClick = {
                    isBuildingProject = true
                    HapticManager.triggerVoiceCommandSuccess(context)
                    speechEngine.speak("Building project with Gradle daemon and AGP 8.8. Assembling debug APK.")
                    buildLog += "\n[GRADLE] :app:assembleDebug STARTED...\n[GRADLE] :app:kspDebugKotlin PASSED\n[GRADLE] :app:compileDebugJavaWithJavac PASSED\n[BUILD SUCCESS] APK assembled at build/outputs/apk/debug/app-debug.apk"
                    isBuildingProject = false
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("RUN GRADLE BUILD (:app:assembleDebug)", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF020617)),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("Studio Build & Logcat Console", fontSize = 10.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        item {
                            Text(buildLog, fontSize = 10.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SdkManagerContent(speechEngine: AriiaSpeechEngine, context: Context) {
    var isUpdatingSdk by remember { mutableStateOf(false) }
    var sdkProgress by remember { mutableFloatStateOf(1.0f) }

    val installedPackages = listOf(
        "platforms;android-35" to "Android SDK Platform 35 (Android 15)",
        "platforms;android-34" to "Android SDK Platform 34 (Android 14)",
        "build-tools;35.0.0" to "Android SDK Build-Tools 35.0.0",
        "platform-tools" to "Android SDK Platform-Tools (adb v1.0.41)",
        "ndk;26.1.10909125" to "NDK (Side-by-side) 26.1.10909125",
        "cmake;3.22.1" to "CMake 3.22.1 Architecture Kit"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0B132B)),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "[SDKMANAGER_COMMAND_LINE_TOOL]",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8),
                        fontFamily = FontFamily.Monospace
                    )
                    Text("SDK Location: /android-sdk/cmdline-tools/latest", fontSize = 10.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)

                    installedPackages.forEach { (pkg, desc) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(desc, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                Text(pkg, fontSize = 9.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                            }
                            Surface(color = Color(0xFF39FF14).copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp)) {
                                Text("INSTALLED", fontSize = 8.sp, color = Color(0xFF39FF14), modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp), fontWeight = FontWeight.Bold)
                            }
                        }
                        Divider(color = Color(0xFF1E293B).copy(alpha = 0.5f))
                    }
                }
            }
        }

        item {
            Button(
                onClick = {
                    HapticManager.triggerVoiceCommandSuccess(context)
                    speechEngine.speak("sdkmanager command line checking repository licenses and package updates.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Sync, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("RUN sdkmanager --update", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun ApkSignerContent(speechEngine: AriiaSpeechEngine, context: Context) {
    var isSigning by remember { mutableStateOf(false) }
    var signatureDetails by remember {
        mutableStateOf(
            "Verifying APK signature using apksigner...\n" +
                    "• Signer #1 certificate DN: CN=Android Debug, O=Android, C=US\n" +
                    "• SHA-256 digest: A4:F8:89:C2:1E:73:09:BF:88:1A:29:F8:8C:30:41:EA\n" +
                    "• Signature Scheme v1 (JAR signing): VERIFIED\n" +
                    "• Signature Scheme v2 (APK Signature Scheme v2): VERIFIED\n" +
                    "• Signature Scheme v3 (APK Signature Scheme v3): VERIFIED\n" +
                    "• Signature Scheme v4 (IncFS v4 Signature): READY\n" +
                    "• Zipalign 4-byte boundary check: PASSED"
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0B132B)),
                border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "[APKSIGNER_CRYPTOGRAPHIC_SUITE]",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8),
                        fontFamily = FontFamily.Monospace
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Keystore Alias", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("androiddebugkey", fontSize = 10.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Key Algorithm", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("RSA 2048-bit", fontSize = 10.sp, color = Color(0xFF39FF14), fontFamily = FontFamily.Monospace)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Signer Scheme Versions", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        Text("v1, v2, v3, v4 Active", fontSize = 10.sp, color = Color(0xFF38BDF8), fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        item {
            Button(
                onClick = {
                    HapticManager.triggerVoiceCommandSuccess(context)
                    speechEngine.speak("Executing apksigner verify and zipalign alignment check on assembled release APK.")
                    signatureDetails = "Executing apksigner verify --verbose --min-sdk-version 26...\n" +
                            "• VERIFIED APK Signature Scheme v2 & v3!\n" +
                            "• SHA-256: A4:F8:89:C2:1E:73:09:BF:88:1A:29:F8:8C:30:41:EA\n" +
                            "• Output APK: Kaleidophone-ARIIA-v4.5-signed.apk\n" +
                            "• Ready for immediate installation and deployment."
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF39FF14)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("VERIFY & SIGN APK WITH apksigner", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF020617)),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("apksigner Verification Logs", fontSize = 10.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        item {
                            Text(signatureDetails, fontSize = 10.sp, color = Color(0xFF38BDF8), fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}
