package com.example.data

data class TelemetryPoint(
    val lat: Double,
    val lon: Double,
    val alt: Double,
    val speedKmh: Float,
    val heading: Float,
    val timestamp: Long,
    val sourceFeed: String
)

data class PresetFaceProfile(
    val id: String,
    val name: String,
    val title: String,
    val clearance: String,
    val department: String,
    val knownFaceScore: Float,
    val description: String,
    val category: String = "PERSON"
)

data class DetectableCanvasTarget(
    val id: String,
    val label: String,
    val category: String, // "PERSON", "VEHICLE", "DRONE", "VESSEL", "FACILITY"
    val xPercent: Float, // 0f..1f on canvas
    val yPercent: Float, // 0f..1f on canvas
    val widthPercent: Float,
    val heightPercent: Float,
    val confidence: Float,
    val faceScore: Float? = null,
    val threatLevel: String = "Low",
    val isAlreadyPainted: Boolean = false
)

data class ColorPickerSearchFilter(
    val query: String = "",
    val category: String = "ALL", // "ALL", "PERSON", "VEHICLE", "DRONE", "VESSEL", "FACILITY"
    val threatLevel: String = "ALL", // "ALL", "LOW", "ELEVATED", "HIGH"
    val locationSector: String = "ALL", // "ALL", "Downtown Core", "Industrial Port", "Tokyo Shibuya", "NYC Times Square", "Orbital Grid"
    val enableFacialRecognition: Boolean = true,
    val selectedFaceProfileId: String? = "DS-001",
    val minConfidenceThreshold: Float = 0.85f,
    val sweepTacticalCams: Boolean = true,
    val sweepWorldCams: Boolean = true,
    val sweepStreamsPubSub: Boolean = true,
    val sweepSatelliteRadar: Boolean = true
)

data class ColorPickerSearchResult(
    val id: String,
    val label: String,
    val category: String,
    val matchedFeedId: String,
    val matchedFeedName: String,
    val coordinates: String,
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Double,
    val confidence: Float,
    val facialMatch: Boolean,
    val facialProfileId: String = "",
    val facialMatchScore: Float = 0.95f,
    val threatLevel: String,
    val estimatedVelocity: Float,
    val headingDegrees: Float,
    val suggestedPaintColorHex: String,
    val suggestedPaintColorName: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class PaintedObject(
    val id: String,
    val name: String,
    val category: String, // "PERSON", "VEHICLE", "DRONE", "VESSEL", "FACILITY"
    val paintColorHex: String = "#00F0FF",
    val paintColorName: String = "Cyan Hunter",
    val priority: String = "CRITICAL_P1", // "CRITICAL_P1", "HIGH_P2", "CONTINUOUS_P3"
    val facialMatchScore: Float = 0.98f,
    val facialProfileId: String = "",
    val coordinates: String = "34.0522° N, 118.2437° W",
    val latitude: Double = 34.0522,
    val longitude: Double = -118.2437,
    val altitudeMeters: Double = 45.0,
    val velocityKmh: Float = 14.5f,
    val headingDegrees: Float = 42.0f,
    val currentFeedId: String = "CAM-01",
    val currentFeedName: String = "Sector Alpha - Downtown Core",
    val sensorType: String = "Optical FLIR + Satellite Telemetry",
    val lockStatus: String = "LOCKED_DRYING", // "LOCKED_DRYING", "STABLE_TRACK", "SATELLITE_HANDOFF", "INTERCEPT_VECTOR"
    val dryStatusPercent: Int = 85, // 0..100%
    val isMonitoring: Boolean = true,
    val detectionSource: String = "Color_Picker Search",
    val notes: String = "Continuous telemetry feed active via orbital relay.",
    val timestamp: Long = System.currentTimeMillis(),
    val breadcrumbs: List<TelemetryPoint> = emptyList()
) {
    fun toEntity(): PaintedObjectEntity {
        return PaintedObjectEntity(
            id = id,
            name = name,
            category = category,
            paintColorHex = paintColorHex,
            paintColorName = paintColorName,
            priority = priority,
            facialMatchScore = facialMatchScore,
            facialProfileId = facialProfileId,
            coordinates = coordinates,
            latitude = latitude,
            longitude = longitude,
            altitudeMeters = altitudeMeters,
            velocityKmh = velocityKmh,
            headingDegrees = headingDegrees,
            currentFeedId = currentFeedId,
            currentFeedName = currentFeedName,
            lockStatus = lockStatus,
            dryStatusPercent = dryStatusPercent,
            isMonitoring = isMonitoring,
            detectionSource = detectionSource,
            notes = notes,
            timestamp = timestamp
        )
    }

    companion object {
        fun fromEntity(entity: PaintedObjectEntity, crumbs: List<TelemetryPoint> = emptyList()): PaintedObject {
            return PaintedObject(
                id = entity.id,
                name = entity.name,
                category = entity.category,
                paintColorHex = entity.paintColorHex,
                paintColorName = entity.paintColorName,
                priority = entity.priority,
                facialMatchScore = entity.facialMatchScore,
                facialProfileId = entity.facialProfileId,
                coordinates = entity.coordinates,
                latitude = entity.latitude,
                longitude = entity.longitude,
                altitudeMeters = entity.altitudeMeters,
                velocityKmh = entity.velocityKmh,
                headingDegrees = entity.headingDegrees,
                currentFeedId = entity.currentFeedId,
                currentFeedName = entity.currentFeedName,
                sensorType = "Optical FLIR + Satellite Telemetry",
                lockStatus = entity.lockStatus,
                dryStatusPercent = entity.dryStatusPercent,
                isMonitoring = entity.isMonitoring,
                detectionSource = entity.detectionSource,
                notes = entity.notes,
                timestamp = entity.timestamp,
                breadcrumbs = crumbs
            )
        }
    }
}
