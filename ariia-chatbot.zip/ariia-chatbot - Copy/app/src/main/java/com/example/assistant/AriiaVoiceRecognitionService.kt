package com.example.assistant

import android.content.Intent
import android.speech.RecognitionService

class AriiaVoiceRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        // Basic placeholder
    }

    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
