import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useMemo, useState } from "react";
import {
  FlatList,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import * as Notifications from "expo-notifications";
import * as ExpoLinking from "expo-linking";
import * as FileSystem from "expo-file-system/legacy";
import { RecordingPresets, requestRecordingPermissionsAsync, setAudioModeAsync, useAudioRecorder, useAudioRecorderState } from "expo-audio";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { ScreenContainer } from "@/components/screen-container";
import { haptic } from "@/lib/haptics";
import { trpc } from "@/lib/trpc";

const COLORS = {
  ink: "#0B0F14",
  slate: "#151C24",
  border: "#263241",
  cloud: "#F4F7FB",
  muted: "#B6C1CE",
  mint: "#7CE7C4",
  violet: "#A992FF",
  amber: "#F6C56F",
  coral: "#FF8B8B",
};

type AppItem = {
  id: string;
  name: string;
  category: string;
  icon: keyof typeof MaterialIcons.glyphMap;
  color: string;
  lastUsed: string;
};

type AssistantCard = { title: string; body: string; action: string; appId?: string; focus?: boolean };
type AssistantResponse = { kind: "focus" | "app" | "web" | "reminder" | "clarify"; appId: string | null; title: string; body: string; actionLabel: string; query: string | null };

const APPS: AppItem[] = [
  { id: "notes", name: "Notes", category: "Create", icon: "edit-note", color: COLORS.mint, lastUsed: "Used today" },
  { id: "calendar", name: "Calendar", category: "Plan", icon: "calendar-today", color: COLORS.violet, lastUsed: "Used yesterday" },
  { id: "camera", name: "Camera", category: "Capture", icon: "photo-camera", color: COLORS.amber, lastUsed: "Used 2 days ago" },
  { id: "messages", name: "Messages", category: "Connect", icon: "chat-bubble-outline", color: "#8FC7FF", lastUsed: "Used today" },
  { id: "music", name: "Music", category: "Listen", icon: "headphones", color: "#F49DEB", lastUsed: "Used 3 days ago" },
  { id: "maps", name: "Maps", category: "Move", icon: "near-me", color: "#8DE4A8", lastUsed: "Used 4 days ago" },
  { id: "browser", name: "Browser", category: "Explore", icon: "language", color: "#FFB38A", lastUsed: "Used today" },
  { id: "tasks", name: "Tasks", category: "Organize", icon: "check-circle-outline", color: "#D9B7FF", lastUsed: "Used yesterday" },
  { id: "reminders", name: "Reminders", category: "Remember", icon: "notifications-none", color: COLORS.amber, lastUsed: "Used today" },
];

const STORAGE_KEY = "ai-orbit-settings";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

async function scheduleLocalReminder(reminder: string) {
  if (Platform.OS === "web") return false;
  const permission = await Notifications.requestPermissionsAsync();
  if (!permission.granted) return false;
  await Notifications.setNotificationChannelAsync("orbit-reminders", {
    name: "Orbit reminders",
    importance: Notifications.AndroidImportance.DEFAULT,
    vibrationPattern: [0, 200, 150, 200],
  });
  await Notifications.scheduleNotificationAsync({
    content: { title: "Orbit reminder", body: reminder, data: { source: "orbit" } },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: 10 },
  });
  return true;
}

type Settings = { pinned: string[]; hidden: string[]; accent: "mint" | "violet" | "amber"; greeting: string; showAssistant: boolean; onboardingComplete: boolean; reminders: string[] };
const DEFAULT_SETTINGS: Settings = { pinned: ["notes", "calendar", "messages", "camera"], hidden: [], accent: "mint", greeting: "", showAssistant: true, onboardingComplete: false, reminders: [] };

function nowGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function formatTime() {
  return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(new Date());
}

function Icon({ name, color = COLORS.cloud, size = 20 }: { name: keyof typeof MaterialIcons.glyphMap; color?: string; size?: number }) {
  return <MaterialIcons name={name} color={color} size={size} />;
}

export default function HomeScreen() {
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [view, setView] = useState<"home" | "drawer" | "focus" | "customize">("home");
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [assistantQuery, setAssistantQuery] = useState("");
  const [selectedApp, setSelectedApp] = useState<AppItem | null>(null);
  const [focusSeconds, setFocusSeconds] = useState(25 * 60);
  const [focusRunning, setFocusRunning] = useState(false);
  const [assistantLoading, setAssistantLoading] = useState(false);
  const [assistantResponse, setAssistantResponse] = useState<AssistantResponse | null>(null);
  const [assistantError, setAssistantError] = useState("");
  const audioRecorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(audioRecorder);
  const voiceMutation = trpc.voice.transcribe.useMutation();

  useEffect(() => {
    if (Platform.OS === "android") {
      Notifications.setNotificationChannelAsync("orbit-reminders", { name: "Orbit reminders", importance: Notifications.AndroidImportance.DEFAULT, vibrationPattern: [0, 200, 150, 200] });
    }
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (raw) setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(raw) });
    });
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    if (!focusRunning || focusSeconds <= 0) return;
    const timer = setInterval(() => setFocusSeconds((value) => Math.max(0, value - 1)), 1000);
    return () => clearInterval(timer);
  }, [focusRunning, focusSeconds]);

  const accent = settings.accent === "violet" ? COLORS.violet : settings.accent === "amber" ? COLORS.amber : COLORS.mint;
  const visibleApps = useMemo(() => APPS.filter((app) => !settings.hidden.includes(app.id)), [settings.hidden]);
  const pinnedApps = settings.pinned.map((id) => APPS.find((app) => app.id === id)).filter((app): app is AppItem => app !== undefined && !settings.hidden.includes(app.id));
  const filteredApps = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return visibleApps;
    return visibleApps.filter((app) => `${app.name} ${app.category}`.toLowerCase().includes(normalized));
  }, [query, visibleApps]);
  const assistMutation = trpc.orbit.assist.useMutation();

  const assistantCards = useMemo<AssistantCard[]>(() => {
    const q = assistantQuery.toLowerCase();
    if (q.includes("focus") || q.includes("concentrate")) return [{ title: "A quieter orbit", body: "Start a 25-minute focus session with only your intention in view.", action: "Start focus", focus: true }];
    if (q.includes("write") || q.includes("note")) return [{ title: "Ready when you are", body: "Notes is the fastest path from a thought to something you can keep.", action: "Open Notes", appId: "notes" }];
    if (q.includes("plan") || q.includes("schedule")) return [{ title: "Make space for it", body: "Calendar can help you turn the next step into a real moment.", action: "Open Calendar", appId: "calendar" }];
    return [
      { title: "Try an intention", body: "Ask for focus, writing, planning, or a quick route to an app.", action: "Start focus", focus: true },
      { title: "Open something", body: "Say “I need to write” or “show me my messages”.", action: "Browse apps" },
    ];
  }, [assistantQuery]);

  const openApp = (app: AppItem) => {
    haptic.light();
    setSelectedApp(app);
  };

  const handleVoicePress = async () => {
    if (Platform.OS === "web") {
      setAssistantError("Voice capture is available in the Android APK build.");
      return;
    }
    try {
      setAssistantError("");
      if (recorderState.isRecording) {
        await audioRecorder.stop();
        const uri = audioRecorder.uri;
        if (!uri) throw new Error("No recording was created");
        const audioBase64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
        const result = await voiceMutation.mutateAsync({ audioBase64, mimeType: "audio/mp4", language: "en" });
        setAssistantQuery(result.text);
        setAssistantResponse(null);
        haptic.success();
      } else {
        const permission = await requestRecordingPermissionsAsync();
        if (!permission.granted) {
          setAssistantError("Microphone permission is needed for voice commands.");
          return;
        }
        await setAudioModeAsync({ playsInSilentMode: true, allowsRecording: true });
        await audioRecorder.prepareToRecordAsync();
        audioRecorder.record();
      }
    } catch {
      setAssistantError("Voice capture could not be completed. Try typing the command instead.");
    }
  };

  const handleOrbitSubmit = async () => {
    const request = assistantQuery.trim();
    if (!request || assistantLoading) return;
    haptic.light();
    setAssistantLoading(true);
    setAssistantError("");
    setAssistantResponse(null);
    try {
      const response = await assistMutation.mutateAsync({ query: request, availableApps: visibleApps.map(({ id, name, category }) => ({ id, name, category })) });
      setAssistantResponse(response);
    } catch {
      setAssistantError("Orbit is offline right now. Try a quick action below.");
    } finally {
      setAssistantLoading(false);
    }
  };

  const runAssistantResponse = () => {
    if (!assistantResponse) return;
    haptic.light();
    const response = assistantResponse;
    setAssistantOpen(false);
    if (response.kind === "focus") {
      setFocusSeconds(25 * 60);
      setFocusRunning(true);
      setView("focus");
    } else if (response.kind === "app" && response.appId) {
      const app = APPS.find((item) => item.id === response.appId);
      if (app && !settings.hidden.includes(app.id)) setSelectedApp(app);
      else setView("drawer");
    } else if (response.kind === "web" && response.query) {
      Linking.openURL(`https://www.google.com/search?q=${encodeURIComponent(response.query)}`);
    } else if (response.kind === "reminder" && response.query) {
      setSettings((current) => ({ ...current, reminders: [...current.reminders, response.query as string].slice(-10) }));
      void scheduleLocalReminder(response.query).then((scheduled) => {
        if (!scheduled && Platform.OS !== "web") setAssistantError("Reminder saved locally, but notification permission was not granted.");
      });
    }
  };

  const runAssistantCard = (card: AssistantCard) => {
    haptic.light();
    setAssistantOpen(false);
    if (card.focus) {
      setFocusSeconds(25 * 60);
      setFocusRunning(true);
      setView("focus");
    } else if (card.appId) {
      const app = APPS.find((item) => item.id === card.appId);
      if (app) setSelectedApp(app);
    } else {
      setView("drawer");
    }
  };

  const togglePinned = (id: string) => {
    haptic.selection();
    setSettings((current) => ({ ...current, pinned: current.pinned.includes(id) ? current.pinned.filter((item) => item !== id) : [...current.pinned, id] }));
  };

  const minute = Math.floor(focusSeconds / 60).toString().padStart(2, "0");
  const second = (focusSeconds % 60).toString().padStart(2, "0");

  if (!settings.onboardingComplete) {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background">
        <StatusBar style="light" />
        <View style={styles.onboardingScreen}>
          <View style={[styles.onboardingOrb, { borderColor: accent }]}><View style={[styles.onboardingOrbCore, { backgroundColor: accent }]} /><View style={[styles.onboardingOrbSpark, { backgroundColor: COLORS.violet }]} /></View>
          <Text style={styles.onboardingEyebrow}>WELCOME TO ORBIT</Text>
          <Text style={styles.onboardingTitle}>Your phone, with less friction.</Text>
          <Text style={styles.onboardingBody}>A calmer home screen with app search, focus mode, and an assistant that turns intent into a next step.</Text>
          <View style={styles.onboardingList}><View style={styles.onboardingRow}><Icon name="search" color={accent} /><View><Text style={styles.onboardingRowTitle}>Find apps fast</Text><Text style={styles.onboardingRowBody}>Search by name or what you want to do.</Text></View></View><View style={styles.onboardingRow}><Icon name="auto-awesome" color={COLORS.violet} /><View><Text style={styles.onboardingRowTitle}>Ask Orbit</Text><Text style={styles.onboardingRowBody}>Use natural language for focus, reminders, and web search.</Text></View></View><View style={styles.onboardingRow}><Icon name="bolt" color={COLORS.amber} /><View><Text style={styles.onboardingRowTitle}>Protect attention</Text><Text style={styles.onboardingRowBody}>Start a quiet 25-minute session whenever you need it.</Text></View></View></View>
          <Pressable accessibilityLabel="Enter AI Orbit Launcher" onPress={() => { haptic.light(); setSettings((current) => ({ ...current, onboardingComplete: true })); }} style={[styles.primaryButton, { backgroundColor: accent, width: "100%" }]}><Text style={styles.primaryButtonText}>Enter your orbit</Text><Icon name="arrow-forward" color={COLORS.ink} size={18} /></Pressable>
          <Text style={styles.onboardingFootnote}>Production Android builds can request the default Home role after onboarding.</Text>
        </View>
      </ScreenContainer>
    );
  }

  if (view === "focus") {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background">
        <StatusBar style="light" />
        <View style={styles.focusScreen}>
          <Pressable accessibilityLabel="Exit focus mode" onPress={() => { haptic.light(); setFocusRunning(false); setView("home"); }} style={styles.backButton}>
            <Icon name="close" color={COLORS.muted} />
          </Pressable>
          <View style={styles.focusCenter}>
            <View style={[styles.orbit, { borderColor: accent }]}><View style={[styles.orbitDot, { backgroundColor: accent }]} /></View>
            <Text style={styles.focusEyebrow}>FOCUS MODE</Text>
            <Text style={styles.focusTitle}>One thing at a time.</Text>
            <Text style={styles.focusTimer}>{minute}:{second}</Text>
            <Text style={styles.focusHint}>Your home screen will stay quiet until you are ready.</Text>
          </View>
          <Pressable accessibilityLabel={focusRunning ? "Pause focus timer" : "Resume focus timer"} onPress={() => { haptic.light(); setFocusRunning((value) => !value); }} style={[styles.primaryButton, { backgroundColor: accent }]}>
            <Icon name={focusRunning ? "pause" : "play-arrow"} color={COLORS.ink} size={18} />
            <Text style={styles.primaryButtonText}>{focusRunning ? "Pause session" : "Resume session"}</Text>
          </Pressable>
        </View>
      </ScreenContainer>
    );
  }

  if (view === "customize") {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background">
        <StatusBar style="light" />
        <ScrollView contentContainerStyle={styles.customizeScreen}>
          <Pressable accessibilityLabel="Back to launcher" onPress={() => setView("home")} style={styles.backButton}><Icon name="arrow-back" color={COLORS.muted} /></Pressable>
          <Text style={styles.sectionEyebrow}>PERSONALIZE</Text>
          <Text style={styles.pageTitle}>Make it yours.</Text>
          <Text style={styles.pageSubtitle}>Small choices. A calmer orbit.</Text>
          <Text style={styles.settingLabel}>Accent</Text>
          <View style={styles.choiceRow}>
            {(["mint", "violet", "amber"] as const).map((choice) => <Pressable key={choice} onPress={() => { haptic.selection(); setSettings((current) => ({ ...current, accent: choice })); }} style={[styles.choice, settings.accent === choice && { borderColor: choice === "mint" ? COLORS.mint : choice === "violet" ? COLORS.violet : COLORS.amber }]}><View style={[styles.choiceDot, { backgroundColor: choice === "mint" ? COLORS.mint : choice === "violet" ? COLORS.violet : COLORS.amber }]} /><Text style={styles.choiceText}>{choice}</Text></Pressable>)}
          </View>
          <Text style={styles.settingLabel}>Pinned apps</Text>
          <View style={styles.appChoiceGrid}>{APPS.map((app) => <Pressable key={app.id} onPress={() => togglePinned(app.id)} style={[styles.appChoice, settings.pinned.includes(app.id) && { backgroundColor: "#20352F", borderColor: accent }]}><Icon name={app.icon} color={app.color} /><Text style={styles.appChoiceText}>{app.name}</Text>{settings.pinned.includes(app.id) && <Icon name="check" color={accent} size={16} />}</Pressable>)}</View>
          <Text style={styles.settingLabel}>Hidden apps</Text>
          <Text style={styles.settingHint}>Keep distractions out of your drawer. You can bring them back anytime.</Text>
          <View style={styles.appChoiceGrid}>{APPS.map((app) => <Pressable key={`hidden-${app.id}`} onPress={() => { haptic.selection(); setSettings((current) => ({ ...current, hidden: current.hidden.includes(app.id) ? current.hidden.filter((item) => item !== app.id) : [...current.hidden, app.id], pinned: current.hidden.includes(app.id) ? current.pinned : current.pinned.filter((item) => item !== app.id) })); }} style={[styles.appChoice, settings.hidden.includes(app.id) && { backgroundColor: "#2C2025", borderColor: COLORS.coral }]}><Icon name={app.icon} color={settings.hidden.includes(app.id) ? COLORS.coral : app.color} /><Text style={styles.appChoiceText}>{app.name}</Text>{settings.hidden.includes(app.id) && <Icon name="visibility-off" color={COLORS.coral} size={16} />}</Pressable>)}</View>
          <Text style={styles.settingLabel}>Home assistant</Text>
          <Pressable onPress={() => { haptic.selection(); setSettings((current) => ({ ...current, showAssistant: !current.showAssistant })); }} style={styles.toggleRow}><View><Text style={styles.toggleTitle}>Show Orbit suggestion</Text><Text style={styles.toggleSubtitle}>A small nudge when your day begins.</Text></View><View style={[styles.toggle, settings.showAssistant && { backgroundColor: accent }]}><View style={[styles.toggleKnob, settings.showAssistant && { alignSelf: "flex-end" }]} /></View></Pressable>
          {settings.reminders.length > 0 && <><Text style={styles.settingLabel}>Local reminders</Text><View style={styles.reminderCard}><Icon name="notifications-none" color={COLORS.amber} /><View style={styles.reminderCopy}><Text style={styles.toggleTitle}>{settings.reminders.length} saved reminder{settings.reminders.length === 1 ? "" : "s"}</Text><Text style={styles.toggleSubtitle}>Orbit keeps these on this device for now.</Text></View><Pressable accessibilityLabel="Clear local reminders" onPress={() => setSettings((current) => ({ ...current, reminders: [] }))}><Icon name="delete-outline" color={COLORS.coral} size={18} /></Pressable></View></>}
          <Text style={styles.settingLabel}>Android setup</Text>
          <Pressable accessibilityLabel="Open Android settings" onPress={() => { haptic.light(); void ExpoLinking.openSettings(); }} style={styles.settingsLink}><Icon name="settings" color={accent} /><View style={styles.reminderCopy}><Text style={styles.toggleTitle}>Choose default Home app</Text><Text style={styles.toggleSubtitle}>Open Android settings to select AI Orbit Launcher.</Text></View><Icon name="chevron-right" color={COLORS.muted} size={18} /></Pressable>
        </ScrollView>
      </ScreenContainer>
    );
  }

  if (view === "drawer") {
    return (
      <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background">
        <StatusBar style="light" />
        <View style={styles.drawerScreen}>
          <View style={styles.drawerHeader}><Pressable accessibilityLabel="Back to home" onPress={() => { setQuery(""); setView("home"); }} style={styles.backButton}><Icon name="arrow-back" color={COLORS.muted} /></Pressable><View><Text style={styles.sectionEyebrow}>YOUR ORBIT</Text><Text style={styles.drawerTitle}>All apps</Text></View><Pressable accessibilityLabel="Open customize" onPress={() => setView("customize")} style={styles.iconButton}><Icon name="tune" color={COLORS.muted} /></Pressable></View>
          <View style={styles.searchBox}><Icon name="search" color={COLORS.muted} size={20} /><TextInput accessibilityLabel="Search apps" value={query} onChangeText={setQuery} autoFocus placeholder="Search apps or actions" placeholderTextColor="#718096" style={styles.searchInput} /></View>
          <FlatList data={filteredApps} keyExtractor={(item) => item.id} contentContainerStyle={styles.appList} ListHeaderComponent={<Text style={styles.listCaption}>{query ? `${filteredApps.length} results` : "RECENTLY IN YOUR ORBIT"}</Text>} renderItem={({ item }) => <Pressable accessibilityLabel={`Open ${item.name}`} onPress={() => openApp(item)} style={({ pressed }) => [styles.appRow, pressed && { opacity: 0.65 }]}><View style={[styles.appIcon, { backgroundColor: `${item.color}20` }]}><Icon name={item.icon} color={item.color} size={22} /></View><View style={styles.appRowCopy}><Text style={styles.appName}>{item.name}</Text><Text style={styles.appMeta}>{item.category} · {item.lastUsed}</Text></View><Icon name="chevron-right" color="#64748B" /></Pressable>} ListEmptyComponent={<View style={styles.emptyState}><Icon name="search-off" color={COLORS.muted} size={32} /><Text style={styles.emptyTitle}>Nothing in orbit yet</Text><Text style={styles.emptyText}>Try another app name or category.</Text></View>} />
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background">
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.homeScreen}>
        <View style={styles.topBar}><View><Text style={styles.dateText}>{new Intl.DateTimeFormat(undefined, { weekday: "long", month: "short", day: "numeric" }).format(new Date()).toUpperCase()}</Text><Text style={styles.greeting}>{settings.greeting || nowGreeting()}</Text></View><Pressable accessibilityLabel="Open customize" onPress={() => { haptic.light(); setView("customize"); }} style={styles.iconButton}><Icon name="tune" color={COLORS.muted} /></Pressable></View>
        <View style={styles.timeBlock}><Text style={styles.time}>{formatTime()}</Text><View style={[styles.timeAccent, { backgroundColor: accent }]} /></View>
        {settings.showAssistant && <Pressable accessibilityLabel="Ask Orbit for help" onPress={() => { haptic.light(); setAssistantOpen(true); }} style={({ pressed }) => [styles.assistantCard, pressed && { opacity: 0.85 }]}><View style={[styles.assistantOrb, { backgroundColor: `${COLORS.violet}22` }]}><Icon name="auto-awesome" color={COLORS.violet} size={20} /></View><View style={styles.assistantCopy}><Text style={styles.cardEyebrow}>ORBIT SUGGESTS</Text><Text style={styles.assistantTitle}>Clear one small space.</Text><Text style={styles.assistantBody}>A 25-minute focus session could make the next thing lighter.</Text></View><Icon name="arrow-forward" color={COLORS.violet} /></Pressable>}
        <View style={styles.sectionHeader}><Text style={styles.sectionEyebrow}>PINNED</Text><Pressable accessibilityLabel="Open all apps" onPress={() => { haptic.light(); setView("drawer"); }}><Text style={[styles.linkText, { color: accent }]}>All apps <Icon name="arrow-forward" color={accent} size={14} /></Text></Pressable></View>
        <FlatList horizontal showsHorizontalScrollIndicator={false} data={pinnedApps} keyExtractor={(item) => item.id} contentContainerStyle={styles.pinnedList} renderItem={({ item }) => <Pressable accessibilityLabel={`Open ${item.name}`} onPress={() => openApp(item)} style={({ pressed }) => [styles.pinnedApp, pressed && { transform: [{ scale: 0.96 }], opacity: 0.7 }]}><View style={[styles.pinnedIcon, { backgroundColor: `${item.color}20` }]}><Icon name={item.icon} color={item.color} size={24} /></View><Text style={styles.pinnedName}>{item.name}</Text></Pressable>} />
        <Pressable accessibilityLabel="Open Orbit assistant" onPress={() => { haptic.light(); setAssistantOpen(true); }} style={styles.askBar}><View style={[styles.askSpark, { backgroundColor: accent }]}><Icon name="auto-awesome" color={COLORS.ink} size={16} /></View><Text style={styles.askText}>Ask Orbit anything…</Text><Icon name="north-east" color={COLORS.muted} size={18} /></Pressable>
        {settings.reminders.length > 0 && <Pressable accessibilityLabel="Open saved reminders" onPress={() => setView("customize")} style={styles.reminderHomeCard}><Icon name="notifications-none" color={COLORS.amber} size={18} /><View style={styles.reminderCopy}><Text style={styles.reminderHomeTitle}>Orbit remembers</Text><Text style={styles.reminderHomeText} numberOfLines={1}>{settings.reminders[settings.reminders.length - 1]}</Text></View><Icon name="chevron-right" color={COLORS.muted} size={18} /></Pressable>}
        <Pressable accessibilityLabel="Start focus mode" onPress={() => { haptic.light(); setFocusSeconds(25 * 60); setFocusRunning(true); setView("focus"); }} style={styles.focusLink}><Icon name="bolt" color={COLORS.amber} size={16} /><Text style={styles.focusLinkText}>Need less noise? Enter focus mode</Text></Pressable>
      </ScrollView>

      <Modal visible={assistantOpen} transparent animationType="slide" onRequestClose={() => setAssistantOpen(false)}><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.modalOverlay}><Pressable style={styles.modalScrim} onPress={() => setAssistantOpen(false)} /><View style={styles.sheet}><View style={styles.sheetHandle} /><View style={styles.sheetHeader}><View><Text style={styles.sectionEyebrow}>ORBIT ASSISTANT</Text><Text style={styles.sheetTitle}>What are you making space for?</Text></View><Pressable accessibilityLabel="Close assistant" onPress={() => setAssistantOpen(false)} style={styles.iconButton}><Icon name="close" color={COLORS.muted} /></Pressable></View><View style={styles.assistantInput}><Icon name="auto-awesome" color={COLORS.violet} size={18} /><TextInput accessibilityLabel="Ask Orbit" value={assistantQuery} onChangeText={(value) => { setAssistantQuery(value); setAssistantResponse(null); setAssistantError(""); }} onSubmitEditing={handleOrbitSubmit} returnKeyType="send" autoFocus placeholder="Try “help me focus”" placeholderTextColor="#718096" style={styles.searchInput} /><Pressable accessibilityLabel={recorderState.isRecording ? "Stop voice command" : "Record voice command"} onPress={handleVoicePress} style={[styles.sendButton, recorderState.isRecording && { backgroundColor: COLORS.coral }]}><Icon name={recorderState.isRecording ? "stop" : "mic-none"} color={COLORS.cloud} size={18} /></Pressable><Pressable accessibilityLabel="Send Orbit request" onPress={handleOrbitSubmit} style={styles.sendButton}><Icon name={assistantLoading ? "hourglass-top" : "arrow-upward"} color={COLORS.cloud} size={18} /></Pressable></View><View style={styles.quickActions}><Text style={styles.listCaption}>QUICK START</Text><View style={styles.quickActionRow}><Pressable onPress={() => { setAssistantQuery("Help me focus"); setAssistantResponse(null); }} style={styles.quickAction}><Icon name="bolt" color={COLORS.amber} size={15} /><Text style={styles.quickActionText}>Focus</Text></Pressable><Pressable onPress={() => { setAssistantQuery("I need to write"); setAssistantResponse(null); }} style={styles.quickAction}><Icon name="edit-note" color={COLORS.mint} size={15} /><Text style={styles.quickActionText}>Write</Text></Pressable><Pressable onPress={() => { setAssistantQuery("Plan tomorrow"); setAssistantResponse(null); }} style={styles.quickAction}><Icon name="calendar-today" color={COLORS.violet} size={15} /><Text style={styles.quickActionText}>Plan</Text></Pressable><Pressable onPress={() => { setAssistantQuery("Search the web for Android launcher ideas"); setAssistantResponse(null); }} style={styles.quickAction}><Icon name="language" color="#8FC7FF" size={15} /><Text style={styles.quickActionText}>Search web</Text></Pressable><Pressable onPress={() => { setAssistantQuery("Remind me to take a break"); setAssistantResponse(null); }} style={styles.quickAction}><Icon name="notifications-none" color={COLORS.amber} size={15} /><Text style={styles.quickActionText}>Reminder</Text></Pressable></View></View>{assistantLoading && <View style={styles.responseState}><Icon name="auto-awesome" color={COLORS.violet} size={17} /><Text style={styles.responseStateText}>Orbit is thinking…</Text></View>}{assistantError && <View style={styles.errorState}><Icon name="cloud-off" color={COLORS.coral} size={17} /><Text style={styles.responseStateText}>{assistantError}</Text></View>}{assistantResponse ? <Pressable onPress={runAssistantResponse} style={({ pressed }) => [styles.suggestionCard, pressed && { opacity: 0.7 }]}><View style={styles.suggestionCopy}><View style={styles.responseBadge}><Text style={styles.responseBadgeText}>{assistantResponse.kind.toUpperCase()}</Text></View><Text style={styles.suggestionTitle}>{assistantResponse.title}</Text><Text style={styles.suggestionBody}>{assistantResponse.body}</Text></View><View style={[styles.suggestionAction, { borderColor: assistantResponse.kind === "focus" ? COLORS.mint : COLORS.violet }]}><Text style={[styles.suggestionActionText, { color: assistantResponse.kind === "focus" ? COLORS.mint : COLORS.violet }]}>{assistantResponse.actionLabel}</Text><Icon name="arrow-forward" color={assistantResponse.kind === "focus" ? COLORS.mint : COLORS.violet} size={16} /></View></Pressable> : <View style={styles.suggestionList}>{assistantCards.map((card) => <Pressable key={card.title} onPress={() => runAssistantCard(card)} style={({ pressed }) => [styles.suggestionCard, pressed && { opacity: 0.7 }]}><View style={styles.suggestionCopy}><Text style={styles.suggestionTitle}>{card.title}</Text><Text style={styles.suggestionBody}>{card.body}</Text></View><View style={[styles.suggestionAction, { borderColor: card.focus ? COLORS.mint : COLORS.violet }]}><Text style={[styles.suggestionActionText, { color: card.focus ? COLORS.mint : COLORS.violet }]}>{card.action}</Text><Icon name="arrow-forward" color={card.focus ? COLORS.mint : COLORS.violet} size={16} /></View></Pressable>)}</View>}</View></KeyboardAvoidingView></Modal>

      <Modal visible={Boolean(selectedApp)} transparent animationType="fade" onRequestClose={() => setSelectedApp(null)}><View style={styles.modalOverlay}><Pressable style={styles.modalScrim} onPress={() => setSelectedApp(null)} /><View style={styles.detailSheet}>{selectedApp && <><View style={[styles.detailIcon, { backgroundColor: `${selectedApp.color}20` }]}><Icon name={selectedApp.icon} color={selectedApp.color} size={30} /></View><Text style={styles.detailTitle}>{selectedApp.name}</Text><Text style={styles.detailMeta}>{selectedApp.category} · {selectedApp.lastUsed}</Text><Text style={styles.detailBody}>This preview routes launcher intent to a local app tile. A production build would hand off to the installed Android package.</Text><View style={styles.detailActions}><Pressable onPress={() => { haptic.light(); setSelectedApp(null); }} style={[styles.primaryButton, { backgroundColor: accent, flex: 1 }]}><Icon name="open-in-new" color={COLORS.ink} size={17} /><Text style={styles.primaryButtonText}>Launch</Text></Pressable><Pressable onPress={() => { togglePinned(selectedApp.id); setSelectedApp(null); }} style={styles.secondaryButton}><Icon name={settings.pinned.includes(selectedApp.id) ? "push-pin" : "add"} color={COLORS.cloud} size={18} /></Pressable></View></>}</View></View></Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  homeScreen: { flexGrow: 1, paddingHorizontal: 24, paddingTop: 18, paddingBottom: 28 },
  topBar: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  dateText: { color: COLORS.muted, fontSize: 11, fontWeight: "700", letterSpacing: 1.4 },
  greeting: { color: COLORS.cloud, fontSize: 18, fontWeight: "600", marginTop: 8 },
  iconButton: { alignItems: "center", justifyContent: "center", width: 42, height: 42, borderRadius: 21, borderWidth: 1, borderColor: COLORS.border },
  timeBlock: { marginTop: 46, alignItems: "flex-start" },
  time: { color: COLORS.cloud, fontSize: 64, lineHeight: 72, fontWeight: "300", letterSpacing: -2 },
  timeAccent: { width: 42, height: 4, borderRadius: 4, marginTop: 12 },
  assistantCard: { flexDirection: "row", alignItems: "center", gap: 14, backgroundColor: COLORS.slate, borderColor: COLORS.border, borderWidth: 1, borderRadius: 20, padding: 16, marginTop: 32 },
  assistantOrb: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  assistantCopy: { flex: 1 },
  cardEyebrow: { color: COLORS.violet, fontSize: 10, fontWeight: "800", letterSpacing: 1.3 },
  assistantTitle: { color: COLORS.cloud, fontSize: 16, fontWeight: "700", marginTop: 4 },
  assistantBody: { color: COLORS.muted, fontSize: 13, lineHeight: 19, marginTop: 3 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 36, marginBottom: 15 },
  sectionEyebrow: { color: COLORS.muted, fontSize: 10, fontWeight: "800", letterSpacing: 1.5 },
  linkText: { fontSize: 12, fontWeight: "700" },
  pinnedList: { gap: 14, paddingBottom: 3 },
  pinnedApp: { alignItems: "center", width: 70 },
  pinnedIcon: { width: 58, height: 58, borderRadius: 18, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: COLORS.border },
  pinnedName: { color: COLORS.muted, fontSize: 12, marginTop: 8 },
  askBar: { flexDirection: "row", alignItems: "center", gap: 11, backgroundColor: COLORS.slate, borderColor: COLORS.border, borderWidth: 1, borderRadius: 18, paddingHorizontal: 13, height: 54, marginTop: 33 },
  askSpark: { width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  askText: { color: COLORS.muted, fontSize: 14, flex: 1 },
  focusLink: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 24 },
  focusLinkText: { color: COLORS.muted, fontSize: 12 },
  drawerScreen: { flex: 1, paddingHorizontal: 24, paddingTop: 18 },
  drawerHeader: { flexDirection: "row", alignItems: "center", gap: 14, marginBottom: 22 },
  drawerTitle: { color: COLORS.cloud, fontSize: 26, fontWeight: "700", marginTop: 5 },
  searchBox: { height: 54, backgroundColor: COLORS.slate, borderRadius: 18, borderWidth: 1, borderColor: COLORS.border, flexDirection: "row", alignItems: "center", paddingHorizontal: 15, gap: 10 },
  searchInput: { color: COLORS.cloud, flex: 1, fontSize: 15, paddingVertical: 0 },
  appList: { paddingTop: 25, paddingBottom: 40 },
  listCaption: { color: COLORS.muted, fontSize: 10, fontWeight: "800", letterSpacing: 1.4, marginBottom: 8 },
  appRow: { flexDirection: "row", alignItems: "center", gap: 14, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: `${COLORS.border}88` },
  appIcon: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  appRowCopy: { flex: 1 },
  appName: { color: COLORS.cloud, fontSize: 16, fontWeight: "600" },
  appMeta: { color: COLORS.muted, fontSize: 12, marginTop: 4 },
  emptyState: { alignItems: "center", paddingTop: 70 },
  emptyTitle: { color: COLORS.cloud, fontWeight: "700", fontSize: 16, marginTop: 14 },
  emptyText: { color: COLORS.muted, fontSize: 13, marginTop: 6 },
  backButton: { width: 42, height: 42, alignItems: "center", justifyContent: "center", borderRadius: 21, borderWidth: 1, borderColor: COLORS.border },
  customizeScreen: { paddingHorizontal: 24, paddingTop: 18, paddingBottom: 45 },
  pageTitle: { color: COLORS.cloud, fontSize: 32, fontWeight: "700", marginTop: 10 },
  pageSubtitle: { color: COLORS.muted, fontSize: 15, marginTop: 7, marginBottom: 34 },
  settingLabel: { color: COLORS.cloud, fontSize: 15, fontWeight: "700", marginTop: 22, marginBottom: 12 },
  settingHint: { color: COLORS.muted, fontSize: 12, lineHeight: 18, marginTop: -4, marginBottom: 12 },
  choiceRow: { flexDirection: "row", gap: 10 },
  choice: { flex: 1, flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 15, borderWidth: 1, borderColor: COLORS.border, padding: 12 },
  choiceDot: { width: 12, height: 12, borderRadius: 6 },
  choiceText: { color: COLORS.muted, fontSize: 12, textTransform: "capitalize" },
  appChoiceGrid: { gap: 9 },
  appChoice: { flexDirection: "row", alignItems: "center", gap: 11, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, paddingHorizontal: 13, paddingVertical: 12 },
  appChoiceText: { color: COLORS.cloud, flex: 1, fontSize: 14 },
  toggleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderWidth: 1, borderColor: COLORS.border, borderRadius: 16, padding: 14 },
  toggleTitle: { color: COLORS.cloud, fontWeight: "600", fontSize: 14 },
  toggleSubtitle: { color: COLORS.muted, fontSize: 12, marginTop: 4 },
  toggle: { width: 46, height: 27, borderRadius: 14, backgroundColor: COLORS.border, padding: 3 },
  toggleKnob: { width: 21, height: 21, borderRadius: 11, backgroundColor: COLORS.cloud },
  reminderCard: { flexDirection: "row", alignItems: "center", gap: 11, borderWidth: 1, borderColor: COLORS.border, borderRadius: 16, padding: 14 },
  reminderCopy: { flex: 1 },
  reminderHomeCard: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderColor: COLORS.border, borderRadius: 16, padding: 13, marginTop: 12 },
  reminderHomeTitle: { color: COLORS.amber, fontSize: 11, fontWeight: "800", letterSpacing: 0.8 },
  reminderHomeText: { color: COLORS.cloud, fontSize: 13, marginTop: 3 },
  settingsLink: { flexDirection: "row", alignItems: "center", gap: 11, borderWidth: 1, borderColor: COLORS.border, borderRadius: 16, padding: 14 },
  focusScreen: { flex: 1, padding: 24, justifyContent: "space-between" },
  focusCenter: { alignItems: "center", marginTop: -35 },
  orbit: { width: 106, height: 106, borderRadius: 53, borderWidth: 1, alignItems: "center", justifyContent: "center", transform: [{ rotate: "-18deg" }] },
  orbitDot: { width: 12, height: 12, borderRadius: 6, position: "absolute", top: -6, right: 12 },
  focusEyebrow: { color: COLORS.muted, fontWeight: "800", fontSize: 10, letterSpacing: 2, marginTop: 28 },
  focusTitle: { color: COLORS.cloud, fontWeight: "700", fontSize: 24, marginTop: 10 },
  focusTimer: { color: COLORS.cloud, fontSize: 72, fontWeight: "300", letterSpacing: -2, marginTop: 28 },
  focusHint: { color: COLORS.muted, fontSize: 14, textAlign: "center", lineHeight: 21, maxWidth: 250, marginTop: 12 },
  primaryButton: { minHeight: 52, borderRadius: 18, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, paddingHorizontal: 18 },
  primaryButtonText: { color: COLORS.ink, fontSize: 14, fontWeight: "800" },
  modalOverlay: { flex: 1, justifyContent: "flex-end" },
  modalScrim: { ...StyleSheet.absoluteFillObject, backgroundColor: "#00000099" },
  sheet: { backgroundColor: COLORS.ink, borderTopLeftRadius: 28, borderTopRightRadius: 28, borderWidth: 1, borderColor: COLORS.border, padding: 22, paddingBottom: 34 },
  sheetHandle: { width: 42, height: 4, borderRadius: 3, backgroundColor: "#526174", alignSelf: "center", marginBottom: 23 },
  sheetHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 16 },
  sheetTitle: { color: COLORS.cloud, fontSize: 23, fontWeight: "700", marginTop: 8, maxWidth: 280 },
  assistantInput: { flexDirection: "row", alignItems: "center", gap: 10, height: 54, paddingHorizontal: 14, borderRadius: 17, backgroundColor: COLORS.slate, borderWidth: 1, borderColor: COLORS.border, marginTop: 22 },
  sendButton: { width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.border },
  quickActions: { marginTop: 18 },
  quickActionRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 9 },
  quickAction: { flexDirection: "row", alignItems: "center", gap: 5, borderWidth: 1, borderColor: COLORS.border, borderRadius: 13, paddingHorizontal: 10, paddingVertical: 8 },
  quickActionText: { color: COLORS.muted, fontSize: 12, fontWeight: "600" },
  responseState: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 18, padding: 12, borderRadius: 14, backgroundColor: "#1B2130" },
  errorState: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 18, padding: 12, borderRadius: 14, backgroundColor: "#2D2025" },
  responseStateText: { color: COLORS.muted, fontSize: 13, flex: 1 },
  responseBadge: { alignSelf: "flex-start", borderRadius: 7, paddingHorizontal: 7, paddingVertical: 4, backgroundColor: "#242B3B", marginBottom: 8 },
  responseBadgeText: { color: COLORS.violet, fontSize: 9, fontWeight: "800", letterSpacing: 1.1 },
  suggestionList: { gap: 10, marginTop: 18 },
  suggestionCard: { borderWidth: 1, borderColor: COLORS.border, borderRadius: 17, padding: 14, gap: 14 },
  suggestionCopy: { gap: 5 },
  suggestionTitle: { color: COLORS.cloud, fontSize: 15, fontWeight: "700" },
  suggestionBody: { color: COLORS.muted, fontSize: 13, lineHeight: 18 },
  suggestionAction: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8 },
  suggestionActionText: { fontSize: 12, fontWeight: "700" },
  detailSheet: { backgroundColor: COLORS.ink, borderRadius: 24, borderWidth: 1, borderColor: COLORS.border, padding: 24, marginHorizontal: 24, marginBottom: 24 },
  detailIcon: { width: 62, height: 62, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  detailTitle: { color: COLORS.cloud, fontSize: 25, fontWeight: "700", marginTop: 18 },
  detailMeta: { color: COLORS.muted, fontSize: 13, marginTop: 5 },
  detailBody: { color: COLORS.muted, fontSize: 14, lineHeight: 21, marginTop: 22 },
  detailActions: { flexDirection: "row", gap: 10, marginTop: 24 },
  secondaryButton: { width: 52, height: 52, borderRadius: 17, borderWidth: 1, borderColor: COLORS.border, alignItems: "center", justifyContent: "center" },
  onboardingScreen: { flex: 1, padding: 24, justifyContent: "flex-end", paddingBottom: 30 },
  onboardingOrb: { width: 128, height: 128, borderRadius: 64, borderWidth: 1, alignSelf: "center", alignItems: "center", justifyContent: "center", marginBottom: 34 },
  onboardingOrbCore: { width: 58, height: 58, borderRadius: 29 },
  onboardingOrbSpark: { width: 14, height: 14, borderRadius: 7, position: "absolute", top: 4, right: 14 },
  onboardingEyebrow: { color: COLORS.mint, fontSize: 10, fontWeight: "800", letterSpacing: 1.8, textAlign: "center" },
  onboardingTitle: { color: COLORS.cloud, fontSize: 32, lineHeight: 38, fontWeight: "700", textAlign: "center", marginTop: 11 },
  onboardingBody: { color: COLORS.muted, fontSize: 15, lineHeight: 22, textAlign: "center", marginTop: 12 },
  onboardingList: { gap: 15, marginTop: 28, marginBottom: 28 },
  onboardingRow: { flexDirection: "row", alignItems: "center", gap: 14, borderTopWidth: 1, borderTopColor: COLORS.border, paddingTop: 13 },
  onboardingRowTitle: { color: COLORS.cloud, fontSize: 14, fontWeight: "700" },
  onboardingRowBody: { color: COLORS.muted, fontSize: 12, lineHeight: 17, marginTop: 3 },
  onboardingFootnote: { color: "#718096", fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: 14 },
});
