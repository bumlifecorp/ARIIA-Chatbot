/** @type {const} */
const themeColors = {
  primary: { light: '#2D7A67', dark: '#7CE7C4' },
  background: { light: '#F7FAFC', dark: '#0B0F14' },
  surface: { light: '#FFFFFF', dark: '#151C24' },
  foreground: { light: '#12202A', dark: '#F4F7FB' },
  muted: { light: '#617180', dark: '#B6C1CE' },
  border: { light: '#DCE5EA', dark: '#263241' },
  success: { light: '#2D7A67', dark: '#7CE7C4' },
  warning: { light: '#A06C15', dark: '#F6C56F' },
  error: { light: '#B54949', dark: '#FF8B8B' },
};

module.exports = { themeColors };
