---
name: decision-making
description: Structured procedure for weighing options against criteria, building options × criteria comparison matrices, recommending with criteria-tied reasoning, and highlighting trade-offs.
---

# Decision Making Skill

The **Structured Decision Making Engine** is automatically invoked whenever a user asks to weigh options against criteria ("which should I pick", "decide between X and Y", "help me choose").

## Mandatory Procedure
1. **Options × Criteria Matrix**:
   - Construct a clear, structured table evaluating candidate options against defined criteria.
   - Assign quantitative or qualitative scores (e.g., 1-10 or High/Med/Low) per criterion.

2. **Reasoned Recommendation**:
   - Provide a explicit recommendation directly tied to the user's weighted criteria.

3. **Trade-off Identification**:
   - Clearly flag key trade-offs, potential risks, and marginal differences between top options.

## Usage in Android App
- Powers `DecisionMatrixScreen.kt` and `VoiceActionExecutor` decision query parser.
