---
name: cognitive-learning
description: Learning semantic engine that understands context, retains cross-session memory, refines rules, and processes semantic meaning and perception. Use when managing user memory, cross-session intent, adaptive rule refinement, or semantic context.
---

# Cognitive Learning Skill

The **Cognitive Learning Engine** provides persistent, cross-session semantic intelligence for the ARIIA AI Assistant. It enables the agent to learn from user preferences, retain long-term goals, process multi-modal perception, and dynamically refine system rules over time.

## Core Capabilities
1. **Semantic Memory Retention**:
   - Store and index key-value preferences, facts, and intent markers across conversation sessions.
   - Automatically retrieve relevant contextual memories during inference to personalize responses.

2. **Perception & Intent Deconstruction**:
   - Extract underlying semantic goals from raw instructions or sensor/vision inputs.
   - Disambiguate multi-part or implicit queries using historical interaction graphs.

3. **Adaptive Rule Refinement**:
   - Monitor user feedback and correction patterns.
   - Dynamically suggest or update active operational rules in `AGENTS.md` and runtime state.

4. **Continuous Skill Acquisition**:
   - Learn procedural user workflows and store them as dynamic action protocols.

## Usage in Android App
- Integrates with `CognitiveLearningScreen.kt` and `MainViewModel` memory repository.
- Exposes `injectMemory()`, `getSemanticContext()`, and `refineSystemRules()` interfaces.
